/*
 * Oracle 19c Exadata Compression Audit Utility
 * Improved Package Body: PKG_COMPRESSION_AUDIT (Simplified Cursor Logic)
 * 
 * Description:
 *   Production-ready implementation with simplified cursor handling.
 *   Uses SAMPLE clause and ROWID ordering for efficient sampling.
 * 
 * Key Improvements:
 *   - Uses SAMPLE clause for efficient random sampling
 *   - Simplified ROWID-based iteration
 *   - Better error handling and logging
 *   - Configurable sample size per object
 */

CREATE OR REPLACE PACKAGE BODY PKG_COMPRESSION_AUDIT AS

  PROCEDURE execute_compression_audit (
    p_config_id     IN NUMBER DEFAULT NULL,
    p_audit_run_id  OUT NUMBER
  )
  IS
    l_run_id              NUMBER;
    l_config_id           NUMBER;
    l_schema_name         VARCHAR2(128);
    l_sample_size         NUMBER;
    l_table_count         NUMBER := 0;
    l_partition_count     NUMBER := 0;
    l_subpartition_count  NUMBER := 0;
    l_row_count           NUMBER := 0;
    l_rows_sampled        NUMBER := 0;
    l_metadata_only_count NUMBER := 0;
    l_start_time          TIMESTAMP;
    l_end_time            TIMESTAMP;
    l_error_msg           VARCHAR2(1000);
    
    CURSOR cur_nonpartitioned_tables(p_owner VARCHAR2) IS
      SELECT table_name, compress, compression
      FROM DBA_TABLES
      WHERE owner = p_owner
        AND (compress = 'Y' OR compression NOT IN ('NONE', 'NO', null))
      ORDER BY table_name;
    
    CURSOR cur_table_partitions(p_owner VARCHAR2) IS
      SELECT DISTINCT table_name, partition_name, compression
      FROM DBA_TAB_PARTITIONS
      WHERE table_owner = p_owner
        AND (compress = 'Y' OR compression NOT IN ('NONE', 'NO', null))
      ORDER BY table_name, partition_name;
    
    CURSOR cur_table_subpartitions(p_owner VARCHAR2) IS
      SELECT DISTINCT table_name, subpartition_name, compression
      FROM DBA_TAB_SUBPARTITIONS
      WHERE table_owner = p_owner
        AND (compress = 'Y' OR compression NOT IN ('NONE', 'NO', null))
      ORDER BY table_name, subpartition_name;
  
  BEGIN
    l_start_time := SYSTIMESTAMP;
    l_run_id := SEQ_COMPRESSION_AUDIT_RUN.NEXTVAL;
    p_audit_run_id := l_run_id;
    
    INSERT INTO COMPRESSION_AUDIT_RUN_LOG 
      (audit_run_id, config_id, schema_name, start_time, status)
    VALUES (l_run_id, p_config_id, NULL, l_start_time, 'RUNNING');
    COMMIT;
    
    BEGIN
      -- Get configuration
      IF p_config_id IS NOT NULL THEN
        SELECT config_id, schema_name, sample_size_per_obj
        INTO l_config_id, l_schema_name, l_sample_size
        FROM COMPRESSION_AUDIT_CONFIG
        WHERE config_id = p_config_id AND is_active = 'Y';
      ELSE
        SELECT config_id, schema_name, sample_size_per_obj
        INTO l_config_id, l_schema_name, l_sample_size
        FROM COMPRESSION_AUDIT_CONFIG
        WHERE is_active = 'Y'
        AND ROWNUM = 1;
      END IF;
      
      UPDATE COMPRESSION_AUDIT_RUN_LOG
      SET config_id = l_config_id, schema_name = l_schema_name
      WHERE audit_run_id = l_run_id;
      
      -- Process nonpartitioned tables
      FOR rec_table IN cur_nonpartitioned_tables(l_schema_name) LOOP
        l_table_count := l_table_count + 1;
        l_row_count := sample_table_rows(
          l_schema_name, rec_table.table_name, l_sample_size, l_run_id
        );
        l_rows_sampled := l_rows_sampled + l_row_count;
      END LOOP;
      
      -- Process partitions
      FOR rec_partition IN cur_table_partitions(l_schema_name) LOOP
        l_partition_count := l_partition_count + 1;
        l_row_count := sample_partition_rows(
          l_schema_name, rec_partition.table_name, 
          rec_partition.partition_name, l_sample_size, l_run_id
        );
        l_rows_sampled := l_rows_sampled + l_row_count;
      END LOOP;
      
      -- Process subpartitions
      FOR rec_subpartition IN cur_table_subpartitions(l_schema_name) LOOP
        l_subpartition_count := l_subpartition_count + 1;
        l_row_count := sample_subpartition_rows(
          l_schema_name, rec_subpartition.table_name, 
          rec_subpartition.subpartition_name, l_sample_size, l_run_id
        );
        l_rows_sampled := l_rows_sampled + l_row_count;
      END LOOP;
      
      -- Count mismatches
      SELECT COUNT(*)
      INTO l_metadata_only_count
      FROM COMPRESSION_AUDIT_RESULTS
      WHERE audit_run_id = l_run_id AND is_physically_compressed = 'N';
      
      l_end_time := SYSTIMESTAMP;
      
      UPDATE COMPRESSION_AUDIT_RUN_LOG
      SET end_time = l_end_time,
          total_objects_checked = l_table_count + l_partition_count + l_subpartition_count,
          total_rows_sampled = l_rows_sampled,
          rows_metadata_compressed_no_physical = l_metadata_only_count,
          status = 'COMPLETED'
      WHERE audit_run_id = l_run_id;
      
      COMMIT;
      
      DBMS_OUTPUT.PUT_LINE('============================================');
      DBMS_OUTPUT.PUT_LINE('Compression Audit Complete');
      DBMS_OUTPUT.PUT_LINE('Run ID: ' || l_run_id);
      DBMS_OUTPUT.PUT_LINE('Schema: ' || l_schema_name);
      DBMS_OUTPUT.PUT_LINE('Tables: ' || l_table_count);
      DBMS_OUTPUT.PUT_LINE('Partitions: ' || l_partition_count);
      DBMS_OUTPUT.PUT_LINE('Subpartitions: ' || l_subpartition_count);
      DBMS_OUTPUT.PUT_LINE('Rows sampled: ' || l_rows_sampled);
      DBMS_OUTPUT.PUT_LINE('Metadata-only: ' || l_metadata_only_count);
      DBMS_OUTPUT.PUT_LINE('============================================');
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_error_msg := 'No active configuration found';
        UPDATE COMPRESSION_AUDIT_RUN_LOG
        SET status = 'FAILED', error_message = l_error_msg, end_time = SYSTIMESTAMP
        WHERE audit_run_id = l_run_id;
        COMMIT;
        RAISE;
      WHEN OTHERS THEN
        l_error_msg := SUBSTR(SQLERRM, 1, 1000);
        UPDATE COMPRESSION_AUDIT_RUN_LOG
        SET status = 'FAILED', error_message = l_error_msg, end_time = SYSTIMESTAMP
        WHERE audit_run_id = l_run_id;
        COMMIT;
        RAISE;
    END;
  
  END execute_compression_audit;

  FUNCTION get_compressed_tables (p_schema_name IN VARCHAR2)
  RETURN SYS_REFCURSOR
  IS
    l_cursor SYS_REFCURSOR;
  BEGIN
    OPEN l_cursor FOR
      SELECT table_name, compress, compression, num_rows, blocks
      FROM DBA_TABLES
      WHERE owner = UPPER(p_schema_name)
        AND (compress = 'Y' OR compression NOT IN ('NONE', 'NO'))
      ORDER BY table_name;
    RETURN l_cursor;
  END get_compressed_tables;

  FUNCTION get_compressed_table_partitions (p_schema_name IN VARCHAR2)
  RETURN SYS_REFCURSOR
  IS
    l_cursor SYS_REFCURSOR;
  BEGIN
    OPEN l_cursor FOR
      SELECT table_name, partition_name, compression, compress, num_rows
      FROM DBA_TAB_PARTITIONS
      WHERE table_owner = UPPER(p_schema_name)
        AND (compress = 'Y' OR compression NOT IN ('NONE', 'NO'))
      ORDER BY table_name, partition_name;
    RETURN l_cursor;
  END get_compressed_table_partitions;

  FUNCTION get_compressed_table_subpartitions (p_schema_name IN VARCHAR2)
  RETURN SYS_REFCURSOR
  IS
    l_cursor SYS_REFCURSOR;
  BEGIN
    OPEN l_cursor FOR
      SELECT table_name, subpartition_name, compression, compress, num_rows
      FROM DBA_TAB_SUBPARTITIONS
      WHERE table_owner = UPPER(p_schema_name)
        AND (compress = 'Y' OR compression NOT IN ('NONE', 'NO'))
      ORDER BY table_name, subpartition_name;
    RETURN l_cursor;
  END get_compressed_table_subpartitions;

  FUNCTION get_row_compression_type (
    p_schema_name IN VARCHAR2,
    p_table_name  IN VARCHAR2,
    p_rowid       IN ROWID
  )
  RETURN VARCHAR2
  IS
    l_compression_type VARCHAR2(50);
    l_blknum           NUMBER;
  BEGIN
    l_blknum := DBMS_ROWID.ROWID_BLOCK_NUMBER(p_rowid);
    
    DBMS_COMPRESSION.GET_COMPRESSION_TYPE(
      ownname      => UPPER(p_schema_name),
      tabname      => UPPER(p_table_name),
      partname     => NULL,
      blknum       => l_blknum,
      comptype     => l_compression_type
    );
    
    RETURN NVL(l_compression_type, 'COMP_NOCOMPRESS');
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 'COMP_NOCOMPRESS';
  END get_row_compression_type;

  FUNCTION is_physically_compressed (p_compression_type IN VARCHAR2)
  RETURN CHAR
  IS
  BEGIN
    RETURN CASE 
             WHEN p_compression_type IN ('COMP_NOCOMPRESS', 'COMP_NONE') THEN 'N'
             ELSE 'Y'
           END;
  END is_physically_compressed;

  FUNCTION sample_table_rows (
    p_schema_name   IN VARCHAR2,
    p_table_name    IN VARCHAR2,
    p_sample_size   IN NUMBER,
    p_audit_run_id  IN NUMBER
  )
  RETURN NUMBER
  IS
    l_rows_sampled     NUMBER := 0;
    l_compression_type VARCHAR2(50);
    l_is_compressed    CHAR(1);
    l_sample_percent   NUMBER;
    l_sql              VARCHAR2(2000);
    l_cursor           SYS_REFCURSOR;
    l_rid              ROWID;
  
  BEGIN
    -- Calculate sample percentage based on table size
    BEGIN
      IF p_sample_size = 0 THEN
        l_sample_percent := 100;
      ELSE
        -- Estimate sample percentage; default to 1% if too small
        l_sample_percent := GREATEST(
          LEAST(100, ROUND(100.0 * p_sample_size / 10000, 2)),
          0.01
        );
      END IF;
      
      -- Build dynamic query with SAMPLE clause
      l_sql := 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
               UPPER(p_table_name) || ' SAMPLE (' || l_sample_percent || ') ' ||
               'WHERE ROWNUM <= ' || p_sample_size;
      
      OPEN l_cursor FOR l_sql;
      
      LOOP
        FETCH l_cursor INTO l_rid;
        EXIT WHEN l_cursor%NOTFOUND;
        
        -- Get compression type
        l_compression_type := get_row_compression_type(
          p_schema_name, p_table_name, l_rid
        );
        
        l_is_compressed := is_physically_compressed(l_compression_type);
        
        INSERT INTO COMPRESSION_AUDIT_RESULTS (
          result_id, schema_name, object_name, object_type,
          sampled_rowid, compression_type, is_physically_compressed,
          scan_timestamp, audit_run_id
        ) VALUES (
          SEQ_COMPRESSION_AUDIT_RESULTS.NEXTVAL,
          UPPER(p_schema_name), UPPER(p_table_name), 'TABLE',
          l_rid, l_compression_type, l_is_compressed,
          SYSTIMESTAMP, p_audit_run_id
        );
        
        l_rows_sampled := l_rows_sampled + 1;
        
        IF MOD(l_rows_sampled, 100) = 0 THEN
          COMMIT;
        END IF;
      
      END LOOP;
      
      CLOSE l_cursor;
      COMMIT;
    
    EXCEPTION
      WHEN OTHERS THEN
        IF l_cursor%ISOPEN THEN
          CLOSE l_cursor;
        END IF;
        DBMS_OUTPUT.PUT_LINE('Error sampling ' || p_table_name || ': ' || SQLERRM);
    END;
    
    RETURN l_rows_sampled;
  
  END sample_table_rows;

  FUNCTION sample_partition_rows (
    p_schema_name     IN VARCHAR2,
    p_table_name      IN VARCHAR2,
    p_partition_name  IN VARCHAR2,
    p_sample_size     IN NUMBER,
    p_audit_run_id    IN NUMBER
  )
  RETURN NUMBER
  IS
    l_rows_sampled     NUMBER := 0;
    l_compression_type VARCHAR2(50);
    l_is_compressed    CHAR(1);
    l_sample_percent   NUMBER;
    l_sql              VARCHAR2(2000);
    l_cursor           SYS_REFCURSOR;
    l_rid              ROWID;
  
  BEGIN
    BEGIN
      IF p_sample_size = 0 THEN
        l_sample_percent := 100;
      ELSE
        l_sample_percent := GREATEST(
          LEAST(100, ROUND(100.0 * p_sample_size / 10000, 2)),
          0.01
        );
      END IF;
      
      l_sql := 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
               UPPER(p_table_name) || ' PARTITION (' || UPPER(p_partition_name) || ') ' ||
               'SAMPLE (' || l_sample_percent || ') WHERE ROWNUM <= ' || p_sample_size;
      
      OPEN l_cursor FOR l_sql;
      
      LOOP
        FETCH l_cursor INTO l_rid;
        EXIT WHEN l_cursor%NOTFOUND;
        
        l_compression_type := get_row_compression_type(
          p_schema_name, p_table_name, l_rid
        );
        
        l_is_compressed := is_physically_compressed(l_compression_type);
        
        INSERT INTO COMPRESSION_AUDIT_RESULTS (
          result_id, schema_name, object_name, partition_name, object_type,
          sampled_rowid, compression_type, is_physically_compressed,
          scan_timestamp, audit_run_id
        ) VALUES (
          SEQ_COMPRESSION_AUDIT_RESULTS.NEXTVAL,
          UPPER(p_schema_name), UPPER(p_table_name), UPPER(p_partition_name), 'PARTITION',
          l_rid, l_compression_type, l_is_compressed,
          SYSTIMESTAMP, p_audit_run_id
        );
        
        l_rows_sampled := l_rows_sampled + 1;
        
        IF MOD(l_rows_sampled, 100) = 0 THEN
          COMMIT;
        END IF;
      
      END LOOP;
      
      CLOSE l_cursor;
      COMMIT;
    
    EXCEPTION
      WHEN OTHERS THEN
        IF l_cursor%ISOPEN THEN
          CLOSE l_cursor;
        END IF;
        DBMS_OUTPUT.PUT_LINE('Error sampling partition ' || p_partition_name || ': ' || SQLERRM);
    END;
    
    RETURN l_rows_sampled;
  
  END sample_partition_rows;

  FUNCTION sample_subpartition_rows (
    p_schema_name       IN VARCHAR2,
    p_table_name        IN VARCHAR2,
    p_subpartition_name IN VARCHAR2,
    p_sample_size       IN NUMBER,
    p_audit_run_id      IN NUMBER
  )
  RETURN NUMBER
  IS
    l_rows_sampled     NUMBER := 0;
    l_compression_type VARCHAR2(50);
    l_is_compressed    CHAR(1);
    l_sample_percent   NUMBER;
    l_sql              VARCHAR2(2000);
    l_cursor           SYS_REFCURSOR;
    l_rid              ROWID;
  
  BEGIN
    BEGIN
      IF p_sample_size = 0 THEN
        l_sample_percent := 100;
      ELSE
        l_sample_percent := GREATEST(
          LEAST(100, ROUND(100.0 * p_sample_size / 10000, 2)),
          0.01
        );
      END IF;
      
      l_sql := 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
               UPPER(p_table_name) || ' SUBPARTITION (' || UPPER(p_subpartition_name) || ') ' ||
               'SAMPLE (' || l_sample_percent || ') WHERE ROWNUM <= ' || p_sample_size;
      
      OPEN l_cursor FOR l_sql;
      
      LOOP
        FETCH l_cursor INTO l_rid;
        EXIT WHEN l_cursor%NOTFOUND;
        
        l_compression_type := get_row_compression_type(
          p_schema_name, p_table_name, l_rid
        );
        
        l_is_compressed := is_physically_compressed(l_compression_type);
        
        INSERT INTO COMPRESSION_AUDIT_RESULTS (
          result_id, schema_name, object_name, subpartition_name, object_type,
          sampled_rowid, compression_type, is_physically_compressed,
          scan_timestamp, audit_run_id
        ) VALUES (
          SEQ_COMPRESSION_AUDIT_RESULTS.NEXTVAL,
          UPPER(p_schema_name), UPPER(p_table_name), UPPER(p_subpartition_name), 'SUBPARTITION',
          l_rid, l_compression_type, l_is_compressed,
          SYSTIMESTAMP, p_audit_run_id
        );
        
        l_rows_sampled := l_rows_sampled + 1;
        
        IF MOD(l_rows_sampled, 100) = 0 THEN
          COMMIT;
        END IF;
      
      END LOOP;
      
      CLOSE l_cursor;
      COMMIT;
    
    EXCEPTION
      WHEN OTHERS THEN
        IF l_cursor%ISOPEN THEN
          CLOSE l_cursor;
        END IF;
        DBMS_OUTPUT.PUT_LINE('Error sampling subpartition ' || p_subpartition_name || ': ' || SQLERRM);
    END;
    
    RETURN l_rows_sampled;
  
  END sample_subpartition_rows;

  FUNCTION get_audit_summary (p_audit_run_id IN NUMBER)
  RETURN SYS_REFCURSOR
  IS
    l_cursor SYS_REFCURSOR;
  BEGIN
    OPEN l_cursor FOR
      SELECT 
        schema_name,
        object_name,
        NVL(partition_name, NVL(subpartition_name, 'N/A')) partition_info,
        object_type,
        COUNT(*) total_rows_sampled,
        SUM(CASE WHEN is_physically_compressed = 'Y' THEN 1 ELSE 0 END) physically_compressed_count,
        SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) metadata_only_count,
        ROUND(100.0 * SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) / 
              COUNT(*), 2) pct_metadata_only
      FROM COMPRESSION_AUDIT_RESULTS
      WHERE audit_run_id = p_audit_run_id
      GROUP BY schema_name, object_name, partition_name, subpartition_name, object_type
      ORDER BY schema_name, object_name, partition_info;
    
    RETURN l_cursor;
  END get_audit_summary;

END PKG_COMPRESSION_AUDIT;
/

SHOW ERRORS

PROMPT
PROMPT ============================================================================
PROMPT Improved package body installed: PKG_COMPRESSION_AUDIT
PROMPT ============================================================================

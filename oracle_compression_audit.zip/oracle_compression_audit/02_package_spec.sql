/*
 * Oracle 19c Exadata Compression Audit Utility
 * Package Specification: PKG_COMPRESSION_AUDIT
 * 
 * Description:
 *   Public API for the compression audit utility. Provides procedures for:
 *   - Discovering objects with metadata compression enabled
 *   - Sampling rows and checking actual compression state
 *   - Recording findings in COMPRESSION_AUDIT_RESULTS
 * 
 * Usage:
 *   sqlplus / as sysdba @02_package_spec.sql
 */

CREATE OR REPLACE PACKAGE PKG_COMPRESSION_AUDIT AS

  /**
   * Main entry point: Execute compression audit for all active configs
   * 
   * Parameters:
   *   p_config_id (optional): If provided, audit only this config; else all active
   *   p_audit_run_id (out): Correlates all findings from this run
   * 
   * Returns:
   *   PL/SQL table with summary statistics
   * 
   * Side Effects:
   *   - Inserts rows into COMPRESSION_AUDIT_RESULTS
   *   - Updates COMPRESSION_AUDIT_RUN_LOG
   *   - Read-only: No DML on application tables
   */
  PROCEDURE execute_compression_audit (
    p_config_id     IN NUMBER DEFAULT NULL,
    p_audit_run_id  OUT NUMBER
  );

  /**
   * Discover all nonpartitioned tables with compression enabled
   * 
   * Parameters:
   *   p_schema_name: Target schema
   * 
   * Returns:
   *   Ref cursor with columns: table_name, compress
   * 
   * Note:
   *   Query sourced from DBA_TABLES where owner = p_schema_name
   *   and compress = 'Y' or compression != 'NONE'
   */
  FUNCTION get_compressed_tables (
    p_schema_name IN VARCHAR2
  )
  RETURN SYS_REFCURSOR;

  /**
   * Discover all partitioned tables with compression enabled
   * 
   * Parameters:
   *   p_schema_name: Target schema
   * 
   * Returns:
   *   Ref cursor with columns: table_name, partition_name, compression, compress
   * 
   * Note:
   *   Query sourced from DBA_TAB_PARTITIONS where table_owner = p_schema_name
   */
  FUNCTION get_compressed_table_partitions (
    p_schema_name IN VARCHAR2
  )
  RETURN SYS_REFCURSOR;

  /**
   * Discover all subpartitioned tables with compression enabled
   * 
   * Parameters:
   *   p_schema_name: Target schema
   * 
   * Returns:
   *   Ref cursor with columns: table_name, subpartition_name, compression, compress
   * 
   * Note:
   *   Query sourced from DBA_TAB_SUBPARTITIONS where table_owner = p_schema_name
   */
  FUNCTION get_compressed_table_subpartitions (
    p_schema_name IN VARCHAR2
  )
  RETURN SYS_REFCURSOR;

  /**
   * Sample rows from a nonpartitioned table and check compression
   * 
   * Parameters:
   *   p_schema_name: Owner of table
   *   p_table_name: Table to audit
   *   p_sample_size: Number of rows to sample (0 = all)
   *   p_audit_run_id: Correlates results
   * 
   * Returns:
   *   Number of rows sampled
   * 
   * Read-Only: Uses DBMS_COMPRESSION.GET_COMPRESSION_TYPE
   */
  FUNCTION sample_table_rows (
    p_schema_name   IN VARCHAR2,
    p_table_name    IN VARCHAR2,
    p_sample_size   IN NUMBER,
    p_audit_run_id  IN NUMBER
  )
  RETURN NUMBER;

  /**
   * Sample rows from a table partition and check compression
   * 
   * Parameters:
   *   p_schema_name: Owner of table
   *   p_table_name: Table to audit
   *   p_partition_name: Partition to audit
   *   p_sample_size: Number of rows to sample
   *   p_audit_run_id: Correlates results
   * 
   * Returns:
   *   Number of rows sampled
   */
  FUNCTION sample_partition_rows (
    p_schema_name     IN VARCHAR2,
    p_table_name      IN VARCHAR2,
    p_partition_name  IN VARCHAR2,
    p_sample_size     IN NUMBER,
    p_audit_run_id    IN NUMBER
  )
  RETURN NUMBER;

  /**
   * Sample rows from a table subpartition and check compression
   * 
   * Parameters:
   *   p_schema_name: Owner of table
   *   p_table_name: Table to audit
   *   p_subpartition_name: Subpartition to audit
   *   p_sample_size: Number of rows to sample
   *   p_audit_run_id: Correlates results
   * 
   * Returns:
   *   Number of rows sampled
   */
  FUNCTION sample_subpartition_rows (
    p_schema_name       IN VARCHAR2,
    p_table_name        IN VARCHAR2,
    p_subpartition_name IN VARCHAR2,
    p_sample_size       IN NUMBER,
    p_audit_run_id      IN NUMBER
  )
  RETURN NUMBER;

  /**
   * Check actual compression type for a single row via ROWID
   * 
   * Parameters:
   *   p_schema_name: Owner of table
   *   p_table_name: Table name
   *   p_rowid: ROWID of row to check
   * 
   * Returns:
   *   Compression type as per DBMS_COMPRESSION.GET_COMPRESSION_TYPE
   *   E.g., COMP_NOCOMPRESS, COMP_FOR_OLTP, COMP_FOR_QUERY_LOW, COMP_FOR_QUERY_HIGH
   */
  FUNCTION get_row_compression_type (
    p_schema_name IN VARCHAR2,
    p_table_name  IN VARCHAR2,
    p_rowid       IN ROWID
  )
  RETURN VARCHAR2;

  /**
   * Classify whether a row is physically compressed
   * 
   * Parameters:
   *   p_compression_type: Output from DBMS_COMPRESSION.GET_COMPRESSION_TYPE
   * 
   * Returns:
   *   'Y' if compressed (not COMP_NOCOMPRESS), 'N' otherwise
   */
  FUNCTION is_physically_compressed (
    p_compression_type IN VARCHAR2
  )
  RETURN CHAR;

  /**
   * Get summary report of audit findings
   * 
   * Parameters:
   *   p_audit_run_id: Run to report on
   * 
   * Returns:
   *   Ref cursor with summary: schema, object_name, partition_name,
   *   total_rows_sampled, phys_compressed_count, metadata_only_count
   */
  FUNCTION get_audit_summary (
    p_audit_run_id IN NUMBER
  )
  RETURN SYS_REFCURSOR;

END PKG_COMPRESSION_AUDIT;
/

SHOW ERRORS

PROMPT
PROMPT ============================================================================
PROMPT Package specification created: PKG_COMPRESSION_AUDIT
PROMPT Next Step: Create package body using 03_package_body.sql
PROMPT ============================================================================

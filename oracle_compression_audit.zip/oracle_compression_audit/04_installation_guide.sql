/*
 * Oracle 19c Exadata Compression Audit Utility
 * Installation and Usage Guide
 * 
 * Purpose:
 *   Quick-start instructions for deploying and running the compression audit utility
 * 
 * Steps:
 *   1. Execute 01_table_definitions.sql
 *   2. Execute 02_package_spec.sql
 *   3. Execute 03_package_body_v2_improved.sql (or 03_package_body.sql)
 *   4. Update configuration in this script
 *   5. Run audit procedures
 */

SET ECHO OFF
SET FEEDBACK ON

-- ============================================================================
-- STEP 1: Verify Installation
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Compression Audit Utility - Installation Verification
PROMPT ============================================================
PROMPT

-- Check if tables exist
BEGIN
  EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM user_tables WHERE table_name = ''COMPRESSION_AUDIT_CONFIG''';
  DBMS_OUTPUT.PUT_LINE('✓ Configuration table exists');
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('✗ Configuration table NOT FOUND - run 01_table_definitions.sql');
END;
/

-- Check if package exists
BEGIN
  EXECUTE IMMEDIATE 'SELECT 1 FROM user_objects WHERE object_name = ''PKG_COMPRESSION_AUDIT'' AND object_type = ''PACKAGE''';
  DBMS_OUTPUT.PUT_LINE('✓ Package specification exists');
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('✗ Package specification NOT FOUND - run 02_package_spec.sql');
END;
/

-- ============================================================================
-- STEP 2: Configure Target Schema (CUSTOMIZE THIS SECTION)
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Configuration Setup
PROMPT ============================================================
PROMPT

-- Update configuration for your target schema
UPDATE COMPRESSION_AUDIT_CONFIG
SET schema_name = 'APPSCHEMA',           -- ← CHANGE THIS TO YOUR SCHEMA
    sample_size_per_obj = 100,
    description = 'Compression audit for primary app schema',
    is_active = 'Y'
WHERE config_id = 1;

COMMIT;

-- Display active configuration
SELECT config_id, schema_name, sample_size_per_obj, is_active
FROM COMPRESSION_AUDIT_CONFIG
WHERE is_active = 'Y'
ORDER BY config_id;

-- ============================================================================
-- STEP 3: Verify Access to DBA Views
-- ============================================================================
PROMPT
PROMPT Checking access to compression metadata...
PROMPT

BEGIN
  DECLARE
    l_count NUMBER;
  BEGIN
    SELECT COUNT(*) INTO l_count FROM DBA_TABLES WHERE ROWNUM = 1;
    DBMS_OUTPUT.PUT_LINE('✓ Access to DBA_TABLES verified (' || l_count || ' total tables)');
  END;
END;
/

BEGIN
  DECLARE
    l_count NUMBER;
  BEGIN
    SELECT COUNT(*) INTO l_count FROM DBA_TAB_PARTITIONS WHERE ROWNUM = 1;
    DBMS_OUTPUT.PUT_LINE('✓ Access to DBA_TAB_PARTITIONS verified');
  END;
END;
/

BEGIN
  DECLARE
    l_count NUMBER;
  BEGIN
    SELECT COUNT(*) INTO l_count FROM DBA_TAB_SUBPARTITIONS WHERE ROWNUM = 1;
    DBMS_OUTPUT.PUT_LINE('✓ Access to DBA_TAB_SUBPARTITIONS verified');
  END;
END;
/

-- ============================================================================
-- STEP 4: Preview Compression Candidates
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Preview: Compressed Objects in Target Schema
PROMPT ============================================================
PROMPT

DECLARE
  l_cursor SYS_REFCURSOR;
  l_table_name VARCHAR2(128);
  l_compress VARCHAR2(10);
  l_compression VARCHAR2(50);
BEGIN
  l_cursor := PKG_COMPRESSION_AUDIT.get_compressed_tables('APPSCHEMA');
  
  DBMS_OUTPUT.PUT_LINE('Nonpartitioned Tables:');
  DBMS_OUTPUT.PUT_LINE('------------------------');
  
  LOOP
    FETCH l_cursor INTO l_table_name, l_compress, l_compression;
    EXIT WHEN l_cursor%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE('  ' || l_table_name || 
      ' [COMPRESS=' || l_compress || ', TYPE=' || l_compression || ']');
  END LOOP;
  
  CLOSE l_cursor;
END;
/

DECLARE
  l_cursor SYS_REFCURSOR;
  l_table_name VARCHAR2(128);
  l_partition_name VARCHAR2(128);
  l_compression VARCHAR2(50);
BEGIN
  l_cursor := PKG_COMPRESSION_AUDIT.get_compressed_table_partitions('APPSCHEMA');
  
  DBMS_OUTPUT.PUT_LINE('');
  DBMS_OUTPUT.PUT_LINE('Partitioned Tables:');
  DBMS_OUTPUT.PUT_LINE('------------------------');
  
  LOOP
    FETCH l_cursor INTO l_table_name, l_partition_name, l_compression;
    EXIT WHEN l_cursor%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE('  ' || l_table_name || '.' || l_partition_name || 
      ' [TYPE=' || l_compression || ']');
  END LOOP;
  
  CLOSE l_cursor;
END;
/

DECLARE
  l_cursor SYS_REFCURSOR;
  l_table_name VARCHAR2(128);
  l_subpartition_name VARCHAR2(128);
  l_compression VARCHAR2(50);
BEGIN
  l_cursor := PKG_COMPRESSION_AUDIT.get_compressed_table_subpartitions('APPSCHEMA');
  
  DBMS_OUTPUT.PUT_LINE('');
  DBMS_OUTPUT.PUT_LINE('Subpartitioned Tables:');
  DBMS_OUTPUT.PUT_LINE('------------------------');
  
  LOOP
    FETCH l_cursor INTO l_table_name, l_subpartition_name, l_compression;
    EXIT WHEN l_cursor%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE('  ' || l_table_name || '.' || l_subpartition_name || 
      ' [TYPE=' || l_compression || ']');
  END LOOP;
  
  CLOSE l_cursor;
  
  DBMS_OUTPUT.PUT_LINE('');
  DBMS_OUTPUT.PUT_LINE('Audit preview complete. Ready to execute full scan.');
END;
/

SET ECHO ON

PROMPT
PROMPT ============================================================
PROMPT STEP 5: Execute Compression Audit
PROMPT ============================================================
PROMPT To run the full compression audit, execute:
PROMPT
PROMPT   DECLARE
PROMPT     l_run_id NUMBER;
PROMPT   BEGIN
PROMPT     PKG_COMPRESSION_AUDIT.execute_compression_audit(
PROMPT       p_config_id => 1,
PROMPT       p_audit_run_id => l_run_id
PROMPT     );
PROMPT     DBMS_OUTPUT.PUT_LINE('Audit Run ID: ' || l_run_id);
PROMPT   END;
PROMPT   /
PROMPT
PROMPT Or use the provided execute_audit.sql script.
PROMPT ============================================================

/*
 * Oracle 19c Exadata Compression Audit Utility
 * Quick Reference Card
 * 
 * Common Operations at a Glance
 */

-- ============================================================================
-- QUICK START (Copy & Paste)
-- ============================================================================

-- 1. Install (run in order)
@01_table_definitions.sql
@02_package_spec.sql
@03_package_body_v2_improved.sql
@04_installation_guide.sql

-- 2. Configure (update YOUR_SCHEMA)
UPDATE COMPRESSION_AUDIT_CONFIG
SET schema_name = 'YOUR_SCHEMA', sample_size_per_obj = 100, is_active = 'Y'
WHERE config_id = 1;
COMMIT;

-- 3. Execute audit
DECLARE l_run_id NUMBER;
BEGIN
  PKG_COMPRESSION_AUDIT.execute_compression_audit(1, l_run_id);
  DBMS_OUTPUT.PUT_LINE('Run ID: ' || l_run_id);
END;
/

-- 4. View results
@06_query_results.sql

-- ============================================================================
-- QUICK QUERIES
-- ============================================================================

-- Last audit summary
SELECT audit_run_id, schema_name, status, total_rows_sampled,
       rows_metadata_compressed_no_physical
FROM COMPRESSION_AUDIT_RUN_LOG
WHERE status = 'COMPLETED'
ORDER BY audit_run_id DESC FETCH FIRST 1 ROW ONLY;

-- Objects with compression mismatch
SELECT object_name, partition_name,
       COUNT(*) total_sampled,
       SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) not_compressed
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
  AND is_physically_compressed = 'N'
GROUP BY object_name, partition_name
ORDER BY not_compressed DESC;

-- Compression type breakdown
SELECT compression_type, COUNT(*) row_count,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) pct
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
GROUP BY compression_type ORDER BY row_count DESC;

-- Sample of uncompressed rows (metadata-only)
SELECT result_id, object_name, partition_name, sampled_rowid, compression_type
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
  AND is_physically_compressed = 'N'
FETCH FIRST 20 ROWS ONLY;

-- ============================================================================
-- CONFIGURATION MANAGEMENT
-- ============================================================================

-- View all configs
SELECT config_id, schema_name, sample_size_per_obj, is_active, description
FROM COMPRESSION_AUDIT_CONFIG
ORDER BY config_id;

-- Create new config for another schema
INSERT INTO COMPRESSION_AUDIT_CONFIG
  (config_id, schema_name, sample_size_per_obj, description, is_active)
VALUES (2, 'OTHER_SCHEMA', 50, 'Audit other schema', 'Y');
COMMIT;

-- Disable config temporarily
UPDATE COMPRESSION_AUDIT_CONFIG SET is_active = 'N' WHERE config_id = 1;
COMMIT;

-- Delete old audit results (keep last 30 days)
DELETE FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id IN (
  SELECT audit_run_id FROM COMPRESSION_AUDIT_RUN_LOG
  WHERE start_time < SYSDATE - 30
);
COMMIT;

-- ============================================================================
-- REPORTING
-- ============================================================================

-- High-level summary for executive report
SELECT 
  schema_name,
  COUNT(DISTINCT audit_run_id) audits_performed,
  MAX(start_time) last_audit_date,
  SUM(total_rows_sampled) total_rows_checked,
  SUM(rows_metadata_compressed_no_physical) mismatch_rows
FROM COMPRESSION_AUDIT_RUN_LOG
WHERE status = 'COMPLETED'
  AND start_time >= SYSDATE - 30
GROUP BY schema_name;

-- Object-level compression health
SELECT 
  object_name,
  COUNT(DISTINCT object_type) object_types,
  SUM(CASE WHEN is_physically_compressed = 'Y' THEN 1 ELSE 0 END) compressed_rows,
  SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) uncompressed_rows,
  ROUND(100.0 * SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) / 
        COUNT(*), 2) pct_uncompressed
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
GROUP BY object_name
HAVING SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) > 0
ORDER BY pct_uncompressed DESC;

-- ============================================================================
-- TROUBLESHOOTING
-- ============================================================================

-- Check for errors in latest run
SELECT audit_run_id, status, error_message, end_time
FROM COMPRESSION_AUDIT_RUN_LOG
WHERE status = 'FAILED'
ORDER BY audit_run_id DESC
FETCH FIRST 5 ROWS ONLY;

-- Verify package compilation
SELECT object_name, status
FROM user_objects
WHERE object_name LIKE 'PKG_COMPRESSION%'
ORDER BY object_name;

-- Check table structure
DESC COMPRESSION_AUDIT_RESULTS;
DESC COMPRESSION_AUDIT_CONFIG;
DESC COMPRESSION_AUDIT_RUN_LOG;

-- Verify sequences
SELECT sequence_name, last_number FROM user_sequences
WHERE sequence_name LIKE 'SEQ_COMPRESSION%';

-- ============================================================================
-- MAINTENANCE
-- ============================================================================

-- Archive old results to external table (example)
-- CREATE TABLE COMPRESSION_AUDIT_RESULTS_ARCHIVE AS
-- SELECT * FROM COMPRESSION_AUDIT_RESULTS
-- WHERE audit_run_id IN (
--   SELECT audit_run_id FROM COMPRESSION_AUDIT_RUN_LOG
--   WHERE start_time < TRUNC(SYSDATE - 90)
-- );

-- Rebuild indices
ALTER INDEX IDX_COMPRESSION_RESULTS_SCHEMA REBUILD;
ALTER INDEX IDX_COMPRESSION_RESULTS_TIMESTAMP REBUILD;
ALTER INDEX IDX_COMPRESSION_RESULTS_AUDIT_RUN REBUILD;

-- Check table size
SELECT SEGMENT_NAME, BYTES / 1024 / 1024 SIZE_MB
FROM USER_SEGMENTS
WHERE SEGMENT_NAME IN ('COMPRESSION_AUDIT_RESULTS', 
                       'COMPRESSION_AUDIT_CONFIG',
                       'COMPRESSION_AUDIT_RUN_LOG')
ORDER BY BYTES DESC;

-- ============================================================================
-- EXPORT/IMPORT
-- ============================================================================

-- Export results to CSV (run in SQL*Plus)
-- SET ECHO OFF FEEDBACK OFF PAGESIZE 0 LINESIZE 32767 HEADING OFF
-- SPOOL compression_audit_results.csv
-- SELECT * FROM COMPRESSION_AUDIT_RESULTS
-- WHERE audit_run_id = <RUN_ID>
-- ORDER BY result_id;
-- SPOOL OFF

-- ============================================================================
-- ADVANCED: Multi-Schema Audit
-- ============================================================================

-- Setup configs for all schemas with compressed tables
INSERT INTO COMPRESSION_AUDIT_CONFIG 
  (config_id, schema_name, sample_size_per_obj, is_active)
SELECT ROW_NUMBER() OVER (ORDER BY owner) config_id,
       owner,
       100,
       'Y'
FROM (
  SELECT DISTINCT owner FROM DBA_TABLES
  WHERE (compress = 'Y' OR compression NOT IN ('NONE', 'NO'))
    AND owner NOT IN ('SYS', 'SYSTEM', 'XDB')
)
WHERE NOT EXISTS (
  SELECT 1 FROM COMPRESSION_AUDIT_CONFIG cac
  WHERE cac.schema_name = owner
);

-- Run audits for all active configs
BEGIN
  FOR conf IN (SELECT config_id FROM COMPRESSION_AUDIT_CONFIG WHERE is_active = 'Y') LOOP
    DECLARE l_run_id NUMBER;
    BEGIN
      PKG_COMPRESSION_AUDIT.execute_compression_audit(conf.config_id, l_run_id);
      COMMIT;
    END;
  END LOOP;
END;
/

-- ============================================================================
-- CLEANUP
-- ============================================================================

-- Remove everything (CAUTION - backup first!)
@99_cleanup.sql

-- Remove specific audit run results
DELETE FROM COMPRESSION_AUDIT_RESULTS WHERE audit_run_id = <RUN_ID>;
DELETE FROM COMPRESSION_AUDIT_RUN_LOG WHERE audit_run_id = <RUN_ID>;
COMMIT;

-- ============================================================================
-- NOTES
-- ============================================================================

/*
- Always update COMPRESSION_AUDIT_CONFIG before running audits
- Schema names must be UPPERCASE (as they appear in DBA_TABLES.OWNER)
- Sample size of 0 means sample all rows (use with caution)
- Results accumulate - implement archival strategy for long-term use
- Read-only on application tables - safe to run in production
- Run during off-peak hours to minimize I/O
- Check COMPRESSION_AUDIT_RUN_LOG.error_message for details on failures
*/

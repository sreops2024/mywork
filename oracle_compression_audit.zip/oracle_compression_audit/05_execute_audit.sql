/*
 * Oracle 19c Exadata Compression Audit Utility
 * Execute Audit Script
 * 
 * Usage:
 *   sqlplus / as sysdba @05_execute_audit.sql
 * 
 * This script:
 *   1. Validates configuration
 *   2. Executes the compression audit
 *   3. Displays immediate results
 *   4. Provides SQL for detailed result analysis
 */

SET ECHO ON
SET FEEDBACK ON
SET PAGESIZE 100
SET LINESIZE 150

PROMPT
PROMPT ============================================================
PROMPT Executing Compression Audit
PROMPT ============================================================

-- Enable output
SET SERVEROUTPUT ON SIZE 10000

-- Declare and execute
DECLARE
  l_run_id   NUMBER;
  l_start    TIMESTAMP;
  l_duration VARCHAR2(100);
BEGIN
  l_start := SYSTIMESTAMP;
  
  -- Execute audit for config_id = 1
  PKG_COMPRESSION_AUDIT.execute_compression_audit(
    p_config_id => 1,
    p_audit_run_id => l_run_id
  );
  
  -- Display run ID
  DBMS_OUTPUT.PUT_LINE('Audit Run ID: ' || l_run_id);
  DBMS_OUTPUT.PUT_LINE('Started: ' || TO_CHAR(l_start, 'YYYY-MM-DD HH24:MI:SS'));
  
END;
/

-- ============================================================================
-- Display Audit Run Log
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Audit Run Summary
PROMPT ============================================================

SELECT 
  audit_run_id,
  schema_name,
  status,
  total_objects_checked,
  total_rows_sampled,
  rows_metadata_compressed_no_physical,
  ROUND((CAST(end_time AS DATE) - CAST(start_time AS DATE)) * 86400) duration_seconds
FROM COMPRESSION_AUDIT_RUN_LOG
ORDER BY audit_run_id DESC
FETCH FIRST 1 ROW ONLY;

-- ============================================================================
-- Display Results Summary
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Detailed Findings by Object
PROMPT ============================================================

SELECT 
  schema_name,
  object_name,
  object_type,
  NVL(partition_name, NVL(subpartition_name, 'N/A')) segment_name,
  COUNT(*) total_sampled,
  SUM(CASE WHEN is_physically_compressed = 'Y' THEN 1 ELSE 0 END) physically_compressed,
  SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) metadata_only,
  ROUND(100.0 * SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) / 
        COUNT(*), 2) pct_metadata_only
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
GROUP BY schema_name, object_name, object_type, partition_name, subpartition_name
ORDER BY schema_name, object_name, segment_name;

-- ============================================================================
-- Identify "Problem" Objects (Metadata Compressed But Not Physically)
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Objects with Metadata/Physical Compression Mismatch
PROMPT ============================================================
PROMPT

WITH mismatches AS (
  SELECT 
    schema_name,
    object_name,
    object_type,
    NVL(partition_name, NVL(subpartition_name, 'N/A')) segment_name,
    COUNT(*) total_sampled,
    SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) uncompressed_count,
    ROUND(100.0 * SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) / 
          COUNT(*), 2) pct_uncompressed
  FROM COMPRESSION_AUDIT_RESULTS
  WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
    AND is_physically_compressed = 'N'
  GROUP BY schema_name, object_name, object_type, partition_name, subpartition_name
  HAVING COUNT(*) > 0
)
SELECT * FROM mismatches
WHERE pct_uncompressed > 0
ORDER BY pct_uncompressed DESC, schema_name, object_name;

-- ============================================================================
-- Detailed Row-Level Results (Sample)
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Sample Row-Level Details (Metadata-Only Compressed Rows)
PROMPT ============================================================
PROMPT

SELECT 
  result_id,
  schema_name,
  object_name,
  NVL(partition_name, NVL(subpartition_name, 'N/A')) segment,
  sampled_rowid,
  compression_type,
  is_physically_compressed,
  scan_timestamp
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
  AND is_physically_compressed = 'N'
FETCH FIRST 20 ROWS ONLY;

-- ============================================================================
-- Compression Type Distribution
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Compression Types Found
PROMPT ============================================================
PROMPT

SELECT 
  compression_type,
  COUNT(*) row_count,
  ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) pct_of_total
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
GROUP BY compression_type
ORDER BY row_count DESC;

PROMPT
PROMPT ============================================================
PROMPT Audit Complete
PROMPT ============================================================
PROMPT
PROMPT Use 06_query_results.sql for additional reporting and analysis.
PROMPT

/*
 * Oracle 19c Exadata Compression Audit Utility
 * Technical Architecture and Design Patterns
 * 
 * This document describes the core design patterns and technical decisions
 * that make this utility production-safe and efficient.
 */

============================================================================
1. METADATA VS. PHYSICAL COMPRESSION DISTINCTION
============================================================================

METADATA COMPRESSION (Data Dictionary):
- Stored in: DBA_TABLES.COMPRESS, DBA_TAB_PARTITIONS.COMPRESS
- Stored in: DBA_TABLES.COMPRESSION, DBA_TAB_PARTITIONS.COMPRESSION
- Indicates: Compression is ENABLED for the object
- Does NOT guarantee: Rows are actually compressed

PHYSICAL COMPRESSION (Actual Stored Data):
- Determined by: DBMS_COMPRESSION.GET_COMPRESSION_TYPE()
- Returns: COMP_NOCOMPRESS, COMP_FOR_OLTP, COMP_FOR_QUERY_LOW, etc.
- Indicates: How rows are actually stored
- Variable: Can differ between rows in same segment

KEY INSIGHT:
A table marked as "COMPRESS = Y" may contain rows that are NOT compressed
because:
1. Rows inserted/updated after compression was enabled
2. Compression settings degraded over time
3. Partial migrations or compression changes
4. Block reuse scenarios

AUDIT STRATEGY:
- Query metadata (DBA_TABLES, etc.) for CANDIDATES
- Sample rows from each candidate
- Use DBMS_COMPRESSION.GET_COMPRESSION_TYPE() to check ACTUAL compression
- Flag mismatches: "Metadata Compressed But Not Physically Compressed"

============================================================================
2. THREE-TIER OBJECT HIERARCHY
============================================================================

TIER 1: NONPARTITIONED TABLES
- Query source: DBA_TABLES
- WHERE clause: owner = schema AND (compress = 'Y' OR compression != 'NONE')
- Sample method: SELECT * FROM schema.table WHERE ROWNUM <= sample_size
- Scope when sampling: table_name only
- DBMS_COMPRESSION call: partname = NULL

TIER 2: PARTITIONED TABLES
- Query source: DBA_TAB_PARTITIONS
- WHERE clause: table_owner = schema AND (compress = 'Y' OR compression != 'NONE')
- Sample method: SELECT * FROM schema.table PARTITION(part_name) ...
- Scope when sampling: table_name + partition_name
- DBMS_COMPRESSION call: partname = partition_name

TIER 3: SUBPARTITIONED TABLES (Composite Partitioning)
- Query source: DBA_TAB_SUBPARTITIONS
- WHERE clause: table_owner = schema AND (compress = 'Y' OR compression != 'NONE')
- Sample method: SELECT * FROM schema.table SUBPARTITION(subpart_name) ...
- Scope when sampling: table_name + subpartition_name
- DBMS_COMPRESSION call: partname = subpartition_name

KEY PATTERN:
Results table stores ALL scope information (partition_name, subpartition_name)
with NULLs for non-applicable tiers. Queries use COALESCE/NVL to reconstruct
the proper object identifier.

============================================================================
3. ROWID-BASED SAMPLING STRATEGY
============================================================================

EFFICIENT SAMPLING APPROACH (v2_improved):

1. Dynamic SQL with SAMPLE Clause:
   SELECT ROWID FROM schema.table SAMPLE(percentage) WHERE ROWNUM <= limit

2. Advantages:
   - Oracle optimizer chooses efficient block sampling
   - Reduces I/O: ~percentage% of blocks accessed
   - Random: Good statistical representation
   - Scales: Works on 1MB tables and 1TB tables
   - Safe: Read-only, no locks

3. Sample Percentage Calculation:
   - Input: sample_size_per_obj (e.g., 100 rows)
   - Assume table has ~10,000 rows per 1% sample
   - Sample% = GREATEST(LEAST(100, ROUND(100.0 * sample_size / 10000, 2)), 0.01)
   - Capped: Min 0.01%, Max 100%

4. ROWID Processing:
   - Extract ROWID from SAMPLE result
   - Extract block number: DBMS_ROWID.ROWID_BLOCK_NUMBER(rowid)
   - Pass to DBMS_COMPRESSION.GET_COMPRESSION_TYPE()
   - Maintains association: rowid + compression_type → results table

============================================================================
4. DBMS_COMPRESSION.GET_COMPRESSION_TYPE() CALL PATTERN
============================================================================

PROCEDURE SIGNATURE:
  DBMS_COMPRESSION.GET_COMPRESSION_TYPE(
    ownname   => VARCHAR2,      -- Schema name (UPPERCASE)
    tabname   => VARCHAR2,      -- Table name (UPPERCASE)
    partname  => VARCHAR2,      -- Partition/subpartition name or NULL
    blknum    => NUMBER,        -- Block number from ROWID
    comptype  => OUT VARCHAR2   -- Compression type (return value)
  )

SAMPLE CALLS:

1. Nonpartitioned table, block 12345:
   DBMS_COMPRESSION.GET_COMPRESSION_TYPE(
     ownname => 'APPSCHEMA',
     tabname => 'CUSTOMERS',
     partname => NULL,
     blknum => 12345,
     comptype => l_type
   )

2. Partitioned table, partition "P_2026_Q1", block 5678:
   DBMS_COMPRESSION.GET_COMPRESSION_TYPE(
     ownname => 'APPSCHEMA',
     tabname => 'ORDERS',
     partname => 'P_2026_Q1',
     blknum => 5678,
     comptype => l_type
   )

3. Subpartitioned table, subpartition "P_2026_Q1_SP1", block 9999:
   DBMS_COMPRESSION.GET_COMPRESSION_TYPE(
     ownname => 'APPSCHEMA',
     tabname => 'TRANSACTIONS',
     partname => 'P_2026_Q1_SP1',  -- subpartition name
     blknum => 9999,
     comptype => l_type
   )

RETURN VALUES:
  COMP_NOCOMPRESS        -- Row is not compressed
  COMP_FOR_OLTP          -- OLTP compression (HCC)
  COMP_FOR_QUERY_LOW     -- Query compression (HCC, low)
  COMP_FOR_QUERY_HIGH    -- Query compression (HCC, high)
  COMP_HYBRID            -- Hybrid compression
  COMP_ARCHIVE_LOW       -- Archive compression (low)
  COMP_ARCHIVE_HIGH      -- Archive compression (high)

ERROR HANDLING:
  - ORA-28024: Bind variable error → check partname format
  - ORA-20000: Table/partition not found → check permissions
  - Default: Return COMP_NOCOMPRESS (conservative) and log error

============================================================================
5. CONFIGURATION-DRIVEN APPROACH
============================================================================

SINGLE CONFIGURATION TABLE: COMPRESSION_AUDIT_CONFIG

Advantages:
1. Reusable: One utility supports multiple schemas
2. Schedulable: Cron jobs read config, execute dynamically
3. Parameterized: Sample size, schema name centralized
4. Auditable: Configuration changes tracked with timestamps
5. Multi-tenant: Different sample strategies per schema

Key Columns:
- config_id: Primary key for scheduling
- schema_name: Target schema (case-sensitive, UPPERCASE required)
- sample_size_per_obj: Tunable per use case
- is_active: Soft disable without deletion
- scan_timestamp: When config was created/updated
- description: Notes for operators

Pattern Example:
  Config 1: APPSCHEMA, sample_size=100, daily schedule
  Config 2: REPORTING_SCHEMA, sample_size=1000, weekly schedule
  Config 3: DW_SCHEMA, sample_size=0 (all rows), monthly schedule

Loop Implementation:
  FOR config IN (SELECT * FROM COMPRESSION_AUDIT_CONFIG WHERE is_active = 'Y') LOOP
    execute_compression_audit(config.config_id, l_run_id);
  END LOOP;

============================================================================
6. AUDIT TRAIL AND RUN CORRELATION
============================================================================

TWO-LEVEL LOGGING:

COMPRESSION_AUDIT_RUN_LOG (Master Log):
- One row per audit execution
- Key: audit_run_id (sequence)
- Fields: schema_name, start_time, end_time, status, statistics
- Purpose: Track "when did we audit this schema?" and "how long?"

COMPRESSION_AUDIT_RESULTS (Detail Log):
- One row per sampled row from one object
- Key: result_id (sequence)
- Foreign key: audit_run_id (correlates to RUN_LOG)
- Fields: object_name, partition_name, rowid, compression_type, ...
- Purpose: Track "which rows were compressed/uncompressed?"

QUERY PATTERN (Joining both):
  SELECT lr.audit_run_id, lr.schema_name, r.object_name,
         COUNT(*) rows_sampled,
         SUM(CASE WHEN r.is_physically_compressed = 'N' THEN 1 ELSE 0 END) mismatches
  FROM COMPRESSION_AUDIT_RUN_LOG lr
  JOIN COMPRESSION_AUDIT_RESULTS r ON lr.audit_run_id = r.audit_run_id
  WHERE lr.status = 'COMPLETED'
    AND lr.start_time >= SYSDATE - 30
  GROUP BY lr.audit_run_id, lr.schema_name, r.object_name;

LIFECYCLE:
  1. User calls: execute_compression_audit(config_id, l_run_id)
  2. Package creates: RUN_LOG row, status='RUNNING'
  3. Package samples objects, inserts: RESULTS rows with audit_run_id
  4. Package aggregates stats: COUNT(RESULTS), etc.
  5. Package updates: RUN_LOG.status='COMPLETED', writes statistics

============================================================================
7. COMMIT STRATEGY FOR LARGE SCANS
============================================================================

PROBLEM:
- Sampling large tables generates many result rows
- Committing after every row: Too slow
- No commits: Rollback segment might overflow

SOLUTION: Bulk Commit Every 100 Rows

Code Pattern:
  FOR rec_row IN cursor_sample_rows LOOP
    -- Process row
    INSERT INTO COMPRESSION_AUDIT_RESULTS (...) VALUES (...);
    
    l_rows_sampled := l_rows_sampled + 1;
    
    IF MOD(l_rows_sampled, 100) = 0 THEN
      COMMIT;  -- Flush results to disk every 100 rows
    END IF;
  END LOOP;
  
  COMMIT;  -- Final commit for remaining rows

ADVANTAGES:
1. Rollback segment: Limited by ~100 rows, never overflows
2. Performance: Commits every 100 rows (acceptable batch size)
3. Safety: If package crashes, can resume from RUN_LOG.audit_run_id
4. Monitoring: Can track progress during long-running audits

============================================================================
8. READ-ONLY DIAGNOSTIC DESIGN
============================================================================

This utility is completely READ-ONLY on application data.

SAFE FOR PRODUCTION:
- No DML on application tables (no INSERT, UPDATE, DELETE)
- Only SELECT queries on data dictionary (DBA_TABLES, etc.)
- Only SELECT + sampling from application tables
- No locks acquired on application data

OPERATIONS:
- DML only on audit infrastructure (COMPRESSION_AUDIT_* tables)
- These are admin/diagnostic tables, not production data
- Isolated from application workload

PROOF:
  % Grep for application DML in package body:
    - No "UPDATE application_schema.%"
    - No "DELETE FROM application_schema.%"
    - No "INSERT INTO application_schema.%"
    - Only SELECT queries with ROWNUM limits

RISK MITIGATION:
1. Audit infrastructure tables in USERS tablespace (can be monitored)
2. Read-only on application data (no risk of accidental corruption)
3. Limited to sampling (not full table scans)
4. Errors in results table don't affect application

============================================================================
9. ERROR HANDLING PHILOSOPHY
============================================================================

DEFENSIVE PROGRAMMING:

1. Individual Partitions Can Fail:
   - If one partition errors, continue to next partition
   - Log error in DBMS_OUTPUT
   - Don't abort entire run

2. Compress Check Defaults to NOCOMPRESS:
   - If DBMS_COMPRESSION.GET_COMPRESSION_TYPE() fails
   - Return COMP_NOCOMPRESS (conservative)
   - Flag for manual investigation

3. Configuration Errors are Fatal:
   - If config_id not found or not active
   - Raise exception and set RUN_LOG.status = FAILED
   - Require operator intervention

4. Overall Audit Completes Despite Errors:
   - Partial results still valuable
   - RUN_LOG captures what succeeded and what failed
   - Error message logged for troubleshooting

CODE PATTERN:
  BEGIN
    FOR rec IN cursor_partition_list LOOP
      BEGIN
        -- Sample this partition
        ...
      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
          -- Continue to next partition
      END;
    END LOOP;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- Config not found - fatal, fail the run
      RAISE;
  END;

============================================================================
10. PERFORMANCE TUNING RECOMMENDATIONS
============================================================================

OPTIMIZATION KNOBS:

1. Sample Size (sample_size_per_obj):
   - 10 rows: Quick surveys, large numbers of objects
   - 100 rows: Default, good balance
   - 1000 rows: Detailed analysis, fewer objects
   - 0 (all rows): Full audit, use for critical objects only

2. Sampling Frequency:
   - Daily: For high-change schemas
   - Weekly: For stable schemas
   - Monthly: For archival/cold data

3. Parallelization:
   - Run separate configs (separate schemas) on different sessions
   - Each config independently

4. Indexing Tuning:
   - Current indices on (schema_name, object_name, audit_run_id)
   - Consider additional indices for your query patterns
   - Suggestion: (is_physically_compressed, compression_type) if doing many type queries

5. Archive Strategy:
   - Purge results older than 90 days
   - Move old RUN_LOG entries to archive table
   - Prevents COMPRESSION_AUDIT_RESULTS from growing unbounded

Example Archive Query:
  CREATE TABLE COMPRESSION_AUDIT_RESULTS_ARCHIVE AS
  SELECT * FROM COMPRESSION_AUDIT_RESULTS
  WHERE audit_run_id IN (
    SELECT audit_run_id FROM COMPRESSION_AUDIT_RUN_LOG
    WHERE start_time < TRUNC(SYSDATE - 90)
  );
  
  DELETE FROM COMPRESSION_AUDIT_RESULTS
  WHERE audit_run_id IN (
    SELECT audit_run_id FROM COMPRESSION_AUDIT_RUN_LOG
    WHERE start_time < TRUNC(SYSDATE - 90)
  );
  
  COMMIT;

============================================================================
11. PRODUCTION DEPLOYMENT CHECKLIST
============================================================================

PRE-DEPLOYMENT:
[ ] Test on non-production replica with same data volume
[ ] Verify DBMS_COMPRESSION package is available
[ ] Confirm DBA_TABLES, DBA_TAB_PARTITIONS access
[ ] Measure baseline audit runtime with small sample
[ ] Confirm audit infrastructure tablespace quota

DEPLOYMENT:
[ ] Create tables with correct tablespace names
[ ] Compile package without errors
[ ] Insert first configuration record
[ ] Run 04_installation_guide.sql to verify
[ ] Test execute_compression_audit() with config_id=1
[ ] Verify results are inserted correctly

POST-DEPLOYMENT:
[ ] Schedule regular audit runs (e.g., weekly)
[ ] Set up result archival job
[ ] Create monitoring alerts on RUN_LOG.status='FAILED'
[ ] Document in runbooks and DBA procedures
[ ] Train operators on result interpretation

============================================================================
12. EXTENSION POINTS
============================================================================

Future Enhancements:

1. Compression Ratio Estimation:
   - Add column: estimated_compression_ratio
   - Query: Compare block count vs. row count
   - Insight: How much space is compression saving?

2. Alert on Degradation:
   - Track pct_uncompressed over time
   - Alert if trending upward (compression degrading)
   - Recommend re-compression action

3. Integration with Performance Hub:
   - Store audit findings in performance schema
   - Correlate with table access statistics
   - Prioritize re-compression efforts

4. Export to EM (Enterprise Manager):
   - Push audit results to EM repository
   - Visualize compression state in EM UI
   - Correlate with EM alerts

5. Automatic Remediation:
   - Detect mismatches automatically
   - Queue re-compression jobs
   - Track remediation success

============================================================================

This design ensures the utility is:
- PRODUCTION-SAFE: Read-only, error-resilient, auditable
- EFFICIENT: Sampling-based, scalable, tunable
- MAINTAINABLE: Configuration-driven, modular, well-documented
- EXTENSIBLE: Easy to add new object types or metrics

============================================================================

# Oracle 19c Exadata Compression Audit Utility

## Overview

This production-safe PL/SQL utility audits Oracle database compression for Oracle 19c Exadata environments. It determines whether objects marked as compressed in the data dictionary are actually storing compressed rows.

### Purpose

In Oracle, compression settings in the data dictionary (metadata) don't always guarantee that rows are physically compressed. This can happen due to:
- Rows that have been updated or inserted after compression was enabled
- Compression settings that degrade over time
- Compression type changes that weren't applied to existing data
- Migration scenarios where compression flags exist but data wasn't re-compressed

This utility discovers this mismatch by:
1. Reading metadata compression settings from DBA_TABLES, DBA_TAB_PARTITIONS, DBA_TAB_SUBPARTITIONS
2. Sampling actual rows from each object
3. Using DBMS_COMPRESSION.GET_COMPRESSION_TYPE() to inspect physical compression on sampled rows
4. Recording findings for analysis and reporting

---

## Architecture

### Table Schema

#### COMPRESSION_AUDIT_CONFIG
Stores audit job parameters (configuration-driven approach).

```sql
config_id           NUMBER PRIMARY KEY
schema_name         VARCHAR2(128)
sample_size_per_obj NUMBER           -- rows to sample per object (0 = all)
scan_timestamp      TIMESTAMP
is_active           CHAR(1)          -- Y/N
description         VARCHAR2(500)
```

#### COMPRESSION_AUDIT_RESULTS
Stores detailed findings from compression checks.

```sql
result_id                    NUMBER PRIMARY KEY
schema_name                  VARCHAR2(128)
object_name                  VARCHAR2(128)
partition_name               VARCHAR2(128)  -- NULL for nonpartitioned
subpartition_name            VARCHAR2(128)  -- NULL for non-subpartitioned
object_type                  VARCHAR2(20)   -- TABLE, PARTITION, SUBPARTITION
sampled_rowid                ROWID          -- Specific row audited
compression_type             VARCHAR2(50)   -- COMP_NOCOMPRESS, COMP_FOR_OLTP, etc.
is_physically_compressed     CHAR(1)        -- Y/N flag
scan_timestamp               TIMESTAMP
audit_run_id                 NUMBER         -- Correlates rows from same run
```

#### COMPRESSION_AUDIT_RUN_LOG
Audit trail of each execution.

```sql
audit_run_id                          NUMBER PRIMARY KEY
config_id                             NUMBER
schema_name                           VARCHAR2(128)
start_time                            TIMESTAMP
end_time                              TIMESTAMP
total_objects_checked                 NUMBER
total_rows_sampled                    NUMBER
rows_metadata_compressed_no_physical  NUMBER
status                                VARCHAR2(20) -- RUNNING, COMPLETED, FAILED
error_message                         VARCHAR2(1000)
```

### Package: PKG_COMPRESSION_AUDIT

#### Main Procedure: execute_compression_audit()
```plsql
PROCEDURE execute_compression_audit (
  p_config_id     IN NUMBER DEFAULT NULL,
  p_audit_run_id  OUT NUMBER
);
```

**Logic Flow:**
1. Create audit run record in RUN_LOG with status = RUNNING
2. Fetch config (schema name, sample size)
3. Discover nonpartitioned tables from DBA_TABLES
4. For each table: sample rows → check compression → record results
5. Discover partitioned tables from DBA_TAB_PARTITIONS
6. For each partition: sample rows → check compression → record results
7. Discover subpartitioned tables from DBA_TAB_SUBPARTITIONS
8. For each subpartition: sample rows → check compression → record results
9. Aggregate statistics and update RUN_LOG with status = COMPLETED

#### Discovery Functions
- **get_compressed_tables()**: Returns nonpartitioned tables with compression enabled
- **get_compressed_table_partitions()**: Returns partitions with compression enabled
- **get_compressed_table_subpartitions()**: Returns subpartitions with compression enabled

All query DBA_* views filtering for: `compress = 'Y' OR compression NOT IN ('NONE', 'NO')`

#### Row Sampling Functions
- **sample_table_rows()**: Samples from nonpartitioned table
- **sample_partition_rows()**: Samples from partition
- **sample_subpartition_rows()**: Samples from subpartition

**Sampling Strategy:**
- Uses SAMPLE clause with calculated sample percentage for efficiency
- Iterates over returned ROWIDs
- For each ROWID: calls get_row_compression_type()
- Inserts result into COMPRESSION_AUDIT_RESULTS
- Commits every 100 rows to manage rollback segment usage

#### Compression Check
```plsql
FUNCTION get_row_compression_type (
  p_schema_name IN VARCHAR2,
  p_table_name  IN VARCHAR2,
  p_rowid       IN ROWID
)
RETURN VARCHAR2
```

**Implementation:**
- Extracts block number from ROWID using DBMS_ROWID.ROWID_BLOCK_NUMBER()
- Calls DBMS_COMPRESSION.GET_COMPRESSION_TYPE()
- Returns compression type (e.g., COMP_NOCOMPRESS, COMP_FOR_OLTP, COMP_FOR_QUERY_LOW, COMP_FOR_QUERY_HIGH)

#### Classification Function
```plsql
FUNCTION is_physically_compressed (p_compression_type IN VARCHAR2)
RETURN CHAR
```

Returns:
- 'Y' if compression_type ≠ COMP_NOCOMPRESS (row is compressed)
- 'N' if compression_type = COMP_NOCOMPRESS (row is NOT compressed)

---

## Installation

### Prerequisites
- Oracle Database 19c or later
- Access to DBMS_COMPRESSION package
- DBA privileges or equivalent
- Target schema name (will be passed to procedure)

### Step-by-Step

1. **Create infrastructure tables:**
   ```bash
   sqlplus / as sysdba @01_table_definitions.sql
   ```
   Creates:
   - COMPRESSION_AUDIT_CONFIG
   - COMPRESSION_AUDIT_RESULTS
   - COMPRESSION_AUDIT_RUN_LOG
   - Sequences and indexes

2. **Create package specification:**
   ```bash
   sqlplus / as sysdba @02_package_spec.sql
   ```

3. **Create package body (choose one):**
   ```bash
   sqlplus / as sysdba @03_package_body_v2_improved.sql
   ```
   (Recommended version with simplified cursor logic and SAMPLE clause)

4. **Verify installation:**
   ```bash
   sqlplus / as sysdba @04_installation_guide.sql
   ```

---

## Configuration

### Update Target Schema
Before running audits, update the configuration table:

```sql
UPDATE COMPRESSION_AUDIT_CONFIG
SET schema_name = 'YOUR_SCHEMA_NAME',
    sample_size_per_obj = 100,
    is_active = 'Y'
WHERE config_id = 1;
COMMIT;
```

**Parameters:**
- `schema_name`: The schema to audit (must be uppercase as stored in DBA_TABLES.OWNER)
- `sample_size_per_obj`: Number of rows to sample from each object
  - 100 = sample 100 rows per table/partition/subpartition
  - 0 = sample all rows (use with caution on large objects)
- `is_active`: Y = process this config; N = skip

---

## Usage

### Execute Audit
```sql
DECLARE
  l_run_id NUMBER;
BEGIN
  PKG_COMPRESSION_AUDIT.execute_compression_audit(
    p_config_id => 1,
    p_audit_run_id => l_run_id
  );
  DBMS_OUTPUT.PUT_LINE('Audit Run ID: ' || l_run_id);
END;
/
```

Or use the provided script:
```bash
sqlplus / as sysdba @05_execute_audit.sql
```

### View Results

**Latest Audit Summary:**
```sql
SELECT * FROM COMPRESSION_AUDIT_RUN_LOG
ORDER BY audit_run_id DESC
FETCH FIRST 1 ROW ONLY;
```

**Objects with Metadata/Physical Mismatch:**
```sql
SELECT 
  object_name,
  partition_name,
  COUNT(*) total_sampled,
  SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) not_compressed_count
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = <YOUR_RUN_ID>
  AND is_physically_compressed = 'N'
GROUP BY object_name, partition_name
ORDER BY not_compressed_count DESC;
```

**Compression Type Distribution:**
```sql
SELECT 
  compression_type,
  COUNT(*) row_count,
  ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) pct
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = <YOUR_RUN_ID>
GROUP BY compression_type
ORDER BY row_count DESC;
```

Use the provided query script for comprehensive analysis:
```bash
sqlplus / as sysdba @06_query_results.sql
```

---

## Key Implementation Details

### Handling Object Scope
- **Nonpartitioned tables**: Queries DBA_TABLES; samples with table name only
- **Partitioned tables**: Queries DBA_TAB_PARTITIONS; samples from specific partition
- **Subpartitioned tables**: Queries DBA_TAB_SUBPARTITIONS; samples from specific subpartition

When calling DBMS_COMPRESSION.GET_COMPRESSION_TYPE():
- `ownname`: schema name (uppercase)
- `tabname`: table name (uppercase)
- `partname`: partition/subpartition name for partitioned objects; NULL for nonpartitioned
- `blknum`: block number extracted from ROWID

### Efficient Sampling
- Uses SQL SAMPLE clause for random, efficient sampling
- Scales sample percentage based on object size
- Commits every 100 rows to prevent rollback segment exhaustion
- Read-only: No DML on application tables

### Error Handling
- Errors in individual sampling functions logged to DBMS_OUTPUT
- Audit continues even if individual partitions/tables fail
- Detailed error messages recorded in RUN_LOG.error_message
- Compression checks default to COMP_NOCOMPRESS on error (conservative approach)

---

## Compression Types Reference

| Compression Type | Meaning |
|---|---|
| COMP_NOCOMPRESS | No compression applied |
| COMP_FOR_OLTP | OLTP-level compression |
| COMP_FOR_QUERY_LOW | Query compression (low) |
| COMP_FOR_QUERY_HIGH | Query compression (high) |
| COMP_HYBRID | Hybrid compression |

---

## Troubleshooting

### "No active configuration found"
- Check COMPRESSION_AUDIT_CONFIG.is_active = 'Y'
- Verify schema_name is in uppercase

### "ORA-28024: Selected bind variable does not exist"
- Ensure DBMS_COMPRESSION package is accessible
- Verify object names are valid in target schema

### "Partition/subpartition not found"
- Check partition names are in uppercase
- Verify partition/subpartition exists in DBA_TAB_PARTITIONS/DBA_TAB_SUBPARTITIONS

### Too many rows being sampled
- Reduce sample_size_per_obj in configuration
- Use SAMPLE clause limit approach

---

## Performance Considerations

### Sampling Strategy
- Default: 100 rows per object (configurable)
- Large tables: Use smaller sample size to reduce scan time
- Critical tables: Sample all rows (set sample_size_per_obj = 0)

### Execution Time
- Depends on:
  - Number of compressed objects
  - Sample size per object
  - Object size (for full-table sampling)
  - Network latency (if remote DBA)

### Storage Requirements
- Result row ~500 bytes each
- 1000 rows sampled from 100 objects = ~50 KB
- Results accumulate in COMPRESSION_AUDIT_RESULTS (consider archival strategy)

---

## Best Practices

1. **Run during off-peak hours** to minimize I/O impact
2. **Start with small sample sizes** (10-50 rows) to validate
3. **Archive results periodically** to manage table size
4. **Create multiple configs** for different schemas
5. **Schedule regular audits** (weekly/monthly) to track compression state
6. **Document findings** in audit trail (RUN_LOG) for DBA reference

---

## Files Included

| File | Purpose |
|---|---|
| 01_table_definitions.sql | Create infrastructure tables and sequences |
| 02_package_spec.sql | Package specification (API) |
| 03_package_body_v2_improved.sql | Package body (RECOMMENDED - uses SAMPLE clause) |
| 03_package_body.sql | Alternative package body (basic version) |
| 04_installation_guide.sql | Setup verification and preview |
| 05_execute_audit.sql | Execute audit and display immediate results |
| 06_query_results.sql | Comprehensive result analysis queries |
| 99_cleanup.sql | Remove all utility objects (caution!) |
| README.md | This file |

---

## Cleanup

To remove the utility:
```bash
sqlplus / as sysdba @99_cleanup.sql
```

**Warning:** This removes all tables, sequences, and package objects. Backup results first if needed.

---

## Example Workflow

```bash
# 1. Install
sqlplus / as sysdba @01_table_definitions.sql
sqlplus / as sysdba @02_package_spec.sql
sqlplus / as sysdba @03_package_body_v2_improved.sql

# 2. Verify
sqlplus / as sysdba @04_installation_guide.sql

# 3. Execute
sqlplus / as sysdba @05_execute_audit.sql

# 4. Analyze
sqlplus / as sysdba @06_query_results.sql

# 5. Export results
sqlplus / as sysdba @07_export_results.sql (custom script)

# 6. Cleanup (optional)
sqlplus / as sysdba @99_cleanup.sql
```

---

## Support and Customization

### Adding New Compression Types
Update `is_physically_compressed()` function in package body to recognize additional types.

### Extending Results Table
Add columns to COMPRESSION_AUDIT_RESULTS as needed:
- `object_size_mb`
- `estimated_compression_ratio`
- `cost_per_compression`

### Multi-Schema Audits
Insert multiple rows into COMPRESSION_AUDIT_CONFIG:
```sql
INSERT INTO COMPRESSION_AUDIT_CONFIG 
  (config_id, schema_name, sample_size_per_obj)
VALUES (2, 'SCHEMA_B', 50);
```

Then run execute_compression_audit for each config.

---

## Version History

| Version | Date | Changes |
|---|---|---|
| 1.0 | 2026-04-20 | Initial release for Oracle 19c |

---

## Author and License

**Created:** April 20, 2026

This utility is provided for production use on Oracle 19c Exadata environments. Use at your own risk and always test in non-production environments first.

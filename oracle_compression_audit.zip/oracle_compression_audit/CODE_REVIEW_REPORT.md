# PL/SQL Code Review Report
## Oracle 19c Exadata Compression Audit Utility

**Review Date:** April 20, 2026  
**Status:** ⚠️ **NOT READY FOR PRODUCTION** (Requires fixes)  
**Severity:** 4 Critical Issues, 3 High Issues, 5 Medium Issues

---

## Executive Summary

The compression audit utility has **solid architecture and good design patterns**, but contains **several critical issues that must be fixed before production deployment**. The issues range from potential SQL injection vulnerabilities to runtime errors and incomplete error handling.

**Recommendation:** Fix the 4 critical issues before deployment. Medium issues can be addressed in Phase 2.

---

## Critical Issues (🔴 Must Fix)

### 1. **SQL INJECTION VULNERABILITY in Dynamic SQL Queries**

**Severity:** 🔴 CRITICAL

**Location:**  
- `03_package_body_v2_improved.sql` → `sample_table_rows()`, lines 274-277
- `03_package_body_v2_improved.sql` → `sample_partition_rows()`, lines 336-339
- `03_package_body_v2_improved.sql` → `sample_subpartition_rows()`, lines 396-399

**Issue:**
```plsql
-- VULNERABLE CODE
l_sql := 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
         UPPER(p_table_name) || ' SAMPLE (' || l_sample_percent || ') ' ||
         'WHERE ROWNUM <= ' || p_sample_size;
OPEN l_cursor FOR l_sql;
```

**Problem:**
- Schema names, table names, and partition names are concatenated directly into SQL
- While you call `UPPER()`, this does NOT sanitize the input
- If a partition name contains `'` or `--` or `/*`, it can break the SQL
- Example attack: partition name = `P_2026_Q1' OR '1'='1` could cause SQL injection

**Risk:** Data exposure, unauthorized access, system compromise

**Fix:** Use bind variables or parameterized queries:

```plsql
-- FIXED VERSION (using dynamic SQL with bind variables)
l_sql := 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
         UPPER(p_table_name) || ' SAMPLE (' || l_sample_percent || ') ' ||
         'WHERE ROWNUM <= :max_rows';

OPEN l_cursor FOR l_sql USING p_sample_size;
```

**OR validate input with whitelist:**
```plsql
-- Validate partition name format (alphanumeric, underscore, $, #)
IF NOT REGEXP_LIKE(p_partition_name, '^[A-Z0-9_$#]+$', 'i') THEN
  RAISE_APPLICATION_ERROR(-20001, 'Invalid partition name format: ' || p_partition_name);
END IF;
```

**Impact if not fixed:** Production system vulnerability to SQL injection attacks

---

### 2. **DBMS_COMPRESSION.GET_COMPRESSION_TYPE() Call Missing Partition Name Parameter**

**Severity:** 🔴 CRITICAL

**Location:**  
- `03_package_body_v2_improved.sql` → `get_row_compression_type()`, lines 245-255

**Issue:**
```plsql
FUNCTION get_row_compression_type (
  p_schema_name IN VARCHAR2,
  p_table_name  IN VARCHAR2,
  p_rowid       IN ROWID
)
RETURN VARCHAR2
IS
  l_compression_type VARCHAR2(50);
  l_blknum           NUMBER;
BEGIN
  l_blknum := DBMS_ROWID.ROWID_BLOCK_NUMBER(p_rowid);
  
  DBMS_COMPRESSION.GET_COMPRESSION_TYPE(
    ownname      => UPPER(p_schema_name),
    tabname      => UPPER(p_table_name),
    partname     => NULL,  -- ❌ ALWAYS NULL - INCORRECT FOR PARTITIONED TABLES
    blknum       => l_blknum,
    comptype     => l_compression_type
  );
```

**Problem:**
- For partitioned tables, `partname` is always `NULL`
- DBMS_COMPRESSION.GET_COMPRESSION_TYPE() may return incorrect results for partitioned tables
- The function receives the partition name but doesn't pass it to DBMS_COMPRESSION

**Fix:**
```plsql
-- Add p_partition_name parameter to function signature
FUNCTION get_row_compression_type (
  p_schema_name     IN VARCHAR2,
  p_table_name      IN VARCHAR2,
  p_partition_name  IN VARCHAR2,  -- NEW PARAMETER
  p_rowid           IN ROWID
)
RETURN VARCHAR2
IS
  l_compression_type VARCHAR2(50);
  l_blknum           NUMBER;
BEGIN
  l_blknum := DBMS_ROWID.ROWID_BLOCK_NUMBER(p_rowid);
  
  DBMS_COMPRESSION.GET_COMPRESSION_TYPE(
    ownname  => UPPER(p_schema_name),
    tabname  => UPPER(p_table_name),
    partname => UPPER(p_partition_name),  -- ✅ USE PARAMETER
    blknum   => l_blknum,
    comptype => l_compression_type
  );
```

**Update all calls:**
```plsql
-- In sample_table_rows()
l_compression_type := get_row_compression_type(
  p_schema_name, p_table_name, NULL, l_rid  -- Pass NULL for nonpartitioned
);

-- In sample_partition_rows()
l_compression_type := get_row_compression_type(
  p_schema_name, p_table_name, p_partition_name, l_rid  -- Pass partition name
);

-- In sample_subpartition_rows()
l_compression_type := get_row_compression_type(
  p_schema_name, p_table_name, p_subpartition_name, l_rid  -- Pass subpartition name
);
```

**Impact if not fixed:** Compression types reported for partitioned tables will be INCORRECT. Main feature of utility fails.

---

### 3. **Cursor Not Closed in Error Path (Resource Leak)**

**Severity:** 🔴 CRITICAL

**Location:**  
- `03_package_body_v2_improved.sql` → All sampling functions (sample_table_rows, sample_partition_rows, sample_subpartition_rows)

**Issue:**
```plsql
BEGIN
  IF p_sample_size = 0 THEN
    l_sample_percent := 100;
  ELSE
    l_sample_percent := GREATEST(
      LEAST(100, ROUND(100.0 * p_sample_size / 10000, 2)),
      0.01
    );
  END IF;
  
  l_sql := 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
           UPPER(p_table_name) || ' SAMPLE (' || l_sample_percent || ') ' ||
           'WHERE ROWNUM <= ' || p_sample_size;
  
  OPEN l_cursor FOR l_sql;  -- ← If next line throws, cursor never closed
  
  LOOP
    FETCH l_cursor INTO l_rid;  -- ← If exception here
    EXIT WHEN l_cursor%NOTFOUND;
    
    -- ... processing ...
    
  END LOOP;
  
  CLOSE l_cursor;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    IF l_cursor%ISOPEN THEN  -- ← This check comes AFTER the OPEN
      CLOSE l_cursor;
    END IF;
    DBMS_OUTPUT.PUT_LINE('Error sampling ' || p_table_name || ': ' || SQLERRM);
END;
```

**Problem:**
- If `OPEN l_cursor FOR l_sql;` throws an exception before the cursor is actually opened (e.g., table doesn't exist), `l_cursor%ISOPEN` will raise `CURSOR_ALREADY_OPEN` or similar error
- Exception handler doesn't catch it properly
- Multiple runs could exhaust cursor limits

**Fix:**
```plsql
BEGIN
  IF p_sample_size = 0 THEN
    l_sample_percent := 100;
  ELSE
    l_sample_percent := GREATEST(
      LEAST(100, ROUND(100.0 * p_sample_size / 10000, 2)),
      0.01
    );
  END IF;
  
  l_sql := 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
           UPPER(p_table_name) || ' SAMPLE (' || l_sample_percent || ') ' ||
           'WHERE ROWNUM <= ' || p_sample_size;
  
  BEGIN  -- ← Nested exception block
    OPEN l_cursor FOR l_sql;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Error opening cursor for ' || p_table_name || ': ' || SQLERRM);
      RETURN 0;  -- Return early if can't open cursor
  END;
  
  LOOP
    FETCH l_cursor INTO l_rid;
    EXIT WHEN l_cursor%NOTFOUND;
    
    -- ... processing ...
    
  END LOOP;
  
  CLOSE l_cursor;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      IF l_cursor%ISOPEN THEN
        CLOSE l_cursor;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN NULL;  -- Suppress cursor errors
    END;
    DBMS_OUTPUT.PUT_LINE('Error sampling ' || p_table_name || ': ' || SQLERRM);
    RETURN l_rows_sampled;  -- Return partial count
END;
```

**Impact if not fixed:** Cursor resource leaks, eventual "Too many open cursors" error after multiple runs

---

### 4. **Missing Commit/Rollback in Exception Paths Can Leave Transactions Open**

**Severity:** 🔴 CRITICAL

**Location:**  
- `03_package_body_v2_improved.sql` → execute_compression_audit(), lines 135-138 (outer exception block)

**Issue:**
```plsql
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    l_error_msg := 'No active configuration found';
    UPDATE COMPRESSION_AUDIT_RUN_LOG
    SET status = 'FAILED', error_message = l_error_msg, end_time = SYSTIMESTAMP
    WHERE audit_run_id = l_run_id;
    COMMIT;  -- ← Good, commits the error state
    RAISE;   -- ← Then raises exception
  WHEN OTHERS THEN
    l_error_msg := SUBSTR(SQLERRM, 1, 1000);
    UPDATE COMPRESSION_AUDIT_RUN_LOG
    SET status = 'FAILED', error_message = l_error_msg, end_time = SYSTIMESTAMP
    WHERE audit_run_id = l_run_id;
    COMMIT;
    RAISE;   -- ← Raising exception here
END;
```

**Problem:**
- When `RAISE` is executed, the calling code may not handle it properly
- If the caller doesn't COMMIT or ROLLBACK, any partial inserts in COMPRESSION_AUDIT_RESULTS will remain uncommitted
- Some rows might be committed (every 100 rows), some might be rolled back
- Results table could end up with inconsistent state

**Better approach:**
```plsql
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    l_error_msg := 'No active configuration found';
    UPDATE COMPRESSION_AUDIT_RUN_LOG
    SET status = 'FAILED', error_message = l_error_msg, end_time = SYSTIMESTAMP
    WHERE audit_run_id = l_run_id;
    COMMIT;
    -- Don't re-raise; return the run_id so caller can check status
    RETURN;
  WHEN OTHERS THEN
    l_error_msg := SUBSTR(SQLERRM, 1, 1000);
    -- Attempt to rollback partial results
    ROLLBACK;
    UPDATE COMPRESSION_AUDIT_RUN_LOG
    SET status = 'FAILED', error_message = l_error_msg, end_time = SYSTIMESTAMP
    WHERE audit_run_id = l_run_id;
    COMMIT;
    -- Don't re-raise
    RETURN;
END;
```

**Impact if not fixed:** Inconsistent audit results after errors. Some rows committed, some not.

---

## High Issues (🟠 Should Fix)

### 5. **Incorrect Dynamic SQL Syntax - SAMPLE Clause Placement**

**Severity:** 🟠 HIGH

**Location:**  
- `03_package_body_v2_improved.sql` → sample_table_rows(), line 276-278

**Issue:**
```plsql
l_sql := 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
         UPPER(p_table_name) || ' SAMPLE (' || l_sample_percent || ') ' ||
         'WHERE ROWNUM <= ' || p_sample_size;
```

**Problem:**
- Oracle's SAMPLE clause syntax is: `SELECT ... FROM table_name SAMPLE (percentage) WHERE ...`
- But you're mixing ROWNUM with SAMPLE clause
- SAMPLE returns approximate number of rows, but ROWNUM limits are applied AFTER sampling
- This could cause unexpected behavior: you might get fewer rows than requested

**Oracle Documentation:** 
- SAMPLE(x) = approximately x% of blocks
- ROWNUM <= N = returns exactly N rows from those blocks
- These don't work together well for precise control

**Fix:**
```plsql
-- Option 1: Use SAMPLE alone for percentage-based sampling
IF p_sample_size = 0 THEN
  l_sql := 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
           UPPER(p_table_name);
ELSE
  l_sql := 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
           UPPER(p_table_name) || ' SAMPLE (' || l_sample_percent || ')';
END IF;

-- OR Option 2: Use ROWNUM alone without SAMPLE
l_sql := 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
         UPPER(p_table_name) || ' WHERE ROWNUM <= ' || p_sample_size;
```

**Impact if not fixed:** Sampling may return inconsistent number of rows per table

---

### 6. **Error Handling Using DBMS_OUTPUT Not Suitable for Production**

**Severity:** 🟠 HIGH

**Location:**  
- Multiple locations using `DBMS_OUTPUT.PUT_LINE()` for error logging

**Issue:**
```plsql
EXCEPTION
  WHEN OTHERS THEN
    IF l_cursor%ISOPEN THEN
      CLOSE l_cursor;
    END IF;
    DBMS_OUTPUT.PUT_LINE('Error sampling ' || p_table_name || ': ' || SQLERRM);
END;
```

**Problem:**
- Errors logged only to DBMS_OUTPUT (requires `SET SERVEROUTPUT ON`)
- If run in DBMS_SCHEDULER job, output is lost
- No persistent error log
- Errors go to session output, not to audit trail table
- If running silently (background job), errors disappear

**Fix:**
```plsql
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      IF l_cursor%ISOPEN THEN
        CLOSE l_cursor;
      END IF;
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
    
    -- Log to database, not just DBMS_OUTPUT
    INSERT INTO COMPRESSION_AUDIT_ERROR_LOG (
      audit_run_id, object_name, error_message, error_time
    ) VALUES (
      p_audit_run_id, p_table_name, SUBSTR(SQLERRM, 1, 1000), SYSTIMESTAMP
    );
    COMMIT;
    
    -- Also output for interactive use
    DBMS_OUTPUT.PUT_LINE('Error sampling ' || p_table_name || ': ' || SQLERRM);
END;
```

**Impact if not fixed:** Production errors won't be logged; troubleshooting becomes difficult

---

### 7. **No Timeout Protection - Could Run Forever on Hung Tables**

**Severity:** 🟠 HIGH

**Location:**  
- All sampling functions lack timeout mechanism

**Issue:**
```plsql
LOOP
  FETCH l_cursor INTO l_rid;
  EXIT WHEN l_cursor%NOTFOUND;
  
  -- Get compression type - could hang if table lock issue
  l_compression_type := get_row_compression_type(
    p_schema_name, p_table_name, l_rid
  );
  
  -- Insert could hang if tablespace full
  INSERT INTO COMPRESSION_AUDIT_RESULTS (...) VALUES (...);
```

**Problem:**
- No protection against long-running operations
- If database has lock contention, audit could hang indefinitely
- If COMPRESSION_AUDIT_RESULTS tablespace fills up, INSERTs hang
- Background DBMS_SCHEDULER jobs will accumulate

**Fix:**
```plsql
-- Add to package initialization
g_max_execution_time_minutes NUMBER := 60;  -- Configurable timeout

-- Add elapsed time check in loops
l_start_loop_time := SYSTIMESTAMP;
LOOP
  FETCH l_cursor INTO l_rid;
  EXIT WHEN l_cursor%NOTFOUND;
  
  -- Check elapsed time
  IF TRUNC((SYSTIMESTAMP - l_start_loop_time) * 24 * 60) > g_max_execution_time_minutes THEN
    DBMS_OUTPUT.PUT_LINE('Warning: Timeout approaching, stopping audit');
    EXIT;
  END IF;
  
  l_compression_type := get_row_compression_type(
    p_schema_name, p_table_name, l_rid
  );
  
  INSERT INTO COMPRESSION_AUDIT_RESULTS (...) VALUES (...);
  l_rows_sampled := l_rows_sampled + 1;
  
  IF MOD(l_rows_sampled, 100) = 0 THEN
    COMMIT;
  END IF;
END LOOP;
```

**Impact if not fixed:** Audit jobs could hang indefinitely in production

---

## Medium Issues (🟡 Consider Fixing)

### 8. **Inefficient Cursor WHERE Condition with ROWNUM**

**Severity:** 🟡 MEDIUM

**Issue:** Using `ROWNUM <= p_sample_size` in dynamic SQL is inefficient. Oracle evaluates ROWNUM before ORDER BY.

**Recommendation:** Consider using `FETCH FIRST n ROWS ONLY` (Oracle 12c+) which is more efficient.

---

### 9. **No Validation of Input Parameters**

**Severity:** 🟡 MEDIUM

**Issue:** Functions don't validate inputs (schema_name, table_name, partition_name could be NULL or excessively long).

**Fix:** Add parameter validation at start of procedures:
```plsql
IF p_schema_name IS NULL THEN
  RAISE_APPLICATION_ERROR(-20001, 'schema_name cannot be NULL');
END IF;
IF LENGTH(p_schema_name) > 128 THEN
  RAISE_APPLICATION_ERROR(-20001, 'schema_name exceeds 128 characters');
END IF;
```

---

### 10. **Missing Index on COMPRESSION_AUDIT_RUN_LOG**

**Severity:** 🟡 MEDIUM

**Location:** 01_table_definitions.sql

**Issue:** Query `WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)` in 05_execute_audit.sql could be slow without index on `audit_run_id`.

**Current:** Only has index on `schema_name`

**Fix:** Add or ensure PRIMARY KEY index is used:
```sql
CREATE INDEX IDX_COMPRESSION_RUN_START_TIME 
  ON COMPRESSION_AUDIT_RUN_LOG(start_time DESC)
TABLESPACE USERS;
```

---

### 11. **Potential NULL Reference in Audit Summary**

**Severity:** 🟡 MEDIUM

**Location:** 03_package_body_v2_improved.sql → get_audit_summary()

**Issue:**
```plsql
ROUND(100.0 * SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) / 
      COUNT(*), 2) pct_metadata_only
```

**Problem:** If COUNT(*) = 0, division by zero could occur.

**Fix:**
```plsql
ROUND(100.0 * SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) / 
      NULLIF(COUNT(*), 0), 2) pct_metadata_only
```

---

## Production Readiness Assessment

| Category | Status | Issues |
|----------|--------|--------|
| **Code Quality** | ⚠️ POOR | SQL injection, resource leaks, missing parameters |
| **Error Handling** | ⚠️ POOR | No persistent logging, silent failures possible |
| **Security** | 🔴 CRITICAL | SQL injection vulnerability |
| **Maintainability** | ✅ GOOD | Well-commented, modular design |
| **Documentation** | ✅ EXCELLENT | 90 pages of docs |
| **Scalability** | ✅ GOOD | Sampling approach scales well |
| **Reliability** | 🔴 CRITICAL | Resource leaks, transaction inconsistency |

---

## Remediation Plan

### Phase 1: Critical Fixes (MUST DO BEFORE PRODUCTION)
1. [ ] Fix SQL injection vulnerabilities (add input validation)
2. [ ] Add partition_name parameter to get_row_compression_type()
3. [ ] Fix cursor resource leak handling
4. [ ] Add persistent error logging (create COMPRESSION_AUDIT_ERROR_LOG table)

### Phase 2: High Priority
5. [ ] Fix SAMPLE + ROWNUM syntax
6. [ ] Replace DBMS_OUTPUT with proper logging
7. [ ] Add timeout protection mechanism
8. [ ] Add parameter validation

### Phase 3: Medium Priority (Nice to Have)
9. [ ] Optimize ROWNUM with FETCH FIRST
10. [ ] Add additional indices
11. [ ] Fix division by zero in summary query

---

## Recommended Pre-Deployment Changes

### File: 01_table_definitions.sql
**ADD** new error logging table:
```sql
CREATE TABLE COMPRESSION_AUDIT_ERROR_LOG (
    error_id        NUMBER PRIMARY KEY,
    audit_run_id    NUMBER,
    object_name     VARCHAR2(128),
    error_message   VARCHAR2(1000),
    error_time      TIMESTAMP,
    CONSTRAINT fk_error_run FOREIGN KEY (audit_run_id)
      REFERENCES COMPRESSION_AUDIT_RUN_LOG(audit_run_id) ON DELETE CASCADE
);

CREATE SEQUENCE SEQ_COMPRESSION_AUDIT_ERROR
  START WITH 1 INCREMENT BY 1 NOCYCLE;
```

### File: 03_package_body_v2_improved.sql
**MODIFY:** get_row_compression_type() to accept partition_name
**MODIFY:** All sampling functions to pass partition_name to get_row_compression_type()
**MODIFY:** Exception handling to use persistent logging
**ADD:** Input validation for all parameters
**FIX:** SQL injection via input validation/whitelist

---

## Testing Recommendations Before Production

1. **SQL Injection Test:** Try partition names with special characters (`'`, `"`, `--`, `/**/`)
2. **Concurrent Audit Test:** Run multiple audits simultaneously; check for cursor exhaustion
3. **Large Table Test:** Run on table with millions of rows; verify no hangs
4. **Error Scenario Test:** Fill tablespace; verify error handling
5. **Rollback Test:** Verify data consistency after forced errors
6. **Long-running Test:** Let audit run for 2+ hours; verify no memory leaks

---

## Final Verdict

### **🔴 NOT READY FOR PRODUCTION**

**Can it run?** Yes, it will likely work for basic usage.

**Will it run safely in production?** No.

**Risk Level:** MEDIUM-HIGH due to:
- SQL injection vulnerability (security risk)
- Resource leaks (eventual system failure)
- Silent error handling (operational blindness)

**Recommendation:** Fix the 4 critical issues, then it can be deployed to production with caution.

**Estimated fix time:** 4-6 hours

---

## Summary of Changes Needed

```
CRITICAL (BLOCK PRODUCTION):
  ❌ SQL Injection in dynamic SQL (3 locations)
  ❌ Missing partition_name in DBMS_COMPRESSION call
  ❌ Cursor not properly closed in error paths
  ❌ Transaction/rollback inconsistency

HIGH (MUST FIX):
  ⚠️ Fix SAMPLE + ROWNUM syntax
  ⚠️ Replace DBMS_OUTPUT with persistent logging
  ⚠️ Add timeout protection

MEDIUM (SHOULD FIX):
  ℹ️ Add parameter validation
  ℹ️ Fix division by zero
  ℹ️ Add error log table
```

---

**Next Step:** Would you like me to create fixed versions of these files with all critical issues resolved?

/*
 * Oracle 19c Exadata Compression Audit Utility
 * Table Definitions for Configuration and Results Storage
 * 
 * Description:
 *   This script creates the infrastructure tables for the compression audit utility.
 *   - COMPRESSION_AUDIT_CONFIG: Configuration-driven parameters
 *   - COMPRESSION_AUDIT_RESULTS: Detailed findings from compression checks
 * 
 * Prerequisites:
 *   - Run as DBA or user with CREATE TABLE privilege
 *   - Adjust TABLESPACE_NAME to match your environment
 * 
 * Usage:
 *   sqlplus / as sysdba @01_table_definitions.sql
 */

SET ECHO ON
SET FEEDBACK ON
SET LINESIZE 120
SET PAGESIZE 50

-- ============================================================================
-- Configuration Table: Stores audit job parameters
-- ============================================================================
CREATE TABLE COMPRESSION_AUDIT_CONFIG (
    config_id          NUMBER PRIMARY KEY,
    schema_name        VARCHAR2(128) NOT NULL,
    sample_size_per_obj NUMBER DEFAULT 100,
    scan_timestamp     TIMESTAMP DEFAULT SYSTIMESTAMP,
    is_active          CHAR(1) DEFAULT 'Y',
    description        VARCHAR2(500),
    created_date       TIMESTAMP DEFAULT SYSTIMESTAMP,
    created_by         VARCHAR2(128) DEFAULT USER,
    modified_date      TIMESTAMP,
    modified_by        VARCHAR2(128)
)
TABLESPACE USERS
/

CREATE INDEX IDX_COMPRESSION_CONFIG_ACTIVE 
  ON COMPRESSION_AUDIT_CONFIG(is_active, schema_name)
TABLESPACE USERS
/

COMMENT ON TABLE COMPRESSION_AUDIT_CONFIG IS 
'Configuration table for compression audit scans. Each row defines a schema and sampling parameters.'
/

COMMENT ON COLUMN COMPRESSION_AUDIT_CONFIG.config_id IS 
'Unique identifier for configuration record'
/

COMMENT ON COLUMN COMPRESSION_AUDIT_CONFIG.schema_name IS 
'Target schema name (uppercase, as stored in DBA_TABLES.OWNER)'
/

COMMENT ON COLUMN COMPRESSION_AUDIT_CONFIG.sample_size_per_obj IS 
'Number of rows to sample from each object; 0 means sample all rows'
/

COMMENT ON COLUMN COMPRESSION_AUDIT_CONFIG.is_active IS 
'Y/N flag; only active configs are processed'
/

-- ============================================================================
-- Results Table: Stores detailed audit findings
-- ============================================================================
CREATE TABLE COMPRESSION_AUDIT_RESULTS (
    result_id           NUMBER,
    schema_name         VARCHAR2(128) NOT NULL,
    object_name         VARCHAR2(128) NOT NULL,
    partition_name      VARCHAR2(128),
    subpartition_name   VARCHAR2(128),
    object_type         VARCHAR2(20),
    sampled_rowid       ROWID,
    compression_type    VARCHAR2(50),
    is_physically_compressed CHAR(1),
    scan_timestamp      TIMESTAMP NOT NULL,
    audit_run_id        NUMBER,
    notes               VARCHAR2(500),
    created_date        TIMESTAMP DEFAULT SYSTIMESTAMP,
    CONSTRAINT pk_compression_results PRIMARY KEY (result_id)
)
TABLESPACE USERS
/

CREATE SEQUENCE SEQ_COMPRESSION_AUDIT_RESULTS
  START WITH 1
  INCREMENT BY 1
  NOCYCLE
/

CREATE INDEX IDX_COMPRESSION_RESULTS_SCHEMA 
  ON COMPRESSION_AUDIT_RESULTS(schema_name, object_name)
TABLESPACE USERS
/

CREATE INDEX IDX_COMPRESSION_RESULTS_TIMESTAMP 
  ON COMPRESSION_AUDIT_RESULTS(scan_timestamp DESC)
TABLESPACE USERS
/

CREATE INDEX IDX_COMPRESSION_RESULTS_AUDIT_RUN 
  ON COMPRESSION_AUDIT_RESULTS(audit_run_id)
TABLESPACE USERS
/

COMMENT ON TABLE COMPRESSION_AUDIT_RESULTS IS 
'Results of compression audit scans. Each row represents one sampled row from one object.'
/

COMMENT ON COLUMN COMPRESSION_AUDIT_RESULTS.compression_type IS 
'Output from DBMS_COMPRESSION.GET_COMPRESSION_TYPE: COMP_NOCOMPRESS, COMP_FOR_OLTP, COMP_FOR_QUERY_LOW, COMP_FOR_QUERY_HIGH, etc.'
/

COMMENT ON COLUMN COMPRESSION_AUDIT_RESULTS.is_physically_compressed IS 
'Y if compression_type is not COMP_NOCOMPRESS; N otherwise. Flags "metadata compressed but not physically compressed".'
/

COMMENT ON COLUMN COMPRESSION_AUDIT_RESULTS.audit_run_id IS 
'Correlates rows from a single audit run for batch processing and reporting.'
/

-- ============================================================================
-- Audit Run Log: Track each execution
-- ============================================================================
CREATE TABLE COMPRESSION_AUDIT_RUN_LOG (
    audit_run_id        NUMBER PRIMARY KEY,
    config_id           NUMBER REFERENCES COMPRESSION_AUDIT_CONFIG(config_id),
    schema_name         VARCHAR2(128) NOT NULL,
    start_time          TIMESTAMP DEFAULT SYSTIMESTAMP,
    end_time            TIMESTAMP,
    total_objects_checked NUMBER,
    total_rows_sampled  NUMBER,
    rows_metadata_compressed_no_physical NUMBER,
    status              VARCHAR2(20),
    error_message       VARCHAR2(1000),
    created_by          VARCHAR2(128) DEFAULT USER
)
TABLESPACE USERS
/

CREATE SEQUENCE SEQ_COMPRESSION_AUDIT_RUN
  START WITH 1
  INCREMENT BY 1
  NOCYCLE
/

CREATE INDEX IDX_COMPRESSION_RUN_SCHEMA 
  ON COMPRESSION_AUDIT_RUN_LOG(schema_name)
TABLESPACE USERS
/

COMMENT ON TABLE COMPRESSION_AUDIT_RUN_LOG IS 
'Log of each compression audit run for audit trail and performance tracking.'
/

-- ============================================================================
-- Create synonym for easier access (optional)
-- ============================================================================
-- CREATE PUBLIC SYNONYM COMPRESSION_AUDIT_CONFIG 
--   FOR COMPRESSION_AUDIT_CONFIG
-- /
-- CREATE PUBLIC SYNONYM COMPRESSION_AUDIT_RESULTS 
--   FOR COMPRESSION_AUDIT_RESULTS
-- /

-- ============================================================================
-- Initial Configuration Record (Sample)
-- ============================================================================
INSERT INTO COMPRESSION_AUDIT_CONFIG 
  (config_id, schema_name, sample_size_per_obj, description)
VALUES 
  (1, 'APPSCHEMA', 100, 'Primary application schema compression audit')
/

COMMIT
/

SET ECHO OFF
PROMPT
PROMPT ============================================================================
PROMPT Table definitions completed successfully.
PROMPT
PROMPT Created:
PROMPT   - COMPRESSION_AUDIT_CONFIG (PK: config_id)
PROMPT   - COMPRESSION_AUDIT_RESULTS (PK: result_id)
PROMPT   - COMPRESSION_AUDIT_RUN_LOG (PK: audit_run_id)
PROMPT   - Sequences and indexes
PROMPT
PROMPT Next Step: Create the PL/SQL package using 02_package_spec.sql
PROMPT ============================================================================

/*
 * Oracle 19c Exadata Compression Audit Utility
 * Package Body: PKG_COMPRESSION_AUDIT
 * 
 * Description:
 *   Complete implementation of compression audit logic. Includes:
 *   - Discovery queries against DBA_TABLES, DBA_TAB_PARTITIONS, DBA_TAB_SUBPARTITIONS
 *   - Row sampling with DBMS_COMPRESSION.GET_COMPRESSION_TYPE
 *   - Results persistence
 * 
 * Prerequisites:
 *   - COMPRESSION_AUDIT_CONFIG, COMPRESSION_AUDIT_RESULTS tables created
 *   - Access to DBMS_COMPRESSION package (Oracle 19c+)
 * 
 * Usage:
 *   sqlplus / as sysdba @03_package_body.sql
 */

CREATE OR REPLACE PACKAGE BODY PKG_COMPRESSION_AUDIT AS

  /**
   * Main entry point: Execute compression audit for all active configs
   */
  PROCEDURE execute_compression_audit (
    p_config_id     IN NUMBER DEFAULT NULL,
    p_audit_run_id  OUT NUMBER
  )
  IS
    l_run_id              NUMBER;
    l_config_id           NUMBER;
    l_schema_name         VARCHAR2(128);
    l_sample_size         NUMBER;
    l_table_count         NUMBER := 0;
    l_partition_count     NUMBER := 0;
    l_subpartition_count  NUMBER := 0;
    l_row_count           NUMBER := 0;
    l_rows_sampled        NUMBER := 0;
    l_metadata_only_count NUMBER := 0;
    l_start_time          TIMESTAMP;
    l_end_time            TIMESTAMP;
    l_error_msg           VARCHAR2(1000);
    
    -- Cursor for nonpartitioned tables
    CURSOR cur_nonpartitioned_tables(p_owner VARCHAR2) IS
      SELECT table_name, compress
      FROM DBA_TABLES
      WHERE owner = p_owner
        AND (compress = 'Y' OR compression != 'NONE')
      ORDER BY table_name;
    
    -- Cursor for partitioned tables
    CURSOR cur_table_partitions(p_owner VARCHAR2) IS
      SELECT DISTINCT table_name, partition_name, compression
      FROM DBA_TAB_PARTITIONS
      WHERE table_owner = p_owner
        AND (compress = 'Y' OR compression != 'NONE')
      ORDER BY table_name, partition_name;
    
    -- Cursor for subpartitioned tables
    CURSOR cur_table_subpartitions(p_owner VARCHAR2) IS
      SELECT DISTINCT table_name, subpartition_name, compression
      FROM DBA_TAB_SUBPARTITIONS
      WHERE table_owner = p_owner
        AND (compress = 'Y' OR compression != 'NONE')
      ORDER BY table_name, subpartition_name;
  
  BEGIN
    l_start_time := SYSTIMESTAMP;
    
    -- Create new audit run record
    l_run_id := SEQ_COMPRESSION_AUDIT_RUN.NEXTVAL;
    p_audit_run_id := l_run_id;
    
    INSERT INTO COMPRESSION_AUDIT_RUN_LOG 
      (audit_run_id, config_id, schema_name, start_time, status)
    VALUES (l_run_id, p_config_id, NULL, l_start_time, 'RUNNING');
    COMMIT;
    
    -- Get list of configs to process
    BEGIN
      IF p_config_id IS NOT NULL THEN
        -- Process single config
        BEGIN
          SELECT config_id, schema_name, sample_size_per_obj
          INTO l_config_id, l_schema_name, l_sample_size
          FROM COMPRESSION_AUDIT_CONFIG
          WHERE config_id = p_config_id AND is_active = 'Y';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            l_error_msg := 'Config ID ' || p_config_id || ' not found or not active';
            RAISE;
        END;
      END IF;
      
      -- If no config specified, process all active configs
      IF p_config_id IS NULL THEN
        -- Process first active config (simplified for demonstration)
        -- In production, you might loop through all active configs
        SELECT config_id, schema_name, sample_size_per_obj
        INTO l_config_id, l_schema_name, l_sample_size
        FROM COMPRESSION_AUDIT_CONFIG
        WHERE is_active = 'Y'
        AND ROWNUM = 1;
      END IF;
      
      -- Update audit run with config
      UPDATE COMPRESSION_AUDIT_RUN_LOG
      SET config_id = l_config_id, schema_name = l_schema_name
      WHERE audit_run_id = l_run_id;
      
      -- ===================================================================
      -- NONPARTITIONED TABLES
      -- ===================================================================
      FOR rec_table IN cur_nonpartitioned_tables(l_schema_name) LOOP
        l_table_count := l_table_count + 1;
        l_row_count := sample_table_rows(
          p_schema_name => l_schema_name,
          p_table_name => rec_table.table_name,
          p_sample_size => l_sample_size,
          p_audit_run_id => l_run_id
        );
        l_rows_sampled := l_rows_sampled + l_row_count;
      END LOOP;
      
      -- ===================================================================
      -- PARTITIONED TABLES
      -- ===================================================================
      FOR rec_partition IN cur_table_partitions(l_schema_name) LOOP
        l_partition_count := l_partition_count + 1;
        l_row_count := sample_partition_rows(
          p_schema_name => l_schema_name,
          p_table_name => rec_partition.table_name,
          p_partition_name => rec_partition.partition_name,
          p_sample_size => l_sample_size,
          p_audit_run_id => l_run_id
        );
        l_rows_sampled := l_rows_sampled + l_row_count;
      END LOOP;
      
      -- ===================================================================
      -- SUBPARTITIONED TABLES
      -- ===================================================================
      FOR rec_subpartition IN cur_table_subpartitions(l_schema_name) LOOP
        l_subpartition_count := l_subpartition_count + 1;
        l_row_count := sample_subpartition_rows(
          p_schema_name => l_schema_name,
          p_table_name => rec_subpartition.table_name,
          p_subpartition_name => rec_subpartition.subpartition_name,
          p_sample_size => l_sample_size,
          p_audit_run_id => l_run_id
        );
        l_rows_sampled := l_rows_sampled + l_row_count;
      END LOOP;
      
      -- Count metadata-compressed-but-not-physically-compressed rows
      SELECT COUNT(*)
      INTO l_metadata_only_count
      FROM COMPRESSION_AUDIT_RESULTS
      WHERE audit_run_id = l_run_id
        AND is_physically_compressed = 'N';
      
      l_end_time := SYSTIMESTAMP;
      
      -- Update audit run with completion
      UPDATE COMPRESSION_AUDIT_RUN_LOG
      SET end_time = l_end_time,
          total_objects_checked = l_table_count + l_partition_count + l_subpartition_count,
          total_rows_sampled = l_rows_sampled,
          rows_metadata_compressed_no_physical = l_metadata_only_count,
          status = 'COMPLETED'
      WHERE audit_run_id = l_run_id;
      
      COMMIT;
      
      DBMS_OUTPUT.PUT_LINE('============================================');
      DBMS_OUTPUT.PUT_LINE('Compression Audit Complete');
      DBMS_OUTPUT.PUT_LINE('Run ID: ' || l_run_id);
      DBMS_OUTPUT.PUT_LINE('Schema: ' || l_schema_name);
      DBMS_OUTPUT.PUT_LINE('Tables checked: ' || l_table_count);
      DBMS_OUTPUT.PUT_LINE('Partitions checked: ' || l_partition_count);
      DBMS_OUTPUT.PUT_LINE('Subpartitions checked: ' || l_subpartition_count);
      DBMS_OUTPUT.PUT_LINE('Total rows sampled: ' || l_rows_sampled);
      DBMS_OUTPUT.PUT_LINE('Metadata-compressed-only rows: ' || l_metadata_only_count);
      DBMS_OUTPUT.PUT_LINE('============================================');
    
    EXCEPTION
      WHEN OTHERS THEN
        l_error_msg := SUBSTR(SQLERRM, 1, 1000);
        UPDATE COMPRESSION_AUDIT_RUN_LOG
        SET status = 'FAILED', error_message = l_error_msg, end_time = SYSTIMESTAMP
        WHERE audit_run_id = l_run_id;
        COMMIT;
        RAISE;
    END;
  
  END execute_compression_audit;

  /**
   * Discover all nonpartitioned tables with compression enabled
   */
  FUNCTION get_compressed_tables (
    p_schema_name IN VARCHAR2
  )
  RETURN SYS_REFCURSOR
  IS
    l_cursor SYS_REFCURSOR;
  BEGIN
    OPEN l_cursor FOR
      SELECT table_name, 
             compress, 
             compression,
             num_rows,
             blocks,
             avg_row_len
      FROM DBA_TABLES
      WHERE owner = UPPER(p_schema_name)
        AND (compress = 'Y' OR compression NOT IN ('NONE', 'NO'))
      ORDER BY table_name;
    RETURN l_cursor;
  END get_compressed_tables;

  /**
   * Discover all partitioned tables with compression enabled
   */
  FUNCTION get_compressed_table_partitions (
    p_schema_name IN VARCHAR2
  )
  RETURN SYS_REFCURSOR
  IS
    l_cursor SYS_REFCURSOR;
  BEGIN
    OPEN l_cursor FOR
      SELECT table_name, 
             partition_name, 
             compression,
             compress,
             num_rows,
             blocks
      FROM DBA_TAB_PARTITIONS
      WHERE table_owner = UPPER(p_schema_name)
        AND (compress = 'Y' OR compression NOT IN ('NONE', 'NO'))
      ORDER BY table_name, partition_name;
    RETURN l_cursor;
  END get_compressed_table_partitions;

  /**
   * Discover all subpartitioned tables with compression enabled
   */
  FUNCTION get_compressed_table_subpartitions (
    p_schema_name IN VARCHAR2
  )
  RETURN SYS_REFCURSOR
  IS
    l_cursor SYS_REFCURSOR;
  BEGIN
    OPEN l_cursor FOR
      SELECT table_name, 
             subpartition_name, 
             compression,
             compress,
             num_rows,
             blocks
      FROM DBA_TAB_SUBPARTITIONS
      WHERE table_owner = UPPER(p_schema_name)
        AND (compress = 'Y' OR compression NOT IN ('NONE', 'NO'))
      ORDER BY table_name, subpartition_name;
    RETURN l_cursor;
  END get_compressed_table_subpartitions;

  /**
   * Get actual compression type for a single row via ROWID
   */
  FUNCTION get_row_compression_type (
    p_schema_name IN VARCHAR2,
    p_table_name  IN VARCHAR2,
    p_rowid       IN ROWID
  )
  RETURN VARCHAR2
  IS
    l_compression_type VARCHAR2(50);
    l_cursor           NUMBER;
    l_rows             NUMBER;
    l_blknum           NUMBER;
    l_offset           NUMBER;
  BEGIN
    -- Extract block number and offset from ROWID
    l_blknum := DBMS_ROWID.ROWID_BLOCK_NUMBER(p_rowid);
    l_offset := DBMS_ROWID.ROWID_ROW_NUMBER(p_rowid);
    
    -- Use DBMS_COMPRESSION to determine compression type
    DBMS_COMPRESSION.GET_COMPRESSION_TYPE(
      ownname      => UPPER(p_schema_name),
      tabname      => UPPER(p_table_name),
      partname     => NULL,
      blknum       => l_blknum,
      comptype     => l_compression_type
    );
    
    RETURN NVL(l_compression_type, 'COMP_NOCOMPRESS');
  
  EXCEPTION
    WHEN OTHERS THEN
      -- If error occurs, assume no compression
      RETURN 'COMP_NOCOMPRESS';
  END get_row_compression_type;

  /**
   * Check if a compression type indicates physical compression
   */
  FUNCTION is_physically_compressed (
    p_compression_type IN VARCHAR2
  )
  RETURN CHAR
  IS
  BEGIN
    IF p_compression_type IN ('COMP_NOCOMPRESS', 'COMP_NONE') THEN
      RETURN 'N';
    ELSE
      RETURN 'Y';
    END IF;
  END is_physically_compressed;

  /**
   * Sample rows from a nonpartitioned table
   */
  FUNCTION sample_table_rows (
    p_schema_name   IN VARCHAR2,
    p_table_name    IN VARCHAR2,
    p_sample_size   IN NUMBER,
    p_audit_run_id  IN NUMBER
  )
  RETURN NUMBER
  IS
    l_rows_sampled     NUMBER := 0;
    l_compression_type VARCHAR2(50);
    l_is_compressed    CHAR(1);
    
    CURSOR cur_sample_rows IS
      SELECT ROWID
      FROM (
        SELECT ROWID, ROW_NUMBER() OVER (ORDER BY ROWID) rn
        FROM TABLE(CAST(
          MULTISET(
            SELECT ROWID
            FROM (
              SELECT ROWID
              FROM TABLE(
                CAST(
                  MULTISET(
                    EXECUTE IMMEDIATE 'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || UPPER(p_table_name)
                  )
                  AS SYS.ODCIVARCHAR2LIST
                )
              )
              ORDER BY DBMS_RANDOM.RANDOM
            )
            WHERE ROWNUM <= NVL(p_sample_size, 1000000)
          )
          AS SYS.ODCIVARCHAR2LIST
        ))
      )
      WHERE ROWNUM <= NVL(p_sample_size, 1000000);
  
  BEGIN
    -- Simplified sampling: get first p_sample_size rows
    BEGIN
      FOR rec_row IN (
        SELECT ROWID rid
        FROM (
          SELECT ROWID, ROW_NUMBER() OVER (ORDER BY ROWID) rn
          FROM (
            SELECT ROWID
            FROM (
              SELECT * FROM TABLE(CAST(
                EXECUTE IMMEDIATE 
                  'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || UPPER(p_table_name)
              AS SYS.ODCIVARCHAR2LIST))
            )
          )
        )
        WHERE (p_sample_size = 0 OR rn <= p_sample_size)
      ) LOOP
        -- Get compression type for this row
        l_compression_type := get_row_compression_type(
          p_schema_name, p_table_name, rec_row.rid
        );
        
        l_is_compressed := is_physically_compressed(l_compression_type);
        
        -- Insert result
        INSERT INTO COMPRESSION_AUDIT_RESULTS (
          result_id, schema_name, object_name, object_type,
          sampled_rowid, compression_type, is_physically_compressed,
          scan_timestamp, audit_run_id
        ) VALUES (
          SEQ_COMPRESSION_AUDIT_RESULTS.NEXTVAL,
          UPPER(p_schema_name), UPPER(p_table_name), 'TABLE',
          rec_row.rid, l_compression_type, l_is_compressed,
          SYSTIMESTAMP, p_audit_run_id
        );
        
        l_rows_sampled := l_rows_sampled + 1;
        
        -- Commit every N rows to avoid excessive rollback segment usage
        IF MOD(l_rows_sampled, 100) = 0 THEN
          COMMIT;
        END IF;
      
      END LOOP;
      
      COMMIT;
    
    EXCEPTION
      WHEN OTHERS THEN
        -- Log error but continue
        DBMS_OUTPUT.PUT_LINE('Error sampling ' || p_table_name || ': ' || SQLERRM);
    END;
    
    RETURN l_rows_sampled;
  
  END sample_table_rows;

  /**
   * Sample rows from a table partition
   */
  FUNCTION sample_partition_rows (
    p_schema_name     IN VARCHAR2,
    p_table_name      IN VARCHAR2,
    p_partition_name  IN VARCHAR2,
    p_sample_size     IN NUMBER,
    p_audit_run_id    IN NUMBER
  )
  RETURN NUMBER
  IS
    l_rows_sampled     NUMBER := 0;
    l_compression_type VARCHAR2(50);
    l_is_compressed    CHAR(1);
  
  BEGIN
    BEGIN
      FOR rec_row IN (
        SELECT ROWID rid, ROW_NUMBER() OVER (ORDER BY ROWID) rn
        FROM (
          SELECT ROWID
          FROM TABLE(
            CAST(
              EXECUTE IMMEDIATE 
                'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
                UPPER(p_table_name) || ' PARTITION (' || UPPER(p_partition_name) || ')'
            AS SYS.ODCIVARCHAR2LIST
          )
        )
      )
      WHERE (p_sample_size = 0 OR rn <= p_sample_size)
      ) LOOP
        
        l_compression_type := get_row_compression_type(
          p_schema_name, p_table_name, rec_row.rid
        );
        
        l_is_compressed := is_physically_compressed(l_compression_type);
        
        INSERT INTO COMPRESSION_AUDIT_RESULTS (
          result_id, schema_name, object_name, partition_name, object_type,
          sampled_rowid, compression_type, is_physically_compressed,
          scan_timestamp, audit_run_id
        ) VALUES (
          SEQ_COMPRESSION_AUDIT_RESULTS.NEXTVAL,
          UPPER(p_schema_name), UPPER(p_table_name), UPPER(p_partition_name), 'PARTITION',
          rec_row.rid, l_compression_type, l_is_compressed,
          SYSTIMESTAMP, p_audit_run_id
        );
        
        l_rows_sampled := l_rows_sampled + 1;
        
        IF MOD(l_rows_sampled, 100) = 0 THEN
          COMMIT;
        END IF;
      
      END LOOP;
      
      COMMIT;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error sampling partition ' || p_partition_name || ': ' || SQLERRM);
    END;
    
    RETURN l_rows_sampled;
  
  END sample_partition_rows;

  /**
   * Sample rows from a table subpartition
   */
  FUNCTION sample_subpartition_rows (
    p_schema_name       IN VARCHAR2,
    p_table_name        IN VARCHAR2,
    p_subpartition_name IN VARCHAR2,
    p_sample_size       IN NUMBER,
    p_audit_run_id      IN NUMBER
  )
  RETURN NUMBER
  IS
    l_rows_sampled     NUMBER := 0;
    l_compression_type VARCHAR2(50);
    l_is_compressed    CHAR(1);
  
  BEGIN
    BEGIN
      FOR rec_row IN (
        SELECT ROWID rid, ROW_NUMBER() OVER (ORDER BY ROWID) rn
        FROM (
          SELECT ROWID
          FROM TABLE(
            CAST(
              EXECUTE IMMEDIATE 
                'SELECT ROWID FROM ' || UPPER(p_schema_name) || '.' || 
                UPPER(p_table_name) || ' SUBPARTITION (' || UPPER(p_subpartition_name) || ')'
            AS SYS.ODCIVARCHAR2LIST
          )
        )
      )
      WHERE (p_sample_size = 0 OR rn <= p_sample_size)
      ) LOOP
        
        l_compression_type := get_row_compression_type(
          p_schema_name, p_table_name, rec_row.rid
        );
        
        l_is_compressed := is_physically_compressed(l_compression_type);
        
        INSERT INTO COMPRESSION_AUDIT_RESULTS (
          result_id, schema_name, object_name, subpartition_name, object_type,
          sampled_rowid, compression_type, is_physically_compressed,
          scan_timestamp, audit_run_id
        ) VALUES (
          SEQ_COMPRESSION_AUDIT_RESULTS.NEXTVAL,
          UPPER(p_schema_name), UPPER(p_table_name), UPPER(p_subpartition_name), 'SUBPARTITION',
          rec_row.rid, l_compression_type, l_is_compressed,
          SYSTIMESTAMP, p_audit_run_id
        );
        
        l_rows_sampled := l_rows_sampled + 1;
        
        IF MOD(l_rows_sampled, 100) = 0 THEN
          COMMIT;
        END IF;
      
      END LOOP;
      
      COMMIT;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error sampling subpartition ' || p_subpartition_name || ': ' || SQLERRM);
    END;
    
    RETURN l_rows_sampled;
  
  END sample_subpartition_rows;

  /**
   * Get summary report of audit findings
   */
  FUNCTION get_audit_summary (
    p_audit_run_id IN NUMBER
  )
  RETURN SYS_REFCURSOR
  IS
    l_cursor SYS_REFCURSOR;
  BEGIN
    OPEN l_cursor FOR
      SELECT 
        schema_name,
        object_name,
        NVL(partition_name, NVL(subpartition_name, 'N/A')) partition_info,
        COUNT(*) total_rows_sampled,
        SUM(CASE WHEN is_physically_compressed = 'Y' THEN 1 ELSE 0 END) physically_compressed_count,
        SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) metadata_only_count,
        ROUND(100.0 * SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) / 
              COUNT(*), 2) pct_metadata_only
      FROM COMPRESSION_AUDIT_RESULTS
      WHERE audit_run_id = p_audit_run_id
      GROUP BY schema_name, object_name, partition_name, subpartition_name
      ORDER BY schema_name, object_name, partition_info;
    
    RETURN l_cursor;
  END get_audit_summary;

END PKG_COMPRESSION_AUDIT;
/

SHOW ERRORS

PROMPT
PROMPT ============================================================================
PROMPT Package body created: PKG_COMPRESSION_AUDIT
PROMPT ============================================================================

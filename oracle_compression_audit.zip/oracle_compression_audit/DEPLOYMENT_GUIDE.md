# Oracle 19c Exadata Compression Audit Utility
## Complete Deployment Package

**Created:** April 20, 2026  
**Version:** 1.0  
**Target:** Oracle 19c Exadata  

---

## 📋 Package Contents

### Core Installation Files (In Order)

| File | Purpose | Role | Size |
|------|---------|------|------|
| [01_table_definitions.sql](01_table_definitions.sql) | Create audit infrastructure tables | REQUIRED | ~300 lines |
| [02_package_spec.sql](02_package_spec.sql) | Define PL/SQL package API | REQUIRED | ~150 lines |
| [03_package_body_v2_improved.sql](03_package_body_v2_improved.sql) | Implement package with SAMPLE clause | RECOMMENDED | ~450 lines |
| [03_package_body.sql](03_package_body.sql) | Alternative implementation | Optional | ~450 lines |

### Usage and Operations Files

| File | Purpose | When to Use |
|------|---------|-----------|
| [04_installation_guide.sql](04_installation_guide.sql) | Verify installation, preview candidates | After installation, before first run |
| [05_execute_audit.sql](05_execute_audit.sql) | Run audit and display immediate results | Execute audits |
| [06_query_results.sql](06_query_results.sql) | Comprehensive result analysis (9 queries) | Analyze findings |
| [QUICK_REFERENCE.sql](QUICK_REFERENCE.sql) | Copy-paste quick start commands | Daily operations |

### Cleanup and Maintenance

| File | Purpose | Caution |
|------|---------|---------|
| [99_cleanup.sql](99_cleanup.sql) | Remove ALL audit objects | ⚠️ Removes all data - backup first |

### Documentation Files

| File | Purpose | Audience |
|------|---------|----------|
| [README.md](README.md) | Complete user manual | Everyone |
| [TECHNICAL_ARCHITECTURE.md](TECHNICAL_ARCHITECTURE.md) | Design patterns and deep dive | Developers, DBAs |
| [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) | This file | DBAs, DevOps |

---

## 🚀 Quick Start (5 Minutes)

### Step 1: Install Infrastructure (2 minutes)
```bash
sqlplus / as sysdba @01_table_definitions.sql
sqlplus / as sysdba @02_package_spec.sql
sqlplus / as sysdba @03_package_body_v2_improved.sql
```

### Step 2: Configure (1 minute)
```sql
UPDATE COMPRESSION_AUDIT_CONFIG
SET schema_name = 'YOUR_SCHEMA_NAME',
    sample_size_per_obj = 100,
    is_active = 'Y'
WHERE config_id = 1;
COMMIT;
```

### Step 3: Execute Audit (1-2 minutes)
```bash
sqlplus / as sysdba @05_execute_audit.sql
```

### Step 4: View Results (1 minute)
```bash
sqlplus / as sysdba @06_query_results.sql
```

---

## 📊 Installation Sequence

### For First-Time Users

```
┌─────────────────────────────────────────────┐
│ 01_table_definitions.sql                    │  Create infrastructure
│ Creates: COMPRESSION_AUDIT_CONFIG           │
│          COMPRESSION_AUDIT_RESULTS          │
│          COMPRESSION_AUDIT_RUN_LOG          │
│          Sequences and indices              │
└──────────────┬──────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────┐
│ 02_package_spec.sql                         │  Define API
│ Creates: PKG_COMPRESSION_AUDIT (SPEC)       │
└──────────────┬──────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────┐
│ 03_package_body_v2_improved.sql             │  Implement logic (RECOMMENDED)
│ Creates: PKG_COMPRESSION_AUDIT (BODY)       │  OR use 03_package_body.sql
└──────────────┬──────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────┐
│ 04_installation_guide.sql                   │  Verify + preview
│ Validates installation                      │
│ Shows candidate objects                     │
└──────────────┬──────────────────────────────┘
               │
               ▼
         ✓ Ready to audit
```

---

## 🔧 Configuration

### Update Target Schema (REQUIRED)

Before running audits, edit:
```sql
UPDATE COMPRESSION_AUDIT_CONFIG
SET schema_name = 'APPSCHEMA'      -- YOUR SCHEMA NAME (UPPERCASE)
WHERE config_id = 1;
COMMIT;
```

**Critical:** Schema name must be UPPERCASE and exactly match `DBA_TABLES.OWNER`.

### Sample Size Tuning

| Sample Size | Use Case | Duration |
|---|---|---|
| 10 | Survey many objects | <1 min |
| 50 | Quick health check | 1-2 min |
| 100 | Default, balanced | 2-5 min |
| 500 | Detailed analysis | 5-10 min |
| 0 | Full audit (all rows) | 10+ min |

---

## ▶️ Running Audits

### Method 1: Direct PL/SQL Call
```sql
DECLARE
  l_run_id NUMBER;
BEGIN
  PKG_COMPRESSION_AUDIT.execute_compression_audit(
    p_config_id => 1,
    p_audit_run_id => l_run_id
  );
  DBMS_OUTPUT.PUT_LINE('Audit Run ID: ' || l_run_id);
END;
/
```

### Method 2: Using Provided Script
```bash
sqlplus / as sysdba @05_execute_audit.sql
```
(Automatically displays results)

### Method 3: Scheduled (via DBMS_SCHEDULER)
```sql
BEGIN
  DBMS_SCHEDULER.CREATE_JOB(
    job_name => 'COMPRESSION_AUDIT_JOB',
    job_type => 'PLSQL_BLOCK',
    job_action => 'DECLARE l_run_id NUMBER; BEGIN 
                   PKG_COMPRESSION_AUDIT.execute_compression_audit(1, l_run_id);
                 END;',
    repeat_interval => 'FREQ=WEEKLY;BYDAY=SUN;BYHOUR=2;BYMINUTE=0',
    enabled => TRUE
  );
END;
/
```

---

## 📈 Viewing Results

### Quick Summary
```bash
sqlplus / as sysdba @06_query_results.sql
```
Displays 9 pre-built queries covering:
- Latest audit summary
- Metadata/physical mismatches
- Compression types found
- Objects fully compressed
- Row-level details
- Sampling coverage
- Efficiency assessment
- Audit history
- Compression breakdown

### Custom Query: Objects with Mismatches
```sql
SELECT object_name, partition_name,
       COUNT(*) total_sampled,
       SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) uncompressed_count
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
  AND is_physically_compressed = 'N'
GROUP BY object_name, partition_name
ORDER BY uncompressed_count DESC;
```

### Export to CSV
```bash
sqlplus / as sysdba <<EOF
SET ECHO OFF FEEDBACK OFF PAGESIZE 0 LINESIZE 32767 HEADING OFF
SPOOL results.csv
SELECT * FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
ORDER BY result_id;
SPOOL OFF
EXIT
EOF
```

---

## 🛡️ Production Considerations

### Pre-Deployment Checklist

- [ ] Test on non-production Oracle 19c instance
- [ ] Verify DBMS_COMPRESSION package available: `SELECT DBMS_COMPRESSION.GET_COMPRESSION_TYPE FROM DUAL;`
- [ ] Confirm DBA_TABLES view access: `SELECT COUNT(*) FROM DBA_TABLES;`
- [ ] Estimate time: Start with sample_size=10, measure duration
- [ ] Plan tablespace: Infrastructure tables need ~100 MB for 1M rows
- [ ] Backup config: Document baseline configuration before changes
- [ ] Permissions: User must have CREATE TABLE, CREATE SEQUENCE, EXECUTE on DBMS_COMPRESSION

### Runtime Considerations

1. **When to Run:**
   - Off-peak hours (2-4 AM)
   - During low-traffic windows
   - Not during critical batch processes

2. **Monitoring:**
   - Check COMPRESSION_AUDIT_RUN_LOG.status
   - Monitor COMPRESSION_AUDIT_RUN_LOG.error_message for failures
   - Track COMPRESSION_AUDIT_RUN_LOG.end_time - start_time for duration trends

3. **Resource Impact:**
   - Primarily read I/O on application tables
   - Write I/O to audit infrastructure (minimal)
   - CPU: Sampling + DBMS_COMPRESSION calls (moderate)
   - Memory: Configurable via PGA (not memory-intensive)

4. **Error Recovery:**
   - If audit fails: Check RUN_LOG.error_message
   - If partial results: Restart from same config_id (appends results)
   - To clean up failed run: `DELETE FROM COMPRESSION_AUDIT_RESULTS WHERE audit_run_id = <ID>;`

---

## 🧹 Maintenance

### Regular Tasks

**Weekly:**
```sql
-- Check for errors
SELECT audit_run_id, schema_name, status, error_message
FROM COMPRESSION_AUDIT_RUN_LOG
WHERE status = 'FAILED'
  AND start_time >= SYSDATE - 7
ORDER BY audit_run_id DESC;
```

**Monthly:**
```sql
-- Archive results older than 90 days
DELETE FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id IN (
  SELECT audit_run_id FROM COMPRESSION_AUDIT_RUN_LOG
  WHERE start_time < SYSDATE - 90
);
COMMIT;
```

**Quarterly:**
```sql
-- Rebuild indices
ALTER INDEX IDX_COMPRESSION_RESULTS_SCHEMA REBUILD;
ALTER INDEX IDX_COMPRESSION_RESULTS_TIMESTAMP REBUILD;
ALTER INDEX IDX_COMPRESSION_RESULTS_AUDIT_RUN REBUILD;
```

### Table Growth Monitoring

```sql
SELECT segment_name, bytes/1024/1024 size_mb
FROM user_segments
WHERE segment_name IN ('COMPRESSION_AUDIT_RESULTS', 'COMPRESSION_AUDIT_RUN_LOG')
ORDER BY bytes DESC;
```

---

## ❌ Cleanup

### Remove Everything (Use with Caution!)

```bash
sqlplus / as sysdba @99_cleanup.sql
```

This removes:
- Package PKG_COMPRESSION_AUDIT
- Tables COMPRESSION_AUDIT_CONFIG, COMPRESSION_AUDIT_RESULTS, COMPRESSION_AUDIT_RUN_LOG
- Sequences SEQ_COMPRESSION_AUDIT_RESULTS, SEQ_COMPRESSION_AUDIT_RUN
- All indices

**⚠️ WARNING:** This is destructive. Archive results first if needed.

### Selective Cleanup (Keep infrastructure, remove results)

```sql
DELETE FROM COMPRESSION_AUDIT_RESULTS;
DELETE FROM COMPRESSION_AUDIT_RUN_LOG;
TRUNCATE TABLE COMPRESSION_AUDIT_CONFIG;
COMMIT;
```

---

## 📞 Troubleshooting

### Common Issues

**Error: "No active configuration found"**
- Fix: `UPDATE COMPRESSION_AUDIT_CONFIG SET is_active = 'Y' WHERE config_id = 1;`

**Error: "ORA-28024: Selected bind variable does not exist"**
- Fix: Verify schema_name is UPPERCASE

**Error: "Table or view does not exist"**
- Fix: Check DBA_TABLES access: `SELECT COUNT(*) FROM DBA_TABLES;`

**Slow execution (>10 min)**
- Fix: Reduce sample_size or run during off-peak
- Check: Number of compressed objects: `SELECT COUNT(*) FROM DBA_TABLES WHERE compress = 'Y';`

**No results returned**
- Fix: Verify schema has compressed tables: 
  ```sql
  SELECT COUNT(*) FROM DBA_TABLES 
  WHERE owner = 'YOUR_SCHEMA' AND compress = 'Y';
  ```

### Debugging

1. Enable DBMS_OUTPUT:
   ```sql
   SET SERVEROUTPUT ON SIZE 10000;
   ```

2. Check package status:
   ```sql
   SELECT object_name, status FROM user_objects 
   WHERE object_name = 'PKG_COMPRESSION_AUDIT';
   ```

3. View error in last run:
   ```sql
   SELECT error_message FROM COMPRESSION_AUDIT_RUN_LOG 
   WHERE status = 'FAILED' 
   ORDER BY audit_run_id DESC FETCH FIRST 1 ROW ONLY;
   ```

---

## 📚 Documentation

| Document | Contents |
|----------|----------|
| README.md | User manual, installation, usage, examples |
| TECHNICAL_ARCHITECTURE.md | Design patterns, optimization, extensions |
| DEPLOYMENT_GUIDE.md | This file - quick reference for DBAs |
| QUICK_REFERENCE.sql | Copy-paste snippets for common tasks |

---

## 🎯 Success Criteria

After deployment, verify:

1. ✅ All 3 tables created
2. ✅ Package compiles without errors
3. ✅ 04_installation_guide.sql shows objects to audit
4. ✅ Audit completes successfully (check RUN_LOG.status = 'COMPLETED')
5. ✅ Results inserted (check count from COMPRESSION_AUDIT_RESULTS)
6. ✅ Mismatches identified (check for is_physically_compressed = 'N')
7. ✅ Scheduled job runs on schedule (if using DBMS_SCHEDULER)

---

## Version and Support

| Property | Value |
|----------|-------|
| Version | 1.0 |
| Release Date | April 20, 2026 |
| Target DB | Oracle 19c Exadata |
| Status | Production-ready |
| Last Updated | April 20, 2026 |

---

## Quick Links

- [Installation Instructions](README.md#installation)
- [Configuration Guide](README.md#configuration)
- [Query Examples](QUICK_REFERENCE.sql)
- [Technical Deep Dive](TECHNICAL_ARCHITECTURE.md)
- [Troubleshooting Guide](#troubleshooting)

---

**Happy auditing! 🚀**

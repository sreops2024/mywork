/*
 * Oracle 19c Exadata Compression Audit Utility
 * Query and Analysis Script
 * 
 * Usage:
 *   sqlplus / as sysdba @06_query_results.sql
 * 
 * This script provides various analysis queries on audit results:
 *   - Summary by object
 *   - Detailed row-level examination
 *   - Compression type statistics
 *   - Compression efficiency analysis
 */

SET ECHO OFF
SET FEEDBACK ON
SET PAGESIZE 50
SET LINESIZE 150
SET COLSEP |

-- ============================================================================
-- QUERY 1: Latest Audit Summary
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Query 1: Latest Audit Run Summary
PROMPT ============================================================

SELECT 
  audit_run_id,
  schema_name,
  TO_CHAR(start_time, 'YYYY-MM-DD HH24:MI:SS') start_time,
  TO_CHAR(end_time, 'YYYY-MM-DD HH24:MI:SS') end_time,
  ROUND((CAST(end_time AS DATE) - CAST(start_time AS DATE)) * 86400, 2) duration_sec,
  total_objects_checked,
  total_rows_sampled,
  rows_metadata_compressed_no_physical
FROM COMPRESSION_AUDIT_RUN_LOG
WHERE status = 'COMPLETED'
ORDER BY audit_run_id DESC
FETCH FIRST 1 ROW ONLY;

-- ============================================================================
-- QUERY 2: Metadata vs Physical Compression Mismatch Summary
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Query 2: Objects with Metadata/Physical Mismatch
PROMPT (Marked as compressed in metadata, but rows are NOT physically compressed)
PROMPT ============================================================

SELECT 
  schema_name,
  object_name,
  object_type,
  NVL(partition_name, NVL(subpartition_name, 'NONPARTITIONED')) segment_name,
  COUNT(*) total_sampled,
  SUM(CASE WHEN is_physically_compressed = 'Y' THEN 1 ELSE 0 END) actually_compressed,
  SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) not_compressed,
  ROUND(100.0 * SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) / 
        COUNT(*), 2) pct_not_compressed
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
GROUP BY schema_name, object_name, object_type, partition_name, subpartition_name
HAVING SUM(CASE WHEN is_physically_compressed = 'N' THEN 1 ELSE 0 END) > 0
ORDER BY pct_not_compressed DESC, object_name;

-- ============================================================================
-- QUERY 3: Compression Types Distribution
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Query 3: Compression Types Found in Sampled Rows
PROMPT ============================================================
PROMPT

SELECT 
  compression_type,
  COUNT(*) row_count,
  ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) pct_total,
  CASE 
    WHEN compression_type = 'COMP_NOCOMPRESS' THEN 'No compression'
    WHEN compression_type = 'COMP_FOR_OLTP' THEN 'OLTP compression'
    WHEN compression_type = 'COMP_FOR_QUERY_LOW' THEN 'Query compression (Low)'
    WHEN compression_type = 'COMP_FOR_QUERY_HIGH' THEN 'Query compression (High)'
    WHEN compression_type = 'COMP_HYBRID' THEN 'Hybrid compression'
    ELSE 'Unknown: ' || compression_type
  END description
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
GROUP BY compression_type
ORDER BY row_count DESC;

-- ============================================================================
-- QUERY 4: Objects Fully Compressed
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Query 4: Objects with All Sampled Rows Physically Compressed
PROMPT ============================================================
PROMPT

SELECT 
  schema_name,
  object_name,
  object_type,
  NVL(partition_name, NVL(subpartition_name, 'NONPARTITIONED')) segment_name,
  COUNT(*) total_sampled,
  MIN(compression_type) compression_type,
  'FULLY COMPRESSED' status
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
  AND is_physically_compressed = 'Y'
GROUP BY schema_name, object_name, object_type, partition_name, subpartition_name
HAVING COUNT(*) = 
  (SELECT MAX(rows_per_object)
   FROM (
     SELECT COUNT(*) rows_per_object
     FROM COMPRESSION_AUDIT_RESULTS r1
     WHERE r1.audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
       AND r1.schema_name = COMPRESSION_AUDIT_RESULTS.schema_name
       AND r1.object_name = COMPRESSION_AUDIT_RESULTS.object_name
       AND NVL(r1.partition_name, NVL(r1.subpartition_name, 'X')) = 
           NVL(COMPRESSION_AUDIT_RESULTS.partition_name, NVL(COMPRESSION_AUDIT_RESULTS.subpartition_name, 'X'))
   ))
ORDER BY object_name;

-- ============================================================================
-- QUERY 5: Detailed Row-Level Results (Top Metadata-Only Rows)
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Query 5: Detailed Row-Level Results - Sample Metadata-Only Rows
PROMPT ============================================================
PROMPT

SELECT 
  result_id,
  schema_name,
  object_name,
  object_type,
  NVL(partition_name, NVL(subpartition_name, 'N/A')) segment_name,
  sampled_rowid,
  compression_type,
  is_physically_compressed,
  TO_CHAR(scan_timestamp, 'YYYY-MM-DD HH24:MI:SS') scan_time
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
  AND is_physically_compressed = 'N'
ORDER BY result_id DESC
FETCH FIRST 50 ROWS ONLY;

-- ============================================================================
-- QUERY 6: Sampling Coverage Analysis
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Query 6: Sampling Coverage by Object
PROMPT ============================================================
PROMPT

WITH metadata_objects AS (
  SELECT 
    owner,
    table_name,
    'TABLE' object_type,
    NULL partition_name,
    compress,
    num_rows
  FROM DBA_TABLES
  WHERE owner IN (SELECT schema_name FROM COMPRESSION_AUDIT_CONFIG WHERE is_active = 'Y')
    AND (compress = 'Y' OR compression NOT IN ('NONE', 'NO'))
  
  UNION ALL
  
  SELECT 
    table_owner,
    table_name,
    'PARTITION',
    partition_name,
    compress,
    num_rows
  FROM DBA_TAB_PARTITIONS
  WHERE table_owner IN (SELECT schema_name FROM COMPRESSION_AUDIT_CONFIG WHERE is_active = 'Y')
    AND (compress = 'Y' OR compression NOT IN ('NONE', 'NO'))
)
SELECT 
  mo.owner schema_name,
  mo.table_name object_name,
  mo.object_type,
  NVL(mo.partition_name, 'N/A') segment,
  mo.num_rows metadata_rows,
  COUNT(car.result_id) sampled_rows,
  ROUND(100.0 * COUNT(car.result_id) / GREATEST(mo.num_rows, 1), 2) sample_coverage_pct
FROM metadata_objects mo
LEFT JOIN COMPRESSION_AUDIT_RESULTS car ON (
  car.schema_name = mo.owner
  AND car.object_name = mo.table_name
  AND car.partition_name = mo.partition_name
  AND car.audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
)
GROUP BY mo.owner, mo.table_name, mo.object_type, mo.partition_name, mo.num_rows
ORDER BY mo.owner, mo.table_name, mo.partition_name;

-- ============================================================================
-- QUERY 7: Compression Efficiency Assessment
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Query 7: Compression Efficiency Assessment
PROMPT ============================================================
PROMPT

SELECT 
  schema_name,
  object_name,
  object_type,
  COUNT(DISTINCT NVL(partition_name, NVL(subpartition_name, 'MAIN'))) num_segments,
  COUNT(*) total_rows_sampled,
  COUNT(DISTINCT compression_type) distinct_compression_types,
  LISTAGG(DISTINCT compression_type, ', ') WITHIN GROUP (ORDER BY compression_type) compression_types,
  CASE 
    WHEN COUNT(CASE WHEN is_physically_compressed = 'Y' THEN 1 END) = COUNT(*) 
      THEN 'FULLY_COMPRESSED'
    WHEN COUNT(CASE WHEN is_physically_compressed = 'Y' THEN 1 END) > 0 
      THEN 'PARTIALLY_COMPRESSED'
    ELSE 'NOT_COMPRESSED'
  END compression_status
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
GROUP BY schema_name, object_name, object_type
ORDER BY schema_name, object_name;

-- ============================================================================
-- QUERY 8: Audit History (Last 5 Runs)
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Query 8: Audit Execution History (Last 5 Runs)
PROMPT ============================================================
PROMPT

SELECT 
  audit_run_id,
  schema_name,
  status,
  TO_CHAR(start_time, 'YYYY-MM-DD HH24:MI:SS') start_time,
  ROUND((CAST(end_time AS DATE) - CAST(start_time AS DATE)) * 86400, 2) duration_sec,
  total_objects_checked,
  total_rows_sampled,
  rows_metadata_compressed_no_physical problem_rows,
  error_message
FROM COMPRESSION_AUDIT_RUN_LOG
ORDER BY audit_run_id DESC
FETCH FIRST 5 ROWS ONLY;

-- ============================================================================
-- QUERY 9: Custom - Find Rows by Compression Type
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Query 9: Count Rows by Compression Type (Latest Audit)
PROMPT ============================================================
PROMPT

SELECT 
  is_physically_compressed,
  compression_type,
  COUNT(*) row_count
FROM COMPRESSION_AUDIT_RESULTS
WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
GROUP BY is_physically_compressed, compression_type
ORDER BY is_physically_compressed DESC, row_count DESC;

-- ============================================================================
-- END OF QUERIES
-- ============================================================================
PROMPT
PROMPT ============================================================
PROMPT Query Script Complete
PROMPT ============================================================
PROMPT
PROMPT Additional Analysis Tips:
PROMPT ----
PROMPT 1. Export results to CSV:
PROMPT    SPOOL compression_audit_results.csv
PROMPT    SET ECHO OFF FEEDBACK OFF PAGESIZE 0 LINESIZE 32767
PROMPT    SELECT * FROM COMPRESSION_AUDIT_RESULTS 
PROMPT    WHERE audit_run_id = (SELECT MAX(audit_run_id) FROM COMPRESSION_AUDIT_RUN_LOG)
PROMPT    ORDER BY schema_name, object_name;
PROMPT    SPOOL OFF
PROMPT
PROMPT 2. Export summary to XML:
PROMPT    SET HEADING OFF FEEDBACK OFF ECHO OFF PAGESIZE 0 LINESIZE 32767
PROMPT    SELECT DBMS_XMLGEN.GETXML('SELECT * FROM COMPRESSION_AUDIT_RESULTS')
PROMPT    FROM DUAL;
PROMPT

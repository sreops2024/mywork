#!/usr/bin/bash
# 
# Author : Victor Zuniga
# Date   : 2022.07.19
# Purpoe : Wrapper script to call python script to monitor couchbase cluster node memory.

export WRKDIR=$PWD
export MON_USER=bbcmon
export MON_PSWD=M3tr1Ca7ch3r
export LOG_DIR=/home/couchbase/logs
export PYTHONPATH=/home/couchbase/DBA/pythonmods

RET=`/usr/local/lib64/icinga2/plugins/cbMonNodeMemUsage.py -u ${MON_USER} -p ${MON_PSWD}`
RC=$?

echo "${RET}"

exit ${RC}


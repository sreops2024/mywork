#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2022.08.26
# Purpose : This script will monitor the Clusters XDCR (replication) processes
#           Accept user inputs, clusters, buckets, etc.

import sys
import os
import json
import argparse
import requests
import logging

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import getClusterNames
from bbc_cb.cb_api import verifyAdminConnection
from bbc_cb.env_detail import CBENV
from bbc_cb.cb_api import getXDCRReplications
from bbc_cb.cbThresholds import gTHRESH

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="pyTemp.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Script to check the XDCR processes in couchbase
      ''')
    parser.add_argument('-u', '--user', help='Admin Account to be used', required=False)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-c', '--cluster', help='Cluster Name', default='all', required=False)
    parser.add_argument('-e', '--env', help='Life Cycle Environment - s (sandbox), i (int), q (qa), p (prod)', default='siqp', required=False)
    parser.add_argument('-d', '--debug', action='store_true', help='Run in DEBUG mode', required=False)

    return vars(parser.parse_args())


def checkClusterXDCR (pCluster, pAuth):
    '''
    Check the cluster XDCR processes, counts, etc.  
    Return dictionary with information if there are issues.
    '''

    logger.info ("in checkClusterXDCR : %s" % pCluster)
    #print ("in checkClusterXDCR : %s" % pCluster)
    
    vClusterEnv = pCluster[-1]
    lvCritChgLeftLimit = gTHRESH[vClusterEnv]['xdcrChangesLeft']['warnThres']
    logger.debug ("XDCR Changes Left Limit: %s" % lvCritChgLeftLimit)
    

    vRepls = getXDCRReplications(pAuth, pCluster)
    logger.debug( "Replications: %s" % str(vRepls))

    vRet = []

    for vRep in vRepls:
        try:
            logger.info ("Cluster: %s Type: %s - source: %s - status: %s - changesLeft: %s - errors: %s" %
                    (
                        pCluster,
                        vRep['type'],
                        vRep['source'],
                        vRep['status'],
                        vRep['changesLeft'],
                        vRep['errors']
                    ))
            if vRep['type'] == 'xdcr'  and (vRep['status'] != 'running' or vRep['changesLeft'] > lvCritChgLeftLimit or vRep['errors'] != []) :
                logger.warning ("Cluster: %s - source: %s - status: %s - changesLeft: %s - errors: %s" %
                    (
                        pCluster,
                        vRep['source'],
                        vRep['status'],
                        vRep['changesLeft'],
                        vRep['errors']
                    ))
                vRet.append( {'source': vRep['source'], 'status': vRep['status'], 'changesLeft': vRep['changesLeft'], 'errors': vRep['errors'] } )
        except Exception as ex:
            logger.warning ("Cluster: %s - vRep: %s" % (pCluster, str(vRep)))
            logger.error ("Repls: %s" % str(vRepls))
            logger.error ("Exception: %s" % str(ex))
            #vRet.append({'source': pCluster, "Msg" : "Error processing replication" })
            #vRet.append({'Error' : "Error processing replication %s" % pCluster })

    #print("Return: %s" % str(vRet))

    return vRet


def main( gvArgs):
    logger.debug ("Main function")
    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    vRet = {}

    if (gvArgs['cluster'] == 'all' and gvArgs['env'] == 'iqp' ):
        # Traverse the CBENV and list all clusters
        for e in CBENV.keys():
            #print ("=====================================================================================================================\n")
            for vClstr in sorted(CBENV[e].keys()):
                #print (vClstr)
                logging.info(vClstr)
                lvRet = checkClusterXDCR( vClstr, lvAuthCreds)
                if lvRet != []:
                    vRet[vClstr] = lvRet

    elif (gvArgs['cluster'] == 'all' and  gvArgs['env'] != 'iqp' ):
        # traverse received environments
        for e in (list(gvArgs['env'])):
            if e in CBENV.keys():
                #print ("=====================================================================================================================\n")
                for vClstr in sorted(CBENV[e].keys()):
                    #print (vClstr)
                    logging.info(vClstr)
                    lvRet = checkClusterXDCR( vClstr, lvAuthCreds)
                    if lvRet != []:
                        vRet[vClstr] = lvRet
    elif (gvArgs['cluster'] != 'all'):
        # Allow for multiple clusters to be passed at once
        #print( "=====================================================================================================================\n")
        vClusterList = gvArgs['cluster'].replace(" ", ",").split(",")
        logger.info("Cluster List: %s" % str(vClusterList))
        for vClstr in vClusterList:
            #if gvArgs['cluster'] not in getClusterNames():
            if vClstr not in getClusterNames():
                print ("ERROR: cluster %s does not exist." % (vClstr))
            else:
                #print (vClstr)
                logging.info(vClstr)
                lvRet = checkClusterXDCR( vClstr, lvAuthCreds)
                if lvRet != []:
                    vRet[vClstr] = lvRet

    
    return vRet


# ------------------------------------------------------------------------------------------------------------------------


if __name__ == "__main__":

    gvArgs = get_args()

    logNamePrefix = 'cbXDCRMon'
    if gvArgs['debug']:
        vLogName = init_logger(logNamePrefix, logging.DEBUG)
    else:
        vLogName = init_logger(logNamePrefix, logging.INFO)

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info(
                "Enter %s\'s Password   : " % gvArgs['user'])

    logger.debug("Args: " + str(gvArgs))

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password'])):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        print("ERROR: Connection using %s failed" % gvArgs['user'])
        print("ERROR: Please verify credentials")
        print("ERROR: Check log (%s) for details" % vLogName)
        exit(-1)
    else:
        logger.info("Credentials verified")
        #print("Credentials verified")

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    for k in gvArgs.keys():
        if k == 'password':
            logger.debug ("%15s: %s" % (k, gvArgs[k].replace(gvArgs['password'], '*'*len(gvArgs['password']))  ) )
        else:
            logger.debug ("%15s: %s" % (k, gvArgs[k]))

    vXDCRIssues = main( gvArgs)

    if len(vXDCRIssues) > 0:
        for vClusterKey in vXDCRIssues.keys():
            logger.warning ("WARNING: XDCR issues found on %s" % vClusterKey)
            for vBktInfo in vXDCRIssues[vClusterKey]:
                logger.warning (str(vBktInfo))
                try:
                    print ("%s: bucket: %s xdcr is %s - changesLeft: %s - errors: %s" % (vClusterKey, vBktInfo['source'], vBktInfo['status'], vBktInfo['changesLeft'], vBktInfo['errors']))
                except:
                    logger.error ("ERROR: issue printing bucket info: %s" % str(vBktInfo))
        logger.warning ( "Exit code: 2")
        logger.info ("----------" * 10)
        exit(2)

    logger.info ("All XDCR ok.")
    print ("All XDCR ok.")
    
    exit(0)
#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2021.06.04
# Purpose : This script will traverse the clusters in the env_detail.py file and will verify the balance state
#           of the cluster.  If balance is not true, then an alarm will be sent to icinga.

import sys
import os
import json
import argparse
import requests
import logging

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import getClusterNames
from bbc_cb.cb_api import verifyAdminConnection
from bbc_cb.env_detail import CBENV
from bbc_cb.cb_monitor import monClusterBalance

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="clusterBalanced.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Script verify status of all or one Couchbase Cluster.
      ''')
    parser.add_argument('-u', '--user', help='Admin Account to be used', required=False)
    parser.add_argument('-c', '--cluster', help='Cluster Name', default='all', required=False)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-e', '--env', help='Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required=False)
    parser.add_argument('-d', '--debug', action='store_true', help='Run in DEBUG mode', required=False)

    return vars(parser.parse_args())


def main( gvArgs):
    #print("Main function")
    lvAuthCreds = (gvArgs['user'], gvArgs['password'])
    lvWarnings = {}

    if (gvArgs['cluster'] == 'all' and gvArgs['env'] == 'iqp' ):
        # Traverse the CBENV and list all clusters
        for e in CBENV.keys():
            for vClstr in sorted(CBENV[e].keys()):
                vClstrBal = monClusterBalance(vClstr, lvAuthCreds)
                
                if vClstrBal[1] != True:
                    lvWarnings[vClstr] = vClstrBal[1]

    elif (gvArgs['cluster'] == 'all' and  gvArgs['env'] != 'iqp' ):
        # traverse received environments
        for e in (list(gvArgs['env'])):
            if e in CBENV.keys():
                for vClstr in sorted(CBENV[e].keys()):
                    vClstrBal = monClusterBalance(vClstr, lvAuthCreds)
                
                    if vClstrBal[1] != True:
                        lvWarnings[vClstr] = vClstrBal[1]

    elif (gvArgs['cluster'] != 'all'):
        vClusterList = gvArgs['cluster'].replace(" ", ",").split(",")
        logger.info("Cluster List: %s" % str(vClusterList))
        for vClstr in vClusterList:
            if vClstr not in getClusterNames():
                logger.warning("ERROR: cluster %s does not exist." % (vClstr))
            else:
                for vClstr in sorted(CBENV[e].keys()):
                    vClstrBal = monClusterBalance(vClstr, lvAuthCreds)
                
                    if vClstrBal[1] != True:
                        lvWarnings[vClstr] = vClstrBal[1]

    return lvWarnings

# ------------------------------------------------------------------------------------------------------------------------

if __name__ == "__main__":

    gvArgs = get_args()

    logNamePrefix = 'cbClusterBalance.py'
    if gvArgs['debug']:
        vLogName = init_logger(logNamePrefix, logging.DEBUG)
    else:
        vLogName = init_logger(logNamePrefix, logging.INFO)

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info(
                "Enter %s\'s Password   : " % gvArgs['user'])

    logger.debug("Args: " + str(gvArgs))

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password'])):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        exit(2)
    else:
        logger.info("Credentials verified")

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    vRes = main( gvArgs)

    if len(vRes) == 0:
        logger.info("All clusters balanced")
        print ("All clusters balanced")
        exit(0)
    else:
        logger.debug("Results: %s" % str(vRes))
        logger.info ("Unbalanced cluster(s) : %s" % str(list(vRes.keys())))
        print ("Unbalanced cluster(s) : %s" % str(list(vRes.keys())))
        exit(2)

exit(2)
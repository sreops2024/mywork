#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2022.07.13
# Purpose : This script will traverse the clusters in the env_detail.py file and will verify the  memory usage
#           on each node of the cluster.
# 2022.08.16 Victor Zuniga         Cleanup log, make some output debug only.
#                                  Ensured only clusters with warnings/critical nodes were returned.  This will 
#                                  allow the script to return preper message when no issues are found.

import sys
import os
import json
import argparse
import requests
import logging

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import getClusterNames
from bbc_cb.cb_api import verifyAdminConnection
from bbc_cb.env_detail import CBENV
from bbc_cb.cb_cluster import cCluster

#from bbc_cb.cb_monitor import monClusterNodeHealth

from bbc_cb.cb_api import getPoolsDefault
import time

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="clusterBalanced.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Script verify node status of all or one Couchbase Cluster.
      ''')
    parser.add_argument('-u', '--user', help='Admin Account to be used', required=False)
    parser.add_argument('-c', '--cluster', help='Cluster Name', default='all', required=False)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-e', '--env', help='Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required=False)
    parser.add_argument('-d', '--debug', action='store_true', help='Run in DEBUG mode', required=False)

    return vars(parser.parse_args())

def checkClusterNodeRAM(pCluster, pAuth):
    '''
    Return nodes that exceed thresholds on memory (RAM) usage
    '''

    logger.debug("in getClusterNodeMemAlerts - %s" % pCluster)

    vClstrInfo = getPoolsDefault(pAuth, pCluster)

    vRet = {}
    vRet[pCluster] = {}
    vRet[pCluster]["warn"] = []
    vRet[pCluster]["crit"] = []

    if 'nodes' in vClstrInfo.keys():
        vRAMLimits = getThresholds('hostRAM', pCluster[-1])
        for vNode in vClstrInfo['nodes']:
            vNodeName = vNode['hostname'].split('.')[0]
            vMemTotal, vMemFree = (vNode['memoryTotal'], vNode['memoryFree'])
            vMemUsagePCT = round((((vMemTotal - vMemFree)/vMemTotal)*100), 2)
            logger.debug ("Cluster: %s - node: %s - memFree: %s / memTotal: %s - Usage: %s%%" % ( pCluster, vNodeName, vMemFree, vMemTotal, vMemUsagePCT) )
            
            logger.debug("Thresholds: %s" % str(vRAMLimits))

            #if vMemUsagePCT >= vRAMLimits['critThres']:
            #    logger.warning("WARNING: %s [%s] Memory usage: %s exceeds critical threshold %s%%" % (vNodeName, pCluster, vMemUsagePCT, vRAMLimits['critThres'] ))
            #    vRet[pCluster][vNodeName] = "Memory usage: %s exceeds critical threshold %s%%" % (vMemUsagePCT, vRAMLimits['critThres'])
            #elif vMemUsagePCT >= vRAMLimits['warnThres']:
            #    logger.warning("WARNING: %s [%s] used RAM %s%% exceeds warning threshold %s%%" % (vNodeName, pCluster, vMemUsagePCT, vRAMLimits['warnThres'] ))
            #    vRet[pCluster][vNodeName] = "used RAM %s%% exceeds warning threshold %s%%" % (vMemUsagePCT, vRAMLimits['warnThres'])

            if vMemUsagePCT >= vRAMLimits['critThres']:
                logger.debug("Node: %s - Usage: %s [crit Thres: %s]" % (vNodeName, vMemUsagePCT, vRAMLimits['critThres']))
                vRet[pCluster]["crit"].append( (vNodeName, vMemUsagePCT, vRAMLimits['critThres'] ))
            elif vMemUsagePCT >= vRAMLimits['warnThres']:
                logger.debug("Node: %s - Usage: %s [warn Thres: %s]" % (vNodeName, vMemUsagePCT, vRAMLimits['warnThres']))
                vRet[pCluster]["warn"].append( (vNodeName, vMemUsagePCT, vRAMLimits['warnThres'] ))
            logger.debug("Ret: %s" % str(vRet))
            
    else:
        logger.warning ("WARNING: Could not get node information for cluster: %s" % pCluster)
        #return {}
    
    # Check if there are warning/critical nodes returned.  If not, then return empty dict.
    if vRet[pCluster]["warn"] == [] and vRet[pCluster]["crit"] == []:
        logger.debug ("No warning/critical nodes found for %s" % pCluster)
        return {}
    else:
        logger.debug ("Found warnings/crit nodes for %s -- %s " % (pCluster, str(vRet)))
        return vRet

def getThresholds( pMetric, pEnv = 'i' ):
    '''
    Return the thresholds for the received metric and environment
    '''

    from bbc_cb.cbThresholds import gTHRESH

    logger.debug ("in getThresholds: %s [%s]" % (pMetric, pEnv))

    try:
        return gTHRESH[pEnv][pMetric]
    except:
        logger.warning ("WARNING: Could not find metrics for %s in env: %s" % (pMetric, pEnv) )
        return {}

def monNodeMemPct( gvArgs):
    
    logger.info ("in monNodeMemPct")

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])
    lvWarnings = {}


    if (gvArgs['cluster'] == 'all' and gvArgs['env'] == 'iqp' ):
        # Traverse the CBENV and list all clusters
        for e in CBENV.keys():
            for vClstr in sorted(CBENV[e].keys()):
                #print("*",vClstr)
                vFStart = time.time()
                vClstrWarnings = checkClusterNodeRAM(vClstr, lvAuthCreds)
                logger.debug ("vClstrWarning: %s" % vClstrWarnings)
                vFEnd = time.time()

                logger.debug("checkClusterNodeRAM Dur [%s]: %s" % (vClstr, vFEnd - vFStart))
                if vClstrWarnings != {} and len(vClstrWarnings[vClstr]) > 0:
                    logger.debug("Cluster Warnings: %s" % vClstrWarnings)
                    lvWarnings[vClstr] = vClstrWarnings[vClstr]
                continue

    elif (gvArgs['cluster'] == 'all' and  gvArgs['env'] != 'siqp' ):
        # traverse received environments
        for e in (list(gvArgs['env'])):
            if e in CBENV.keys():
                for vClstr in sorted(CBENV[e].keys()):
                    #print(vClstr)

                    vFStart = time.time()
                    vClstrWarnings = checkClusterNodeRAM(vClstr, lvAuthCreds)
                    logger.debug ("vClstrWarning: ", vClstrWarnings)
                    vFEnd = time.time()

                    logger.debug("checkClusterNodeRAM Dur [%s]: %s" % (vClstr, vFEnd - vFStart))
                    if len(vClstrWarnings[vClstr]) > 0:
                        logger.debug("Cluster Warnings: %s" % vClstrWarnings)
                        lvWarnings[vClstr] = vClstrWarnings[vClstr]

    elif (gvArgs['cluster'] != 'all'):
        vClusterList = gvArgs['cluster'].replace(" ", ",").split(",")
        logger.info("Cluster List: %s" % str(vClusterList))
        vNodeRAMUsage = {}
        for vClstr in vClusterList:
            vClstrWarnings = {}
            logger.debug("Processeing %s" % vClstr)
            
            if vClstr not in getClusterNames():
                logger.warning("ERROR: cluster %s does not exist." % (vClstr))
            else:
                vFStart = time.time()
                vClstrWarnings = checkClusterNodeRAM(vClstr, lvAuthCreds)
                logger.debug ("vClstrWarning: ", vClstrWarnings)
                vFEnd = time.time()

                logger.debug("checkClusterNodeRAM Dur [%s]: %s" % (vClstr, vFEnd - vFStart))
                if len(vClstrWarnings[vClstr]) > 0:
                    logger.debug("Cluster Warnings: %s" % vClstrWarnings)
                    lvWarnings[vClstr] = vClstrWarnings[vClstr]
                    
                #continue

    return lvWarnings

# ------------------------------------------------------------------------------------------------------------------------

if __name__ == "__main__":

    gvArgs = get_args()

    logNamePrefix = 'cbMonNodeMemUsage'
    if gvArgs['debug']:
        vLogName = init_logger(logNamePrefix, logging.DEBUG)
    else:
        vLogName = init_logger(logNamePrefix, logging.INFO)

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info(
                "Enter %s\'s Password   : " % gvArgs['user'])

    logger.debug("Args: " + str(gvArgs))

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password']), gvArgs["cluster"]):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        exit(2)
    else:
        logger.info("Credentials verified")

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    vRes = monNodeMemPct( gvArgs)

    #print ("Results: %s" % str(vRes))
    logger.info("Result DIct: %s" % str(vRes))

    if len(vRes) == 0:
        logger.info("All Nodes OK")
        print ("All Nodes OK")
        exit(0)
    else:
        logger.debug("Results: %s" % str(vRes))
        logger.info ("Node(s) w/memory issues: %s" % str(vRes))

        for vCluster in vRes.keys():
            vWarnCount = len(vRes[vCluster]['warn'])
            vCritCount = len(vRes[vCluster]['crit'])
            
            if vWarnCount > 0:
                vWarnThres = list(set( [x[2] for x in vRes[vCluster]['warn'] ] ))[0]
                print("%s: %d node(s) exceed RAM warn threshold (%d): %s" % (vCluster, len(vRes[vCluster]['warn']), vWarnThres, str( [ (node[0],node[1]) for node in vRes[vCluster]['warn']] )))
            if vCritCount > 0:
                vCritThres = list(set( [x[2] for x in vRes[vCluster]['crit'] ] ))[0]
                print("%s: %d node(s) exceed RAM warn threshold (%d): %s" % (vCluster, len(vRes[vCluster]['crit']), vCritThres, str( [ (node[0],node[1]) for node in vRes[vCluster]['crit']] )))

        exit(2)

exit(2)
#!/usr/bin/bash
# 
# Author : Victor Zuniga
# Date   : 2022.07.19
# Purpoe : Wrapper script to call python script to monitor couchbase replications.

export WRKDIR=$PWD
export MON_USER=bbcmon
export MON_PSWD=M3tr1Ca7ch3r
export LOG_DIR=/home/couchbase/logs
export PYTHONPATH=/home/couchbase/DBA/pythonmods
export CB_CERTS_INBOX=/opt/couchbase/var/lib/couchbase/inbox

RET=`/usr/local/lib64/icinga2/plugins/cbXDCRMon.py`
RC=$?

echo "${RET}"
echo "RC: ${RC}"

exit ${RC}


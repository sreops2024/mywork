#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2022.05.19
# Purpose : This script will traverse the clusters in the env_detail.py file and will verify the health state of each node in 
#           the cluster.  If any node is found to be unhealthy (or inactive) an alert will be triggered by icinga.

import sys
import os
import json
import argparse
import requests
import logging

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import getClusterNames
from bbc_cb.cb_api import verifyAdminConnection
from bbc_cb.env_detail import CBENV
from bbc_cb.cb_cluster import cCluster
from bbc_cb.cb_monitor import monClusterNodeHealth

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="clusterBalanced.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Script verify node status of all or one Couchbase Cluster.
      ''')
    parser.add_argument('-u', '--user', help='Admin Account to be used', required=False)
    parser.add_argument('-c', '--cluster', help='Cluster Name', default='all', required=False)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-e', '--env', help='Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required=False)
    parser.add_argument('-d', '--debug', action='store_true', help='Run in DEBUG mode', required=False)

    return vars(parser.parse_args())


def monNodeHealth( gvArgs):
    #print("Main function")
    lvAuthCreds = (gvArgs['user'], gvArgs['password'])
    lvWarnings = {}

    if (gvArgs['cluster'] == 'all' and gvArgs['env'] == 'iqp' ):
        # Traverse the CBENV and list all clusters
        for e in CBENV.keys():
            for vClstr in sorted(CBENV[e].keys()):
                vNodeWarnList = monClusterNodeHealth(vClstr, lvAuthCreds)
                logger.debug("%s:%s" % (vClstr, str(vNodeWarnList)))
                
                if vNodeWarnList != []:
                    lvWarnings[vClstr] = vNodeWarnList

    elif (gvArgs['cluster'] == 'all' and  gvArgs['env'] != 'iqp' ):
        # traverse received environments
        for e in (list(gvArgs['env'])):
            if e in CBENV.keys():
                for vClstr in sorted(CBENV[e].keys()):
                    #vNodeWarnList = monClusterNodeHealth(cCluster(vClstr, lvAuthCreds))
                    vNodeWarnList = monClusterNodeHealth(vClstr, lvAuthCreds)
                    logger.debug("%s:%s" % (vClstr, str(vNodeWarnList)))

                    if vNodeWarnList != []:
                        lvWarnings[vClstr] = vNodeWarnList

    elif (gvArgs['cluster'] != 'all'):
        vClusterList = gvArgs['cluster'].replace(" ", ",").split(",")
        logger.info("Cluster List: %s" % str(vClusterList))
        for vClstr in vClusterList:
            if vClstr not in getClusterNames():
                logger.warning("ERROR: cluster %s does not exist." % (vClstr))
            else:
                #vNodeWarnList = monClusterNodeHealth(cCluster(vClstr, lvAuthCreds))
                vNodeWarnList = monClusterNodeHealth(vClstr, lvAuthCreds)
                logger.debug("%s:%s" % (vClstr, str(vNodeWarnList)))
                
                if vNodeWarnList != []:
                    lvWarnings[vClstr] = vNodeWarnList

    return lvWarnings

# ------------------------------------------------------------------------------------------------------------------------

if __name__ == "__main__":

    gvArgs = get_args()

    logNamePrefix = 'cbNodeHealth.py'
    if gvArgs['debug']:
        vLogName = init_logger(logNamePrefix, logging.DEBUG)
    else:
        vLogName = init_logger(logNamePrefix, logging.INFO)

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info(
                "Enter %s\'s Password   : " % gvArgs['user'])

    logger.debug("Args: " + str(gvArgs))

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password'])):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        exit(2)
    else:
        logger.info("Credentials verified")

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    vRes = monNodeHealth( gvArgs)

    if len(vRes) == 0:
        logger.info("All Nodes OK")
        print ("All Nodes OK")
        exit(0)
    else:
        logger.debug("Results: %s" % str(vRes))
        logger.info ("Unhealthy Node(s) : %s" % str(vRes))
        print ("Unhealthy Node(s) : %s" % str(vRes))
        exit(2)

exit(2)
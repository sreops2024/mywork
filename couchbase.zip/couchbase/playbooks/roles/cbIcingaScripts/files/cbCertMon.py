#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2022.07.21
# Purpose : This script will traverse the clusters in the env_detail.py file and will verify the certificate expiration date
#           on each node of the cluster.
# 
# 2023.03.07 Victor Zuniga          Fix a bug when getting the cluster nodes and spare.
#

import sys
import os
#import json
import argparse
#import requests
import logging

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import getClusterNames, getClusterNodes, getClusterSpareNode
#from bbc_cb.cb_api import verifyAdminConnection
from bbc_cb.env_detail import CBENV
from bbc_cb.cb_api import getCertExpDate

import time

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="clusterBalanced.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Script verify node status of all or one Couchbase Cluster.
      ''')
    #parser.add_argument('-u', '--user', help='Admin Account to be used', required=False)
    parser.add_argument('-c', '--cluster', help='Cluster Name', default='all', required=False)
    #parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-e', '--env', help='Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required=False)
    parser.add_argument('-d', '--debug', action='store_true', help='Run in DEBUG mode', required=False)

    return vars(parser.parse_args())

def checkNodeCertExpDT(pCluster):
    '''
    Return nodes that exceed thresholds on memory (RAM) usage
    '''
    from datetime import datetime

    logger.debug("in checkNodeCertExpDT - %s" % pCluster)

    vNodeList = getClusterNodes(pCluster)
    vNodeList.append(getClusterSpareNode(pCluster))

    logger.debug("NodeList: %s" % str(vNodeList))

    vToday = datetime.today()
    vRet = {}
    vRet['crit'] = []
    vRet['warn'] = []
    vThresholds = getThresholds('certExpDays', pCluster[-1])
    logger.debug("%s Thresholds: %s" % (pCluster, vThresholds))
    logger.debug("Nodes: %s" % vNodeList)

    for node in vNodeList:
        vNodeCertExpDt = getCertExpDate(node, "%Y.%m.%d")
        logger.info("Node: %s - Exp Date: %s" % (node, vNodeCertExpDt))
        try:
            vNodeCertExpDtObj = datetime.strptime(vNodeCertExpDt, "%Y.%m.%d")
            vDaysDiff = vNodeCertExpDtObj - vToday
            logger.debug("node: %s - %s [Diff: %s]" % (node, vNodeCertExpDt, vDaysDiff.days))

            if vDaysDiff.days < vThresholds["critThres"]:
                vRet['crit'].append( (node, vNodeCertExpDt ))
            elif vDaysDiff.days < vThresholds["warnThres"]:
                vRet['warn'].append( (node, vNodeCertExpDt ))
        except:
            logger.warning("node: %s - could not translate %s into date object" % (node, vNodeCertExpDt))
        
    # Remove empty items from dict
    logger.debug("vRet: %s" % str(vRet))
    if len(vRet['crit']) == 0:
        x = vRet.pop('crit')
    if len(vRet['warn']) == 0:
        x = vRet.pop('warn')
    
    return vRet

def getThresholds( pMetric, pEnv = 'i' ):
    '''
    Return the thresholds for the received metric and environment
    '''

    from bbc_cb.cbThresholds import gTHRESH

    logger.debug ("in getThresholds: %s [%s]" % (pMetric, pEnv))

    try:
        return gTHRESH[pEnv][pMetric]
    except:
        logger.warning ("WARNING: Could not find metrics for %s in env: %s" % (pMetric, pEnv) )
        return {}

def monNodeCertExpDT (gvArgs):
    
    logger.debug ("in monNodeMemPct")

    vClusterData = {}

    if (gvArgs['cluster'] == 'all' and gvArgs['env'] == 'iqp' ):
        # Traverse the CBENV and list all clusters
        for e in CBENV.keys():
            for vClstr in sorted(CBENV[e].keys()):
                #print("*",vClstr)
                vFStart = time.time()
                logger.debug("Processing %s" % vClstr)
                vFStart = time.time()
                vCertExp = checkNodeCertExpDT(vClstr)
                vFEnd = time.time()
                vDur = vFEnd - vFStart
                logger.debug("Duration: %s" % vDur)
                
                if len(vCertExp) > 0:
                    vClusterData[vClstr] = vCertExp

    elif (gvArgs['cluster'] == 'all' and  gvArgs['env'] != 'siqp' ):
        # traverse received environments
        for e in (list(gvArgs['env'])):
            if e in CBENV.keys():
                for vClstr in sorted(CBENV[e].keys()):
                    #print(vClstr)
                    vFStart = time.time()
                    logger.debug("Processing %s" % vClstr)
                    vFStart = time.time()
                    vCertExp = checkNodeCertExpDT(vClstr)
                    vFEnd = time.time()
                    vDur = vFEnd - vFStart
                    logger.debug("Duration: %s" % vDur)
                    
                    if len(vCertExp) > 0:
                        vClusterData[vClstr] = vCertExp

    elif (gvArgs['cluster'] != 'all'):
        vClusterList = gvArgs['cluster'].replace(" ", ",").split(",")
        logger.info("Cluster List: %s" % str(vClusterList))
        vClusterCerts = {}
        for vClstr in vClusterList:
            vClstrWarnings = {}
                        
            if vClstr not in getClusterNames():
                logger.warning("ERROR: cluster %s does not exist." % (vClstr))
            else:
                logger.debug("Processing %s" % vClstr)
                vFStart = time.time()
                vCertExp = checkNodeCertExpDT(vClstr)
                vFEnd = time.time()
                vDur = vFEnd - vFStart
                logger.debug("Duration: %s" % vDur)
                
                if len(vCertExp) > 0:
                    vClusterData[vClstr] = vCertExp
                
    return vClusterData

# ------------------------------------------------------------------------------------------------------------------------

if __name__ == "__main__":

    gvArgs = get_args()

    logNamePrefix = 'cbCertMon'
    if gvArgs['debug']:
        vLogName = init_logger(logNamePrefix, logging.DEBUG)
    else:
        vLogName = init_logger(logNamePrefix, logging.INFO)

    logger.debug("Args: " + str(gvArgs))

    vRes = monNodeCertExpDT (gvArgs)

    if len(vRes) == 0:
        logger.info("All Nodes OK")
        print ("All Nodes OK")
        exit(0)
    else:
        logger.debug("Results: %s" % str(vRes))
        logger.info ("Node(s) w/memory issues: %s" % str(vRes))

        for vCluster in vRes.keys():
            try:
                vWarnCount = len(vRes[vCluster]['warn'])
            except:
                vWarnCount = 0
            try:
                vCritCount = len(vRes[vCluster]['crit'])
            except:
                vCritCount = 0
            
            #print("Warn Count: %s" % vWarnCount)
            #print("Crit Count: %s" % vCritCount)

            if vWarnCount > 0:
                print("%s : WARNING : Certs expiring soon - %s" % (vCluster, [x for x in vRes[vCluster]['warn']]))
            if vCritCount > 0:
                print("%s : ALERT : Certs expiring soon - %s" % (vCluster, [x for x in vRes[vCluster]['crit']]))
                
        exit(2)

exit(2)
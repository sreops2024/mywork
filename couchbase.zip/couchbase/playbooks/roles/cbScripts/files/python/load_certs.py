#!/bin/python3
# ------------------------------------------------------------------------------------------------------------------------
# Author  : Victor Zuniga
# Date    : 2019.08.19
# Purpose : Script to automate the loading of the node certificates.
#           This script is intended to be executed from puppet when certificate files are modified and need to be
#           uploaded to the couchbase server/node.

# ------------------------------------------------------------------------------------------------------------------------
# History
# 2019.12.04 Victor Zuniga   Use the encrypted credentials.
#                            Email when successful, and send the log when errors are found.
# 2019.12.06 Victor Zuniga   Hide password visibility on error messages.
#                            Fixed a type on upper() call.
#                            Make the stdout and stderr info messages in execOSCommand function.
#                            Moved execOSCommand function to externam module bbc_misc.
# 2019.12.11 Victor Zuniga   Removed CURL command as it was redundant according to Couchbase support.  The functionality 
#                            is included on the --set node certificate call.
# 2020.07.02 Victor Zuniga   Allow for username (-u, --user) and password (-p, --password) to be provided as parameters
# ------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------
#
import logging
import os, sys
import subprocess
import argparse

from bbc_log.dba_log import init_logger
from bbc_fileSec.encServer import getPassword
from bbc_email.dba_email import send_email, email_log
from bbc_misc.bbc_os import execOSCommand

# ------------------------------------------------------------------------------------------------------------------------
# Function Definitions
# ------------------------------------------------------------------------------------------------------------------------
def get_args() :
   """ Set up the arguments and return the python dictionary containing the received values """
   parser = argparse.ArgumentParser ( prog = "load_certs.py",
                                      formatter_class=argparse.RawDescriptionHelpFormatter,
                                      description=
      '''
      Script to load the node certificates into couchbase.
      ''' )
   parser.add_argument ( '-u', '--user', help = 'Admin Account to be used', required = False )
   parser.add_argument ( '-p', '--password', help = 'Admin Password to be used', required = False )
   return  vars(parser.parse_args() )


def main():
    '''Load the certificates into Couchbase'''

    logger.info ("Admin Account: " + vAdminAcct )
    logger.debug ("Admin Password: " + vAdminPswd.replace(vAdminPswd, '*' * len(vAdminPswd) ) )
    logger.debug ("Email to: " + vDBAEmail )

    vEmailBody = "-------------------------------------------------------\n"
    vEmailBody += "Host: " + vHost + "\n"
    vEmailBody += "-------------------------------------------------------\n\n"

    vCmd = "%s ssl-manage -c %s -u %s -p %s --upload-cluster-ca=%s" % (cbCLI, cluster, vAdminAcct, vAdminPswd, rootCert)
    logger.info ("Load root Cert")
    logger.debug ("Command: " + vCmd.replace(vAdminPswd, '*' * len(vAdminPswd) ))
    vRC = execOSCommand( vCmd )
    if vRC != 0:
        logger.error ("Error while executing command: %s" % vCmd.replace(vAdminPswd, '*' * len(vAdminPswd) ) )
        logger.error ("Error code: %d" % vRC)
        vEmailBody += "Error loading root certificate\n"
        vEmailBody += "Error Code: " + str(vRC) + "\n"
        vEmailBody += "-------------------------------------------------------\n"
    else:
        logger.info ("Command successfully executed")
        logger.info ("Ret Code: " + str(vRC) )
        vEmailBody += "Root Certificate loaded successfully\n"
        vEmailBody += "-------------------------------------------------------\n"

    vCmd = "%s ssl-manage -c %s -u %s -p %s --set-node-certificate" % (cbCLI, cluster, vAdminAcct, vAdminPswd)
    logger.info ("Set Node Certificate")
    logger.debug ("Command: " + vCmd.replace(vAdminPswd, '*' * len(vAdminPswd) ))
    vRC = execOSCommand( vCmd )
    if vRC != 0:
        logger.error ("Error while executing command: %s" % vCmd.replace(vAdminPswd, '*' * len(vAdminPswd) ) )
        logger.error ("Error code: %d" % vRC)
        vEmailBody += "Error setting node certificate\n"
        vEmailBody += "Error Code: " + str(vRC) + "\n"
        vEmailBody += "-------------------------------------------------------\n"
    else:
        logger.info ("Command successfully executed")
        logger.info ("Ret Code: " + str(vRC) )
        vEmailBody += "Set Node Certificate successfully\n"
        vEmailBody += "-------------------------------------------------------\n"

    if 'ERROR' in vEmailBody.upper():
        logger.info ("Errors were found.  Adjust the email subject accordingly")
        email_log( "Certificate Reload [Not Successful] - " + os.environ['CLUSTER_NAME'].upper(),
                    "couchbase@" + vHost,
                    vDBAEmail,
                    vLogName )
        return 1
    else:
        send_email( "Certificate Reload [Success] - " + os.environ['CLUSTER_NAME'].upper(),
                    "couchbase@" + vHost,
                    vDBAEmail,
                    vEmailBody )
        return 0
# ------------------------------------------------------------------------------------------------------------------------

if __name__ == '__main__':

    logNamePrefix = 'certLoad'
    #vLogName = init_logger( logNamePrefix, logging.DEBUG )
    vLogName = init_logger( logNamePrefix, logging.INFO )
    logger = logging.getLogger ()

    gvArgs = get_args()
    if gvArgs['user'] != None:
        logger.info ("Received credentials %s" % ( str(gvArgs).replace(gvArgs['password'], '*' * len(gvArgs['password']) ) ) )

    if gvArgs['user'] == '' or gvArgs['user'] is None:
        logger.info("Credentials not received from the command line.  Use dbadmin account")
        # Variable definitions
        vAdminAcct = 'dbadmin'
        vAdminPswd = getPassword (vAdminAcct)
    else:
       logger.info ("Credentials provided -- %s" % gvArgs['user'] )
       vAdminAcct = gvArgs['user']
       vAdminPswd = gvArgs['password']

    try:
        vDBAEmail = os.environ['DBA_EMAIL']
    except:
        logger.warning ("The DBA_EMAIL variable has not been set in the profile")
        vDBAEmail = 'Couchbase_DBA@bbc.com'

    vHost = os.environ['HOSTNAME']
    vEmailBody = ''
    cbCLI = "/opt/couchbase/bin/couchbase-cli"
    cbCURL = "/opt/couchbase/bin/curl"
    cluster = "localhost:8091"
    certPath = "/opt/couchbase/var/lib/couchbase/inbox"
    rootCert = certPath + "/ca.pem"

    main()


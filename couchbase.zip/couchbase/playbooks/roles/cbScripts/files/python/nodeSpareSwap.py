#!/usr/bin/python3
# Author  : Victor Zuniga
# Date    : 2022.10.11
# Purpose : Swap the current node with the spare node to maintain cluster resources.
#           This is intended for DBAs or Admins when the node needs to be upgraded.
#

import logging
import argparse

from bbc_log.dba_log import init_logger
#from bbc_fileSec.encServer import getPassword
from bbc_fileSec.encServer import getClusterCred
from bbc_cb.env_config import getClusterNames
from bbc_misc.bbc_os import getOSVar
from bbc_cb.cb_cluster import cCluster

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------------------------------

def get_args() :
   """ Set up the arguments and return the python dictionary containing the received values """
   parser = argparse.ArgumentParser ( prog = "nodeSwap.py",
                                      formatter_class=argparse.RawDescriptionHelpFormatter,
                                      description=
      '''
      Swap the node with the cluster's spare node and vice versa.
      ''' )

   parser.add_argument ( '-d', '--debug', action='store_true',  help = 'Run in DEBUG mode', required = False )
   parser.add_argument ( '-c', '--cluster', help = 'Cluster Name', default=None, required = False )
   parser.add_argument ( '-n', '--node', help = "Node Name", default=None, required = False )


   return  vars(parser.parse_args() )

# ------------------------------------------------------------------------------------------------------------------------



def main (pArgs):
    ''' Swap the local node from the couchbase cluster with the defined cluster spare node'''
    vCluster = getOSVar('CLUSTER_NAME')
    vNode = getOSVar('HOST_ALIAS')

    if vCluster == '' or vCluster == None:
        if pArgs['cluster'] == None:
            logger.error ("ERROR: Unknown Cluster")
            print ("ERROR: Unknown Cluster")
            exit(1)
        else:
            vCluster = pArgs['cluster']

    if vNode == '' or vNode == None:
        if pArgs['node'] == None:
            logger.error ("ERROR: Unknown Node")
            print ("ERROR: Unknown Node")
            exit(1)
        else:
            vNode = pArgs['node']

    if vCluster not in getClusterNames ():
        logger.error ("ERROR: Invalid cluster Name")
        print ("ERROR: Invalid cluster Name")
        exit(2)

    logger.debug ("Swapping node %s out of cluster %s" % (vNode, vCluster))
    print ("Swapping node %s out of cluster %s" % (vNode, vCluster))

    #vAuth = ('dbadmin', getPassword('dbadmin'))
    try:
        vAuth = ('dbadmin', getClusterCred('dbadmin', vCluster, getOSVar('CB_KEY_DIR')))
    except:
        logger.error ("ERROR: Could not get the cluster credentials for dbadmin")
        logger.error ("ERROR: invalid credentials - %s" % vCluster)
        exit (1)


    logger.debug ("Credentials: %s/%s" % (vAuth[0], '*' * len(vAuth[1])))
    print ("Credentials: %s/%s" % (vAuth[0], '*' * len(vAuth[1])))

    exit(0)

    vCluster = cCluster( vCluster, vAuth)

    print(vCluster)

    print ("Set time delay to 30 secs")
    vCluster.setTimeDelay(30)

    if vCluster.swapNodeWithSpare(vNode):
        print ("Node swapped")
        vCluster.refresh()
        print( vCluster )


if __name__ == "__main__":
    logNamePrefix = 'nodeSwap'

    gvArgs = get_args()

    if gvArgs['debug']:
        vLogName = init_logger( logNamePrefix, logging.DEBUG )
    else:
        vLogName = init_logger( logNamePrefix, logging.INFO )

    main(gvArgs)

exit (0)
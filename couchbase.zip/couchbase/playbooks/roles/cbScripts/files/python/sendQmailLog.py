#!/bin/python3
# Author  : Victor Zuniga
# Date    : 2022.01.25
# Purpose : Provide a simple script that can be used to send logs to the Couchbase DBA team.
#           The script will use the email address set in the DBA_EMAIL environment variable.
#           Only expects to receive SUBJECT and file location (including name) as parameters.

import os
import sys
import logging

from bbc_email.dba_email import email_log
from bbc_log.dba_log import init_logger

vTO = 'couchbase_dba@bbc.com'
vHost = os.environ['HOST_ALIAS']
vCluster = os.environ['CLUSTER_NAME']
vFROM = 'couchbase@' + vHost + "[" + vCluster + "]"


logFileName = 'emailLog'
vLogName = init_logger( logFileName, logging.DEBUG )

try:
    vSubj = sys.argv[1]
except:
    vSubj = "No Subject"

logging.info("Subject: %s" % vSubj)

try:
    vFile = sys.argv[2]
except:
    vFile = "Empty Message Body"

logging.info("File: %s" % vFile)

rc = email_log ( vSubj, vFROM, vTO, vFile )

logging.info("Done")

exit (rc)

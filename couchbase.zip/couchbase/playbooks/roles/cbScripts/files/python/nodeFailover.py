#!/usr/bin/python3
# Author  : Victor Zuniga
# Date    : 2020.06.09
# Purpose : Failover the current Couchbase node to prepare for an upgrade
#           This is intended for DBAs or Admins when the node needs to be upgraded.
#
#
# 20200825 Victor Zuniga        Perform hardfailover for non-data nodes
# 20210129 Victor Zuniga        Make sure node names and aliases are lower case
# 20210204 Victor Zuniga        Use node alias from the env variable, since the IP address 
#                               is not guaranteed to be correct (PCI cluster issue).

import sys
import os
import socket
import requests
import time
import json
import logging

from bbc_log.dba_log import init_logger
from pprint import PrettyPrinter
from bbc_cb.env_config import getClusterNames, getClusterNodes
from bbc_fileSec.encServer import getPassword
from bbc_email.dba_email import send_email, email_log


def getNodeServices ( pNodeName, pAuth ):
    ''' Return the services for the recieved node name.  
        Empty if node is not found or invalid
    '''
    logger.info ("Get node services for : " + pNodeName )

    vURL = "http://%s:8091/pools/nodes" % (pNodeName)
    try:
       r = requests.get (vURL, auth=(pAuth) )
    except:
        logger.error ( "ERROR getting services for " + pNodeName )
        logger.debug ( "URL: " + vURL )
        logger.error ( "ERROR: ", sys.exc_info()[0] )
        return list('')
    for n in range(len( r.json()['nodes'])):
        if pNodeName.lower() in r.json()['nodes'][n]['hostname'].lower():
            return r.json()['nodes'][n]['services']
    return list('')


def getAliasName ( pVMName, pClusterName ):
    ''' Get the alias name based on IP addresses'''

    logger.info("getAliasName : starting")
    
    vNodeAlias = os.getenv("HOST_ALIAS")

    if vNodeAlias != None:
        logger.info("Node: %s - Alias: %s" % (pVMName, vNodeAlias))
        
        return {'host': pVMName.lower(), 'alias': vNodeAlias.lower() }

    try:
        vIP = socket.gethostbyname( pVMName )
    except:
        print ("ERROR: Host Name (" + pVMName + ") is not valid.")
        return None

    logger.info ("getAliasName : " + pVMName + "[" + vIP + "]" )

    if pClusterName in getClusterNames( ):
        vNodeList = getClusterNodes ( pClusterName )
        logger.info ("getAliasName : Node List : " + str(vNodeList) )
        for vNode in vNodeList:
            if vIP == socket.gethostbyname( vNode ):
                logger.info ("getAliasName : Match Found")
                logger.info ("getAliasName : " + pVMName + " -> " + vNode )
                return {'host': pVMName.lower(), 'alias': vNode.lower() }
    else:
        logger.warning ("getAliasName : No alias found")
        return {}


def nodeFailover( pAdminCreds, pNodeAlias ):
    
    logger.info ("nodeFailover : alias : " + pNodeAlias )

    vNodeServices = getNodeServices( pNodeAlias, pAdminCreds )
    logger.info ("Node Services: " + str(vNodeServices ))
 
    otpNode = 'ns_1@' + pNodeAlias + '.south.edu'
    vData = { 'otpNode' :  otpNode }

    logger.info ("nodeFailover : data : " + str (vData) )

    # If node is not running the kv service (data), then perform a hard failover
    if 'kv' in vNodeServices:
        vURL = "http://%s.south.edu:8091/controller/startGracefulFailover" % (pNodeAlias.lower()) 
        logger.info ("Perform a graceful failover")
    else:
        vURL = "http://%s.south.edu:8091/controller/failOver" % (pNodeAlias.lower()) 
        logger.info ("Perform a hard failover")

    logger.info ("nodeFailover : URL : " + vURL )

    r = requests.post (vURL, data=vData, auth=(pAdminCreds) )

    if r.status_code != 200:
        logger.error ("nodeFailover : request call failed. Status : " + str(r.status_code) )
        logger.error ("nodeFailover : error text : " + r.text )
        print ("ERROR: Failed to run request.post")
        print ("ERROR: " + r.text )
        return False

    logger.info ("nodeFailover : status_code : " + str( r.status_code) )
    logger.info ("nodeFailover : text : " + r.text )

    return True

def showRebalanceProgress( pAdminCreds, pNodeAlias, delay = 30 ):

    vSleepDelay = 15
    logger.info ("showRebalanceProgress : Sleep delay : " + str( vSleepDelay ) )

    pp = PrettyPrinter(indent=4)

    time.sleep( vSleepDelay )

    vURL = 'http://' + pNodeAlias + '.south.edu:8091/pools/default/rebalanceProgress'
    logger.info ("showRebalanceProgress : URL : " + vURL )

    r = requests.get( vURL, auth=(pAdminCreds) )

    if r.status_code != 200:
        logger.info ("showRebalanceProgress : request failed : status_code : " + str(r.status_code) )
        logger.info ("showRebalanceProgress : text : " + r.text )
        print ("Rebalance Completed or call failed" )
        return True

    logger.info ("showRebalanceProgress : " + str ( r.text ) )
    pp.pprint ( json.loads(r.text ) )
    print ("...")
    logger.info ("showRebalanceProgress : looping until done..." )
    while r.text != '{"status":"none"}':
        time.sleep( vSleepDelay )
        r = requests.get( vURL, auth=(pAdminCreds) )
        logger.info ("showRebalanceProgress : " + str ( r.text ) )
        pp.pprint ( json.loads(r.text ) )
        print ("...")

    logger.info ("Rebalance Complete")
    print ("Rebalance Completed")

    return True


def main ():

    pp = PrettyPrinter( indent=4 )

    vVMName = socket.gethostname()
    vClusterName = os.getenv('CLUSTER_NAME')
    vNodeInfo = getAliasName ( vVMName, vClusterName )

    vEmail = os.getenv('DBA_EMAIL')
    logger.debug ('DBA Email: ' + vEmail )

    logger.info ("VM Name: " + vVMName)
    logger.info ("Cluster: " + vClusterName )
    logger.info ("Alias  : " + str( vNodeInfo ) )

    if vNodeInfo is {}:
        logger.warning ("Node Alias not found")
        print ("Node Alias unavailable")
        return False

    #vAdminAcct = getPassword('dbadmin')
    vAdminCreds = ('dbadmin', getPassword('dbadmin') )
    logger.info ( ("Admin Creds: " + str(vAdminCreds) ).replace( vAdminCreds[1], '*' * len( vAdminCreds[1]) ) )

    vClusterNodes = getClusterNodes ( vClusterName )
    logger.info ("Nodes : " + str(vClusterNodes) )

    if nodeFailover( vAdminCreds, vNodeInfo['alias'] ):
        showRebalanceProgress ( vAdminCreds, vNodeInfo['alias'] )
        send_email ( Subject = "Couchbase node failover: [" + vNodeInfo['alias'] + "] successful.",
                     To = vEmail,
                     Body = "VM Name: %s\nAlias: %s\n\nFailed over by admin script" % (vNodeInfo['host'], vNodeInfo['alias']) )
        return True
    else:
        email_log ( Subject = "Couchbase node failover: [" + vNodeInfo['alias'] + "] FAILED.",
                     To = vEmail,
                     File = vLogName )
        return False

if __name__ == "__main__":
    logFileName = 'nodeFailover'
    #vLogName = init_logger( logFileName, logging.INFO )
    vLogName = init_logger( logFileName, logging.DEBUG )
    logger  = logging.getLogger ()
    logger.info ( "------------------------------------------------------------------------------------------------------------------------" )

    if main():
        logger.info ("Node Failover completed successfully" )
        exit (0)
    else:
        logger.info ("Node Failover completed unsuccessfully" )
        exit (1)



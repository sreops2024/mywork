#!/bin/python3
# ----------------------------------------------------------------------------------------------------------------------
# Author  : Victor Zuniga
# Date    : 2020.05.15
# Purpose : Download the Venafi certificate for the received host name (should be the local host in HA name format)
#           decrypt the private key file (required to load certs into Couchbase node).
# ----------------------------------------------------------------------------------------------------------------------
# History
#
# Who               Date       Comments
# ----------------- ---------- -------------------------------------------------------------
# Victor Zuniga     2020.04.07 Initial version
# Victor Zuniga     2020.05.15 Modify to only download 1 certificate and use the expected
#                              cert file names (ca.pem, chain.pem, pkey.key).
#                              Added -d (dest) parameter to receive the location where the certs should be downloaded.
# Victor Zuniga     2021.12.07 Change the certificate path in Venafi to ensure the certificate is found.
# Victor Zuniga     2022.01.11 Fix bug that gets cert inbox dir from env variable.  Use CB_CERTS_INBOX instead of CERTS_DIR
#                              which does not exist.
# ----------------------------------------------------------------------------------------------------------------------

import json
import logging
import os
import urllib3
import argparse
import pprint

from bbc_log.dba_log import init_logger
from bbc_sec.passwd_gen import pwd_gen
from bbc_cb.env_config import getClusterNames, getClusterNodes


# ----------------------------------------------------------------------------------------------------------------------

def get_args() :
   """ Set up the arguments and return the python dictionary containing the received values """
   parser = argparse.ArgumentParser ( prog = "getVenafiCert.py",
                                      formatter_class=argparse.RawDescriptionHelpFormatter,
                                      description=
      '''
      Downloads the certificate for the received node from the Venafi QVC site.
      ''' )
   parser.add_argument ( '-n', '--node',    help = 'Node Name',    default=None, required = False )
   parser.add_argument ( '-d', '--dest', help = 'Cert Dest Directory', default=None, required = False )
   return  vars(parser.parse_args() )


def fileExists(pFileName, pMode):
    """ Check the existance (readability) of a file """

    try:
        f = open(pFileName, pMode)
        f.close
        logger.debug("fileExists: file %s was found and opened with mode %s " % (pFileName, pMode))
    except IOError as e:
        logger.warning("WARNING fileExists: file %s was not found or could not be opened with mode %s " % (pFileName, pMode))
        return False

    return True

def venafiAuthenticate (pHTTP):
    '''Authenticate to the Venafi QVC site'''

    logger.info ("venafiAuthenticate")

    vBody = {"Username": "sUS-P-CBQVC-VENAFI",
             "Password": "xgH66jYA3-@sHgj"}

    vHeaders = {'Content-Type': 'application/json'}
    vURL = "https://venafi.south.edu/vedsdk/Authorize"

    r = pHTTP.request(url=vURL, body=json.dumps(vBody).encode(), headers=vHeaders, method='POST')

    if r.status != 200:
        logger.error("ERROR: Could not authorize with Venafi")
        logger.error("ERROR: Ret Code: %s" % str(r.status))
        return r

    logger.debug("Authenticated to Venafi %s" % str(r.status))

    return r


def getVenafiPEMCertificate(pHTTP, pNode, pCertPassword, pAPIKey):
    '''Download the certificate from Vanafi site'''

    logger.info ( "getVenafiPEMCertificate - %s" % pNode )

    vCertFmt = 'Base64'
    logger.debug ( "cert format: %s" % vCertFmt )

    #vQuery = "CertificateDN=%5CVED%5CPolicy%5CManaged%5CInternal%5CDBA%20Team%5C" + pNode + "&Format=" + \
    vQuery = "CertificateDN=%5CVED%5CPolicy%5CManaged%5CInternal%5CDBA%20Group%5C" + pNode + "&Format=" + \
              vCertFmt + "&Password=" + pCertPassword + "&IncludePrivateKey=True&IncludeChain=True&FriendlyName=" + pNode
    logger.debug ("Query: %s" % vQuery )

    vURL = "https://venafi.south.edu/vedsdk/certificates/Retrieve?" + vQuery
    logger.debug ("URL: %s" % vURL)

    vHeader = {'ContentType': 'application/x-pkcs12',
               'X-Venafi-API-Key': pAPIKey}

    logger.debug("Header: %s" % str(vHeader))

    r = pHTTP.request(url=vURL, headers=vHeader, method='GET')
    if r.status != 200:
        logger.error("ERROR: Error getting certificate data - %s" % pNode)
        logger.error("ERROR: Status: " + str(r.status))
    else:
        logger.debug("Cert Data Length: " + pNode + " " + str(len(r.data)))

    return r


def splitCerts(pCertDataStr, pNodeName, pCertPswd, pDest = None):
    '''
    Split the certificate data received into root, chain, key files.
    The key file will be decrypted using the received password.
    Return True|False (Success|Failure)
    '''

    logger.info ("splitCerts")

    vCerPerms = 0o755

    vTmpDir = '/tmp'

    vCertDir = pDest

    if vCertDir == None:
        vCertDir = os.getenv("CB_CERTS_INBOX", None)
        logger.debug("Cert Dest Dir: %s -- from env variable" % vCertDir)

    if vCertDir == None:
        vCertDir = os.getcwd()
        logger.debug("Cert Dest Dir: %s -- using current directory" % vCertDir)

    logger.info ("Cert Dir: %s" % vCertDir )
    logger.info ("Temp Dir: %s" % vTmpDir )

    #vChainFile = vCertDir + '/' + pNodeName + ".chain.pem"
    #vRootFile = vCertDir + '/' + pNodeName + ".ca.pem"
    #vEncKeyFile = vTmpDir + '/' + pNodeName + ".encKey"
    #vKeyFile = vCertDir + '/' + pNodeName + ".pkey.key"

    vChainFile = vCertDir + '/' + "chain.pem"
    vRootFile = vCertDir + '/' + "ca.pem"
    vEncKeyFile = vTmpDir + '/' + "pkey.encKey"
    vKeyFile = vCertDir + '/' + "pkey.key"

    logger.info ("Root File   : %s" % vRootFile)
    logger.info ("Chain File  : %s" % vChainFile)
    logger.info ("Enc Key File: %s" % vEncKeyFile)
    logger.info ("Key File    : %s" % vKeyFile)

    # Split the data into a list of lines
    vLineList = pCertDataStr.split("\r\n")

    try:
        f = open(vChainFile, 'wb')
    except:
        logger.error("ERROR: Could not open file: " + vChainFile)
        return False

    logger.debug ("Traverse cert data")
    vLineNum = 0
    while vLineNum < len(vLineList):
        # Traverse certificate lines and save to the appropriate file.  Start with Chain file.

        if vLineList[vLineNum] == 'subject=CN=QVC Root CA':
            # Encountered the first line of the root certificate.  Switch files.
            logger.debug( "Found root cert at line %d" % vLineNum )
            f.close()
            try:
                f = open(vRootFile, 'wb')
            except:
                logger.error("ERROR: Could not open file: " + vRootFile)

        if vLineList[vLineNum] == '-----BEGIN RSA PRIVATE KEY-----':
            # Encountered the first line of the key certificate.  Switch files.
            logger.debug("Found key cert at line %d" % vLineNum)
            f.close()
            try:
                f = open(vEncKeyFile, 'wb')
            except:
                logger.error("ERROR: Could not open file: " + vEncKeyFile)

        f.write(vLineList[vLineNum].encode() + b'\r\n')
        vLineNum += 1

    f.close()
    logger.debug ("Traverse complete... files generated")

    if fileExists( vRootFile, 'r'):
        logger.debug ("Root file found: %s" % vRootFile)
        logger.debug("Reset file perms - %s" % vRootFile)
        os.chmod( vRootFile, vCerPerms)
    else:
        logger.warning("Root file NOT found: %s" % vRootFile)

    if fileExists( vChainFile, 'r'):
        logger.debug ("Chain file found: %s" % vChainFile)
        logger.debug("Reset file perms - %s" % vChainFile)
        os.chmod( vChainFile, vCerPerms)
    else:
        logger.warning("Chain file NOT found: %s" % vChainFile)

    if fileExists(vEncKeyFile, 'r'):
        # Decrypt key file
        vCmd = "/usr/bin/openssl rsa -in %s -out %s -passin pass:%s > /dev/null 2>&1" % (vEncKeyFile, vKeyFile, pCertPswd)
        logger.debug ("Decrypt Cmd: %s" % vCmd )
        os.system(vCmd)

        if fileExists(vKeyFile, 'r'):
            logger.info("Key file decypted")
            logger.debug("Reset file perms - %s" % vKeyFile)
            os.chmod(vKeyFile, vCerPerms)
        else:
            logger.error("ERROR: key file decyption failed")
            return False

    else:
        return False

    return True


def main():
    '''Meat of the Cert Download from Venafi script'''

    # Get the Couchbase node from the OS environment variable is available.
    #vCBNode = 'hcb001sp01i'

    pp = pprint.PrettyPrinter(indent=4)
    gvArgs = get_args()

    # If node name is not provided as an argument, then check for a cluster name, if none
    # provided, then get node name from the OS env variable.
    # If the CBNODE environment variable is not present, then provide an error and terminate.
    vCBNode = gvArgs['node']

    if gvArgs['node'] == None: 
        vCBNode = os.getenv('HOST_ALIAS', None )
        logger.info ("Reading node [%s] from environment variable" % vCBNode )

    if vCBNode == None:
       logger.error ("ERROR: Missing Couchbase Node Name... exiting")
       print ("ERROR: Missing Couchbase Node Name... exiting")
       return False

    http = urllib3.PoolManager(
        cert_reqs='CERT_REQUIRED',
        ca_certs='/etc/ssl/certs/ca-bundle.trust.crt')

    vRet = venafiAuthenticate (http)

    if vRet.status != 200:
       logger.error("ERROR: Authentication failed")
       return False

    vAPIKey = json.loads(vRet.data.decode())['APIKey']
    logger.debug ("API Key: %s" % str(vAPIKey))

    vStatus = {}

    for iNode in vCBNode.split(','):

        vCertFile = iNode + '.pem'
        vCBNodeFQ = iNode + '.south.edu'
        vCertPassword = pwd_gen (20, 5, 5, 0)

        vStatus[iNode] = []

        vRet = getVenafiPEMCertificate(http, vCBNodeFQ, vCertPassword, vAPIKey)

        if vRet.status != 200:
            logger.error ("ERROR: Could not get certificate data [%s]" % iNode)
            logger.error ("ERROR: Ret Code: " + str(vRet.status) )
            vStatus[iNode].append ("DownloadError_%s" % str(vRet.status) )
        else: 
            logger.info ("%s cert downloaded ok" % iNode )
            vStatus[iNode].append ("DownloadOK_%s" % str(vRet.status) )

            if splitCerts( vRet.data.decode(), iNode, vCertPassword, gvArgs["dest"] ):
                logger.info ("Cert split and decrypted - %s" % iNode )
                vStatus[iNode].append ("CertSplitOK")
            else:
                logger.error("Cert split and decrypt Failed - %s" % iNode)
                vStatus[iNode].append ("CertSplitERROR")

    # Assume that only manual execution will have the cluster argument, therefore, print the status to the screen.
    logger.info( str(vStatus) )
    pp.pprint (vStatus)

    return True


if __name__ == '__main__':
    logNamePrefix = 'getNodeCerts'
    #vLogName = init_logger(logNamePrefix, logging.DEBUG)
    vLogName = init_logger(logNamePrefix, logging.INFO)
    logger = logging.getLogger()

    main()

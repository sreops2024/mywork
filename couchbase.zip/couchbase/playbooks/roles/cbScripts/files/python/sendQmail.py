#!/bin/python3
# Author  : Victor Zuniga
# Date    : 2019.12.10
# Purpose : Provide a simple script that can be used to send email to the Couchbase DBA team.
#           The script will use the email address set in the DBA_EMAIL environment variable.
#           Only expects to receive SUBJECT and MESSAGE_BODY as parameters.

import os
import sys

from bbc_email.dba_email import send_email

vTO = 'couchbase_dba@bbc.com'
vHost = os.environ['HOSTNAME']
vCluster = os.environ['CLUSTER_NAME']
vFROM = 'couchbase@' + vHost + "[" + vCluster + "]"

try:
    vSubj = sys.argv[1]
except:
    vSubj = "No Subject"

try:
    vBody = sys.argv[2]
except:
    vBody = "Empty Message Body"

rc = send_email ( vSubj, vFROM, vTO, vBody )

exit (rc)

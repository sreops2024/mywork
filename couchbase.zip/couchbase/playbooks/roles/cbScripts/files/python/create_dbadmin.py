#!/bin/python3
# ------------------------------------------------------------------------------------------------------------------------
# Author  : Victor Zuniga
# Date    : 2019.12.06
# Purpose : Script to create dbadmin account using encrypted credentials.
# ------------------------------------------------------------------------------------------------------------------------
# History
# 2019.12.06 Victor Zuniga   Initial version
#
# ------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------
#
import logging
import os, sys
import subprocess
import argparse

from bbc_log.dba_log import init_logger
from bbc_fileSec.encServer import getPassword
from bbc_misc.bbc_os import execOSCommand
from bbc_sec.get_creds import get_user_info

# ------------------------------------------------------------------------------------------------------------------------
# Function Definitions
# ------------------------------------------------------------------------------------------------------------------------

def get_args() :
   """ Set up the arguments and return the python dictionary containing the received values """
   parser = argparse.ArgumentParser ( prog = "create_dbadmin.py",
                                      formatter_class=argparse.RawDescriptionHelpFormatter,
                                      description=
      '''
      Script to create dbadmin account
      ''' )
   parser.add_argument ( '-u', '--user', help = 'iAdmin Account to be used', required = True )
   parser.add_argument ( '-p', '--password', help = 'Admin Password to be used' )
   parser.add_argument ( '-d', '--debug', action='store_true',  help = 'Run in DEBUG mode', required = False )

   return  vars(parser.parse_args() )


def main():
    '''Create the dbadmin account'''
   
    logger.info ("Admin Account: " + vAdminAcct )
    logger.debug ("Admin Password: " + vAdminPswd.replace(vAdminPswd, '*' * len(vAdminPswd) ) )

    vCmd = "%s user-manage -c localhost:8091 -u %s -p %s " % (cbCLI, gvArgs['user'], gvArgs['password'] )
    vCmd += "--set --rbac-username %s --rbac-password %s --rbac-name %s " % (vAdminAcct, vAdminPswd, "Couchbase_DBA@bbc.com")
    vCmd += "--roles security_admin,cluster_admin --auth-domain local" 

    vCmdStr = vCmd.replace(vAdminPswd, '*' * len(vAdminPswd) )
    vCmdStr = vCmdStr.replace(gvArgs['password'], '*' * len(gvArgs['password']) )
    logger.debug ("Command: " + vCmdStr )

    logger.info ("Create user")
    vRC = execOSCommand( vCmd )
    if vRC != 0:
       logger.error( "ERROR: Failed to create dbadmin account" )
       logger.error( "Error code: %d" % vRC)
       print ( "ERROR: Failed to create dbadmin account")
       print ( "Error code: " + str(vRC) )
       return 1

    print ("dbadmin account created\n\n")
    return 0

# ------------------------------------------------------------------------------------------------------------------------

if __name__ == '__main__':

    logFileName = 'dbadminCreation'

    gvArgs = get_args()

    if gvArgs['debug']:
       vLogName = init_logger( logFileName, logging.DEBUG )
    else:
       vLogName = init_logger( logFileName, logging.INFO )

    logger = logging.getLogger ()
    logger.info ( "------------------------------------------------------------------------------------------------------------------------" )

    if gvArgs['password'] == None or gvArgs['password'] == '':
        gvArgs['password'] = get_user_info  ("Enter %s\'s Password   : " % gvArgs['user'] )

    # Log arguments recieved
    for arg in gvArgs.keys():
        msg = ("%s: %s") % ( arg, gvArgs[arg] )
        if arg == 'password' and gvArgs[arg] != None:
            msg = msg.replace ( gvArgs[arg], '*' * len(gvArgs[arg]) )
            logger.info (msg)

    # Get dbadmin password
    vAdminAcct = 'dbadmin'
    vAdminPswd = getPassword (vAdminAcct)
    cbCLI = "/opt/couchbase/bin/couchbase-cli"

    
    main()


#!/usr/bin/python3
# Author  : Victor Zuniga
# Date    : 2020.06.09
# Purpose : Recover the current node after a fail over has occured
#           This is intended for DBAs or Admins when the fail over is intended/expected
#
# 2020.06.25 Victor Zuniga       Send email when complete.
# 2020.09.09 Victor Zuniga       Add 10s delay to ally for recovery setting to take place.
#                                This should solve issue where node is rebalanced out of the cluster.
# 2021.02.04 Victor Zuniga       Use node alias from the env variable, since the IP address 
#                                is not guaranteed to be correct (PCI cluster issue).
# 2021.12.14 Victor Zuniga       Fix issue with cluster class call.
# 2023.02.14 Victor Zuniga       Fix issue introduced with new cluster class which returns nodes including
#                                the spare node.  This causes the rebalance call to fail.  Changed the call
#                                to return only the active nodes via method - getActiveNodes()
# 2023.03.13 Victor Zuniga       getActiveNodes excludes the node to be recovered, so change it to getHealthyNodes()
#



import os
import socket
import requests
import time
import json
import logging

from bbc_log.dba_log import init_logger
from pprint import PrettyPrinter
from bbc_cb.env_config import getClusterNames, getClusterNodes
from bbc_fileSec.encServer import getPassword
from bbc_email.dba_email import send_email, email_log
from bbc_cb.cb_cluster import cCluster

# Variables that will need to be provided/found

gvSleepDelay = 10

def getAliasName ( pVMName, pClusterName ):
    ''' Get the alias name based on IP addresses'''

    logger.info("getAliasName : starting")
    
    vNodeAlias = os.getenv("HOST_ALIAS")

    if vNodeAlias != None:
        logger.info("Node: %s - Alias: %s" % (pVMName, vNodeAlias))
        
        return {'host': pVMName.lower(), 'alias': vNodeAlias.lower() }


    try:
        vIP = socket.gethostbyname( pVMName )
    except:
        print ("ERROR: Host Name (" + pVMName + ") is not valid.")
        return None

    logger.info ("getAliasName : " + pVMName + "[" + vIP + "]" )

    if pClusterName in getClusterNames( ):
        vNodeList = getClusterNodes ( pClusterName )
        logger.info ("getAliasName : Node List : " + str(vNodeList) )
        for vNode in vNodeList:
            if vIP == socket.gethostbyname( vNode ):
                logger.info ("getAliasName : Match Found")
                logger.info ("getAliasName : " + pVMName + " -> " + vNode )
                return {'host': pVMName, 'alias': vNode }
    else:
        logger.warning ("getAliasName : No alias found")
        return {}

def setNodeRecovery( pAdminCreds, pNodeAlias, pRecType = 'full' ):
    
    logger.info ("setNodeRecovery : alias : " + pNodeAlias + " - Rec Type : " + pRecType )

    otpNode = 'ns_1@' + pNodeAlias + '.south.edu'
    vData = { 'otpNode' : otpNode , 'recoveryType' : pRecType }

    logger.info ("setNodeRecovery : optNode : " + otpNode)
    logger.info ("setNodeRecovery : data : " + str(vData) )

    vURL = "http://%s.south.edu:8091/controller/setRecoveryType" % (pNodeAlias)

    logger.info ("setNodeRecovery : URL : " + vURL)

    r = requests.post ( vURL, data=vData, auth=(pAdminCreds) )

    if r.status_code != 200:
       logger.error ("setNodeRecovery : request call failed. Status : " + str( r.status_code ) )
       logger.error ("setNodeRecovery : error text : " + r.text )
       print ("ERROR: Failed to run request.post")
       print ("r.text: " + r.text)
       return False

    logger.info ("setNodeRecovery : status_code : " + str( r.status_code ) )
    logger.info ("setNodeRecovery : text : " + r.text )

    return True

def startRebalance( pAdminCreds, pNodeAlias, pClusterNodes ):

    logger.info ("startRebalance : starting")

    tmpList = []
    for node in pClusterNodes:
       tmpList.append('ns_1@' + node + '.south.edu' )
 
    vKnownNodes = ','.join(tmpList)
    logger.info ("startRebalance : known nodes : " + vKnownNodes )

    vData = { 'knownNodes' : vKnownNodes }
    logger.info ("startRebalance : data : " + str(vData) )

    vURL = 'http://' + pNodeAlias + ':8091/controller/rebalance'
    logger.info ("startRebalance : URL : " + vURL )

    r = requests.post( vURL, data=vData, auth=(pAdminCreds) )

    if r.status_code != 200:
        logger.error ("startRebalance : rebalance call failed. Status Code : " + str( r.status_code ) )
        logger.error ("startRebalance : text : " + r.text )
   
        print ("ERROR: Rebalance start failed")
        print ("ERROR: Ret Code: " + str(r.status_code) )
        print ("ERROR: " + r.text )
        return False

    logger.info ("startRebalance : Rebalance Started. Status Code : " + str(r.status_code) )

    return True

def showRebalanceProgress( pAdminCreds, pNodeAlias, delay = 30 ):

    vSleepDelay = 15
    logger.info ("showRebalanceProgress : Sleep delay : " + str( vSleepDelay ) )

    pp = PrettyPrinter(indent=4)

    time.sleep( vSleepDelay )

    vURL = 'http://' + pNodeAlias + '.south.edu:8091/pools/default/rebalanceProgress'
    logger.info ("showRebalanceProgress : URL : " + vURL )

    r = requests.get( vURL, auth=(pAdminCreds) )

    if r.status_code != 200:
        logger.info ("showRebalanceProgress : request failed : status_code : " + str(r.status_code) )
        logger.info ("showRebalanceProgress : text : " + r.text )
        print ("Rebalance Completed or call failed" )
        return True

    logger.info ("showRebalanceProgress : " + str ( r.text ) )
    pp.pprint ( json.loads(r.text ) )
    print ("...")
    logger.info ("showRebalanceProgress : looping until done..." )
    while r.text != '{"status":"none"}':
        time.sleep( vSleepDelay )
        r = requests.get( vURL, auth=(pAdminCreds) )
        logger.info ("showRebalanceProgress : " + str ( r.text ) )
        pp.pprint ( json.loads(r.text ) )
        print ("...")
       
    logger.info ("Rebalance Complete")
    print ("Rebalance Completed")

    return True

def main ():

    pp = PrettyPrinter( indent=4 )

    vVMName = socket.gethostname()
    vClusterName = os.getenv('CLUSTER_NAME')
    vNodeInfo = getAliasName ( vVMName, vClusterName )

    logger.info ("VM Name: " + vVMName)
    logger.info ("Cluster: " + vClusterName )
    logger.info ("Alias  : " + str( vNodeInfo ) )

    if vNodeInfo is {}:
        logger.warning ("Node Alias not found")
        print ("Node Alias unavailable")
        return False

    #vAdminAcct = getPassword('dbadmin')
    vAdminCreds = ('dbadmin', getPassword('dbadmin') )
    logger.info ( ("Admin Creds: " + str(vAdminCreds) ).replace( vAdminCreds[1], '*' * len( vAdminCreds[1]) ) )

    # Get the cluster nodes from the cluster, and not from the config file, to ensure all active nodes are present
    #vClusterNodes = getClusterNodes ( vClusterName )
    #vClusterNodes = list( cCluster( vClusterName, vAdminCreds ).nodeInfo.keys() )
    #vClusterNodes = list( cCluster( vClusterName, vAdminCreds ).clusterInfo['nodes'].keys() )
    vClusterNodes = list( cCluster( vClusterName, vAdminCreds ).getHealthyNodes() )
    logger.info ("Nodes : " + str(vClusterNodes) )

    if setNodeRecovery( vAdminCreds, vNodeInfo['alias'] ):
        # Recovery has been set, start rebalance
        # Delay rebalance by 10 secs
        logger.info("Sleeping for " + str(gvSleepDelay) + " secs")
        time.sleep( gvSleepDelay )
        if startRebalance ( vAdminCreds, vNodeInfo['alias'], vClusterNodes ) :
            showRebalanceProgress ( vAdminCreds, vNodeInfo['alias'] )
            send_email ( Subject = "Couchbase node Recovery [" + vNodeInfo['alias'] + "] Successful",
                         To = os.getenv('DBA_EMAIL'),
                         Body = "VM Name: %s\nAlias : %s\n\nRecovered by admin script." % (vNodeInfo['host'], vNodeInfo['alias'] ) )
            return True
        else:
            logger.info ("Rebalance start failed" )
            email_log ( Subject =  "Couchbase node recovery [" + vNodeInfo['alias'] + "] FAILED",
                        To = os.getenv('DBA_EMAIL'),
                        File = vLogName )
            return False
    else:
        logger.error ("ERROR: Failed to start node recovery")
        print ("ERROR: Failed to start node recovery.")
        email_log ( Subject =  "Couchbase node recovery [" + vNodeInfo['alias'] + "] FAILED",
                    To = os.getenv('DBA_EMAIL'),
                    File = vLogName )
        return False


    return True

if __name__ == "__main__":
    logFileName = 'nodeRecovery'
    vLogName = init_logger( logFileName, logging.INFO )
    logger  = logging.getLogger ()
    logger.info ( "------------------------------------------------------------------------------------------------------------------------" )

    if main():
        logger.info ("Node recovery completed successfully" )
        exit (0)
    else:
        logger.info ("Node recovery completed unsuccessfully" )
        exit (1)



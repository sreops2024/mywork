#!/usr/bin/bash

# ========================================================================================================================
# Author  : Dhinesh V
# Date    : 06/13/2022
# Purpose : Script to create the Analytics  account

#================================================================================================================
# Functions

usage ()
{ # Display usage and exit
   echo "$0 <Admin Password>"
   exit 1
}

# ========================================================================================================================
# Ensure the Administrator password is passed
if [ "$1" == "" ]; then 
   usage 
fi

echo "Creating XDCR Admin Account"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/local/analytics_user -d roles="replication_admin,replication_target[*]" -d name="XDCR Admin" -d password="e9uK93?rwaY_jZEF"

exit 0
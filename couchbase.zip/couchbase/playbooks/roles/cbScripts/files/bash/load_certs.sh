#!/bin/bash
# Victor Zuniga
# 2019.12.05
# Wrapper to be used by puppet to execute certificate load script.
# 2020.05.22 vzuniga Add export to ensure ansible can execute
#                    Add date to the log to see load time.

# Source bash profile
source /home/couchbase/.bash_profile
export HOSTNAME=`hostname`

# Exec load script
#/bin/python3 /home/couchbase/DBA/bin/cert_mgmt/load_certs.py -u $1 -p $2 > ${LOG_DIR}/cert_load.out
# Disable receiving parameters ,temporary fix for certLoad issue.
/bin/python3 /home/couchbase/DBA/bin/cert_mgmt/load_certs.py  > ${LOG_DIR}/cert_load.out
echo "Done: `date`" >> ${LOG_DIR}/cert_load.out

exit 0



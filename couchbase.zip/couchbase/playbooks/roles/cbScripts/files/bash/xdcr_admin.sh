#!/usr/bin/bash

# ========================================================================================================================
# Author  : Victor Zuniga
# Date    : 2018.04.23
# Purpose : Script to create the xdcr admin account

# History :
# Name              Date       Change Description
# ----------------- ---------- ---------------------------------------------------------------------------
# Victor Zuniga     2018.04.23 Initial Creation

# ========================================================================================================================
# Functions

usage ()
{ # Display usage and exit
   echo "$0 <Admin Password>"
   exit 1
}

# ========================================================================================================================
# Ensure the Administrator password is passed
if [ "$1" == "" ]; then 
   usage 
fi

echo "Creating XDCR Admin Account"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/local/xdcr_admin -d roles="replication_admin,replication_target[*]" -d name="XDCR Admin" -d password="tra77ic_c0p"

exit 0


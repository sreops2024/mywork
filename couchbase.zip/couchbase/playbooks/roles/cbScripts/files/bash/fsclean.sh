#!/bin/bash
#set -x

source /home/couchbase/.bash_profile

DT=`date +"%Y%m%d"`

fsclean_tbl=/home/couchbase/DBA/bin/maint/.fsclean.tbl

MAIL_FILE=${LOG_DIR}/fsclean_mail_file.${DT}.log

MAIL_LIST=couchbase_dba@bbc.com
HOSTNAME=`hostname`
HOSTALIAS=${HOST_ALIAS}

###############################################################

MAILIT ()
{
    MAIL_MSG=$1
    MAIL_FILE=$2
    #mailx -s "$MAIL_MSG" $MAIL_LIST < $MAIL_FILE
    /home/couchbase/DBA/bin/maint/sendQmailLog.py "${SUBJECT}" "${MAIL_FILE}"

}

###############################################################

rm ${MAIL_FILE} > /dev/null 2>&1

MAILSUBJ="CB: FSCLEAN on ${HOSTALIAS} [${HOSTNAME}]"

##################################################################

echo "--------------------------------------------------------------------------------" > ${MAIL_FILE}
echo "${HOSTALIAS} [${HOSTNAME}] " >> ${MAIL_FILE}
date >> ${MAIL_FILE} >&1
echo "--------------------------------------------------------------------------------" >> ${MAIL_FILE}
while read  directory retention
do
    echo "${directory} ${retention} days retained " >> ${MAIL_FILE}

    pCount=`ls -l ${directory} | wc -l`
    pSpace=`df -m ${directory} | grep -v Filesystem`

    touch  ${directory}

    find  ${directory} -mtime +$retention -exec rm -f  {} \;
    
    aCount=`ls -l ${directory} | wc -l`
    aSpace=`df -m ${directory} | grep -v Filesystem`

    echo -e "   Before:" >> ${MAIL_FILE}
    echo -e "\tfiles: ${pCount}" >> ${MAIL_FILE}
    echo -e "\tspace: ${pSpace}" >> ${MAIL_FILE}
    echo -e "   After:" >> ${MAIL_FILE}
    echo -e "\tfiles: ${aCount}" >> ${MAIL_FILE}
    echo -e "\tspace: ${aSpace}" >> ${MAIL_FILE}
    echo "--------------------------------------------------------------------------------" >> ${MAIL_FILE}
done  < $fsclean_tbl

RC=$?

if  [ $RC -ne 0 ]
then
    /home/couchbase/DBA/bin/maint/sendQmailLog.py "${MAILSUBJ}" "${MAIL_FILE}"
fi


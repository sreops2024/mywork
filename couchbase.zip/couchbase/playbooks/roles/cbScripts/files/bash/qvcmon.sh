#!/usr/bin/bash

# ========================================================================================================================
# Author  : Victor Zuniga
# Date    : 2018.04.23
# Purpose : Script to create the monitoring account

# History :
# Name              Date       Change Description
# ----------------- ---------- ---------------------------------------------------------------------------
# Victor Zuniga     2018.04.26 Initial Creation

# ========================================================================================================================
# Functions

usage ()
{ # Display usage and exit
   echo "$0 <Admin Password>"
   exit 1
}

# ========================================================================================================================
# Ensure the Administrator password is passed
if [ "$1" == "" ]; then 
   usage 
fi

echo "Creating Monitoring Account"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/local/bbcmon -d roles="ro_admin" -d name="QVC Monitoring" -d password="M3tr1Ca7ch3r"

exit 0


#!/bin/bash
# ========================================================================================================================
# Author   : Victor Zuniga
# Data     : 2018.07.06
# Purpose  : Script to load the security certificates into the Couchbase node/cluster.
# 
# Change History
# Date       User                  Comments
# ---------- --------------------- -------------------------------------------------------------------
# 2018.07.06 Victor Zuniga         Initial version
#
# ========================================================================================================================
# Functions

function usage ()
{ # Display usage and exit
   echo "$0 -u <AdminAcct> [-p <Password>]"
   echo "   if password is not provided, you will be prompted for it and verification."
   exit 1
}

function getPassword()
{ # Get the account password

   stty -echo 
   printf "Password: "
   read PASSWD
   printf "\n"
   printf "Retype Password: "
   read PASSWD2
   stty echo 
   printf "\n"

   if [[ "${PASSWD}" != "${PASSWD2}" ]]; then
      echo "Passwords do not match."
      echo "Try again"
      exit 1
   fi

}

function loadCerts()
{ # Load the certificates into Couchbase node/cluster.

   CB_CLI="/opt/couchbase/bin/couchbase-cli"
   CB_CURL="/opt/couchbase/bin/curl"
   CLUSTER="localhost:8091"
   CERT_PATH="/opt/couchbase/var/lib/couchbase/inbox"
   ROOT_CERT="${CERT_PATH}/ca.pem"

   echo "Load Root Certificate"
   #echo "Creds: ${ADMIN}/${PASSWD}"
   #echo "${CB_CLI} ssl-manage -c ${CLUSTER} -u ${ADMIN} -p ${PASSWD} --upload-cluster-ca=${ROOT_CERT}"
   ${CB_CLI} ssl-manage -c ${CLUSTER} -u ${ADMIN} -p ${PASSWD} --upload-cluster-ca=${ROOT_CERT}
   [ $? -ne 0 ] && echo "ERROR: Could not load ROOT Certificate" &&  exit 1

   echo "Set Node Certificate"
   ${CB_CLI} ssl-manage -c ${CLUSTER} -u ${ADMIN} -p ${PASSWD} --set-node-certificate
   [ $? -ne 0 ] && echo "ERROR: Could not set node Certificate" && exit 1

   echo "Reload Certificate"
   ${CB_CURL} -X POST http://${ADMIN}:${PASSWD}@${CLUSTER}/node/controller/reloadCertificate
   [ $? -ne 0 ] && echo "ERROR: Could not reload certificate" &&  exit 1

   echo "Complete"

}
# ========================================================================================================================

#OPTIND=1

while getopts ":u:p:" opt; do

   case "$opt" in 
      u )
         ADMIN=$OPTARG
         # echo "Got ADMIN: ${ADMIN}"
      ;;
      p )
         PASSWD=$OPTARG
         # echo "Got PASSWD: ${PASSWD}"
      ;;
      \?)
         echo "Invalid option: -$OPTARG" >&2
         exit 1
      ;;
      : )
         echo "Option -$OPTARG required an argument." >&2
         exit 1
      ;;
   esac
done

[ "${ADMIN}" == "" ] && usage

#echo "Get/verify Password"
[ "${PASSWD}" == "" ] && getPassword

# Load certificates
loadCerts

exit 0

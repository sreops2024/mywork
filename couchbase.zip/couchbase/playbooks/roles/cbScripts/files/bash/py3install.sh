#!/bin/bash
# Author  : Victor Zuniga
# Date    : 2019.08.09
# Purpose : Script to install Python3 and create a virtual environment for the modules needed by QVCs couchbase scripts.
#
# 2019.08.16 Victor Zuniga     Add python3 modules outside of the virtual env.
# ## 2019.12.06 Victor Zuniga     Add comment to force install on new hosts.

yum install -y epel-release
yum install -y python36 python36-pip
python3 -m venv /qutil/cbPython3/venv
cd /qutil/cbPython3
source venv/bin/activate
pip install --upgrade pip
pip install requests pycryptodome
deactivate
python3 -m pip install --upgrade pip
python3 -m pip install requests pycryptodome
python3 -m pip install envoy
python3 -m pip install prettytable

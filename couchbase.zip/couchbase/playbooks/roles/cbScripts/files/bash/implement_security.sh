#!/bin/bash
# ========================================================================================================================
# Author   : Raymond Lee
# Data     : 2018.07.23
# Purpose  : Script to enable auditing, XCDR and email security.
#
# Change History
# Date       User                  Comments
# ---------- --------------------- -------------------------------------------------------------------
# 2018.07.23 Raymond Lee           Initial version
# 2018.11.25 Raymond Lee           Updated script to remove depricated flags; Updated values for auditing
# ========================================================================================================================
# Functions

function usage ()
{ # Display usage and exit
   echo "$0 -u <AdminAcct> [-p <Password>]"
   echo "   if password is not provided, you will be prompted for it and verification."
   exit 1
}

function getPassword()
{ # Get the account password

   stty -echo
   printf "Admin Account Password: "
   read PASSWD
   printf "\n"
   printf "Retype Password: "
   read PASSWD2
   stty echo
   printf "\n"

   if [[ "${PASSWD}" != "${PASSWD2}" ]]; then
      echo "Passwords do not match."
      echo "Try again"
      exit 1
   fi

   stty -echo
   printf "XDCR Password: "
   read XDCRPASSWD
   printf "\n"
   printf "Retype Password: "
   read XDCRPASSWD2
   stty echo
   printf "\n"

   if [[ "${XDCRPASSWD}" != "${XDCRPASSWD2}" ]]; then
      echo "Passwords do not match."
      echo "Try again"
      exit 1
   fi


}

function getJsonVal () {
    python -c "import json,sys;sys.stdout.write(json.dumps(json.load(sys.stdin)$1))";
}

function executeSecurityFunctions()
{ # Load the certificates into Couchbase node/cluster.

   CB_CLI="/opt/couchbase/bin/couchbase-cli"
   CB_CURL="/opt/couchbase/bin/curl"
   CLUSTER="localhost:8091"
   CLUSTERNAME=`${CB_CURL} -s -u ${ADMIN}:${PASSWD} http://localhost:8091/pools/default | getJsonVal "['clusterName']"`               #ex: cbfp01i...
   XDCR_USERNAME=`${CB_CURL} -s -u ${ADMIN}:${PASSWD} http://localhost:8091/pools/default/remoteClusters | getJsonVal "[0]['username']"` #ex: xdcr_admin...
   XDCR_HOSTNAME=`${CB_CURL} -s -u ${ADMIN}:${PASSWD} http://localhost:8091/pools/default/remoteClusters | getJsonVal "[0]['hostname']"` #ex: hcb002sp01i:8091...
   XDCR_REP_CLUSTER=`${CB_CURL} -s -u ${ADMIN}:${PASSWD} http://localhost:8091/pools/default/remoteClusters | getJsonVal "[0]['name']"`  #ex: cbsp01i...

   echo "Cluster: " $CLUSTER
   echo "Cluster name: " $CLUSTERNAME
   echo "XDCR_Username: " $XDCR_USERNAME
   echo "XDCR_Hostname: " $XDCR_HOSTNAME
   echo "XDCR_REP_CLUSTER: " $XDCR_REP_CLUSTER

   echo "Enable Auditing"
   ${CB_CLI} setting-audit -c ${CLUSTER} -u ${ADMIN} -p ${PASSWD} --audit-enabled=1 --audit-log-rotate-interval 86400 --audit-log-path /log/audit --audit-log-rotate-size 524288000
   [ $? -ne 0 ] && echo "ERROR: Auditing is NOT enabled" &&  exit 1


   echo "Enable Client Certificate"
   echo "Generating Security JSON file"
   python ~/DBA/cert/CB_Security_JSON.py -u ${ADMIN} -p ${PASSWD}
   [ $? -ne 0 ] && echo "ERROR: Encountered an error generating the Security JSON File" &&  exit 1

   echo "Importing Security JSON File"
   ${CB_CURL} -X POST http://${ADMIN}:${PASSWD}@localhost:8091/settings/clientCertAuth -d@/home/couchbase/DBA/cert/CBSecClientCert.json
   [ $? -ne 0 ] && echo "ERROR: Encountered an error importing the Security JSON File" &&  exit 1

   echo "Enable XCDR TLS"

  eval ${CB_CLI} xdcr-setup -c "${CLUSTER}" -u "${ADMIN}" -p "${PASSWD}" --edit \
  --xdcr-cluster-name="${XDCR_REP_CLUSTER}" --xdcr-hostname="${XDCR_HOSTNAME}" \
  --xdcr-username="\"xdcr_admin"\" --xdcr-password="${XDCRPASSWD}" \
  --xdcr-secure-connection=full --xdcr-certificate=/opt/couchbase/var/lib/couchbase/inbox/ca.pem

  [ $? -ne 0 ] && echo "ERROR: Could NOT enable XDCR encryption" && exit 1


   #echo "Enable Email TLS"
   #${CB_CURL} -i -u ${ADMIN}:${PASSWD} http://localhost:8091/settings/alerts \
   #-d 'enabled=true&sender=couchbase@'${CLUSTERNAME:1:-1}'&recipients=couchbase_DBA@bbc.com,esmauto@bbc.com,esmauto2@bbc.com&emailHost=localhost&emailPort=25&emailEncrypt=true' \
   #-d 'alerts=auto_failover_node,auto_failover_maximum_reached,auto_failover_other_nodes_down,auto_failover_cluster_too_small,auto_failover_disabled,ip,disk,overhead,ep_oom_errors,ep_item_commit_failed,audit_dropped_events,indexer_ram_max_usage,ep_clock_cas_drift_threshold_exceeded,communication_issue'

   #[ $? -ne 0 ] && echo "ERROR: Could NOT enable TLS on email alerts" &&  exit 1

   echo "Complete"

}
# ========================================================================================================================

#OPTIND=1

while getopts ":u:p:" opt; do

   case "$opt" in
      u )
         ADMIN=$OPTARG
         # echo "Got ADMIN: ${ADMIN}"
      ;;
      p )
         PASSWD=$OPTARG
         # echo "Got PASSWD: ${PASSWD}"
      ;;
      \?)
         echo "Invalid option: -$OPTARG" >&2
         exit 1
      ;;
      : )
         echo "Option -$OPTARG required an argument." >&2
         exit 1
      ;;
   esac
done

[ "${ADMIN}" == "" ] && usage

echo "Get/verify Password"
[ "${PASSWD}" == "" ] && getPassword

echo "Get/verify XDCR Password"
[ "${XDCRPASSWD}" == "" ] && getPassword

#Execute Security Functions
executeSecurityFunctions

exit 0

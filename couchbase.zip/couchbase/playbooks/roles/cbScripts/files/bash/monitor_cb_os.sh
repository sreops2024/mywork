#!/bin/bash
# Author  : John Fak (and Victor Zuniga)
# Date    : 2019.12.10
# Purpose : Capture OS metrics on the Couchbase nodes.
#

source /home/couchbase/.bash_profile

LOG_DIR=/log/cb_mon_os
MSG_FILE=/tmp/cb_monitor_os.msg

rm -f ${MSG_FILE} > /dev/null 2>&1

######################
#collect top proc statisics
######################
if ! /usr/sbin/fuser -s ${LOG_DIR}/top_samples.dat; then 
   /usr/bin/top -b -H -d 5 | sed 's/[ ?]*$//g' | grep --regexp "top - [0-9][0-9]:[0-9][0-9]:[0-9][0-9] up.*load average.*" -A 100 2>/dev/null >> ${LOG_DIR}/top_samples.dat &
   echo "Starting TOP samples monitoring" >> ${MSG_FILE}
fi

######################
#collect IO statistics
######################
if ! /usr/sbin/fuser -s ${LOG_DIR}/iostat_samples.dat; then 
   /usr/bin/iostat -t -x -p  5  2>/dev/null >> ${LOG_DIR}/iostat_samples.dat &
   echo "Starting IOSTAT samples monitoring" >> ${MSG_FILE}
fi

######################
#collect CPU core stat
######################
if ! /usr/sbin/fuser -s ${LOG_DIR}/mpstat_samples.dat; then 
   /usr/bin/mpstat -P ALL  5  2>/dev/null >> ${LOG_DIR}/mpstat_samples.dat &
   echo "Starting MPSTAT samples monitoring" >> ${MSG_FILE}
fi

######################
#collect vmstat for memory treends
######################
if ! /usr/sbin/fuser -s ${LOG_DIR}/vmstat_samples.dat; then 
   /usr/bin/vmstat -t 5  2>/dev/null >> ${LOG_DIR}/vmstat_samples.dat &
   echo "Starting VMSTAT samples monitoring" >> ${MSG_FILE}
fi

if test -f ${MSG_FILE}; then
   msg=`cat ${MSG_FILE}`
   /home/couchbase/DBA/bin/sendQmail.sh "Couchbase OS Monitoring - [${CLUSTER_NAME}:${HOST_ALIAS}]" "${msg}"
fi

exit 0
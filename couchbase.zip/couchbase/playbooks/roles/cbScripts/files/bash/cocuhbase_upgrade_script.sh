#/bin/bash
###Author: Dhinesh
###Purpose: This script is to automate the couchbase upgrade prcoess on each node. This script will be executed under assumption that temporary 
####node was already added as part of the upgrade process. It when executed on the node, does a graceful failover, stops the cluster, upgrades the cluster using rpm command
####does a delta recovery and rebalnces the cluster. 
#### If the node runs the  query and index services, the script will remove the node, stops the cluster, add the node with query and index service and then does a rebalance. 
export CB_USERNAME=aqusdvi 
export CB_PASSWORD=*******
export TEMP_NODE=U01VDAALAPP0451
export CB_HOME=/opt/couchbase/bin/
export CLUSTER_STATUS_BEFORE_UPGRADE=/tmp/preup.txt
#####Couchbase upgrade steps
##### Script to add a temporary node to a cluster, Assumption is this node is already upgraded to the latest version 
cluster_info()
{
for hosts in `/opt/couchbase/bin/couchbase-cli host-list  -c localhost:8091 --username $CB_USERNAME --password $CB_PASSWORD |awk -F ':' '{print $1}'`
do 
export VERSION=$(/opt/couchbase/bin/couchbase-cli server-info  -c $hosts:8091 --username $CB_USERNAME --password $CB_PASSWORD  |grep version |awk -F ':' '{print $2}' | awk '{gsub(/\"/,"")};1')
export IS_DATA=$(/opt/couchbase/bin/couchbase-cli server-info  -c $hosts:8091  --username $CB_USERNAME --password $CB_PASSWORD  | sed -n '/services/,/status/p' |grep kv |wc -l )
export IS_QUERY=$(/opt/couchbase/bin/couchbase-cli server-info  -c $hosts:8091 --username $CB_USERNAME --password $CB_PASSWORD   | sed -n '/services/,/status/p' |grep n1ql |wc -l )
export IS_INDEX=$(/opt/couchbase/bin/couchbase-cli server-info  -c $hosts:8091  --username $CB_USERNAME --password $CB_PASSWORD   | sed -n '/services/,/status/p' |grep index|wc -l )
    if [ $IS_DATA -eq 1 -a  $IS_QUERY -eq 1 -a  $IS_INDEX -eq 1  ]
        then 
        export service=data,index,query 
        elif [ $IS_DATA -eq 1 -a  $IS_QUERY -eq 0 -a  $IS_INDEX -eq 0 ] 
    then 
        export service=data
    elif [  $IS_DATA -eq 1 -a  $IS_QUERY -eq  0 -a  $IS_INDEX -eq  0  ] 
    then 
        export service=data 
    elif [  $IS_DATA -eq 0 -a  $IS_QUERY -eq  1 -a  $IS_INDEX -eq  1  ] 
    then 
        export service=index,query
        elif [  $IS_DATA -eq 1 -a  $IS_QUERY -eq  1 -a  $IS_INDEX -eq  0  ] 
    then 
        export service=index,query
    else 
        echo "check the services "
        exit 1
    fi 
echo " Hostname:$hosts version:$VERSION service: $service"
echo " Hostname:$hosts version:$VERSION service: $service" > $CLUSTER_STATUS_BEFORE_UPGRADE
done 
}
cluster_info



#!/bin/bash
# Author  :
# Date    :
# Purpose : Script to create/reset the dbadmin account in Couchbase
#
# History
# ----------------------------------------------------------------------------------------------------
# User                Date       Comments
# ------------------- ---------- ---------------------------------------------------------------------
# Victor Zuniga       2019.08.30 Initial version
#
# ----------------------------------------------------------------------------------------------------

function usage ()
{ # Display usage and exit
   echo "$0 -u <AdminAcct> [-p <Password>]"
   echo "   if password is not provided, you will be prompted for it"
   exit 1
}

function getPassword()
{ # Get the account password

   stty -echo
   printf "Password: "
   read ADMINPWD
   stty echo
   printf "\n"

}

# ----------------------------------------------------------------------------------------------------

USER='dbadmin'

PSWD="$(python3 /home/couchbase/DBA/bin/gc.py 2>&1)"

CLUSTER="localhost"
PORT="8091"

while getopts ":u:p:" opt; do

   case "$opt" in
      u )
         ADMIN=$OPTARG
      ;;
      p )
         ADMINPWD=$OPTARG
      ;;
      \?)
         echo "Invalid option: -$OPTARG" >&2
         exit 1
      ;;
      : )
         echo "Option -$OPTARG required an argument." >&2
         exit 1
      ;;
   esac
done

[ "${ADMIN}" == "" ] && usage

[ "${ADMINPWD}" == "" ] && getPassword

/opt/couchbase/bin/couchbase-cli user-manage -c ${CLUSTER}:${PORT} -u ${ADMIN} -p ${ADMINPWD}  \
   --set --rbac-username dbadmin --rbac-password ${PSWD} --rbac-name "DB Admin" \
   --roles security_admin,cluster_admin --auth-domain local

exit 0


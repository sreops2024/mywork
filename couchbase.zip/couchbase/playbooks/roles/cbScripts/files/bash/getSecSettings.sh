#!/bin/bash
#
# Author  : Victor Zuniga
# Date    : 2021.05.14
# Purpose : SCript to display the Couchbase security settings for the particular cluster provided.
#

CB_USERNAME=${CB_USERNAME:=${MON_USER}}
CB_PASSWORD=${CB_PASSWORD:=${MON_PSWD}}
NODE='localhost'
PORT=${PORT:='8091'}
PROTOCOL=${PROTOCOL:='http'}

TODAY=`date +"%Y%m%d.%H%M%S"`
LOG="${LOG_DIR}/getSecSettings.${TODAY}.log"
OUTPIPE="/tmp/getSecSettings.pipe"

function setLogging {

  if [ ! -e $OUTPIPE ]; then
     mkfifo $OUTPIPE
  fi
  if [ -e $LOG ]; then
     rm $LOG
  fi

  exec 3>&1 4>&2
  tee $LOG < $OUTPIPE >&3 &
  tpid=$!
  exec >> $OUTPIPE 2>&1
}

function cleanUpLogging {

  exec 1>&3 3>&1 2>&4 4>&-
  wait $tpid

  rm $OUTPIPE

}

function usage {
   echo "$0 [options]"
   echo "   options:"
   echo "     --node=<s>              The node (node alias) name"
   echo "     --username=<s>          Cluster Admin or RBAC username (default: Administrator)"
   echo "     --password=<s>          Cluster Admin or RBAC password (default: password)"
   echo "     --port=<port#>          Port number (default: 8091)"
   echo "     --protocol=<protocol>   Protocol (default: http)"

   exit 1

}

while [ $# -gt 0 ]; do
  case "$1" in
    --username=*)
      CB_USERNAME="${1#*=}"
      ;;
    --password=*)
      CB_PASSWORD="${1#*=}"
      ;;
    --node=*)
      NODE="${1#*=}"
      ;;
    --port=*)
      PORT="${1#*=}"
      ;;
    --protocol=*)
      PROTOCOL="${1#*=}"
      ;;
    *)
      printf "* Error: Invalid argument.*\n"
      exit 1
  esac
  shift
done

if [[ ${NODE} == '' ]]; then
   usage
fi

if [[ ${CB_USERNAME} == '' ]]; then
   usage
fi

if [[ ${CB_PASSWORD} == '' || ${CB_USERNAME} != ${MON_USER} ]]; then
  read -s -p "${CB_USERNAME}'s Password: " CB_PASSWORD
fi

setLogging


WHO=`whoami`
WHOAMI=`who am i | awk '{print $1}'`
DT=`date`
echo ""
echo "Starting : `date`"
echo "============================================================================================================"
echo "Running by : ${WHO}"
echo "Loging acct: ${WHOAMI}"
echo "Date:      : ${DT}"
echo "Cluster Usr: ${CB_USERNAME}"
echo "Node       : ${NODE}"
echo "============================================================================================================"

echo ""
CLI="/opt/couchbase/bin/couchbase-cli"
CURL=`which curl`
JQ=`which jq`

#echo "CURL: ${CURL}"

echo "============================================================================================================"

echo "Security settings: ${NODE}"
echo ""

CMD="${CURL} -X GET -u ${CB_USERNAME}:${CB_PASSWORD} ${PROTOCOL}://${NODE}:${PORT}/settings/security "
CMDOUT=$($CMD 2>/dev/null)

disUIOverHttp=`echo ${CMDOUT} | ${JQ} '.disableUIOverHttp' `
disUIOverHttps=`echo ${CMDOUT} | ${JQ} '.disableUIOverHttps' `
tlsMinVer=`echo ${CMDOUT} | ${JQ} '.tlsMinVersion' `
ciphers=`echo ${CMDOUT} | ${JQ} '.cipherSuites' `
echo "Disable UI Over http : ${disUIOverHttp}"
echo "Disable UI Over https: ${disUIOverHttps}"
echo "TLS Min Version      : ${tlsMinVer}"
echo "Enabled Ciphers      : ${ciphers}"
echo ""

CMD="${CLI} ip-family -c ${PROTOCOL}://${NODE}:${PORT} -u ${CB_USERNAME} -p ${CB_PASSWORD} --get"
#echo "CMD: ${CMD}"
IPFAM=$($CMD)
echo "IP Family: ${IPFAM}"
echo ""

CMD="${CURL} -X GET -u ${CB_USERNAME}:${CB_PASSWORD} ${PROTOCOL}://${NODE}:${PORT}/settings/autoFailover "
CMDOUT=$($CMD 2>/dev/null)

foEnabled=`echo ${CMDOUT} | ${JQ} '.enabled' `
foTimeout=`echo ${CMDOUT} | ${JQ} '.timeout' `

echo "Cluster Timeout Settings:"
echo "... enabled: ${foEnabled}"
echo "... timout : ${foTimeout} secs"


echo "============================================================================================================"
echo "Done : `date` "

cleanUpLogging

exit 0

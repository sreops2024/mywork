#!/usr/bin/bash

# ========================================================================================================================
# Author  : Victor Zuniga
# Date    : 2018.04.23
# Purpose : Script to create the backup admin account

# History :
# Name              Date       Change Description
# ----------------- ---------- ---------------------------------------------------------------------------
# Victor Zuniga     2018.04.23 Initial Creation
# Mark Dealy        2018.05.31 Copied for Backup admin account.

# ========================================================================================================================
# Functions

usage ()
{ # Display usage and exit
   echo "$0 <Admin Password>"
   exit 1
}

# ========================================================================================================================
# Ensure the Administrator password is passed
if [ "$1" == "" ]; then
   usage
fi

echo "Creating BKUP Admin Account"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/local/bkup_admin -d roles="data_backup[*]" -d name="BACKUP Admin" -d password="N0t_C0mmVlt!"

exit 0


#!/usr/bin/bash

# ========================================================================================================================
# Author  : Victor Zuniga
# Date    : 2018.04.23
# Purpose : Script to make changes to the cluster upon initialization.

# History :
# Name              Date       Change Description
# ----------------- ---------- ---------------------------------------------------------------------------
# Victor Zuniga     2018.04.24 Initial Creation

# ========================================================================================================================
# Functions

usage ()
{ # Display usage and exit
   echo "$0 <Admin Password>"
   exit 1
}

# ========================================================================================================================
# Ensure the Administrator password is passed
if [ "$1" == "" ]; then 
   usage 
fi

echo "Disable HTTP Access"
/opt/couchbase/bin/curl -u Administrator:$1 http://localhost:8091/settings/security -d disableUIOverHttp=true

echo "Set SSL Minumim Protocol to TLS v1.2"
/opt/couchbase/bin/curl -X POST -u Administrator:$1 http://localhost:8091/diag/eval -d "ns_config:set(ssl_minimum_protocol, 'tlsv1.2')"

echo "Enable Cluster LDAP feature"
/opt/couchbase/bin/couchbase-cli setting-ldap -c localhost:8091 -u Administrator -p $1 --ldap-enabled 1

exit 0


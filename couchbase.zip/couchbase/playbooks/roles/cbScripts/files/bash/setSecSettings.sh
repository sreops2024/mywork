#!/bin/bash
#
# Author  : Victor Zuniga
# Date    : 2021.05.14
# Purpose : SCript to set the Couchbase security settings for the particular cluster provided.
#

CB_USERNAME=${CB_USERNAME:='Administrator'}
CB_PASSWORD=${CB_PASSWORD:=''}
NODE='localhost'
PORT=${PORT:='8091'}
PROTOCOL=${PROTOCOL:='http'}

TODAY=`date +"%Y%m%d.%H%M%S"`
LOG="${LOG_DIR}/setSecSettings.${TODAY}.log"
OUTPIPE="/tmp/getSecSettings.pipe"

function setLogging {

  if [ ! -e $OUTPIPE ]; then
     mkfifo $OUTPIPE
  fi
  if [ -e $LOG ]; then
     rm $LOG
  fi

  exec 3>&1 4>&2
  tee $LOG < $OUTPIPE >&3 &
  tpid=$!
  exec >> $OUTPIPE 2>&1
}

function cleanUpLogging {

  exec 1>&3 3>&1 2>&4 4>&-
  wait $tpid

  rm $OUTPIPE

}

function usage {
   echo "$0 [options]"
   echo "   options:"
   echo "     --node=<s>              The node (node alias) name"
   echo "     --username=<s>          Cluster Admin or RBAC username (default: Administrator)"
   echo "     --password=<s>          Cluster Admin or RBAC password (default: password)"
   echo "     --port=<port#>          Port number (default: 8091)"
   echo "     --protocol=<protocol>   Protocol (default: http)"

   exit 1

}


while [ $# -gt 0 ]; do
  case "$1" in
    --username=*)
      CB_USERNAME="${1#*=}"
      ;;
    --password=*)
      CB_PASSWORD="${1#*=}"
      ;;
    --node=*)
      NODE="${1#*=}"
      ;;
    --port=*)
      PORT="${1#*=}"
      ;;
    --protocol=*)
      PROTOCOL="${1#*=}"
      ;;
    *)
      printf "* Error: Invalid argument.*\n"
      exit 1
  esac
  shift
done

if [[ ${NODE} == '' || ${CB_USERNAME} == '' ]]; then
   usage
fi


if [[ ${CB_PASSWORD} == '' ]]; then
  read -s -p "${CB_USERNAME}'s Password: " CB_PASSWORD
fi

CLI="/opt/couchbase/bin/couchbase-cli"
CURL=`which curl`
JQ=`which jq`

setLogging

echo "Starting : `date`"
echo "============================================================================================================"

echo "Security settings: ${NODE}"
echo ""
echo "Setting Security settings:"
echo "   - disable UI over http: true"
echo "   - min TLS version: 1.2"
echo "   - ciphers: [TLS_DHE_RSA_WITH_AES_256_CBC_SHA256, TLS_DHE_DSS_WITH_AES_256_CBC_SHA256, TLS_RSA_WITH_AES_256_CBC_SHA256, "
echo "               TLS_DHE_RSA_WITH_AES_128_CBC_SHA256, TLS_DHE_DSS_WITH_AES_128_CBC_SHA256, TLS_RSA_WITH_AES_128_CBC_SHA256, "
echo "               TLS_DHE_RSA_WITH_AES_256_CBC_SHA256, TLS_DHE_DSS_WITH_AES_256_CBC_SHA, TLS_RSA_WITH_AES_256_CBC_SHA]       "

echo -n "... modifying security settings ... "
RC=`${CURL} -X POST -u ${CB_USERNAME}:${CB_PASSWORD} ${PROTOCOL}://${NODE}:${PORT}/settings/security \
-d disableUIOverHttp=true \
-d tlsMinVersion=tlsv1.2 \
-d 'cipherSuites=["TLS_DHE_RSA_WITH_AES_256_CBC_SHA256","TLS_DHE_DSS_WITH_AES_256_CBC_SHA256","TLS_RSA_WITH_AES_256_CBC_SHA256", \
"TLS_DHE_RSA_WITH_AES_128_CBC_SHA256","TLS_DHE_DSS_WITH_AES_128_CBC_SHA256","TLS_RSA_WITH_AES_128_CBC_SHA256", \
"TLS_DHE_RSA_WITH_AES_256_CBC_SHA256","TLS_DHE_DSS_WITH_AES_256_CBC_SHA","TLS_RSA_WITH_AES_256_CBC_SHA"]' 2>/dev/null`


if [[ ${RC} != "[]" ]]; then
   echo "oops"
   echo "ERROR: encounter error setting security on cluster [${NODE}]"
   echo "ERROR: Ret Code: ${RC}"
   echo -1
else
   echo "OK"
fi

echo ""
echo "Setting IP Family to ipv4"
echo -n "... disablinng autofailover ... "
RC=`${CLI} setting-autofailover -c ${PROTOCOL}://${NODE}:${PORT} -u ${CB_USERNAME} -p ${CB_PASSWORD} --enable-auto-failover 0`
rc=`echo ${RC} | cut -d: -f1`
if [[ ${rc} != 'SUCCESS' ]]; then
   echo "oops"
   echo "ERROR: Failed to disable auto failover"
   echo "ERROR: RC = ${RC}"
   exit -1
else
   echo "OK"
fi

echo -n "... setting ip family to IPV4 ... "
RC=`${CLI} ip-family -c ${PROTOCOL}://${NODE}:${PORT} -u ${CB_USERNAME} -p ${CB_PASSWORD} --set --ipv4`
rc=`echo ${RC} | cut -d: -f1`
#if [[ ${rc} != 'SUCCESS' ]]; then
if grep -q "SUCCESS" <<< "$RC"; then
   echo "OK"
else
   echo "oops"
   echo "ERROR: Failed to set ip family to ipv4"
   echo "ERROR: RC = ${RC}"
   echo "Verify cluster and auto failover settings."
   exit -1
fi

echo -n "... enabling autofailover ... "
RC=`${CLI} setting-autofailover -c ${PROTOCOL}://${NODE}:${PORT} -u ${CB_USERNAME} -p ${CB_PASSWORD} --enable-auto-failover 1 --auto-failover-timeout 15`
if [[ ${RC} =~ .*"SUCCESS".* ]]; then
   echo "OK"
else
   echo "oops"
   echo "ERROR: Failed to disable auto failover"
   echo "ERROR: RC = ${RC}"
   exit -1
fi

echo "============================================================================================================"
echo "Done : `date` "

#echo ${CMDOUT} | ${JQ} '.'
cleanUpLogging

exit 0

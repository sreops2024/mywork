#!/bin/bash
# Author  : Victor Zuniga
# Date    : 2019.12.10
# Purpose : Provide a wrapper script for python email script.

SUBJECT=${1:-"No Subject"}
MESSAGE=${2:-"No Message"}

/home/couchbase/DBA/bin/sendQmail.py "${SUBJECT}" "${MESSAGE}"



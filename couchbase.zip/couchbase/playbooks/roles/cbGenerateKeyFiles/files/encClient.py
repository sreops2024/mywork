# Author  : Victor Zuniga
# Date    : 2019.06.04
# Purpose : Package of client encryption functions used in generation of cluster keys and credential files

# ----------------------------------------------------------------------------------------------------------------------

from bbc_log.dba_log import *
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
from Crypto.Cipher import AES, PKCS1_OAEP

logger = logging.getLogger(__name__)

# ----------------------------------------------------------------------------------------------------------------------

def createFile(pFileName, pData, pMode='wb'):
   '''Save received data to file'''

   logger.debug(" createFile ~ FileName: " + pFileName + " Mode: " + pMode)
   try:
      with open(pFileName, pMode) as f:
         f.write(pData)

   except IOError:
      logger.error("ERROR: Can't open " + pFileName)
      return False

   return True


# ----------------------------------------------------------------------------------------------------------------------

def genRSAKeys(pPath, pName):
   '''Function that will cgenerate the RSA Key files for a given host/cluster on a provided directory'''

   logger.debug("genRSAKeys:")
   logger.debug("...Path: " + pPath)
   logger.debug("...Name: " + pName)

   vPubKey = pPath + "/" + pName + ".bin"
   vPrvKey = pPath + "/" + pName + "_priv.bin"

   vCode = 'Zeazqohryxqujbcy'
   vKey = RSA.generate(2048)
   vEncKey = vKey.exportKey(passphrase=vCode, pkcs=8, protection="scryptAndAES128-CBC")

   if not createFile(vPubKey, vKey.publickey().exportKey(), 'wb'):
      logger.error("ERROR: Error creating file " + vPubKey)
      return False
   else:
      logger.info("Created public Key file: " + vPubKey)

   if not createFile(vPrvKey, vEncKey, 'wb'):
      logger.error("ERROR: Error creating file " + vPrvKey)
      return False
   else:
      logger.info("Created public Key file: " + vPrvKey)

   return True


# ----------------------------------------------------------------------------------------------------------------------

def getPublickKey(pPath, pName):
   '''Returns public key found in path received for file name received.'''

   logger.debug("getPuclicKey")
   logger.debug("... path: " + pPath)
   logger.debug("... name: " + pName)

   vKeyFile = pPath + "/" + pName + ".bin"

   logger.info("Reading file: " + vKeyFile)

   try:
      vPublicKey = RSA.import_key(open(vKeyFile).read())
   except:
      logger.error("ERROR: Could not access file: " + vKeyFile )
      return False

   return vPublicKey


# ----------------------------------------------------------------------------------------------------------------------

def genCredFile(pPath, pName, pCreds):
   '''Received the credentials and file destination and name, and will encrypt using the public key in that directory'''

   logger.debug("encAdminClusterFile:")
   logger.debug("... path: " + pPath)
   logger.debug("... name: " + pName)

   vCredFile = pPath + "/" + pName + "." + pCreds[0] + ".cred"
   logger.info("Cred file: " + vCredFile)

   # pCreds is a tuple with user, password information.  Convert it to a dictionary to encript.
   if not isinstance(pCreds, tuple) :
      logger.error("ERROR: The credentials received are not a tuple.")
      logger.error("ERROR: Check the credentials datatype.")
      return False

   vCred = {}
   vCred[pCreds[0]] = pCreds[1]
   vCredData = str(vCred).encode()

   vKey = getPublickKey(pPath, pName)

   #if type(vKey) == type(False):
   #   '''There was an error getting the key file'''
   #   logger.error("ERROR: Key is invalid")
   #   print ("ERROR: Key for cluster " + pName + " is not valid.  Verify")
   #  return False

   try:
      with open(vCredFile, 'wb') as outFile:
         vSessionKey = get_random_bytes(16)
         vCipherRSA = PKCS1_OAEP.new(vKey)
         outFile.write(vCipherRSA.encrypt(vSessionKey))

         vCipherAES = AES.new(vSessionKey, AES.MODE_EAX)
         vCipherText, vTag = vCipherAES.encrypt_and_digest(vCredData)

         outFile.write(vCipherAES.nonce)
         outFile.write(vTag)
         outFile.write(vCipherText)

   except IOError:
      logger.error("ERROR: Could not create file: " + vCredFile)
      return False

   return True

# ----------------------------------------------------------------------------------------------------------------------


#!/usr/bin/bash

# ========================================================================================================================
# Author  : Victor Zuniga
# Date    : 2018.04.23
# Purpose : Script to generate the DBA accounts in the local cluster.

# History :
# Name              Date       Change Description
# ----------------- ---------- ---------------------------------------------------------------------------
# Victor Zuniga     2018.04.23 Initial Creation
# Victor Zuniga     2019.04.26 Remove accounts for Ray, Sarayu, Krishna

# ========================================================================================================================
# Functions

usage ()
{ # Display usage and exit
   echo "$0 <Admin Password>"
   exit 1
}

# ========================================================================================================================
# Ensure the Administrator password is passed
if [ "$1" == "" ]; then 
   usage
fi

echo "Creating Account for Victor Zuniga"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/external/aqusvzu -d roles=admin -d name="Victor Zuniga"

echo "Creating Account for Joe Tarsatana"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/external/aqusjta -d roles=admin -d name="Joe Tarsatana"

echo "Creating Account for Mark Dealy"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/external/aqusmde -d roles=admin -d name="Mark Dealy"

echo "Creating Account for Anthony Cordell"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/external/aqusaco -d roles=admin -d name="Anthony Cordell"

echo "Creating Account for Dhinesh Viswanathan"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/external/aqusdvi -d roles=admin -d name="Dhinesh Viswanathan"

echo "Creating Account for Ellen Cox"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/external/aquseco -d roles=admin -d name="Ellen Cox"

echo "Creating Account for John Fak"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/external/aqusjfa -d roles=admin -d name="John Fak"

echo "Creating Account for Mike Thompson"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/external/aqusmth -d roles=admin -d name="Mike Thompson"

echo "Creating Account for Patrick Santucci"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/external/aquspsa -d roles=admin -d name="Patrick Santucci"

echo "Creating Account for Joyce White"
/opt/couchbase/bin/curl -X PUT -u Administrator:$1 http://localhost:8091/settings/rbac/users/external/aqusjwh -d roles=admin -d name="Joyce White"

exit 0


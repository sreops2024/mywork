# ------------------------------------------------------------------------------------------------------------------------
# Author : Victor Zuniga
# Date   : 2017.12.15
# Purpose: Define a class to handle the bucket information for Couchbase Buckets.
#
# 2018.11.26 Victor Zuniga  Initial Class definition
#
# ------------------------------------------------------------------------------------------------------------------------

import sys

sys.path.insert ( 0, '/home/mobaxterm/vzuniga/pythonmods/' )

from bbc_log.dba_log import *

class cBucket ( object ):

   def __init__ (self, name):
      logger.info ("Initializing bucket : %s" % ( name ) )
      self.bucketName = name.lower()

   def __str__ (self):
      return self.bucketName



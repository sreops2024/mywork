import os
import sys
import random

sys.path.insert ( 0,'/home/couchbase/DBA/tools/pythonmods' )

from bbc_log.dba_log import *

logger = logging.getLogger ( __name__ )

# ------------------------------------------------------------------------------------------------------------------------

CBENV_PORT = {
  'i' : {
    'cbfp01i' : {'hcb001fp01i' : '8901', 'hcb002fp01i' : '8091' },
    'cbfp02i' : {'hcb001fp02i' : '8901', 'hcb002fp02i' : '8091' },
    'cbsp01i' : {'hcb001sp01i' : '8091', 'hcb002sp01i' : '8091' } }, 
  'q'  : {
    'cbfp01q' : {'hcb001fp01q' : '8091', 'hcb002fp01q' : '8091', 'hcb003fp01q' : '8091', 'hcb004fp01q' : '8091', 'hcb005fp01q' : '8091' },
    'cbsp01q' : {'hcb001sp01q' : '8091', 'hcb002sp01q' : '8091', 'hcb003sp01q' : '8091', 'hcb004sp01q' : '8091', 'hcb005sp01q' : '8091' },
    'cbsp03q' : {'hcb001sp03q' : '8091', 'hcb002sp03q' : '8091', 'hcb003sp03q' : '8091', 'hcb004sp03q' : '8091', 'hcb005sp03q' : '8091' },
    'cbfp03q' : {'hcb001fp03q' : '8091', 'hcb002fp03q' : '8091', 'hcb003fp03q' : '8091' }
    }, 
  'p': {
    'cbfp01p' : {'hcb001fp01p' : '8091', 'hcb002fp01p' : '8091', 'hcb003fp01p' : '8091', 'hcb004fp01p' : '8091', 'hcb005fp01p' : '8091' },
    'cbsp01p' : {'hcb001sp01p' : '8091', 'hcb002sp01p' : '8091', 'hcb003sp01p' : '8091', 'hcb004sp01p' : '8091', 'hcb005sp01p' : '8091' },
    'cbfp03p' : {'hcb001fp03p' : '8091', 'hcb002fp03p' : '8091', 'hcb003fp03p' : '8091', 'hcb004fp03p' : '8091', 'hcb005fp03p' : '8091' }
    }
  }

CBENV = {
  'i' : {
    'cbfp01i' : ['hcb001fp01i', 'hcb002fp01i'],
    'cbsp01i' : ['hcb001sp01i', 'hcb002sp01i'],
    'cbfp02i' : ['hcb001fp02i', 'hcb002fp02i'],
    'cbsp02i' : ['hcb001sp02i', 'hcb002sp02i']
    }, 
  'q'  : {
    'cbfp01q' : ['hcb001fp01q', 'hcb002fp01q', 'hcb003fp01q', 'hcb004fp01q', 'hcb005fp01q' ],
    'cbsp01q' : ['hcb001sp01q', 'hcb002sp01q', 'hcb003sp01q', 'hcb004sp01q', 'hcb005sp01q' ],
    'cbfp03q' : ['hcb001fp03q', 'hcb002fp03q', 'hcb003fp03q' ],
    'cbsp03q' : ['hcb001sp03q', 'hcb002sp03q', 'hcb003sp03q', 'hcb004sp03q', 'hcb005sp03q' ]
    }, 
  'p': {
    'cbfp01p' : ['hcb001fp01p', 'hcb002fp01p', 'hcb003fp01p', 'hcb004fp01p', 'hcb005fp01p' ],
    'cbsp01p' : ['hcb001sp01p', 'hcb002sp01p', 'hcb003sp01p', 'hcb004sp01p', 'hcb005sp01p' ],
    'cbfp03p' : ['hcb001fp03p', 'hcb002fp03p', 'hcb004fp03p', 'hcb004fp03p', 'hcb005fp03p' ],
    'cbfp04p' : ['hcb001fp04p', 'hcb002fp04p', 'hcb003fp04p', 'hcb004fp04p', 'hcb005fp04p' ],
    'cbsp04p' : ['hcb001sp04p', 'hcb002sp04p', 'hcb003sp04p', 'hcb004sp04p', 'hcb005sp04p' ]
    } 
  }

PORT = 8091
TLS_PORT = 18091
FQDN = 'south.edu'

# ------------------------------------------------------------------------------------------------------------------------

def getRandomNode ( pENV ):
   """Return single node (random) for each env cluster in each data center.  Currently, it will return list of 2 host names."""

   logger.debug("getRandomNode")

   vNodes = []

   for vCluster in CBENV[ pENV ].keys():
      logger.debug ("Cluster: %s" % vCluster )
      tNode = CBENV[ pENV ][vCluster][random.randint(0, len(CBENV[ pENV ][vCluster])-1 )]
      logger.debug ("   Node: %s" % tNode)
      vNodes.append (tNode)

   logger.info ( "Nodes: %s" % vNodes )

   return vNodes
   
# ------------------------------------------------------------------------------------------------------------------------

def getFirstNode ( pENV ):
   """Return single (first) node for each env cluster in each data center.  Currently, it will return list of 2 host names."""

   logger.debug("getFirstNode")

   vNodes = []

   for vCluster in CBENV[ pENV ].keys():
      logger.debug ("Cluster: %s" % vCluster )
      tNode = CBENV[ pENV ][vCluster][0]
      logger.debug ("   Node: %s" % tNode)
      vNodes.append (tNode)

   logger.info ( "Nodes: %s" % vNodes )

   return vNodes

# ------------------------------------------------------------------------------------------------------------------------

def getPort ( ):
   """Returns the port (non-tls)"""
   logger.debug ("getPort")

   return PORT

# ------------------------------------------------------------------------------------------------------------------------

def getTLSPort ( ):
   """Returns the TLS port """
   logger.debug ("getTLSPort")

   return TLS_PORT

# ------------------------------------------------------------------------------------------------------------------------

def getClusterNames ():
   """Returns an array of cluster names from the defined environment"""
   logger.debug ("getClusterNames")
   
   lClusters = []

   for k in CBENV.keys():
      logger.debug ("Getting clusters for %s" % k)
      lClusters = lClusters + list( CBENV[k].keys() )

   logger.debug ("Cluster Names: %s" % lClusters )

   return lClusters

# ------------------------------------------------------------------------------------------------------------------------

def getRandomClusterNode ( pClusterName ):
   """Return random node in received cluster"""
   logger.debug ("getRandomClusterNode")

   lNode = ""
   lClustNodes = {}

   for k in CBENV.keys():
      logger.debug ( "Process env: %s" % k )
      for l in CBENV[k]:
         logger.debug ("Cluster: %s:%s" % (l, CBENV[k][l] ) )
         lClustNodes[l] = CBENV[k][l]

   lNode = lClustNodes[pClusterName][random.randint(0, len(lClustNodes[pClusterName])-1)]
   logger.debug ("Returning node: %s" % lNode )
   return lNode

# ------------------------------------------------------------------------------------------------------------------------

def getRandomNode ():
   """
   Return a random node from a random cluster.
   This is intended to verify database connectivity
   """

   lNode = ""
   lClust = ""
   lClustNodes = {}

   for k in CBENV.keys():
      logger.debug ( "Process env: %s" % k )
      for l in CBENV[k]:
         logger.debug ("Cluster: %s:%s" % (l, CBENV[k][l] ) )
         lClustNodes[l] = CBENV[k][l]

   lNode = getRandomClusterNode( list(lClustNodes.keys())[random.randint(0, len(lClustNodes.keys())-1)] )
   logger.debug ("Returning node: %s" % lNode )

   return lNode

# ------------------------------------------------------------------------------------------------------------------------

def getClusterNodes ( pClusterName ):
   """Returns the list of nodes for the cluster received"""
   logger.debug ("getClusterNodes")

   lEnvSuffix = pClusterName[-1].lower()

   try:
      return CBENV[lEnvSuffix][pClusterName.lower()]
   except:
      logger.error("ERROR: Cluster %s not found" % pClusterName)
      return []

# ------------------------------------------------------------------------------------------------------------------------



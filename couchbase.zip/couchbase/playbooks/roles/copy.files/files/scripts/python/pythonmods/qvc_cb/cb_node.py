# ------------------------------------------------------------------------------------------------------------------------
# Author : Victor Zuniga
# Date   : 2017.12.15
# Purpose: Define a class to handle the node information for Couchbase clusters.
#
# 2018.11.26 Victor Zuniga  Initial Class definition
#
# ------------------------------------------------------------------------------------------------------------------------

import sys

sys.path.insert ( 0, '/home/mobaxterm/vzuniga/pythonmods/' )

from bbc_log.dba_log import *
from bbc_cb.cbThresholds import *
from bbc_cb.strFormat import strColorFmt

logger = logging.getLogger ( __name__ )

class cNode:

   vEmptyNode = { "status" : "Unknown",
                  "version": "Unknown",
		  "services" : [],
		  "systemStats" : { "cpu_utilization_rate" : 0.0 },
		  "secSettings" : { "disableUIOverHTTP" : '',
		                    "sslMinProtocol" : '',
				    "ldapEnabled" : False }
		}


   def __init__ (self, name, nodeData = vEmptyNode):
      logger.info ("Initializing node: %s " % name )
      logger.debug ( "... node data: %s" % nodeData )
      self.nodeName = name
      self.nodeStatus = nodeData['status']
      self.cbVersion = nodeData['version']
      #self.secSettings = { "disableUIOverHTTP" : '',
                           #"sslMinProtocol" : '',
                           #"ldapEnabled" : False }

      self.secSettings = nodeData['secSettings']

      if ( 'services' in nodeData.keys() ):
         #self.cbServices = [ s.encode() for s in nodeData['services']]
         self.cbServices = [s for s in nodeData['services']]
      else:
         self.cbServices = []

      if ( 'cpuCount' in nodeData.keys() ):
          self.cpuCount = nodeData['cpuCount']
      else:
          self.cpuCount = ' '

      if self.nodeStatus == "Unknown":
          self.cpu_util_rate = -0.0
          self.mem_util_rate = -0.0
          self.swap_rate = -0.0
      else:
          self.cpu_util_rate = nodeData['systemStats']['cpu_utilization_rate']
          self.mem_util_rate = round ( ( ( ( nodeData['systemStats']['mem_total'] - nodeData['systemStats']['mem_free']) / nodeData['systemStats']['mem_total'] ) * 100 ), 2 )
          self.swap_rate = round ( ( ( nodeData['systemStats']['swap_used'] / nodeData['systemStats']['swap_total'] ) * 100 ), 2 )
      logger.debug ("%s: cpu_util_rate: %f" % (self.nodeName, self.cpu_util_rate) )
      logger.debug ("%s: mem_util_rate: %f" % (self.nodeName, self.mem_util_rate) )
      logger.debug ("%s: swap_rate: %f" % (self.nodeName, self.swap_rate) )


   def __str__ (self):
      outTxt = "   %14s: %-11s ver: %-16s   cpu(%s): %5s   mem: %5s   swap: %6s   serv: %-25s \n" % (
                                                                            self.nodeName,
                                                                            strColorFmt( self.nodeStatus, "", "unhealthy" ),
								                                            self.cbVersion[:14],
                                                                            self.cpuCount,
								                                            strColorFmt ( round( self.cpu_util_rate, 2) , hostCPU.warnThresh, hostCPU.critThresh ),
                                                                            strColorFmt( self.mem_util_rate, hostCPU.warnThresh, hostCPU.critThresh),
                                                                            strColorFmt ( self.swap_rate, hostSWAP.warnThresh, hostSWAP.critThresh ),
                                                                            self.cbServices )
      #outTxt += "     Security Settings: \n"
      #outTxt += "          Disable UI Over HTTP: %s   SSL Min Protocol: %s   LDAP Enabled: %s   SSL Cipher List: %s \n" % (self.secSettings["disableUIOverHTTP"],
      #                                               self.secSettings["sslMinProtocol"],
	  #                                               self.secSettings["ldapEnabled"],
      #                                               self.secSettings["sslCipherList"] )

      logger.debug ("cNode.outTxt:")
      logger.debug ("%s" % outTxt)
      return outTxt


# ------------------------------------------------------------------------------------------------------------------------
# Author : Victor Zuniga
# Date   : 2017.12.15
# Purpose: Define a class to handle the cluster information for Couchbase clusters.
#
# 2018.11.26 Victor Zuniga  Initial Class definition
#
# ------------------------------------------------------------------------------------------------------------------------

import sys

sys.path.insert ( 0, '/home/mobaxterm/vzuniga/pythonmods/' )

from bbc_log.dba_log import *
from bbc_cb.env_config import getClusterNodes
from bbc_cb.env_config import getRandomClusterNode
from bbc_cb.cb_node import cNode
from bbc_cb.cb_api import getNodeInfo, getNodeSecSettings
from bbc_cb.cb_api import getPoolsDefault
from bbc_cb.clsFonts import fontColors
from bbc_cb.cbThresholds import hostCPU, clustRAM
from bbc_cb.strFormat import strColorFmt

logger = logging.getLogger ( __name__ )

class cCluster ( cNode ):


   def __init__ (self, name, pAuth):
      logger.info ("Initializing cluster : %s" % ( name ) )
      self.clusterName = name.lower()
      self.clusterStatus = ''
      self.__clusterAuth = pAuth

      self.__clusterInfo = getPoolsDefault ( self.__clusterAuth,  self.clusterName )

      self.nodeInfo = {}

      lvNodeList = []
      if ( 'nodes' in self.__clusterInfo.keys() ):
         for n in range( len( self.__clusterInfo['nodes'])):
            lvNodeList.append( self.__clusterInfo['nodes'][n]['hostname'].split('.')[0] )
         logger.debug ("Nodes from cluster info: %s" % lvNodeList)
         lvNodeList = set( lvNodeList + getClusterNodes (self.clusterName) )
         logger.debug ("... including nodes from cofig: %s" % lvNodeList)

         # Traverse the node list and initialize them.
         for lvNode in lvNodeList:
            logger.debug ("Initialize node: %s" % lvNode )
            vFound = 0
            for x in range(len(self.__clusterInfo['nodes'])):
               if lvNode in self.__clusterInfo['nodes'][x]['hostname']:
                  logger.debug ("Node %s was found" % lvNode )

                  # Get node security settings
                  self.__nodeSecSettings = getNodeSecSettings ( self.__clusterAuth, lvNode )
                  logger.debug ("Node Sec Settings: %s" % self.__nodeSecSettings )
                  self.__clusterInfo['nodes'][x]['secSettings'] = self.__nodeSecSettings

                  self.nodeInfo[ lvNode ] = cNode ( lvNode, self.__clusterInfo['nodes'][x] )
                  vFound = 1
            if vFound == 0:
               logger.debug ( "Node %s was not found, initialize to empty" % lvNode )
               self.nodeInfo[ lvNode ] = cNode ( lvNode )

         self.storage = self.__clusterInfo['storageTotals']
         if 'balanced' in self.__clusterInfo.keys():
            self.clusterBalanced = self.__clusterInfo['balanced']
         else:
            self.clusterBalanced = 'N/A'
      else:
         logger.warning ("WARNING: %s is not configured")
         self.clusterBalanced = 'N/A'
         self.storage = {'ram' : {'quotaUsed':1, 'quotaTotal':1} }

   def __str__ (self):
      if self.clusterName == '':
         logger.debug (" cCluster: Un-initialized" )
         return "Un-initialized"
      else:
         outTxt = "%s\n" % (self.clusterName)
         outTxt += "   Balanced: %6s \n" % strColorFmt( self.clusterBalanced, True, False )
         outTxt += "   RAM: used (gb): %6.2f/%0.2f (%s) \n" % (
                             ( float(self.storage['ram']['quotaUsed'])/(1024*1024*1024) ),
                             ( float(self.storage['ram']['quotaTotal'])/(1024*1024*1024) ),
                            strColorFmt  ( round( ( self.storage['ram']['quotaUsed']/self.storage['ram']['quotaTotal']) *100,2 ), clustRAM.warnThresh, clustRAM.critThresh )
                          )

         for n in sorted(self.nodeInfo.keys()):
            outTxt += str( self.nodeInfo[n] )

      logger.debug ("cCluster.outTxt:")
      logger.debug ("%s" % outTxt )

      return outTxt

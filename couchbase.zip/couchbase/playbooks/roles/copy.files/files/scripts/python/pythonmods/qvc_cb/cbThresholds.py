
class hostCPU:
   warnThresh = 75
   critThresh = 90

class clustRAM:
   warnThresh = 70
   critThresh = 90

class hostSWAP:
   warnThresh = 10
   critThresh = 40

class hostRAM:
   warnThresh = 75
   critThresh = 90

import os
import sys
import requests

sys.path.insert ( 0,'/home/couchbase/DBA/tools/pythonmods' )

from bbc_log.dba_log import *
from bbc_cb.env_config import getClusterNames
from bbc_cb.env_config import getPort
from bbc_cb.env_config import getRandomClusterNode
from bbc_cb.env_config import getRandomNode
from bbc_cb.env_config import getClusterNodes

logger = logging.getLogger ( __name__ )

# ------------------------------------------------------------------------------------------------------------------------

def formatRoles ( pRoleDict ):
    """ Return the bucket roles string based on the dictionary received"""

    logger.debug ("formatRoles: " + str(pRoleDict) )

    vRoleStr = ''

    for bucket in pRoleDict.keys():
        logger.debug ("Bucket: " + bucket)
        for x in range(len(pRoleDict[bucket])):
            if len(vRoleStr) != 0:
                vRoleStr = vRoleStr + ","
            vRoleStr = (vRoleStr + pRoleDict[bucket][x] + "[" + bucket + "]")

    logger.debug ("Roles: " + (vRoleStr) )
    return vRoleStr

# ------------------------------------------------------------------------------------------------------------------------

def getClusterBuckets ( pNode, pUser, pPass ):
    """Return list of buckets for the cluster using the received node"""
    logger.debug ("getClusterBuckets" )

    llBuckets = []
    lvPort = getPort()

    lvURL = "http://" + pNode + ".south.edu:" + str(lvPort) + "/pools/default/buckets/"
    logger.debug ("Bucket URL: " + lvURL )
    r = requests.get ( lvURL, auth=(pUser, pPass) )

    if r.status_code != 200:
        logger.error ("ERROR: Received code " + str(r.status_code) + " from request call" )
        llBuckets = None
    else:
        for x in range(len(r.json())):
            logger.debug( "Append " + r.json()[x]['name'] )
            llBuckets.append(r.json()[x]['name'])

    return llBuckets

# ------------------------------------------------------------------------------------------------------------------------

def getAllClustBuckets( pUser, pPass ):
    """Return dictionary of cluster and its buckets"""
    logger.debug ("getAllClustBuckets")

    ldClustBuckets = {}
    lvClusters = getClusterNames ()
    lvNode = ""
    llBuckets = []

    for clstr in lvClusters:
        logger.info ("Get buckets for cluster: " + clstr )
        lvNode = getRandomClusterNode( clstr )
        logger.info ("Using node: " + lvNode )
        llBuckets = getClusterBuckets ( lvNode, pUser, pPass )

        if llBuckets is None:
            logger.error("No buckets found for " + clstr)
        else:
            logger.info ("Cluster/buckets: " + clstr + "[" + str(llBuckets) +"]" )
            ldClustBuckets[clstr] = llBuckets

    return ldClustBuckets


# ------------------------------------------------------------------------------------------------------------------------

def getBucketClustDict ( pClusterBucketDict ):
    """
    Takes a dictionary of Cluster and its buckets, and flips it to a dictionary of buckets and its clusters.
    This is useful to assist in the search of clusters containing a bucket.
    """
    logger.debug ("getBucketClustDict")

    lBucketCluster = {}

    # Create empty dictionary of buckets
    for x in pClusterBucketDict.keys():
        for y in pClusterBucketDict[x]:
            #logger.debug("Create dict key %s" % y)
            lBucketCluster[y] = []

    # Populate the dictionary with the clusters accordingly
    for x in pClusterBucketDict.keys():
        for y in pClusterBucketDict[x]:
            #logger.debug("Append %s to %s" % (x, y) )
            lBucketCluster[y].append(x)

    logger.debug ("Resulting dictionary: %s" % lBucketCluster )

    return lBucketCluster

# ------------------------------------------------------------------------------------------------------------------------

def verifyAdminConnection( pAdminCreds, pCluster = None ):
    """
    Verify the credentials provided are valid to connect to a cluster
    """

    logger.debug ("verifyAdminConnection - Cluster: " + str(pCluster) )

    if pCluster == None:
        lNode = getRandomNode()
    else:
        lNode = getRandomClusterNode( pCluster )
        logger.debug( "Random Node -- cluster: " +  pCluster + " ["+ lNode + "]" )

    lvPort = getPort()

    lvURL = "http://"+ lNode + ".south.edu:" + str(lvPort) + "/pools/default/buckets/"
    logger.debug ("URL: " + lvURL )
    r = requests.get ( lvURL, auth=( pAdminCreds[0], pAdminCreds[1] ) )

    if r.status_code != 200:
        logger.error ("ERROR: Received code " + str(r.status_code) + " from request call" )
        return False
    else:
        return True

# ------------------------------------------------------------------------------------------------------------------------

def getUserInfo ( pUser, pNode, pAdminCreds ):
    """
    Get user information.
    """

    logger.debug ("getUserInfo: "  + pUser + " " + pNode)

    vPort = getPort ()
    vUserInfo = {}
    vURL = "http://" + pNode + ".south.edu:" + str(vPort) + "/settings/rbac/users/external/" + pUser
    logger.debug ("URL: " + vURL)
    r = requests.get ( vURL, auth=( pAdminCreds[0], pAdminCreds[1] ) )

    if r.status_code != 200:
        logger.warning ( "WARNING: Could not get user information for " + pUser + " from node " + pNode)
        logger.warning ( "WARNING: status code: " + str(r.status_code) )
    return r

# ------------------------------------------------------------------------------------------------------------------------

def createCBUser ( pAcctInfo, pNode, pAdminCreds, pType='EXTERNAL' ):
    """
    Create the account in the Couchbase cluster.
    """

    logger.debug ("createUser")
    logger.debug ("pAcctInfo: " + str(pAcctInfo) )

    # There should be only one account in the dictionary.
    vUser = pAcctInfo.keys()[0].lower()
    vUserName = pAcctInfo[vUser]['NAME']
    vRoles = formatRoles ( pAcctInfo[vUser]['ROLES'] )
    vPort = getPort ()

    vData = {'roles':vRoles, 'name':vUserName}

    if pType.upper() == 'EXTERNAL':
        vURL = "http://" + pNode + ".south.edu:" + str(vPort) + "/settings/rbac/users/external/" +  vUser

    logger.debug ("User : " + vUser)
    logger.debug ("Name : " + vUserName)
    logger.debug ("Roles: " + vRoles)
    logger.debug ("URL  : " + vURL)
    logger.debug ("Data : " + str(vData))

    r = requests.put (vURL, auth=( pAdminCreds[0], pAdminCreds[1] ), data=vData )

    if r.status_code != 200:
        logger.error ("ERROR: Could not create/update account " + vUser + " on node " + pNode)
        logger.error ("ERROR: status code: " + str(r.status_code) )
        return False
    else:
        logger.info ( "Account " + vUser + "[" + pNode + "] created" )

    return True

# ------------------------------------------------------------------------------------------------------------------------

def getEndpoint (pAuth, pURL ):
    """Return JSON format from received endpoint"""
    logger.info ("getEndpoint")
    logger.info ("URL: " + pURL)
    logger.debug ( ("auth: " + str(pAuth) ).replace(pAuth[1], '*' * len(pAuth[1])) )

    try:
        r = requests.get ( pURL, auth=(pAuth[0], pAuth[1] ) )

        if r.status_code != 200:
            logger.error ("ERROR: Could not retrieve data from " + pURL )
            logger.error ("ERROR: status_code: " + str(r.status_code) )
            return {"bbc_err_code": r.status_code}
        else:
            #logger.debug ( "r.json: %s" % r.json() )
            return r.json()

    except:
        logger.error ("ERROR: Could not retrieve data from " + pURL )
        logger.error ("ERROR: bbc_err_code: " + '0001' )
        return {"bbc_err_code" : "0001" }


# ------------------------------------------------------------------------------------------------------------------------

def getNodeInfo (pAuth, pNode, pPort=8091):
    """Get node information from the couchbase cluster."""
    logger.info ("getNodeInfo: " + pNode)

    lURL = "http://" + pNode + ":" + str(pPort) + "/pools/default/"

    logger.debug ("getNodeInfo - URL : " + lURL)

    r = getEndpoint (pAuth, lURL)

    #if 'status_code' in r.keys():
    if r['bbc_err_code'] != 200:
        """The call to getEndpoint failed"""
        logger.warning ("WARNING: could not get data from " + lURL)
        logger.warning ("WARNING: Status Code: " +  str(r['status_code']) )

        return {}

    else:
        for n in range(len(r['nodes'])):
            if 'thisNode' in r['nodes'][n].keys():
                logger.debug ("This Node: " + r['nodes'][n] )
                return r['nodes'][n]


# ------------------------------------------------------------------------------------------------------------------------

def getClusterStorage (pAuth, pNode, pPort=8091):
    """Return storage portion of the cluster json doc."""
    logger.info ("getClusterStorage: %s" % pNode)

    lURL = "http://%s:%d/pools/default/" % (pNode, pPort)

    logger.debug ("getClusterStorage - URL : %s" % lURL)

    r = getEndpoint (pAuth, lURL)

    #if 'status_code' in r.keys():
    if r['bbc_err_code'] != 200:
        """The call to getEndpoint failed"""
        logger.warning ("WARNING: could not get data from %s" % lURL)
        logger.warning ("WARNING: Status Code: %d" % r['bbc_err_code'])

        return {}

    else:
        return r['storageTotals']

# ------------------------------------------------------------------------------------------------------------------------

def getPoolsDefault ( pAuth, pCluster, pPort=8091):
    """Return endpoint /pools/default from Couchbase cluster"""

    logger.info ("getPoolsDefault: %s" % pCluster)

    lvNodes = getClusterNodes ( pCluster )
    logger.debug ("%s : %s" % (pCluster, lvNodes) )

    lvFound = 0
    lvCount = 0
    r = {}

    while lvFound == 0 and lvCount < len(lvNodes):
        logger.debug ("Nodes: %s" % lvNodes)
        logger.debug ("Index: %d" % lvCount )
        lvNode = lvNodes[ lvCount ]

        lURL = "http://%s:%d/pools/default/" % ( lvNode, pPort )
        logger.debug ("getPoolsDefault - URL: %s" % lURL)

        r = getEndpoint (pAuth, lURL)

        if 'bbc_err_code' in r.keys():
            lvFound = 0
        else:
            lvFound = 1

        lvCount += 1

    if lvFound == 1:
        logger.debug ("%s:%s" % (pCluster, r) )
        return r
    else:
        logger.debug ("%s:%s" % (pCluster, {}) )
        return {}


# ------------------------------------------------------------------------------------------------------------------------

def getUIOverHTTP ( pAuth, pNode, pPort=8091 ):
    """
    Return whether access to UI has been disabled over HTTP
    Returns True or False
    """

    logger.info ("getUIOverHTTP: %s" % pNode )
    lURL = "http://%s:%d/settings/security" % ( pNode, pPort )

    logger.debug (" getUIOverHTTP - URL: %s" % lURL )

    r = getEndpoint ( pAuth, lURL )

    if 'bbc_err_code' in r.keys():
        logger.error ("ERROR: Could not get UI Over HTTP setting")
        logger.error ("ERROR: %s" % r["bbc_err_code"] )
        return False
    else:
        return r['disableUIOverHttp']

    return False

# ------------------------------------------------------------------------------------------------------------------------

def getSSLMinProtocol ( pAuth, pNode, pPort=8091 ):
    """Returns the minimum protocol setting value."""

    lURL = "http://%s:%d/diag/eval" % (pNode, pPort )

    logger.debug (" getUIOverHTTP - URL: %s" % lURL )

    r = getEndpoint ( pAuth, lURL )

    if 'bbc_err_code' in r.keys():
        logger.error ("ERROR: Could not get minimum SSL protocol setting")
        logger.error ("ERROR: %s" % r["bbc_err_code"] )
        return 'unknown'
    else:
        return r['ssl_minimum_protocol']


# ------------------------------------------------------------------------------------------------------------------------

def getLDAPEnabled ( pAuth, pNode, pPort=8091 ):
    """Return whether ldap in enabled or not"""

    lURL = "http://%s:%d/settings/saslauthdAuth" % (pNode, pPort)

    logger.debug ("getLDAPEnabled - URL: %s" % lURL)

    r = getEndpoint ( pAuth, lURL )

    if 'bbc_err_code' in r.keys():
        logger.error ( "ERROR: Could not get LDAP_enabled setting" )
        logger.error ("ERROR: %s" % r["bbc_err_code"] )
        return 'unknown'
    else:
        if 'enabled' in r.keys():
            return r['enabled']
        else:
            return ''

# ------------------------------------------------------------------------------------------------------------------------

def getNodeCipherList ( pAuth, pNode, pPort=8091 ):
    """Return the Cipher List setting for the node."""

    lURL = "http://%s:%d/pools/default/settings/memcached/node/self" % (pNode, pPort)

    logger.debug ("getNodeCipherList - URL: %s" % lURL)

    r = getEndpoint ( pAuth, lURL )

    if 'bbc_err_code' in r.keys():
        logger.error ("ERROR: Could not get cipher list value")
        logger.error ("ERROR: %s" % r["bbc_err_code"] )
        return 'unknown'
    else:
        if 'ssl_cipher_list' in r.keys():
            return r['ssl_cipher_list'].encode()
        else:
            return ''


# ------------------------------------------------------------------------------------------------------------------------

def getNodeSecSettings ( pAuth, pNode, pPort=8091 ):
    """Get the node's security settings, and return in JSON dictionary"""

    logger.debug ("getNodeSecSettings - Node: %s:%d" % (pNode, pPort) )

    lDict = { "disableUIOverHTTP" : 'unknown',
              "sslCipherList" : 'unknown',
              "sslMinProtocol" : 'unknown',
              "ldapEnabled" : 'unknown' }

    # Commented out since not needed currently.
    #lDict['sslCipherList'] = getNodeCipherList ( pAuth, pNode, pPort )
    #lDict['disableUIOverHTTP'] = getUIOverHTTP ( pAuth, pNode, pPort )
    #lDict['sslMinProtocol'] = getSSLMinProtocol ( pAuth, pNode, pPort )
    #lDict['ldapEnabled'] = getLDAPEnabled ( pAuth, pNode, pPort )

    return lDict

# ------------------------------------------------------------------------------------------------------------------------

def getBucketIndexStats (pAuth, pNode, pBucket, pPort=8091, pZoom='minute'):
    """Get the index stats for the bucket received.  Return the JSON dictionary received"""

    logger.debug ("getBucketIndexStats - Node: %s[%d]  - Bucket: %s " % (pNode, pPort, pBucket ))

    lURL = "http://%s:%d//pools/default/buckets/@index-%s/stats?zoom=%s" % (pNode, pPort, pBucket, pZoom)

    logger.debug(" getBucketIndexStats - URL: %s" % lURL)

    r = getEndpoint(pAuth, lURL)

    if 'bbc_err_code' in r.keys():
        logger.error("ERROR: Could not get Index Stats for Bucket " + pbucket )
        logger.error("ERROR: %s" % r["bbc_err_code"])
        return False
    else:
        return r['op']

    return False

# ------------------------------------------------------------------------------------------------------------------------

def getClusterUserList ( pAuth, pNode, pPort = 8091, pDomain = 'All' ):
    """ Get a list of RBAC accounts from the cluster.  Retrn the JSON dictionary received"""

    logger.debug ("getClusterUserList: - Node: %s[%d] - Domain: %s" % (pNode, pPort, pDomain) )

    if pDomain == 'All':
        lURL = "http://%s:%d/settings/rbac/users" % (pNode, pPort)
    else:
        lURL = "http://%s:%d/settings/rbac/users/%s" % (pNode, pPort, pDomain.lower() )

    r = getEndpoint( pAuth, lURL )

    return r

# ------------------------------------------------------------------------------------------------------------------------


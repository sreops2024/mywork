# Authon  : Victor Zuniga
# Date    : 2019.03.04
# Purpose : Provide a function to color the value provided and convert to a string based on provided thresholds.

# History
# Author              Date        Comments
# ------------------- ---------- -------------------------------------------------------------------------------
# Victor Zuniga       2019.09.17 Convert to python3

#import os
#import sys
#import requests

#sys.path.insert ( 0,'/home/couchbase/DBA/tools/pythonmods' )

from bbc_log.dba_log import *
from bbc_cb.clsFonts import fontColors

logger = logging.getLogger ( __name__ )

def strColorFmt ( pMetric, pWarning, pCritical ):
   """Determine the display color for the received pMetric based on the type and thresholds received."""
   logger.debug ("strColorFmt")
   
   logger.debug ("Metric: %s - Type: %s - Warn: %s - Crit: %s" % ( pMetric, type(pMetric), pWarning, pCritical ) )

   lvOut = ''

   if ( str( type(pMetric) ) == "<class 'float'>" or str( type(pMetric) ) == "<class 'int'>" ):
      lvOut = "%5.2f" % ( pMetric )
      if pMetric <= pWarning:
         lvOut = "%s" % (fontColors.OKGREEN + lvOut + fontColors.ENDC)
      if pMetric <= pCritical:
         lvOut = "%s" % (fontColors.WARNING + lvOut + fontColors.ENDC)
      if pMetric > pCritical:
         lvOut = "%s" % (fontColors.FAIL + lvOut + fontColors.ENDC)
   elif str( type(pMetric) )  == "<class 'bool'>" :
      lvOut = str(pMetric)
      if pMetric == pCritical:
         lvOut = "%s" % (fontColors.FAIL + lvOut + fontColors.ENDC)
      else:
         lvOut = "%s" % (fontColors.OKGREEN + lvOut + fontColors.ENDC)
   elif ( str( type(pMetric) ) == "<class 'str'>" or str( type(pMetric) ) == "<class 'unicode'>" ):
      lvOut = pMetric
      if pMetric == pCritical:
         lvOut = "%s" % (fontColors.FAIL + lvOut + fontColors.ENDC)
      elif pMetric == pWarning:
         lvOut = "%s" % (fontColors.WARNING + lvOut + fontColors.ENDC)
      else:
         lvOut = "%s" % lvOut 
   else:
      return pMetric
      
   return lvOut


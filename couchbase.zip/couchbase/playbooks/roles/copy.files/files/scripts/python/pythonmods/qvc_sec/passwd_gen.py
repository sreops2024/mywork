# ------------------------------------------------------------------------------------------------------------------------
import random
import string
import logging
logger = logging.getLogger ( __name__ )

# ------------------------------------------------------------------------------------------------------------------------

def hide_str ( p_str ):
   """Returns a string of asterisks the length of the received string"""
   l_str = ''
   for s in range ( len ( p_str ) ):
      l_str = l_str + '*'

   return l_str

# ------------------------------------------------------------------------------------------------------------------------

def pwd_gen (p_length=8, p_min_digits=2, p_min_upper=2, p_min_special=2):
   '''
   Generate a password of desired length
   The lenght is considered a minumum size.  Based on other parameters, the length
   can increase.
   '''

   v_lower = string.ascii_lowercase
   v_upper = string.ascii_uppercase
   v_chars = v_upper + v_lower
   v_numbs = string.digits
   #v_specs = '!#$%()+,-/:;<=>_'
   #v_specs = '#%()+,-/:;<=>_'       # Removed $ and ! from list to prevent issues in password.
   #v_specs = '#%()+,-/:<=>_'        # The semicolon (;) is causing issues when creating the attributes passed to OMS.
   #v_specs = '#()+,-/:<=>_'         # The percent (%) is causing issues when creating the attributes passed to OMS.
   #v_specs = '#()+,-/<=>_'          # The colon (:) is causing issues when creating the attributes passed to OMS.
   v_specs = '()+,-<=>_'             # The hash (#) and forward slash (/) are not recognized as valid by Password Verify Function
   v_init = ''

   logger.debug ( 'enter pwd_gen' )
   logger.debug ( 'lower    : ' + v_lower )
   logger.debug ( 'upper    : ' + v_upper )
   logger.debug ( 'combined : ' + v_chars )
   logger.debug ( 'numbers  : ' + v_numbs )
   logger.debug ( 'specials : ' + v_specs )

   pw_length = p_length -1 # 1 for leading char.
   mypw = []

   v_init = v_chars[random.randrange(len(v_chars))]

   # Add 2-3 upper case chars
   logger.debug ( "Add %d - %d upper chars" % (p_min_upper, p_min_upper + 1) )
   for i in range(random.randrange(p_min_upper, p_min_upper + 1 )):
      mypw.append(v_upper[random.randrange(len(v_upper))])
   #print "After upper: ".join(mypw)

   # Add 2-3 digits
   logger.debug ( "Add %d - %d digits" % (p_min_digits, p_min_digits + 1) ) 
   for i in range(random.randrange(p_min_digits, p_min_digits + 1)):
      mypw.append(v_numbs[random.randrange(len(v_numbs))])
   #print "After digs: ".join(mypw)

   # Add 2 special chars
   logger.debug ( "Add %d - %d special chars" % (p_min_special, p_min_special + 1) ) 
   for i in range(random.randrange(p_min_special, p_min_special + 1)):
      mypw.append(v_specs[random.randrange(len(v_specs))])

   # Add the rest lower case
   logger.debug ( "Add remaining %d lower chars" % (pw_length-len(mypw) ) )
   for i in range(pw_length-len(mypw)):
      mypw.append(v_lower[random.randrange(len(v_lower))])

   random.shuffle(mypw)
   pwstring = "".join(mypw)
   pwstring = v_init + pwstring
   
   logger.debug ( 'string : ' + pwstring )
   logger.debug ( 'exit pwd_gen' )
   return pwstring

# ------------------------------------------------------------------------------------------------------------------------

def verify_password ( pPassword, pLength, pDigits, pUpperChars, pSpecial):
   """Determine if the received password meets the criteria received"""

   v_RetVal = ''
   v_specs = '()+,-<=>_.'
   v_numbs = string.digits
   vLength = len( pPassword )
   vDigitNum = 0
   vUpperNum = 0
   vSpecialNum = 0

   logger.debug ( "Determine password components" )
   for c in pPassword:
      if c in string.ascii_uppercase:
         vUpperNum += 1
      if c in v_specs:
         vSpecialNum += 1
      if c in v_numbs:
         vDigitNum += 1

   logger.debug ( "Length : %d" % vLength )
   logger.debug ( "Upper  : %d" % vUpperNum )
   logger.debug ( "Digits : %d" % vDigitNum )
   logger.debug ( "Special: %d" % vSpecialNum )

   #print ( "Length : %d" % vLength )
   #print ( "       : %d" % pLength )
   #print ( "Upper  : %d" % vUpperNum )
   #print ( "Digits : %d" % vDigitNum )
   #print ( "Special: %d" % vSpecialNum )

   if vLength < pLength:
      v_RetVal = "Password too short. Must be at least %d characters. " % pLength
   if vUpperNum < pUpperChars:
      v_RetVal = v_RetVal +  "Not enough Upper Case characters, must have at least %d characters. " % pUpperChars
   if vSpecialNum < pSpecial:
      v_RetVal = v_RetVal +  "Not enough Special characters, must have at least %d characters. " % ( pSpecial )
      v_RetVal = v_RetVal + "Special Characters: %s " % ( v_specs )
   if vDigitNum < pDigits:
      v_RetVal = v_RetVal + "Not enough digits, must have at least %d characters. " % pDigits

   if v_RetVal == '':
      v_RetVal = 'OK'

   if v_RetVal == 'OK':
      logger.info ( "Verification: %s " % v_RetVal )
   else:
      logger.warning ( "Verification: %s " % v_RetVal )


   return v_RetVal

# ------------------------------------------------------------------------------------------------------------------------

def man_pwd_gen (p_length=8, p_min_digits=2, p_min_upper=2, p_min_special=2):
   '''
   Generate a password of desired length
   The lenght is considered a minumum size.  Based on other parameters, the length
   can increase.
   '''

   v_lower = string.ascii_lowercase
   v_upper = string.ascii_uppercase
   v_chars = v_upper + v_lower
   v_numbs = string.digits
   #v_specs = '!#$%()+,-/:;<=>_'
   #v_specs = '#%()+,-/:;<=>_'       # Removed $ and ! from list to prevent issues in password.
   #v_specs = '#%()+,-/:<=>_'        # The semicolon (;) is causing issues when creating the attributes passed to OMS.
   #v_specs = '#()+,-/:<=>_'         # The percent (%) is causing issues when creating the attributes passed to OMS.
   #v_specs = '#()+,-/<=>_'          # The colon (:) is causing issues when creating the attributes passed to OMS.
   #v_specs = '()+,-<=>_'            # The hash (#) and forward slash (/) are not recognized as valid by Password Verify Function
   v_specs = '(),-<=>_'              # The plus sign (+) seems to be a special character in yml files when not surrownded by quotes (')
   v_init = ''

   logger.debug ( 'enter pwd_gen' )
   logger.debug ( 'lower    : ' + v_lower )
   logger.debug ( 'upper    : ' + v_upper )
   logger.debug ( 'combined : ' + v_chars )
   logger.debug ( 'numbers  : ' + v_numbs )
   logger.debug ( 'specials : ' + v_specs )

   pw_length = p_length -1 # 1 for leading char.
   mypw = []

   v_init = v_chars[random.randrange(len(v_chars))]

   # Add 2-3 upper case chars
   logger.debug ( "Add %d - %d upper chars" % (p_min_upper, p_min_upper + 1) )
   for i in range(random.randrange(p_min_upper, p_min_upper + 1 )):
      mypw.append(v_upper[random.randrange(len(v_upper))])
      #print "After upper: ".join(mypw)

   # Add 2-3 digits
   logger.debug ( "Add %d - %d digits" % (p_min_digits, p_min_digits + 1) )
   for i in range(random.randrange(p_min_digits, p_min_digits + 1)):
      mypw.append(v_numbs[random.randrange(len(v_numbs))])
   #print "After digs: ".join(mypw)

   # Add 2 special chars
   logger.debug ( "Add %d - %d special chars" % (p_min_special, p_min_special + 1) )
   for i in range(random.randrange(p_min_special, p_min_special + 1)):
      mypw.append(v_specs[random.randrange(len(v_specs))])

   # Add the rest lower case
   logger.debug ( "Add remaining %d lower chars" % (pw_length-len(mypw) ) )
   for i in range(pw_length-len(mypw)):
      mypw.append(v_lower[random.randrange(len(v_lower))])

   random.shuffle(mypw)
   pwstring = "".join(mypw)
   pwstring = v_init + pwstring

   logger.debug ( 'string : ' + pwstring )
   logger.debug ( 'exit pwd_gen' )
   return pwstring


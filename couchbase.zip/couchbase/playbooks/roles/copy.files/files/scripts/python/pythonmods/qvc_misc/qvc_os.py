# ----------------------------------------------------------------------------------------------------------------------
# Author  : Victor Zuniga
# Date    : 2019.12.06
# Purpose : Organize misc OS functions for QVC purposes
# ----------------------------------------------------------------------------------------------------------------------
# History
#
# Author               Date         Changes
# -------------------- ----------  -------------------------------------------------------------------------------------
# Victor Zuniga        2019.12.06  Initial version
#                                  Can't hide the password since the variable is out of scope.
# ----------------------------------------------------------------------------------------------------------------------

import logging
import subprocess

def execOSCommand ( cmd ):
    '''Executes the command received'''

    logging.debug ("execOSCommand")

    #logging.debug ("Cmd: " + cmd.replace(vAdminPswd, '*' * len(vAdminPswd) ) )
    #logging.debug ("Cmd: " + cmd )
    arCmd = cmd.split()
    logging.debug ("Cmd Array: " + str(arCmd) )

    logging.info ("Exceute subprocess")
    proc = subprocess.Popen (arCmd,
                      stdout=subprocess.PIPE,
                      stderr=subprocess.PIPE,
                      universal_newlines=True)
    stdout, stderr = proc.communicate()
    rc = proc.poll()

    logging.info ("Std Output: " + stdout)
    logging.debug ("Std Error : " + stderr)
    logging.info ("Ret Code  : " + str(rc) )

    return rc


#!/bin/bash
# Victor Zuniga
# 2019.12.05
# Wrapper to be used by puppet to execute certificate load script.

# Source bash profile
source /home/couchbase/.bash_profile

# Exec load script
/bin/python3 /home/couchbase/DBA/bin/cert_mgmt/load_certs.py > /home/couchbase/logs/cert_load.out

exit 0


# Author : Raymond Lee
# Date   : 2019.01.11
# Purpose: Class definition and function for Couchbase Log files
import scan
import io
import sys
sys.path.insert(0, '/home/couchbase/DBA/python')
from bbc_log.dba_log import *

class AbstractLogFile(object):
    def __init__(self, directory, filename, scanstartime):
        self.dirfilename = directory+filename
        self.filename = filename
        self.scanstarttime = scanstartime
        self.timestamp = ''
        self.date = ''
        self.time = ''
        self.lastlinenum = 0
        self.errorlist = ['empty', 'crash report','error report', 'error-report', 'failed', 'error', 'terminating', 'exception in',
                          'disconnected', 'not ready', 'didn''t respond','killed', 'exited unexpectedly']
        self.whitelist = ['error_logger', 'memcached_error', 'notifier returned', 'loglevel_mapreduce_errors',
                          'loglevel_xdcr_trace,error', 'ale_logger', 'sink-disk', 'supervisor_bridge', 'overhead', 'release_handler',
                          'connect_max_errors', 'see ns_server']
        self.unwhitelist = ['terminating']
        self.scanstarttime = ''
        self.emailerrorlist = []

    def runlogscan(self):
        try:
            scan.scanlogfile(self)
        except:
            logger.error("Scan FAILED on " + self.filename)


    def gettime(self, line):
        try:
            self.timestamp = line.split(",")[1]
            self.time = self.timestamp.split("t")[1]
            self.time = self.time.split("-")[0]
            #print("time", self.time)
            return self.time
        except IndexError:
            pass

    def getdate(self, line):
        try:
            self.timestamp = line.split(",")[1]
            self.date = self.timestamp.split("t")[0]
            #print("date", self.date)
            return self.date
        except IndexError:
            pass

    def gettimestamp(self, line):
        try:
            time = self.gettime(line)
            date = self.getdate(line)
            self.timestamp = (date, time)
            return self.timestamp
        except IndexError:
            pass
            print(IndexError, 'gettimestamp')

    def printdisconnected(self, error_line_num):
        raise NotImplementedError

    def printerror_report(self, error_line_num):
        raise NotImplementedError

    def printexception(self, error_line_num):
        raise NotImplementedError

    def printnotready(self, error_line_num):
        raise NotImplementedError

    def printkilled(self, error_line_num):
        raise NotImplementedError

    def printexitedunexpectedly(self, error_line_num):
        raise NotImplementedError

    def printerrorreport(self, error_line_num):
        raise NotImplementedError

class DebugLog(AbstractLogFile):
    def __init__(self, directory, filename, scanstartime):
        super(DebugLog, self).__init__(directory, filename, scanstartime)
        self.scanstarttime = scanstartime

        #CRASH REPORT
        #crasher
        #error
        #termination
        #terminating

    def printcrasher(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num-error_line_num <= 19:
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 19
        except:
            print(Exception, "printcrasher")



    def printterminator(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num-error_line_num <= 17:
                        logfile.emailerrorlist.append("               " + line)
                        # print("     " + line)
            logfile.lastlinenum += 17
        except:
            print(Exception, "printterminator")

    def printerrorreport(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num-error_line_num <= 4:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 4
        except:
            print(Exception, "printerrorreport")

    def printerror_report(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 3:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 3
        except:
            print(Exception, "printerror_report")

class CouchdbLog(AbstractLogFile):
    def __init__(self, directory, filename, scanstartime):
        super(CouchdbLog, self).__init__(directory, filename, scanstartime)
        self.scanstarttime = scanstartime

        #Empty


class InfoLog(AbstractLogFile):
    def __init__(self,  directory, filename, scanstartime):
        super(InfoLog, self).__init__(directory, filename, scanstartime)
        self.scanstarttime = scanstartime
        self.whitelist.append(".net',{err")
        #error
        #Exception in
        #disconnected
        #not ready

    def printdiscconected(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 3:
                        #print("     " + line)
                        logfile.emailerrorlist.append("               " + line)

            logfile.lastlinenum += 3
        except:
            print(Exception, "printdiscconected")

    def printerror_report(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 3:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 3
        except:
            print(Exception, "printerror_report")

    def printexception(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 21:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 21
        except:
            print(Exception, "printexception")

    def printnotready(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 4:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 4
        except:
            print(Exception, "printexception")

    def printkilled(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 2:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 2
        except:
            print(Exception, "printexception")

    def printexitedunexpectedly(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 22:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)

            logfile.lastlinenum += 22
        except:
            print(Exception, "printexception")


class HttpAccessLog(AbstractLogFile):
    def __init__(self, directory, filename, scanstartime):
        super(HttpAccessLog, self).__init__(directory, filename, scanstartime)
        self.scanstarttime = scanstartime


    def gettimestamp(self, line):
        try:
            self.timestamp = line.split("[")[1]
            self.timestamp = self.timestamp.split("]")[0]
            self.timestamp = self.timestamp.split("-")[0]
            #print("timestamp", self.timestamp)
            return self.timestamp
        except IndexError:
            print(IndexError, 'gettimestamp')

    def gettime(self, line):
        try:
            self.time = line.split("[")[1]
            self.time = self.time.split("]")[0]
            self.time = self.time.split("-")[0]
            self.time = self.time.split("-")[0]
            self.time = self.time.split(":")[1] + ":" + self.time.split(":")[2] + ":" + \
                             self.time.split(":")[3]
            #print("time:", self.timestamp)
            return self.time
        except IndexError:
            print(IndexError, 'gettime')

    def getdate(self, line):
        try:
            self.date = line.split("[")[1]
            self.date = self.date.split("]")[0]
            self.date = self.date.split("-")[0]
            self.date = self.date.split(":")[0]
            #print("date:", self.timestamp)
            return self.date
        except IndexError:
            print(IndexError, 'getdate')




class ErrorLog(AbstractLogFile):
    def __init__(self, directory, filename, scanstartime):
        super(ErrorLog, self).__init__(directory, filename, scanstartime)
        self.scanstarttime = scanstartime

        #error
        #didn't respond
        #not ready
        #Exception


    def printexitedunexpectedly(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 22:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 22
        except:
            print(Exception, "printexception")


    def printnotready(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 4:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 4
        except:
            print(Exception, "printexception")

    def printexception(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 21:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 21
        except:
            print(Exception, "printexception")

class XcdrErrorLog(AbstractLogFile):
    def __init__(self, directory, filename, scanstartime):
        super(XcdrErrorLog, self).__init__(directory, filename, scanstartime)
        self.scanstarttime = scanstartime

        #error

class XdcrLog(AbstractLogFile):
    def __init__(self, directory, filename, scanstartime):
        super(XdcrLog, self).__init__(directory, filename, scanstartime)
        self.scanstarttime = scanstartime

        #error

class ReportsErrorLog(AbstractLogFile):
    def __init__(self, directory, filename, scanstartime):
        super(ReportsErrorLog, self).__init__(directory, filename, scanstartime)
        self.scanstarttime = scanstartime
        self.whitelist.append('killed')
        self.whitelist.append('context')
        self.whitelist.append("badmatch")
        self.whitelist.append("conn_error")
        self.whitelist.append("**")

        #error_logger
        #terminating
        #termination

    def printcrasher(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num-error_line_num <= 19:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 19
        except:
            print(Exception, "printcrasher")

    def printkilled(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 2:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 2
        except:
            print(Exception, "printexception")

    def printterminator(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num-error_line_num <= 17:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 17
        except:
            print(Exception, "printterminator")

    def printerrorreport(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num-error_line_num <= 4:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 4
        except:
            print(Exception, "printerrorreport")

    def printerror_report(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 3:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 3
        except:
            print(Exception, "printerror_report")

# class MapreduceErrorsLog(AbstractLogFile):
#     def __init__(self, directory, filename):
#         super().__init__(directory, filename)
#     #error


# class ViewsLog(AbstractLogFile):
#     def __init__(self, directory, filename):
#         super().__init__(directory, filename)
#
#
# class StatsLog(AbstractLogFile):
#     def __init__(self, directory, filename):
#         super().__init__(directory, filename)
#         #Error

class SslProxyLog(AbstractLogFile):
    def __init__(self, directory, filename, scanstartime):
        super(SslProxyLog, self).__init__(directory, filename, scanstartime)
        self.scanstarttime = scanstartime
        self.whitelist.append("badmatch,{error,closed")
        #error
        #closed
        #CRASH REPORT
        #crasher
        #exception error

    def printcrasher(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num-error_line_num <= 19:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 19

        except:
            print(Exception, "printcrasher")

    def printkilled(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 2:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 2
        except:
            print(Exception, "printexception")

    def printterminator(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num-error_line_num <= 17:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 17
        except:
            print(Exception, "printterminator")

    def printerrorreport(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num-error_line_num <= 4:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 4
        except:
            print(Exception, "printerrorreport")

    def printerror_report(logfile, error_line_num):
        try:
            with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
                error_line_num = error_line_num
                current_line_num = 0
                for line in f:
                    current_line_num += 1
                    if 0 <= current_line_num - error_line_num <= 3:
                        # print("     " + line)
                        logfile.emailerrorlist.append("               " + line)
            logfile.lastlinenum += 3
        except:
            print(Exception, "printerror_report")

class babysitterLog(AbstractLogFile):
    def __init__(self, directory, filename, scanstartime):
        super(babysitterLog, self).__init__(directory, filename, scanstartime)
        self.scanstarttime = scanstartime
        #error
        #closed
        #CRASH REPORT
        #crasher
        #exception error

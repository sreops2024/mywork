# Author : Raymond Lee
# Date   : 2019.02.09
# Logic to scan log files

from datetime import *
import io
import sys
sys.path.insert(0, '/home/couchbase/DBA/python')
from bbc_log.dba_log import *


def scanlogfile(logfile):
    #try:
        with io.open(logfile.dirfilename, 'r', encoding='utf-8') as f:
            line_num = 0
            lastLine = None

            logger.info("Starting scan...")
            #read each line in file
            for line in f:
                previousLine = lastLine
                lastLine = str(line).lower()
                #loop the line through all the key error word in error list
                for keyerrorword in logfile.errorlist:
                    if keyerrorword in lastLine and (line_num == logfile.lastlinenum):
                        whitelisted = False
                        #loop the line through all the whitelisted words in whitelisted list
                        for whitelistword in logfile.whitelist:
                            if whitelistword in lastLine:
                                whitelisted = True
                                #unwhitelist certain terms, ex: "error_logger" is whitelisted, but the keyword terminiating
                                #usually appears in the same line as "error_logger"
                                for unwhitelistedword in logfile.unwhitelist:
                                    if unwhitelistedword in lastLine:
                                            whitelisted = False
                        #No whitelist word found in line. Proceed to print error
                        #if whitelisted == False and line_num == logfile.lastlinenum:
                        if whitelisted == False:
                                #address crash reports
                                if keyerrorword == 'crash report':
                                    if checktimeframe(logfile, previousLine) == True:
                                        # temp_str = ("Error Detected. Time: ", logfile.getdate(previousLine), logfile.gettime(previousLine),
                                        #        "File:", logfile.filename, "Error keyword:", keyerrorword)
                                        logfile.emailerrorlist.append("File: " + logfile.filename + " \n Time: "+ logfile.getdate(previousLine) + " " + logfile.gettime(previousLine) +
                                               "\n" + " Error keyword: " + keyerrorword + " \n")
                                        logger.warning("Error Detected. Time: " + logfile.getdate(previousLine) +
                                                     logfile.gettime(previousLine) + " File: " + logfile.filename +
                                                     "Error keyword: " + keyerrorword)
                                        logfile.printcrasher(line_num)
                                    else:
                                        logfile.lastlinenum += 1
                                    # address error report
                                elif keyerrorword == 'error report':
                                    if checktimeframe(logfile, previousLine) == True:
                                        # print("Error Detected. Time: ", logfile.getdate(previousLine),
                                        #       logfile.gettime(previousLine),
                                        #       "File:", logfile.filename, "Error keyword:", keyerrorword)
                                        logfile.emailerrorlist.append("File: " + logfile.filename + " \n Time: "+ logfile.getdate(previousLine) + " " + logfile.gettime(previousLine) +
                                               "\n" + " Error keyword: " + keyerrorword + " \n")
                                        logger.warning("Error Detected. Time: " + logfile.getdate(previousLine) +
                                                     logfile.gettime(previousLine) + " File: " + logfile.filename +
                                                     "Error keyword: " + keyerrorword)
                                        logfile.printerrorreport(line_num)
                                    else:
                                        logfile.lastlinenum += 1
                                # address error_report
                                elif keyerrorword == 'error-report':
                                    if checktimeframe(logfile, lastLine) == True:
                                        # print("Error Detected. Time: ", logfile.getdate(lastLine),
                                        #       logfile.gettime(lastLine),
                                        #       "File:", logfile.filename, "Error keyword:", keyerrorword)
                                        logfile.emailerrorlist.append("File: " + logfile.filename + " \n Time: "+ logfile.getdate(lastLine) + " " + logfile.gettime(lastLine) +
                                               "\n" + " Error keyword: " + keyerrorword + " \n")
                                        logger.warning("Error Detected. Time: " + logfile.getdate(lastLine) +
                                                     logfile.gettime(lastLine) + " File: " + logfile.filename +
                                                     "Error keyword: " + keyerrorword)
                                        logfile.printerror_report(line_num)
                                    else:
                                        logfile.lastlinenum += 1
                                #address termination/terminating
                                elif keyerrorword == 'terminating':
                                    if checktimeframe(logfile, lastLine) == True:
                                        # print("Error Detected. Time: ", logfile.getdate(lastLine),
                                        #       logfile.gettime(lastLine),
                                        #       "File:", logfile.filename, "Error keyword:", keyerrorword)
                                        logfile.emailerrorlist.append("File: " + logfile.filename + " \n Time: "+ logfile.getdate(lastLine) + " " + logfile.gettime(lastLine) +
                                               "\n" + " Error keyword: " + keyerrorword + " \n")
                                        logger.warning("Error Detected. Time: " + logfile.getdate(lastLine) +
                                                     logfile.gettime(lastLine) + " File: " + logfile.filename +
                                                     "Error keyword: " + keyerrorword)
                                        logfile.printterminator(line_num)
                                    else:
                                        logfile.lastlinenum += 1
                                #address disconnected
                                elif keyerrorword == 'disconnected':
                                    if checktimeframe(logfile, lastLine) == True:
                                        # print("Error Detected. Time: ", logfile.getdate(lastLine),
                                        #       logfile.gettime(lastLine),
                                        #       "File:", logfile.filename, "Error keyword:", keyerrorword)
                                        logfile.emailerrorlist.append("File: " + logfile.filename + " \n Time: "+ logfile.getdate(lastLine) + " " + logfile.gettime(lastLine) +
                                               "\n" + " Error keyword: " + keyerrorword + " \n")
                                        logger.warning("Error Detected. Time: " + logfile.getdate(lastLine) +
                                                     logfile.gettime(lastLine) + " File: " + logfile.filename +
                                                     "Error keyword: " + keyerrorword)
                                        logfile.printdiscconected(line_num)
                                    else:
                                        logfile.lastlinenum += 1
                                #address exception
                                elif keyerrorword == 'exception in':
                                    if checktimeframe(logfile, lastLine) == True:
                                        # print("Error Detected. Time: ", logfile.getdate(lastLine),
                                        #       logfile.gettime(lastLine),
                                        #       "File:", logfile.filename, "Error keyword:", keyerrorword)
                                        logfile.emailerrorlist.append("File: " + logfile.filename + " \n Time: "+ logfile.getdate(lastLine) + " " + logfile.gettime(lastLine) +
                                               "\n" + " Error keyword: " + keyerrorword + " \n")
                                        logger.warning("Error Detected. Time: " + logfile.getdate(lastLine) +
                                                     logfile.gettime(lastLine) + " File: " + logfile.filename +
                                                     "Error keyword: " + keyerrorword)
                                        logfile.printexception(line_num)
                                    else:
                                        logfile.lastlinenum += 1
                                #address not ready
                                elif keyerrorword == 'not ready':
                                    if checktimeframe(logfile, lastLine) == True:
                                        # print("Error Detected. Time: ", logfile.getdate(lastLine),
                                        #       logfile.gettime(lastLine),
                                        #       "File:", logfile.filename, "Error keyword:", keyerrorword)
                                        logfile.emailerrorlist.append("File: " + logfile.filename + " \n Time: "+ logfile.getdate(lastLine) + " " + logfile.gettime(lastLine) +
                                               "\n" + " Error keyword: " + keyerrorword + " \n")
                                        logger.warning("Error Detected. Time: " + logfile.getdate(lastLine) +
                                                     logfile.gettime(lastLine) + " File: " + logfile.filename +
                                                     "Error keyword: " + keyerrorword)
                                        logfile.printnotready(line_num)
                                    else:
                                        logfile.lastlinenum += 1
                                #address killed
                                elif keyerrorword == 'killed':
                                    if checktimeframe(logfile, previousLine) == True:
                                        # print("Error Detected. Time: ", logfile.getdate(previousLine),
                                        #       logfile.gettime(previousLine),
                                        #       "File:", logfile.filename, "Error keyword:", keyerrorword)
                                        logfile.emailerrorlist.append("File: " + logfile.filename + " \n Time: "+ logfile.getdate(previousLine) + " " + logfile.gettime(previousLine) +
                                               "\n" + " Error keyword: " + keyerrorword + " \n")
                                        logger.warning("Error Detected. Time: " + logfile.getdate(previousLine) +
                                                     logfile.gettime(previousLine) + " File: " + logfile.filename +
                                                     "Error keyword: " + keyerrorword)
                                        logfile.printkilled(line_num)
                                    else:
                                        logfile.lastlinenum += 1
                                #address exited unexpectedly
                                elif keyerrorword == 'exited unexpectedly':
                                    if checktimeframe(logfile, lastLine) == True:
                                        # print("Error Detected. Time: ", logfile.getdate(lastLine),
                                        #       logfile.gettime(lastLine),
                                        #       "File:", logfile.filename, "Error keyword:", keyerrorword)
                                        logfile.emailerrorlist.append("File: " + logfile.filename + " \n Time: "+ logfile.getdate(lastLine) + " " + logfile.gettime(lastLine) +
                                               "\n" + " Error keyword: " + keyerrorword + " \n")
                                        logger.warning("Error Detected. Time: " + logfile.getdate(lastLine) +
                                                     logfile.gettime(lastLine) + " File: " + logfile.filename +
                                                     "Error keyword: " + keyerrorword)
                                        logfile.printexitedunexpectedly(line_num)
                                    else:
                                        logfile.lastlinenum += 1
                                #address "{error,no_samples} oneoff line"
                                elif lastLine[0] == '{' and lastLine[-2] == '}' and keyerrorword == 'error':
                                    if checktimeframe(logfile, previousLine) == True:
                                        # print("Error Detected. Time: ", logfile.getdate(previousLine), logfile.gettime(previousLine),
                                        #       "File:", logfile.filename, "Error keyword:", keyerrorword)
                                        logfile.emailerrorlist.append("File: " + logfile.filename + " \n Time: "+ logfile.getdate(previousLine) + " " + logfile.gettime(previousLine) +
                                               "\n" + " Error keyword: " + keyerrorword + " \n")
                                        logfile.emailerrorlist.append("     " + previousLine + '    ' + lastLine)
                                        #print("     ", previousLine, '    ', lastLine)
                                    else:
                                        logfile.lastlinenum += 1
                                #address error messages on one liners ex: "          {error,"
                                elif keyerrorword == 'error' and len(lastLine.strip()) <= 20:
                                    if checktimeframe(logfile, previousLine) == True:
                                        continue
                                    else:
                                        logfile.lastlinenum += 1
                                #address regular one line error messages
                                else:
                                    if checktimeframe(logfile, lastLine) == True:
                                        # print("Error Detected. Time: ", logfile.getdate(lastLine), logfile.gettime(lastLine),
                                        #       "File:", logfile.filename, "Error keyword:", keyerrorword)
                                        # print("     ", lastLine)
                                        logfile.emailerrorlist.append("File: " + logfile.filename + " \n Time: "+ logfile.getdate(lastLine) + " " + logfile.gettime(lastLine) +
                                               "\n" + " Error keyword: " + keyerrorword + " \n")
                                        logger.warning("Error Detected. Time: " + logfile.getdate(lastLine) +
                                                     logfile.gettime(lastLine) + " File: " + logfile.filename +
                                                     "Error keyword: " + keyerrorword)
                                        logfile.emailerrorlist.append("     " + lastLine)
                                    else:
                                        logfile.lastlinenum += 1
                #Line skipper for printing reports - takes line_num + anticipated amount of rows in report and skips
                #those lines to avoid scanning them
                if line_num < logfile.lastlinenum:
                    line_num += 1
                else:
                    #print("Line number", line_num, "LastLineNum", logfile.lastlinenum)
                    line_num += 1
                    logfile.lastlinenum = line_num
    # except:
    #     print(Exception, "scanlogfile")


def getstarttime(minutes):
    currentDT = datetime.now()
    startScanDt = currentDT - timedelta(minutes=minutes)
    # print("Current Time", currentDT)
    # print("Start Time", startScanDt)
    return startScanDt


def checktimeframe(logfile, line):
    lineTimeStamp = str(logfile.gettimestamp(line)).replace('(\'', '').replace('\')', '').replace('\', \'', ' ')
    try:
        if datetime.strptime(lineTimeStamp, '%Y-%m-%d %H:%M:%S.%f') >= logfile.scanstarttime:
            return True
        else:
            return False
    except:
        return False


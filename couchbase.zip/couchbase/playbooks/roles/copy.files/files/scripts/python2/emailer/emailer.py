# Author : Raymond Lee
# Date   : 2019.02.19
# Email class. Generates and sends an email


import smtplib
#import argparse
import email.utils
from email.mime.text import MIMEText


def generateEmailMsg(host, receivers, subject, msg):
    msgerrors = ''
    for line in msg:
        msgerrors += str(line)

    emailmsg = MIMEText(msgerrors)
    emailmsg['Subject'] = str(subject)
    emailmsg['From'] = host
    emailmsg['To'] = str(receivers)
    return emailmsg

def sendmail(sender, receivers, message):
    try:
       smtpObj = smtplib.SMTP('localhost')
       smtpObj.sendmail(sender, receivers, message.as_string())
       print("Successfully sent email")
    except Exception:
       print("Error: unable to send email")


def __init__(host, to, subject, msg):
    emailmsg = generateEmailMsg(host, to, subject, msg)
    sendmail(host, to, emailmsg)


if __name__ == '__main__':
    def get_args():
        """ Set up the arguments and return the python dictionary containing the received values """
        parser = argparse.ArgumentParser(prog = "emailer.py",
                                         formatter_class=argparse.RawDescriptionHelpFormatter,
                                         description=
                                         '''
                                         Script to send an email to the DBAs from the local server.
                                         ''')
        parser.add_argument('-f', '--from', help = 'Sender name', required=True)
        parser.add_argument('-t', '--to', help = 'Recipient name', required=True)
        parser.add_argument('-s', '--subject', help = 'Subject of email', default='null', required=False)
        parser.add_argument('-m', '--message', help = 'Message of email', default='null', required=False)
        return vars(parser.parse_args())

#!/bin/python

# Author : Raymond Lee
# Date   : 2018.11.01
# Purpose: Generate the JSON file needed to enable Client Certificate.
#          Prerequiste to enabling XDCR encryption

import json
import requests
import argparse
import sys

# {
#   "prefixes": [
#     {
#       "delimiter": ".",
#       "path": "subject.cn",
#       "prefix": "QVC Root CA"
#     },
#     {
#       "delimiter": ".",
#       "path": "san.uri",
#       "prefix": "hcb001fp01i.south.edu"
#     },
#     {
#       "delimiter": ".",
#       "path": "san.uri",
#       "prefix": "hcb002fp01i.south.edu"
#     },
#     {
#       "delimiter": "",
#       "path": "san.uri",
#       "prefix": "cbfp01i"
#     }
#   ],
#   "state": "enable"
# }

def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog = "status.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description=
                                     '''
                                     Script to obtain status of couchbase clusters/nodes.
                                     ''')
    parser.add_argument('-u', '--user', help = 'Admin Account to be used', required=True)
    parser.add_argument('-p', '--password', help = 'Admin Password to be used', default='null', required=False)
    return vars(parser.parse_args())

def generate_json(user, password):
    #Get information on Cluster/Nodes
        # r = requests.get('http://hcb001fp01i.south.edu:8091/pools/default/', auth=('Administrator', 'password'))
        #r = requests.get('http://hcb001fp01i.south.edu:8091/pools/default/', auth=(user, password))
    r = requests.get('http://localhost:8091/pools/default/', auth=(user, password))
    print(r)
    if str(r) != "<Response [200]>":
        sys.exit("Error logging in using provided credentials")

    node_json = (r.json())
    nodelist = []
    node_in_cluster = 0
    cluster = ""
    sanuri = ""

    #Get Node Names
    for node in node_json:
        try:
            nodelist.append(str(node_json['nodes'][node_in_cluster]['hostname']).split('.')[0])
            node_in_cluster = node_in_cluster + 1
        except:
            break

    #Get Cluster Name
    for cluster in node_json:
        try:
            #cluster.append(str(node_json['clusterName']).split('.')[0])
            cluster = (str(node_json['clusterName']))
        except:
            break

    #Prefix of Cert
    prefixes = str({"prefixes": [{"delimiter": "","path": "subject.cn","prefix": "QVC Root CA"}]})[:-2]+", "

    #Body - Nodes
    for node in nodelist:
        sanuri += str({"""delimiter""": ".", "path": "san.uri", "prefix": node + ".south.edu"}) + ","

    #Body - Cluster
    sanuri += str({"""delimiter""": ".", "path": "san.uri", "prefix": cluster + ".south.edu"})

    #End of cert
    end = str("],'"'state'"': '"'enable'"'}")
    certjson = str(prefixes) + str(sanuri) + str(end)

    print(json.dumps(certjson)[1:-1].replace('\'', '\"'))

    #Produce JSON file
#    file = open("CBSecClientCert.json", "w")
    file = open("/home/couchbase/DBA/cert/CBSecClientCert.json", "w")
    file.write((json.dumps(certjson)[1:-1].replace('\'', '\"')))
    file.close()


gvArgs = get_args()
generate_json(gvArgs['user'], gvArgs['password'])

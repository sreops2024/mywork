#!/bin/python2
# Author   : Victor Zuniga
# Date     : 2018.07.05
# Purpose  : Script to split certificate file into 3 diferent files, root cert, chain cert, key file.
#
# History
#
# Date       Author             Comments
# ---------- ------------------ ------------------------------------------------------------------------------------------
# 2019.12.13 Victor Zuniga      Clean up files and move to done directory

import os, sys
import argparse

# ------------------------------------------------------------------------------------------------------------------------

def get_args() :
   """ Set up the arguments and return the python dictionary containing the received values """
   parser = argparse.ArgumentParser ( prog = "reset_db_account.py",
                                      formatter_class=argparse.RawDescriptionHelpFormatter,
                                      description=
      '''
      Split cerificate password into 3 files needed to load into Couchbase node.
      ''' )

   parser.add_argument ( '-c', '--cluster', help = 'Couchbase Cluster Name', required = True )
   
   return  vars(parser.parse_args() )

def fileExists ( pFileName, pMode ):
   """ Check the existance (readability) of a file """
   try:
      f = open (pFileName, pMode )
      f.close
   except IOError as e:
      return False

   return True

# ------------------------------------------------------------------------------------------------------------------------

gvArgs = get_args()

#print gvArgs

vCwd = os.getcwd()

print "Current DIR: %s" % (vCwd)

# Check to see if cluster certificate exists.
vDomainName = 'south.edu'
vCertFile = "%s/%s.%s.pem" % ( vCwd, gvArgs['cluster'], vDomainName )

print "Domain Name: %s" % vDomainName
print "Cert File  : %s" % vCertFile

#if vCertFile.is_file():
if fileExists( vCertFile, 'r' ):
   # The file exists
   print "   File is OK\n"
else:
   # The files does not exist
   print "   File does not exist\n"
   exit (-1)

# Generate file names needed
vCertRoot  = "%s/%s.root" % ( vCwd, gvArgs['cluster'])
vCertChain = "%s/%s.chain" % ( vCwd, gvArgs['cluster'])
vCertKeyEnc   = "%s/%s.key.enc" % ( vCwd, gvArgs['cluster'])
vCertKey   = "%s/%s.key" % ( vCwd, gvArgs['cluster'])

print "Generating: %s" % vCertRoot
vCmd = "sed -n '/subject=CN=QVC Root CA/,/-----END CERTIFICATE-----/p' %s > %s" % (vCertFile, vCertRoot)
#print "Command: %s" % vCmd
os.system ( vCmd )
if fileExists ( vCertRoot, 'r'):
   print "\t %s : Ready\n" % vCertRoot
else: 
   print "\t %s : Please check\n" % vCertRoot



print "Generating: %s" % vCertChain
vCmd = "sed '/-----BEGIN RSA PRIVATE KEY-----/,/-----END RSA PRIVATE KEY-----/ {d}' %s > %s" % (vCertFile, vCertChain)
#print "Command: %s" % vCmd
os.system ( vCmd )
if fileExists ( vCertChain, 'r'):
   print "\t %s : Ready\n" % vCertChain
else: 
   print "\t %s : Please check\n" % vCertChain

print "Generating: %s" % vCertKey
vCmd = "sed -n '/-----BEGIN RSA PRIVATE KEY-----/,/-----END RSA PRIVATE KEY-----/p'  %s > %s" % (vCertFile, vCertKeyEnc)
#print "Command: %s" % vCmd

os.system ( vCmd )
vCmd = "openssl rsa -in %s -out %s" % (vCertKeyEnc, vCertKey)

if fileExists ( vCertKeyEnc, 'r'):
   print "\t %s : Ready" % vCertKeyEnc
   print "\nExecute the following command to decrypt the key file:"
   print "%s" % vCmd
   print "mv %s done/" % (vCertKeyEnc)
else: 
   print "\t %s : Please check" % vCertKeyEnc

# Move cert file to done directory
vCmd = "mv %s done/" % (vCertFile)
os.system (vCmd)
if fileExists (vCertFile, 'r'):
   print "File Cleanup failed"
   print "ERROR: Could not move cert file to done directory"

print "Done"
exit()

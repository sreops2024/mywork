# Author : Raymond Lee
# Date   : 2019.02.09
# Main - Calls other classes and functions

import logs
import scan
import sys
import socket

sys.path.insert(0, '/home/couchbase/DBA/python/emailer')
import emailer

sys.path.insert(0, '/home/couchbase/DBA/python')
from bbc_log.dba_log import *
#sys.path.insert(0, 'C:\\Users\\00922715\\Box\PyCharm\\Log_Monitor')
#logs_dir = 'C:\\Users\\00922715\\Desktop\\1.22.2019\\'
logs_dir = '/opt/couchbase/var/lib/couchbase/logs/'


current_host = socket.gethostname()
scanstartime = scan.getstarttime(60)
emailmsg = []

logFileName = 'log_monitor'
init_logger(logFileName, logging.INFO)
logger = logging.getLogger(logFileName)

logger.info("------------------------------------------------------------------------------------------------------------------------")
logger.info("Scan start time: "  + str(scanstartime))

logger.info("Starting scan on debug.log")
debugfile = logs.DebugLog(logs_dir, 'debug.log', scanstartime)
debugfile.runlogscan()
if debugfile.emailerrorlist != []:
    emailmsg.append(debugfile.emailerrorlist)

logger.info("Starting scan on couchdb.log")
couchdbfile = logs.CouchdbLog(logs_dir, 'couchdb.log', scanstartime)
couchdbfile.runlogscan()
if couchdbfile.emailerrorlist != []:
    emailmsg.append(couchdbfile.emailerrorlist)

logger.info("Starting scan on info.log")
infologfile = logs.InfoLog(logs_dir, 'info.log', scanstartime)
infologfile.runlogscan()
if infologfile.emailerrorlist != []:
    emailmsg.append(infologfile.emailerrorlist)

logger.info("Starting scan on xdcr.log")
xdcrfile = logs.XdcrLog(logs_dir, 'xdcr.log', scanstartime)
xdcrfile.runlogscan()
if xdcrfile.emailerrorlist != []:
    emailmsg.append(xdcrfile.emailerrorlist)

logger.info("Starting scan on xdcr_errors.log")
xdcrerrorsfile = logs.XcdrErrorLog(logs_dir, 'xdcr_errors.log', scanstartime)
xdcrerrorsfile.runlogscan()
if xdcrerrorsfile.emailerrorlist != []:
    emailmsg.append(xdcrerrorsfile.emailerrorlist)

logger.info("Starting scan on reports.log")
reportsfile = logs.ReportsErrorLog(logs_dir, 'reports.log', scanstartime)
reportsfile.runlogscan()
if reportsfile.emailerrorlist != []:
    emailmsg.append(reportsfile.emailerrorlist)

logger.info("Starting scan on ssl_proxy.log")
sslproxyfile = logs.SslProxyLog(logs_dir, 'ssl_proxy.log', scanstartime)
sslproxyfile.runlogscan()
if sslproxyfile.emailerrorlist != []:
    emailmsg.append(sslproxyfile.emailerrorlist)

if emailmsg != []:
    tmplist = []
    x = 0
    logger.info("Sending email...")
    for list in emailmsg[x]:
        for line in list:
            tmplist.append(line)
        x += 1
    emailer.__init__(current_host, "raymond.lee@bbc.com", "Couchbase Error(s) detected on " + current_host, tmplist)



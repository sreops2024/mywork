cbDIR
=========

This role ensures the needed directories are present for Couchbase QVC implementation.

Requirements
------------

QVC's common roles must have been executed ahead of time to ensure the proper variables and facts have been set up.

Role Variables
--------------

All variables should be set up from the common role.

Dependencies
------------



Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

  - name: Ensure Couchbase Directories are up to date
    hosts: all
    
    roles: 
      - common
      - cbDirs

License
-------

Author Information
------------------

Victor Zuniga
2020.05.15
couchbase_dba@bbc.com

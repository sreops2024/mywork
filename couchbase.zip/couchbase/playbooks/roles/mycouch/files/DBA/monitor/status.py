#!/bin/python

# Author : Raymond Lee
# Date   : 2018.10.02
# Purpose: Script to quickly perform a healthcheck on couchbase clusters/nodes

import requests
import cbnodes
from time import sleep
import datetime
import csv
import platform
import sys
import argparse
import getpass

sys.path.insert(0, '/home/couchbase/DBA/tools/pythonmods/')

from bbc_log.dba_log import *

# Get user input
def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog = "status.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description=
                                     '''
                                     Script to obtain status of couchbase clusters/nodes.
                                     ''')
    parser.add_argument('-u', '--user', help = 'Admin Account to be used', required = True)
    parser.add_argument('-p', '--password', help = 'Admin Password to be used', default='null', required = False)
    parser.add_argument('-e', '--env', help = 'Env to target - all, int, qa, prod', default='all', required = False)
    parser.add_argument('-l', '--level', help = 'Level at which to alert - all, warning or critical', default='all', required = False)
    parser.add_argument('-t', '--time', help = 'Refresh time in seconds', default=600, required = False)
    parser.add_argument('-d', '--debug', help='Run in DEBUG mode', required=False)
    return vars(parser.parse_args())

def login(v_user, v_pw):
    logger.info("Attempting to login...")
    try:
        print(platform.system())
        user = v_user
        if platform.system() == 'Linux':
            pw = getpass.getpass(prompt="Enter Password: ")
            logger.info("Password obtained for Linux environment.")
        elif v_pw == 'null':
            if (os.environ.get('DB_PASS') != None) and (platform.system() != "Linux"):
                pw = os.environ.get('DB_PASS')
                logger.info("Password obtained from Windows environment")
            else:
                print("No password found in Windows environment")
                logger.error("ERROR: No password provided, no password found in windows environment.")
                sys.exit("Password Error. Stopping...")
        else:
            pw = v_pw
    except Exception as error:
        print('ERROR', error)
        logger.ERROR("ERROR: Failed to obtain admin credentials.")
    else:
        print('Username entered: ', user)
        print('Password obtained')
        logger.info("Username and password successfully obtained.")
        return user, pw

# Test credential against first node in the CSV file
def connect_db(user, pw, test_node):
    url = 'http://' + str(test_node) + ':8091/pools/default/'
    try:
        logger.info("Attempting to login against %s", url)
        r = requests.get(url, auth=(user, pw))
        print(r)
    except Exception as error:
        #print(r.json())
        logger.Error("ERROR: Login failed. Credential is invalid or does not have permission on node. %s", url)
        print("Error logging in, please try again.")
        print(r)
    else:
        return r


# Read node information from CSV file. Placed into a list
def import_cluster_info(v_env):
    logger.info("Reading CSV file")
    if platform.system() == 'Linux':
        reader = csv.DictReader(open('/home/couchbase/DBA/monitor/clusters_info.csv', 'r'))
    else:
        reader = csv.DictReader(open('C:\\Users\\00922715\\Desktop\\Couchbase_Monitor_Python\\clusters_info.csv', 'r'))
    gvList = []
    logger.info("Reading CSV file and converting to list.")
    logger.info("Targeting %s environment", v_env)
    for dct in reader:
        if platform.system() == "Linux":
            if v_env == 'int' and (str({dct['Environment']})[6:-3]) == 'Integration':
                gvList.append([dct['DNSAlias'], dct['Cluster']])
            elif v_env == 'qa' and (str({dct['Environment']})[6:-3]) == 'QA':
                gvList.append([dct['DNSAlias'], dct['Cluster']])
            elif v_env == 'prod' and (str({dct['Environment']})[6:-3]) == 'Production':
                gvList.append([dct['DNSAlias'], dct['Cluster']])
            elif v_env == None or v_env == 'all':
                gvList.append([dct['DNSAlias'], dct['Cluster']])
        else:
            if v_env == 'int' and (str({dct['Environment']})[2:-2]) == 'Integration':
                gvList.append([dct['DNSAlias'], dct['Cluster']])
            elif v_env == 'qa' and (str({dct['Environment']})[2:-2]) == 'QA':
                gvList.append([dct['DNSAlias'], dct['Cluster']])
            elif v_env == 'prod' and (str({dct['Environment']})[2:-2]) == 'Production':
                gvList.append([dct['DNSAlias'], dct['Cluster']])
            elif v_env == None or v_env =='all':
                gvList.append([dct['DNSAlias'], dct['Cluster']])
    if len(gvList) == 0:
        logger.error("ERROR: No cluster/nodes can be found under the specified environment or CSV file is empty.")
        sys.exit("No Cluster/Nodes found under the specified environment.")
    else:
        return gvList

# Get and display CB node information
def populate_node_info(user, pw, nodes_info, v_level):
    logger.info("Populating CB node information...")
    logger.info("Information level set to %s", v_level)
    cluster_list = []
    for cluster in nodes_info:
        if cluster[1] not in cluster_list:
            cluster_list.append(cluster[1])
        cluster_list.sort()
    for cluster in cluster_list:
        print("Cluster Name: %s " % cluster)
        nodes_info.sort()
        for node in nodes_info:
            if node[1] == cluster:
                try:
                    url = 'http://' + node[0] + ':8091/pools/default/'
                    node_in_cluster = int(str(node)[5:-18])-1
                    r = requests.get(url, auth=(user, pw))
                    node_json = (r.json())
                    cb_node = cbnodes.Node(node_json['nodes'][node_in_cluster]['hostname'],
                                           node_json['clusterName'],
                                           node_json['nodes'][node_in_cluster]['clusterMembership'],
                                           node_json['rebalanceStatus'],
                                           node_json['balanced'],
                                           node_json['nodes'][node_in_cluster]['uptime'],
                                           node_json['nodes'][node_in_cluster]['systemStats']['mem_free'],
                                           node_json['nodes'][node_in_cluster]['systemStats']['mem_total'],
                                           node_json['nodes'][node_in_cluster]['services'],
                                           node_json['nodes'][node_in_cluster]['status'],
                                           node_json['storageTotals']['hdd']['used'],
                                           node_json['storageTotals']['hdd']['total'],
                                           node_json['nodes'][node_in_cluster]['systemStats']['cpu_utilization_rate'],
                                           )
                    if v_level == 'warning':
                        cb_node.print_warnings()
                    elif v_level == 'critical':
                        cb_node.print_critical()
                    else:
                        cb_node.print_status()
                except:
                    print('!!! Error on Node: ' + str(node[0]))
                    print('!!!Node might be down')

def main():
    logFileName = 'CBStatus'
    gvArgs = get_args()


    if gvArgs['debug']:
        vLogName = init_logger(logFileName, logging.DEBUG)
    else:
        vLogName = init_logger(logFileName, logging.INFO)

    logger = logging.getLogger()
    logger.info("------------------------------------------------------------------------------------------------------------------------")
    userCreds = login(gvArgs['user'], gvArgs['password'])
    nodes_info = import_cluster_info(gvArgs['env'])
    login_code = connect_db(userCreds[0], userCreds[1], nodes_info[0][0])

    if str(login_code) == "<Response [200]>":
        logger.info("Login successful")
        while True:
            print(datetime.datetime.now())
            print("-------------------------------------------------------------------------------")
            try:
                populate_node_info(userCreds[0], userCreds[1], nodes_info, gvArgs['level'])
            except Exception:
                print(Exception)
            print("--------------------------------------END--------------------------------------")
            print("\r")
            try:
                logger.info("Sleeping for %s secs", int(gvArgs['time']))
                sleep(int(gvArgs['time']))
            except Exception:
                print(Exception)
                print("Invalid refresh time")
                logger.error("Invalid refresh time")
                break
    else:
        logger.error("ERROR: Login failed. Credential is invalid or does not have permission on node.")
        print('Login failed')

    logger.info("Complete")
    exit(0)

main()


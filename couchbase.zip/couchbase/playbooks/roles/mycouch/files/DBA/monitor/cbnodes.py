#!/bin/python

# Author : Raymond Lee
# Date   : 2018.10.02
# Purpose: Class definition and methods for nodes
from __future__ import division

class Node:
    warningMinThreshold = 65
    criticalMinThreshold = 85

    def __init__(self, hostname, clusterName, clusterMembership, rebalanceStatus, balanced, uptime, ramFree, ramTotal,
                 services, status, hddUsed, hddTotal, cpuUsed):
        self.hostname = hostname
        self.clusterName = clusterName
        self.clusterMembership = clusterMembership
        self.rebalanceStatus = rebalanceStatus
        self.balanced = balanced
        self.uptime = int(uptime)/60/60
        self.ramFree = ramFree
        self.ramTotal = ramTotal
        self.ramUsed = int((1-(self.ramFree/self.ramTotal))*100)
        self.services = services
        self.overallStatus = status
        self.hddUsed = hddUsed
        self.hddTotal = hddTotal
        self.cpuUsed = cpuUsed

    def print_status(self):
        #print(fontColors.CBOLD + "Cluster Name: %s " % self.clusterName)
        print(fontColors.CBOLD + "    Hostname: %s " % self.hostname + fontColors.ENDC)
        print(fontColors.CBOLD + "    Uptime(h) : %s " % self.uptime + fontColors.ENDC)


        if str(self.overallStatus) == "healthy":
            print("    Overall Status: %s " % (fontColors.OKGREEN + self.overallStatus + fontColors.ENDC))
        else:
            print(fontColors.FAIL + "    Overall Status: %s " % (self.overallStatus + fontColors.ENDC))

        if str(self.clusterMembership) == "active":
            print("        Cluster Member: %s " % (fontColors.OKGREEN + self.clusterMembership + fontColors.ENDC))
        else:
            print(fontColors.FAIL + "        Cluster Member: %s " % (self.clusterMembership + fontColors.ENDC))
        if bool(self.balanced == True):
            print("        Balance: %s " % (fontColors.OKGREEN + str(self.balanced) + fontColors.ENDC))
        else:
            print(fontColors.FAIL + "        Balance: %s " % (str(self.balanced) + fontColors.ENDC))

        if bool(self.rebalanceStatus == "none"):
            print("        Rebalance Status: %s " % (fontColors.OKGREEN + str(self.rebalanceStatus) + fontColors.ENDC))
        else:
            print(fontColors.FAIL + "        Rebalance Status: %s " % (str(self.rebalanceStatus) + fontColors.ENDC))

        if int(self.cpuUsed <= self.warningMinThreshold):
            print("        Current CPU Usage: " + fontColors.OKGREEN + "[%-20s] %d%%" %
                  ('=' * int((self.cpuUsed / 5)), int(self.cpuUsed)) + fontColors.ENDC)
        elif int(self.cpuUsed > self.warningMinThreshold) and (self.cpuUsed <= self.criticalMinThreshold):
            print(fontColors.WARNING + "        Current CPU Usage: [%-20s] %d%%" %
                  ('=' * int((self.cpuUsed / 5)), int(self.cpuUsed)) + fontColors.ENDC)
        else:
            print(fontColors.FAIL + "        Current CPU Usage: [%-20s] %d%%" %
                  ('=' * int((self.cpuUsed / 5)), int(self.cpuUsed)) + fontColors.ENDC)

        if int(self.ramUsed) <= self.warningMinThreshold:
            print("        Current RAM Usage: " + fontColors.OKGREEN + "[%-20s] %d%%" %
                  ('=' * int((self.ramUsed / 5)), int(self.ramUsed)) + fontColors.ENDC)
        elif (int(self.ramUsed > self.warningMinThreshold)) and (int(self.ramUsed) <= self.criticalMinThreshold):
            print(fontColors.WARNING + "        Current RAM Usage: [%-20s] %d%%" %
                  ('=' * int((self.ramUsed / 5)), int(self.ramUsed)) + fontColors.ENDC)
        else:
            print(fontColors.FAIL + "        Current RAM Usage: [%-20s] %d%%" %
                  ('=' * int((self.ramUsed / 5)), int(self.ramUsed)) + fontColors.ENDC)

        if int(((self.hddUsed / self.hddTotal) * 100) <= self.warningMinThreshold):
            print("        Current HDD Usage: " + fontColors.OKGREEN + "[%-20s] %d%%" %
                  ('=' * int(((self.hddUsed / self.hddTotal) * 100) / 5), (self.hddUsed / self.hddTotal) * 100) + fontColors.ENDC)
        elif int(((self.hddUsed / self.hddTotal) * 100) > self.warningMinThreshold) and (int((self.hddUsed / self.hddTotal) * 100) <= self.criticalMinThreshold):
            print(fontColors.WARNING + "        Current HDD Usage: [%-20s] %d%%" %
                  ('=' * int(((self.hddUsed / self.hddTotal) * 100) / 5), (self.hddUsed / self.hddTotal) * 100) + fontColors.ENDC)
        else:
            print(fontColors.FAIL + "        Current HDD Usage: [%-20s] %d%%" %
                  ('=' * int(((self.hddUsed / self.hddTotal) * 100) / 5), (self.ramFree / self.hddTotal) * 100) + fontColors.ENDC)
        tmp_str = ""
        for i in self.services:
            tmp_str += i + " "
        print("        Services: %s \r" % (fontColors.OKBLUE + tmp_str + fontColors.ENDC))



    def print_warnings(self):
        if (str(self.overallStatus) != "healthy") or (str(self.clusterMembership) != "active") \
            or (bool(self.balanced != True)) or (bool(self.rebalanceStatus != "none") or (self.cpuUsed > self.warningMinThreshold)
            or (int(self.ramUsed > self.warningMinThreshold)) or int(((self.hddUsed / self.hddTotal) * 100) > self.warningMinThreshold)):

            #print(fontColors.CBOLD + "Cluster Name: %s " % self.clusterName)
            print(fontColors.CBOLD + "    Hostname: %s " % self.hostname + fontColors.ENDC)
            print(fontColors.CBOLD + "    Uptime(h) : %s " % self.uptime + fontColors.ENDC)

            if str(self.overallStatus) == "healthy":
                print("    Overall Status: %s " % (fontColors.OKGREEN + self.overallStatus + fontColors.ENDC))
            else:
                print(fontColors.FAIL + "    Overall Status: %s " % (self.overallStatus + fontColors.ENDC))

            if str(self.clusterMembership) == "active":
                print("        Cluster Member: %s " % (fontColors.OKGREEN + self.clusterMembership + fontColors.ENDC))
            else:
                print(fontColors.FAIL + "        Cluster Member: %s " % (self.clusterMembership + fontColors.ENDC))
            if bool(self.balanced == True):
                print("        Balance: %s " % (fontColors.OKGREEN + str(self.balanced) + fontColors.ENDC))
            else:
                print(fontColors.FAIL + "        Balance: %s " % (str(self.balanced) + fontColors.ENDC))

            if bool(self.rebalanceStatus == "none"):
                print("        Rebalance Status: %s " % (fontColors.OKGREEN + str(self.rebalanceStatus) + fontColors.ENDC))
            else:
                print(fontColors.FAIL + "        Rebalance Status: %s " % (str(self.rebalanceStatus) + fontColors.ENDC))

            if int(self.cpuUsed <= self.warningMinThreshold):
                print("        Current CPU Usage: " + fontColors.OKGREEN + "[%-20s] %d%%" %
                      ('=' * int((self.cpuUsed / 5)), int(self.cpuUsed)) + fontColors.ENDC)
            elif int(self.cpuUsed > self.warningMinThreshold) and (self.cpuUsed <= self.criticalMinThreshold):
                print(fontColors.WARNING + "        Current CPU Usage: [%-20s] %d%%" %
                      ('=' * int((self.cpuUsed / 5)), int(self.cpuUsed)) + fontColors.ENDC)
            else:
                print(fontColors.FAIL + "        Current CPU Usage: [%-20s] %d%%" %
                      ('=' * int((self.cpuUsed / 5)), int(self.cpuUsed)) + fontColors.ENDC)

            if int(self.ramUsed) <= self.warningMinThreshold:
                print("        Current RAM Usage: " + fontColors.OKGREEN + "[%-20s] %d%%" %
                      ('=' * int((self.ramUsed / 5)), int(self.ramUsed)) + fontColors.ENDC)
            elif (int(self.ramUsed > self.warningMinThreshold)) and (int(self.ramUsed) <= self.criticalMinThreshold):
                print(fontColors.WARNING + "        Current RAM Usage: [%-20s] %d%%" %
                      ('=' * int((self.ramUsed / 5)), int(self.ramUsed)) + fontColors.ENDC)
            else:
                print(fontColors.FAIL + "        Current RAM Usage: [%-20s] %d%%" %
                      ('=' * int((self.ramUsed / 5)), int(self.ramUsed)) + fontColors.ENDC)



            if int(((self.hddUsed / self.hddTotal) * 100) <= self.warningMinThreshold):
                print("        Current HDD Usage: " + fontColors.OKGREEN + "[%-20s] %d%%" %
                      ('=' * int(((self.hddUsed / self.hddTotal) * 100) / 5), (self.hddUsed / self.hddTotal) * 100) + fontColors.ENDC)
            elif int(((self.hddUsed / self.hddTotal) * 100) > self.warningMinThreshold) and (int((self.hddUsed / self.hddTotal) * 100) <= self.criticalMinThreshold):
                print(fontColors.WARNING + "        Current HDD Usage: [%-20s] %d%%" %
                      ('=' * int(((self.hddUsed / self.hddTotal) * 100) / 5), (self.hddUsed / self.hddTotal) * 100) + fontColors.ENDC)
            else:
                print(fontColors.FAIL + "        Current HDD Usage: [%-20s] %d%%" %
                      ('=' * int(((self.hddUsed / self.hddTotal) * 100) / 5), (self.ramFree / self.hddTotal) * 100) + fontColors.ENDC)
            tmp_str = ""
            for i in self.services:
                tmp_str += i + " "
            print("        Services: %s \r" % (fontColors.OKBLUE + tmp_str + fontColors.ENDC))


    def print_critical(self):
        if (str(self.overallStatus) != "healthy") or (str(self.clusterMembership) != "active") \
            or (bool(self.balanced != True)) or (bool(self.rebalanceStatus != "none") or (self.cpuUsed > self.criticalMinThreshold)
            or int(self.ramUsed > self.criticalMinThreshold) or int(((self.hddUsed / self.hddTotal) * 100) > self.criticalMinThreshold)):

            #print(fontColors.CBOLD + "Cluster Name: %s " % self.clusterName)
            print(fontColors.CBOLD + "    Hostname: %s " % self.hostname + fontColors.ENDC)
            print(fontColors.CBOLD + "    Uptime(h) : %s " % self.uptime + fontColors.ENDC)

            if str(self.overallStatus) == "healthy":
                print("    Overall Status: %s " % (fontColors.OKGREEN + self.overallStatus + fontColors.ENDC))
            else:
                print(fontColors.FAIL + "    Overall Status: %s " % (self.overallStatus + fontColors.ENDC))

            if str(self.clusterMembership) == "active":
                print("        Cluster Member: %s " % (fontColors.OKGREEN + self.clusterMembership + fontColors.ENDC))
            else:
                print(fontColors.FAIL + "        Cluster Member: %s " % (self.clusterMembership + fontColors.ENDC))
            if bool(self.balanced == True):
                print("        Balance: %s " % (fontColors.OKGREEN + str(self.balanced) + fontColors.ENDC))
            else:
                print(fontColors.FAIL + "        Balance: %s " % (str(self.balanced) + fontColors.ENDC))

            if bool(self.rebalanceStatus == "none"):
                print("        Rebalance Status: %s " % (fontColors.OKGREEN + str(self.rebalanceStatus) + fontColors.ENDC))
            else:
                print(fontColors.FAIL + "        Rebalance Status: %s " % (str(self.rebalanceStatus) + fontColors.ENDC))

            if int(self.cpuUsed <= self.warningMinThreshold):
                print("        Current CPU Usage: " + fontColors.OKGREEN + "[%-20s] %d%%" %
                      ('=' * int((self.cpuUsed / 5)), int(self.cpuUsed)) + fontColors.ENDC)
            elif int(self.cpuUsed > self.warningMinThreshold) and (self.cpuUsed <= self.criticalMinThreshold):
                print(fontColors.WARNING + "        Current CPU Usage: [%-20s] %d%%" %
                      ('=' * int((self.cpuUsed / 5)), int(self.cpuUsed)) + fontColors.ENDC)
            else:
                print(fontColors.FAIL + "        Current CPU Usage: [%-20s] %d%%" %
                      ('=' * int((self.cpuUsed / 5)), int(self.cpuUsed)) + fontColors.ENDC)

            if int(self.ramUsed) <= self.warningMinThreshold:
                print("        Current RAM Usage: " + fontColors.OKGREEN + "[%-20s] %d%%" %
                      ('=' * int((self.ramUsed / 5)), int(self.ramUsed)) + fontColors.ENDC)
            elif (int(self.ramUsed > self.warningMinThreshold)) and (int(self.ramUsed) <= self.criticalMinThreshold):
                print(fontColors.WARNING + "        Current RAM Usage: [%-20s] %d%%" %
                      ('=' * int((self.ramUsed / 5)), int(self.ramUsed)) + fontColors.ENDC)
            else:
                print(fontColors.FAIL + "        Current RAM Usage: [%-20s] %d%%" %
                      ('=' * int((self.ramUsed / 5)), int(self.ramUsed)) + fontColors.ENDC)

            if int(((self.hddUsed / self.hddTotal) * 100) <= self.warningMinThreshold):
                print("        Current HDD Usage: " + fontColors.OKGREEN + "[%-20s] %d%%" %
                      ('=' * int(((self.hddUsed / self.hddTotal) * 100) / 5), (self.hddUsed / self.hddTotal) * 100) + fontColors.ENDC)
            elif int(((self.hddUsed / self.hddTotal) * 100) > self.warningMinThreshold) and (int((self.hddUsed / self.hddTotal) * 100) <= self.criticalMinThreshold):
                print(fontColors.WARNING + "        Current HDD Usage: [%-20s] %d%%" %
                      ('=' * int(((self.hddUsed / self.hddTotal) * 100) / 5), (self.hddUsed / self.hddTotal) * 100) + fontColors.ENDC)
            else:
                print(fontColors.FAIL + "        Current HDD Usage: [%-20s] %d%%" %
                      ('=' * int(((self.hddUsed / self.hddTotal) * 100) / 5), (self.ramFree / self.hddTotal) * 100) + fontColors.ENDC)
            tmp_str = ""
            for i in self.services:
                tmp_str += i + " "
            print("        Services: %s \r" % (fontColors.OKBLUE + tmp_str + fontColors.ENDC))


    def __str__(self):
        return "(Hostname: %s, \n" \
               "ClusterName: %s, \n" \
               "Clustermembership: %s, \n" \
               "RebalanceStatus: %s, \n" \
               "balanced: %s \n" \
               "uptime: %s hours  \n" \
               "ram free: %s  \n" \
               "ram total: %s \n" \
               "services: %s \n" \
               "overall status: %s \n" \
               "hdd used: %s \n" \
               "hdd total: %s \n" \
               "cpu used: %s \n" % \
               (self.hostname,
                self.clusterName,
                self.clusterMembership,
                self.rebalanceStatus,
                self.balanced,
                self.uptime,
                self.ramFree,
                self.ramTotal,
                self.services,
                self.overallStatus,
                self.hddUsed,
                self.hddTotal,
                self.cpuUsed
               )


class fontColors:
    CBOLD = '\33[1m'
    CITALIC = '\33[3m'
    OKBLUE = '\33[94m'
    OKGREEN = '\33[92m'
    WARNING = '\33[93m'
    FAIL = '\33[91m'
    ENDC = '\33[0m'
    BOLD = '\33[1m'
    UNDERLINE = '\33[4m'


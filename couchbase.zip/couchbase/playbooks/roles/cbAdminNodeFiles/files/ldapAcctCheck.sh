#!/bin/bash
#
# Author :  Victor Zuniga
# Date   :  2021.06.08
# Purpose:  Dsiplay LDAP information about received account.

function usage {
   echo "$0 [options]"
   echo "   options:"
   echo "      <ACCT(s)>    The account(s) to be verified. Comma separated if more than one."

   exit 1

}

if [ $# -lt 1 ]; then
    usage
fi


IFS=', ' read -r -a arACCTS <<< "${1}"

for vACCT in "${arACCTS[@]}"
do

    echo '=========================================================================================='
    echo "" > /tmp/out.tmp
    ldapsearch -LLL -o ldif-wrap=no -b "dc=south,dc=bbc,dc=net" \
    -H ldaps://ldaps.south.edu \
    -D "CN=CouchbaseBind,OU=Bind,OU=ServiceAccounts,DC=south,DC=bbc,DC=net" -w EU24Vn3B7T6@tY3K \
    "(&(sAMAccountName=${vACCT}))" name displayName description employeeType memberof | while read -r line; do
        if [[ "$line" == *"memberOf"* ]] ; then
            echo "$line" >> /tmp/out.tmp
        else
            echo "$line"
        fi
    done
    echo "Groups:"
    cat /tmp/out.tmp | awk '{print $2}' | awk -F, '{print $1}' | awk -F= '{print "    "$2}'
    echo '=========================================================================================='

done

echo 'Done.'

#!/bin/bash
#
# Author :  Victor Zuniga
# Date   :  2021.06.16
# Purpose:  Display LDAP couchbase groups


#if [ $# -lt 1 ]; then
    
#fi


IFS=', ' read -r -a arENV <<< "${1:-INT,QA,PROD}"
arENV=${arENV^^}


echo '=========================================================================================='
for vENV in "${arENV[@]}"
do

    echo "${vENV}"
    echo '=========================================================================================='
    echo "" > /tmp/out.tmp
    ldapsearch -LLL -o ldif-wrap=no -b "ou=${vENV},ou=couchbase,ou=groups,dc=south,dc=bbc,dc=net" \
    -H ldaps://ldaps.south.edu \
    -D "CN=CouchbaseBind,OU=Bind,OU=ServiceAccounts,DC=south,DC=bbc,DC=net" -w EU24Vn3B7T6@tY3K \
    name | sort | while read -r line; do

    if [[ "name: ${vENV}" != *"${line}"* && "dn: CN=" != *"${line}"* ]] ; then
        echo ${line} | grep "dn:" > /dev/null
        if [[ $? != 0 ]]; then
            echo "    $line "
        fi
    fi

    done
    echo '=========================================================================================='

done

echo 'Done.'

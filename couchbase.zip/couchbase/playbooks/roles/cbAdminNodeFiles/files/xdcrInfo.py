#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2021.06.17
# Purpose : This script will display XDCR information in our cluster(s)


import sys
import os
import json
import argparse
import requests
import logging

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import getClusterNames, getRandomClusterNode
from bbc_cb.cb_api import verifyAdminConnection, getSSLEndpoint
from bbc_cb.env_detail import CBENV

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="checkXDCR.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Script verify status of all or one Couchbase Cluster.
      ''')
    
    parser.add_argument('-c', '--cluster', help='Cluster Name', default='all', required=False)
    #parser.add_argument('-b', '--bucket', help='Bucket Name', default='all', required=False)
    parser.add_argument('-u', '--user', help='Admin Account to be used', required=False)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-e', '--env', help='Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required=False)
    parser.add_argument('-d', '--debug', action='store_true', help='Run in DEBUG mode', required=False)

    return vars(parser.parse_args())

def getRemoteClusters( pAuth, pCluster):
    """
    Gets information on the XDCR remote clusters defined in the cluster
    """
    logger.info ("In getRemoteClusters - [%s]" % pCluster)
    logger.debug ("Auth: %s/%s" % (pAuth[0], "******"))

    vNode = getRandomClusterNode( pCluster)
    logger.debug("Cluster: %s [%s]" % (pCluster, vNode))

    vURL = "http://%s:8091/pools/default/remoteClusters" % vNode

    vCert = "%s/ca.pem" % os.getenv("CB_CERTS_INBOX")
    logger.debug ("cert: %s" % vCert)

    vRemoteClusters = getSSLEndpoint( pAuth, vURL, vCert)
    
    logger.debug ("RemoteClusters: %s" % str(vRemoteClusters))

    return vRemoteClusters


def getReplications( pAuth, pCluster):
    """
    Gets task information from the cluster where type = xdcr
    """
    logger.info ("In getReplications- [%s]" % pCluster)
    logger.debug ("Auth: %s/%s" % (pAuth[0], "******"))

    vNode = getRandomClusterNode( pCluster)
    logger.debug("Cluster: %s [%s]" % (pCluster, vNode))
    
    vURL = "http://%s:8091/pools/default/tasks" % vNode

    vCert = "%s/ca.pem" % os.getenv("CB_CERTS_INBOX")
    logger.debug ("cert: %s" % vCert)

    vReplications = getSSLEndpoint( pAuth, vURL, vCert)
    logger.debug ("Raw Replications: %s" % str(vReplications))

    # Keep only the items with type xdcr
    for rep in vReplications:
        if rep["type"] != "xdcr":
            # Remove the item
            vReplications.remove(rep)

    logger.debug("Net Replications: %s" % str(vReplications))

    for r in vReplications:
        logger.debug ("type: %s" % r["type"])
    
    return vReplications


def displayXDCRInfo ( pRemote, pRepl, pCluster, pDispOpts ):
    """
    Traverse the list of remote cluster information
    """
    logger.debug("in displayRemoteClusters")
    logger.debug("display options - cluster: %s" % pDispOpts["cluster"])
    #logger.debug("display options - bucket: %s" % pDispOpts["bucket"])
    logger.debug("remote: %s" % str(pRemote))
    logger.debug("repl  : %s" % str(pRepl))

    if len(pRemote) <= 0:
        print ("    No Remote Clusters Found")
        logger.info ( "displayXDCRInfo: %s - No remote clusters defined" % pCluster)
    else:

        print ("    %-15s %-15s %-40s %-5s" % ("Remote", "user", "host", "uuid"))
        print ("    %-15s %-15s %-40s %-5s" % ("---------------", "---------------", "----------------------------------------", "---------------------------------"))

        for lvRemote in pRemote:
            logger.debug( "Remote Cluster: %s" % str(lvRemote))
            print ("    %-15s %-15s %-40s %-5s" % (lvRemote["name"], lvRemote["username"], lvRemote["hostname"], lvRemote["uuid"]  ))

            # Traverse the replications and display only ones for the current remote cluster (uuid)
            if len(pRepl) > 0:
                print ("        %s %s %s %s  %s" % ( "Src Bucket".ljust(17, ' '),
                                                        "Trgt Bucket".ljust(25, ' '),
                                                        "Status".ljust(15, ' '),
                                                        #"User & node".ljust(49, ' '),
                                                        "ChngsLeft".ljust(10, ' '),
                                                        "Errors".ljust(25, ' ')
                                                       ))
                print ("        %s %s %s %s  %s" % ( "-".ljust(17, '-'),
                                                        "-".ljust(25, '-'),
                                                        "-".ljust(15, '-'),
                                                        #"-".ljust(49, '-'),
                                                        "-".ljust(10, '-'),
                                                        "-".ljust(25, '-')
                                                       ))
                for lvRepl in pRepl:
                    #print (str(lvRepl))
                    if "id" in lvRepl.keys() and lvRemote["uuid"] in lvRepl["id"]:
                        vTargetBucket = lvRepl["target"].split("/")[4]
                        
                        # Filter by bucket if one is provided
                       
                        print ("        %s %s %s %s  errors: %s" % ( 
                                        lvRepl["source"].ljust(17,' '), 
                                        (lvRemote["name"] + "." + vTargetBucket).ljust(25,' '), 
                                        lvRepl["status"].ljust(15, ' '), 
                                        #("["+lvRemote["username"] + " - " + lvRemote["hostname"] + "]").ljust(49,' '),
                                        str(lvRepl["changesLeft"]).rjust(10, ' '),
                                        lvRepl["errors"]  ))  
            print(' ')
    print (' ')

    return True


def main( pArgs):
    
    lvAuthCreds = (pArgs['user'], pArgs['password'])

    if (pArgs['cluster'] == 'all' and pArgs['env'] == 'iqp' ):
        # Traverse the CBENV and list all clusters
        for e in CBENV.keys():
            print ("\n=====================================================================================================================\n")
            for vClstr in sorted(CBENV[e].keys()):
                print (vClstr)
                displayXDCRInfo( getRemoteClusters( lvAuthCreds, vClstr), getReplications (lvAuthCreds, vClstr), vClstr, pArgs )
    elif (pArgs['cluster'] == 'all' and pArgs['env'] != 'iqp' ):
        # traverse received environments
        for e in (list(pArgs['env'])):
            if e in CBENV.keys():
                print ("=====================================================================================================================\n")
                for vClstr in sorted(CBENV[e].keys()):
                    print (vClstr)
                    displayXDCRInfo( getRemoteClusters( lvAuthCreds, vClstr), getReplications (lvAuthCreds, vClstr), vClstr, pArgs )
    elif (pArgs['cluster'] != 'all'):
        # Allow for multiple clusters to be passed at once
        print( "=====================================================================================================================\n")
        vClusterList = pArgs['cluster'].replace(" ", ",").split(",")
        logger.info("Cluster List: %s" % str(vClusterList))
        for vClstr in vClusterList:
            #if gvArgs['cluster'] not in getClusterNames():
            if vClstr not in getClusterNames():
                print ("ERROR: cluster %s does not exist." % (vClstr))
            else:
                #getRemoteClusters( lvAuthCreds, vClstr)
                #getReplications (lvAuthCreds, vClstr)
                print (vClstr)
                displayXDCRInfo( getRemoteClusters( lvAuthCreds, vClstr), getReplications (lvAuthCreds, vClstr), vClstr, pArgs )
                
    print( "=====================================================================================================================\n")

    return True


# ------------------------------------------------------------------------------------------------------------------------


if __name__ == "__main__":

    gvArgs = get_args()

    logNamePrefix = 'xdcrInfo'
    if gvArgs['debug']:
        vLogName = init_logger(logNamePrefix, logging.DEBUG)
    else:
        vLogName = init_logger(logNamePrefix, logging.INFO)

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info(
                "Enter %s\'s Password   : " % gvArgs['user'])

    logger.debug("Args: " + str(gvArgs))

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password'])):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        print("ERROR: Connection using %s failed" % gvArgs['user'])
        print("ERROR: Please verify credentials")
        print("ERROR: Check log (%s) for details" % vLogName)
        exit(-1)
    else:
        logger.info("Credentials verified")
        print("Credentials verified")

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    if gvArgs['debug']:
        print("Username: %s" % gvArgs['user'])
        print("Password: %s" % gvArgs['password'].replace(gvArgs['password'], '*'*len(gvArgs['password'])))
        print("Env     : %s" % gvArgs['env'])
        print("Cluster : %s" % gvArgs['cluster'])
    main( gvArgs)
    print ("Done")
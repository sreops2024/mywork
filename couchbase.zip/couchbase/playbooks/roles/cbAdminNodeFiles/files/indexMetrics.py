#!/usr/bin/python3
# Author  : Victor Zuniga
# Date    : 2020.06.30
# Purpose : Script to traverse Index stats CSV file and display desired index metrics
#
# 2023.03.01 Victor Zuniga        Added logic to handle scope and collections introduced in CB v7.0

import os
import sys
import csv
import time
import argparse
import operator
import prettytable

from datetime import datetime
from prettytable import PrettyTable
from bbc_log.dba_log import init_logger


def get_args() :
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser ( 
        prog = "indexMetrics.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=
'''
Script to display index statistics
''',
        epilog =  
'''
List of possible metrics:
    - avg_array_length      avg_drain_rate             avg_item_size           avg_scan_latency         cache_hit_percent
      cache_hits            cache_misses               data_size               disk_size                docid_count
      frag_percent          initial_build_progress     items_count             last_known_scan_time     memory_used     
      num_docs_indexed      num_docs_pending           num_docs_queued         num_items_flushed        num_pending_requests
      num_requests          num_rows_returned          num_scan_errors         num_scan_timeouts        recs_in_mem              
      recs_on_disk          resident_percent           scan_bytes_read         total_scan_duration

Filter: will only match on
    - cluster
    - node
    - bucket
    - index name
'''
    )
    parser.add_argument ( '-u', '--user', help = 'Admin Account to be used', required = False )
    parser.add_argument ( '-p', '--password', help = 'Admin Password to be used', required = False )
    parser.add_argument ( '-f', '--filter', help = 'List of filter values (comma separated)', required = False, default = None )
    parser.add_argument ( '-m', '--metrics', help = "List of metrics (comma separated) (see below)", required = False, default = None )
   
    return  vars(parser.parse_args() )


def getData ( pCSVFile, pFilter = None ):
    '''
    Traverse the CSV file and return the pretty table object.  Filter as needed
    '''

    if pFilter != None:
        vFilter = pFilter.lower().replace(' ','').split(',')
        print ("Filter: " + str(vFilter) + "\n")

    try:
        with open ( pCSVFile, 'r') as csvData:
            rd = csv.reader( csvData, delimiter = ',' )
            pTable = prettytable.PrettyTable (next (rd) )
            for row in rd:
                if pFilter == None :
                    pTable.add_row (row)
                else:
                    
                    if all( x in str(row[:4]) for x in vFilter):
                        pTable.add_row (row)  

        return pTable
    except:
        print ("ERROR: ")
        print("Unexpected error:", sys.exc_info()[0] )
        return False

def validateMetrics ( pValidMetrics, pRecMetrics ):
    'Validate the received matrics'

    if pRecMetrics != None:    
        for m in pRecMetrics:
            if not m in pValidMetrics:
                print ("Invalid metric: " + str(m))
                return False

    print ("Metrics validated")
    return True


def main():
    '''
    Main function - get index data, display needed metrics
    '''

    gvArgs = get_args()
    if gvArgs['metrics'] != None:
        vMetricsArg = gvArgs['metrics'].replace(' ', '').lower().split(',')
        #print ("Metrics Arg rec: " + str(gvArgs['metrics']))
        #print ("Metrics Arg arr: " + str(vMetricsArg))
    else:
        vMetricsArg = None

    lLogDir = os.environ["LOG_DIR"]
    lDTSuf = time.strftime("%Y%m%d")
    lIdxMetricsFile = lLogDir + "/clstrIdxMetrics." + lDTSuf + '.csv'

    # Default columns
    #vMustCols = ['Cluster', 'Node', 'Bucket', 'Index']
    vMustCols = ['Cluster', 'Node', 'Bucket', 'Scope', 'Collection', 'Index']
    vDefCols = ['last_known_scan_time', 'cache_hit_percent', 'disk_size', 'memory_used', 'num_scan_timeouts', 'num_requests', 'items_count', 'resident_percent']
    vPossibleCols = [ 
               'avg_array_length', 'avg_drain_rate', 'avg_item_size', 'avg_scan_latency', 'cache_hit_percent', 
               'cache_hits', 'cache_misses', 'data_size', 'disk_size', 'docid_count', 'frag_percent', 
               'initial_build_progress', 'items_count', 'last_known_scan_time', 'memory_used', 'num_docs_indexed',  
               'num_docs_pending', 'num_docs_queued', 'num_items_flushed', 'num_pending_requests', 'num_requests', 
               'num_rows_returned', 'num_scan_errors', 'num_scan_timeouts', 'recs_in_mem', 'recs_on_disk', 
               'resident_percent', 'scan_bytes_read', 'total_scan_duration' ]

    if validateMetrics ( vPossibleCols, vMetricsArg ) :
        #print ("metrics are valid or none")
        if vMetricsArg != None:
            vColumns = vMustCols + vMetricsArg
        else:
            vColumns = vMustCols + vDefCols
    else:
        print ("ERROR: Invalid metric received.")
        return False

    # Get csv data
    pt = getData (lIdxMetricsFile, gvArgs['filter'])

    if pt == False:
        print ("ERROR reading data")
    else:   
        # Format columns accordingly
        for col in vColumns:
            if col in vMustCols:
                pt.align[col] = 'l'
            else:
                pt.align[col] = 'r'

        print ( pt.get_string( fields = vColumns ))
        #print ( pt.get_string( fields = vColumns, sort_key=operator.itemgetter(0,3,2), sortby="Cluster" ) ) 
        #print ( pt.get_string( fields = vColumns, sort_key=operator.itemgetter(3,0), sortby="Index", reversesort=True ) )
        
        
    
    return True
    
if __name__ == "__main__":
    
    if main ():
        exit(0)
    else:
        exit (1)


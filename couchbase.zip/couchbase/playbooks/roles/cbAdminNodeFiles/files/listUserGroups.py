#!/usr/bin/python3
# Author  : Victor Zuniga
# Date    : 2021.01.26
# Purpose : Add a spare node to the recived cluster based on the configuration files.
#

import os
import argparse
import logging
import time
import json
from subprocess import check_output
#from pprint import PrettyPrinter


from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import getClusterNames, getClusterNodes, getRandomClusterNode
from bbc_fileSec.encServer import getClusterCred
from bbc_cb.cb_api import getSSLEndpoint

def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="listUserGroups.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Receive the list of clusters to list user groups for.
      ''')
    parser.add_argument('-u', '--user', help='Admin User Name', required=False)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-d', '--detail', help='Provide group details', required=False, default=False, action='store_true')
    parser.add_argument('-c', '--cluster', help='Cluster Name(s) [comma separated list]', required=False)
    parser.add_argument('-D', '--debug', help='Enable debug mode', required=False, default=False, action='store_true')

    return vars(parser.parse_args())

def getClusterUserGroups(pAuth, pCluster, pBucket=None):
    """
    Get the list of user Groups from the cluster.
    If a bucket name is received, look for USR and APP groups with that bucket name
    """

    logger.info("getClusterUserGroups")
    #logger.debug("Auth: %s, %s" % (pAuth[0], pAuth[1].replace(pAuth[1], '*' * len(pAuth[1]))))
    logger.debug("Auth: %s, %s" % (pAuth[0], pAuth[1]) )
    logger.debug("Cluster: %s" % pCluster)

    vPort = "18091"
    vHost = getRandomClusterNode(pCluster)
    vURL = "https://%s:%s/settings/rbac/groups" % (vHost, vPort)
    vCert = os.getenv("CB_CERTS_INBOX") + "/ca.pem"
    vRet = []
    try:
        vRet = getSSLEndpoint(pAuth, vURL, vCert)

    except:
        logger.warning("Error getting groups [%s]" % pCluster)
        print ("Error getting groups [%s]" % pCluster)
    
    return vRet


def cleanGroupData(pGroupData):
    """
    Clean up the received JSON to remove unneeded lists, making it easier to display the data.
    """

    logger.debug("in cleanGroupData")
    logger.debug("pGroupData: %s" % str(pGroupData))
    vData = {}
    
    # Expecting a list.  If dictionary, it means an error was encountered getting the information.
    # Just return the received info.
    if 'dict' in str(type(pGroupData)):
        logger.warning('Expecting a list, got a dictionary')
        logger.warning(str(pGroupData))
        #return pGroupData
        return {}

    # Process each list item containing the group id, roles, ldap_group_ref, description
    for grp in pGroupData:
        vData[grp['id']] = {}
        vData[grp['id']]['ldap_group_ref'] = grp['ldap_group_ref']
        vData[grp['id']]['description'] = grp['description']
        vData[grp['id']]['roles'] = {}

        # Process the roles.
        for item in grp['roles']:
            #logger.debug (item)
            try:
                if item['bucket_name'] not in vData[grp['id']]['roles'].keys():
                    vData[grp['id']]['roles'][item['bucket_name']] = []
                vData[grp['id']]['roles'][item['bucket_name']].append(item['role'])
            except:
                logger.warning("could not process bucket or role")
                vData[grp['id']]['roles']['AdminRole'] = []
                vData[grp['id']]['roles']['AdminRole'].append(item['role'])

        logger.debug("id            : %s" % grp['id'])
        logger.debug("ldap group ref: %s" % grp['ldap_group_ref'])
        logger.debug("description   : %s" % grp['description'])
        logger.debug("roles         : %s" % vData[grp['id']]['roles'])
            
    return vData

def main( pClusterStr = None, pCreds = (None, None), pDetails = False ):
    """Provide a list of cluster and their user groups."""

    logger.info("Main...")

    # Get list of clusters
    vClusterList = getClusterNames()
    vClusters = []
    #print("Clusters: %s" % str(vClusterList))

    # Parse clusters received and determine if valid name
    if pClusterStr is not None:
        logging.debug ("Cluster String: %s " % pClusterStr)
        for i in pClusterStr.split(","):
            logger.debug("Cluster: %s" % i)
            if i in vClusterList:
                logger.info ("Cluster: %s appended to list" % i)
                vClusters.append(i)
            else:
                logger.warning("Cluster name (%s) not found" % i)
                print ("Warning: Cluster name (%s) not found" % i)

    else:
        logger.info("No cluster received, using all clusters")
        vClusters = vClusterList
        logger.debug("Clusters: %s" % str(vClusters))

    vdGroups = {}

    for xClstr in vClusters:
        vCred = getClusterCred('dbadmin', xClstr, "/home/couchbase/DBA/.cbAdmin")
        vRawData = {}
        vCleanGroups = {}
        vRawData = getClusterUserGroups(("dbadmin", vCred), xClstr)
        vCleanGroups = cleanGroupData(vRawData)
        vdGroups[xClstr] = vCleanGroups
        
    logger.debug("User Groups: %s" % str(vdGroups))
      
    # Display the received information
    print("\nUser Groups: ")
    for vClstr in vdGroups.keys():
        print("\n%s" % (vClstr))

        for vGrp in sorted(vdGroups[vClstr]):
            if vGrp == 'bbc_err_code':
                print("   No groups found")
            else:
                print("   %s" % vGrp)

                if pDetails:
                    for bkt in vdGroups[vClstr][vGrp]['roles'].keys():
                        print("         Bucket  : %s - %s " % (bkt, vdGroups[vClstr][vGrp]['roles'][bkt]))
                    print("         Desc    : %s " % vdGroups[vClstr][vGrp]['description'])
                    print("         LDAP ref: %s " % vdGroups[vClstr][vGrp]['ldap_group_ref'])
            
    return True

if __name__ == "__main__":
    gvArgs = get_args()
    logFileName = 'userGroupList'

    if gvArgs['debug'] is True:
        print ("In debug mode")
        vLogName = init_logger(logFileName, logging.DEBUG)
    else:
        #print ("In info mode")
        vLogName = init_logger(logFileName, logging.INFO)

    print("Log file: %s" % vLogName)

    if gvArgs['user'] == '' or gvArgs['user'] is None:
        # User is empty, get credentials from the env.
        gvArgs['user'] = os.getenv('MON_USER')
        gvArgs['password'] = os.getenv('MON_PSWD')
    
    if gvArgs['password'] == '' or gvArgs['password'] is None:
        # Request Password
        gvArgs['password'] = get_user_info  ("Enter %s\'s Password   : " % gvArgs['user'] )
    logger = logging.getLogger()
    logger.info("------------------------------------------------------------------------------------------------------------------------")

    rc = main(gvArgs['cluster'], (gvArgs['user'], gvArgs['password']), gvArgs['detail'])
exit (0)
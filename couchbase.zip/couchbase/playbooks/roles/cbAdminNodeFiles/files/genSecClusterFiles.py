#!/usr/bin/python3
# Author  : Victor Zuniga
# Date    : 2019.06.06
# Name    : genSecClusterFiles
# Purpose : Script to create RSA keys and admin credential encrypting files for a specific cluster.

# History
#
# 2019.06.17 Victor Zuniga     If RSA files exist, do not overwrite.
# 2021.01.13 Victor Zuniga     Remove the password parameter.  A password will be generated to
#                              prevent the DBA from knowing the password.
#                              Convert the username to lowercase, which is expected by the
#                              getPassword function.
#

import argparse
import os

from bbc_fileSec.encClient import genRSAKeys, genCredFile
from bbc_log.dba_log import *
from bbc_sec.passwd_gen import verify_password, pwd_gen
from bbc_sec.get_creds import get_user_info


# ----------------------------------------------------------------------------------------------------------------------
# Global Variables
vPWDMinLength = 10
vPWDMinNum = 2
vPWDMinUpper = 2
vPWDMinSpecials = 2
# ----------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="genSecClusterFiles.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      This script generated RSA public and private keys, and encrypted credential files for the received cluster and 
      account. 
      ''')

    parser.add_argument('-c', '--cluster', help='Cluster Name', required=True)
    parser.add_argument(
        '-u', '--user', help='Admin Account Name', required=True)
    #parser.add_argument('-p', '--password', help='Password to be used')
    parser.add_argument('-d', '--directory',
                        help='Directory path - Use *NIX format (/)')

    return vars(parser.parse_args())


# ----------------------------------------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------------------------------------------------
# logger = logging.getLogger ( __name__ )
logger = logging.getLogger("root")

logNamePrefix = 'genSecClusterFiles'
vLogName = init_logger(logNamePrefix, logging.DEBUG)
logger.info('------------------------------------------------------------------------')

lvClusterPrvKey = ''
lvClusterPubKey = ''

gvArgs = get_args()

# Verify that the received directory exists
if gvArgs['directory'] is None:
    lLogDir = os.getenv('LOG_DIR')
    logger.info("Log dir env var: " + str(lLogDir))

    print("\n\nPlease use / or \\\\ as directory separator(s)...\n")

    vCounter = 0
    lDir = ''
    while ((vCounter < 3) and not os.path.isdir(lDir)):
        if (lLogDir is None) or (lLogDir == ''):
            # Environment variable is not set; must get a valid directory from user.  Loop 3 times.
            lDir = input("Enter log destination path : ")
        else:
            lDir = input("Enter log destination path [" + lLogDir + "] : ")
            if lDir == '':
                lDir = lLogDir

        vCounter += 1

        logger.debug("Counter : " + str(vCounter))
        logger.info("entered dir: " + lDir)
        logger.info("Dir exists: " + str(os.path.isdir(lDir)))

        if (not os.path.isdir(lDir)) and (vCounter < 3):
            print("\n ... Directory does not exist, please try again.\n")

    if os.path.isdir(lDir):
        logger.debug("Set log dir : " + lDir)
        gvArgs['directory'] = lDir

else:
    '''Verify the directory provided exists'''
    if os.path.isdir(gvArgs['directory']):
        logger.info("Directory: " + gvArgs['directory'] + " exists.")
    else:
        logger.error("Directory: " + gvArgs['directory'] + " does not exists.")
        print("Directory: " + gvArgs['directory'] + " does not exists.")
        exit(-1)

logger.info("Generating Password")
gvArgs['password'] = pwd_gen(
    vPWDMinLength, vPWDMinNum, vPWDMinUpper, vPWDMinSpecials)
logger.debug("gvArgs: " + str(gvArgs))

# Check to see if the RSA keys exist in the received directory.
#if not (os.path.isfile(gvArgs['directory'] + "/" + gvArgs['cluster']+".bin") and os.path.isfile(gvArgs['directory'] + "/" + gvArgs['cluster']+"_priv.bin")):
lvClusterPrvKey = "%s/%s_priv.bin" % ( gvArgs['directory'], gvArgs['cluster'] )
lvClusterPubKey = "%s/%s.bin" % (gvArgs['directory'], gvArgs['cluster'])
logger.debug("Private key file: %s" % lvClusterPrvKey)
logger.debug("Public  key file: %s" % lvClusterPubKey)
if not (os.path.isfile(lvClusterPubKey) and os.path.isfile(lvClusterPrvKey)):
    # Key files do not exists.  Both files must be present, if not, regenerate them.
    logger.info("One, or both. key file(s) are not present.  Recreate...")

    if genRSAKeys(gvArgs['directory'], gvArgs['cluster']):
        logger.info("RSA Key files generated: %s" % gvArgs['directory'])
    else:
        logger.error("Error creating RSA Key files.")
        print(
            "Error creating RSA Key files. Check log file for details [" + vLogName + "]")
        exit(-1)

if genCredFile(gvArgs['directory'], gvArgs['cluster'], (gvArgs['user'].lower(), gvArgs['password'])):
    logger.info("Key files generated")
else:
    logger.error("Error creating encrypted credential file.")
    print(
        "Error creating credential files. Check log file for details [" + vLogName + "]")
    exit(-1)

exit(0)

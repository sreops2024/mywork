#!/usr/bin/python3

# Author : Victor Zuniga
# Date   : 2022.07.05
# Purpose: Capture the VM and the host (VM) name for each node in the couchbase clusters.
#          Save the information to a json file.


import os
import time
import socket
import pprint
import json

from bbc_cb.cb_api import getClusterNames,getClusterNodes

def saveJSONFile( pData ):
    # Write the pData dictionary to a file name cbNodeInfo.<YYYYMMDD>.json

    lDTSuf = time.strftime("%Y%m%d")
    lLogDir = os.environ['LOG_DIR']
    lvFile = "%s/cbNodeInfo.%s.json" % (lLogDir, lDTSuf)

    print ("JSON File: %s" % lvFile)

    try:
        with open(lvFile, "w") as f:
            json.dump(pData, f, indent=4)
    except:
        print("ERROR: Could not write to %s" % lvFile)
        return False

    return True


def main():
    vDict = {}
    for c in getClusterNames():
        vDict[c] = {}
        for n in getClusterNodes(c):
            v,a,i = socket.gethostbyname_ex(n)
            v = v.split('.')[0]
            #print("Cluster: %s - Node: %s - VM: %s %s" % (c,n,v,i))
            vDict[c][n] = {v:i}
            vDict[n] = {"vm":v, "ip":i, "cluster":c}
            vDict[v] = {"node":n,"ip":i, "cluster":c}
            #vDict[c][v] = vDict[v]
    return vDict


if __name__ == "__main__":
    vJson = {}
    vTimeSrt = time.time()
    vJson = main()
    vTimeEnd = time.time()

    pp = pprint.PrettyPrinter( indent = 4)
    
    #pp.pprint(vJson)
    #print(vJson)

    saveJSONFile(vJson)

    print("Start Time: %s" % str(vTimeSrt))
    print("End   Time: %s" % str(vTimeEnd))
    print("Dur: %s", vTimeEnd - vTimeSrt)

exit(0)

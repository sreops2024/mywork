#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2020.06.24
# Purpose : Script to display cluster certificate information.

import os
import argparse
import pprint
import logging

from bbc_log.dba_log import init_logger
from bbc_cb.cb_api import verifyAdminConnection, getEndpoint
from bbc_cb.env_config import getClusterNames, getRandomClusterNode
from bbc_email.dba_email import email_log

# ------------------------------------------------------------------------------------------------------------------------

def get_args() :
   """ Set up the arguments and return the python dictionary containing the received values """
   parser = argparse.ArgumentParser ( prog = "clusterCertInfo.py",
                                      formatter_class=argparse.RawDescriptionHelpFormatter,
                                      description=
      '''
      Script to monitor cluster certificates
      ''' )
   parser.add_argument ( '-u', '--user', help = 'Account to be used', required = False )
   parser.add_argument ( '-p', '--password', help = 'Password to be used', required = False )
   return  vars(parser.parse_args() )

# ------------------------------------------------------------------------------------------------------------------------

def getNodeCertInfo( pAuth, pNode ):
    '''
    Get cluster Certificate Information from the node received
    '''

    logger.info ('getNodeCertInfo')
    logger.info ('Auth: ' + str( pAuth ).replace( pAuth[1], '*' * len( pAuth[1] )))

    vURL = "http://%s:%d/pools/default/certificate?extended=true" % (pNode, 8091)
    logger.debug ("URL: " + vURL)

    certInfo = getEndpoint ( pAuth, vURL)
    logger.debug ("Cert Info: " + str(certInfo))

    return certInfo

# ------------------------------------------------------------------------------------------------------------------------

def main( pAuth ):
    logger.info( "Main")
    logger.info ('Auth info: ' + str(pAuth).replace( pAuth[1], '*' * len(pAuth[1]) ) )

    vDBAEmail = os.environ.get('DBA_EMAIL')
    logFile = os.environ.get('LOG_DIR') + '/certInfo.warning.log'
    logger.info ("Log file: " + logFile)

    vClusters = getClusterNames ()

    logger.info ("Clusters: " + str(vClusters))
    
    pp = pprint.PrettyPrinter ( indent=4 )

    # Empty out the log file
    with open( logFile, 'w' ) as outFile:
        vWarnings = 0
        outFile.write ("\nCouchbase clusters with certificate warnings: \n\n")

    for cluster in vClusters:
        logger.info ("Process cluster: " + cluster)
        node = getRandomClusterNode( cluster )
        logger.info ('Node: ' + node)
        certInfo = getNodeCertInfo ( pAuth, node )

        # Clear out the cert - not needed and too long to print
        certInfo['cert']['pem'] = [' ... ']
        logger.info ("Cert Info: " + str (certInfo) )

        if len(certInfo['warnings']) > 0:
            logger.info ("%s has warnings, display on screen")
            # pp.pprint (certInfo)
            vDataOut = pprint.pformat( certInfo['warnings'])
            logger.info( vDataOut )
            # Append data to log file
            with open( logFile, 'a') as logOut:
                logOut.write('='*80 + "\n" )
                logOut.write(cluster + " warnings:\n")
                for warn in range(len(certInfo['warnings'])):
                    #logOut.write("   Node   : " + certInfo['warnings'][warn]['node'] + "\n")
                    #logOut.write("   Message: " + certInfo['warnings'][warn]['message'] + "\n")
                    for key in certInfo['warnings'][warn].keys():
                        logOut.write( "   " + key + " :" + certInfo['warnings'][warn][key] + "\n")
                logOut.write('='*80 + "\n")
                logOut.write("\n")
            vWarnings += 1

    # If file was created and appended to, email it to the DBAs
    logger.debug ( "Warnings encountered: " + str( vWarnings ) )
    if vWarnings > 0:
        # List possible solutions
        with open( logFile, 'a') as logOut:
            logOut.write( "\n\n\n")
            logOut.write( "*" * 100 + "\n")
            logOut.write( "Possible solutions:\n")
            logOut.write( "- Download Node Certificates [$HOME/DBA/bin/cert_mgmt/getNodeCerts.py & load_certs.py]\n")
            logOut.write( "- Reload Node Certificates[$HOME/DBA/bin/cert_mgmt/load_certs.sh]\n")

        email_log ("Couchbase Cert Warnings", "Admin Node", vDBAEmail, logFile)

    logger.info ("Done")
    
    return True
# ------------------------------------------------------------------------------------------------------------------------

if __name__ == '__main__':
    #logNamePrefix = 'IndexCerts'
    logNamePrefix = 'clusterCerts'
    #vLogName = init_logger( logNamePrefix, logging.DEBUG )
    vLogName = init_logger( logNamePrefix, logging.INFO )
    logger = logging.getLogger ( __name__ )

    gvArgs = get_args()

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get( 'MON_USER' )
        gvArgs['password'] = os.environ.get( 'MON_PSWD' )
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info  ("Enter %s\'s Password   : " % gvArgs['user'] )

    logger.debug ("Args: " + str(gvArgs) )

    if not verifyAdminConnection ( (gvArgs['user'], gvArgs['password']) ):
        logger.error ("ERROR: Connection using %s failed" % gvArgs['user'] )
        logger.error ("ERROR: Please verify credentials" )
        print ("ERROR: Connection using %s failed" % gvArgs['user'] )
        print ("ERROR: Please verify credentials" )
        print ("ERROR: Check log (%s) for details" % vLogName)
        exit (-1)
    else:
        logger.info ( "Credentials verified" )
    
    logger.info ("***************************************************")

    main( (gvArgs['user'], gvArgs['password']) )
   
    logger.info ("***************************************************") 

exit (0)
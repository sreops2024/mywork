#! /usr/bin/python3

# Author  : Victor Zuniga
# Date    : 2021.05.25
# Purpose : Script to manage Couchbase LDAP user groups based on the cluster buckets
#           Will receive the following parameters
#           --cluster/-c : Cluster Name(s) (comma separated list) for clusters to traverse.
#           --user/-u    : Admin username to use against the clusters.
#           --pass/-p    : password for the user account received.
#           --bucket/-b  : bucket name to report/create group.
#           --debug/-d   : enable debug logging
#           --exec/-e    : execute bucket build if needed.

# History
# Date       Who                  Comments
# ---------- -------------------- -------------------------------------------------------------------------------------
# 2021.05.25 Victor Zuniga        Initial build
# 2022.07.07 Vcitor Zuniga        Trap and handle error when getting cluster version and latency exceeds http timeout.

import os
import sys
import logging
import argparse
import re

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import getClusterNames, getRandomClusterNode
from bbc_cb.cb_api import getClusterBuckets, getRbacGroupDetails, createUserGroup, getClusterMinVersion


# ---------------------------------------------------------------------------------------------------------------------

vMinVersion = '6.6'


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="cbBucketGroups.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
     Script to report/manage the Couchbase bucket groups to authenticate against LDAP.
     ''')
    parser.add_argument('-c', '--cluster', help='Cluster Name',
                        default='None', required=True)
    parser.add_argument('-b', '--bucket', help='Bucket Name',
                        default='all', required=False)
    parser.add_argument(
        '-u', '--user', help='Admin Account to be used', required=True)
    parser.add_argument('-p', '--password',
                        help='Admin Password to be used', required=False)
    parser.add_argument('-e', '--exec', action='store_true',
                        help='Execute Group Creation', required=False)
    parser.add_argument('-d', '--debug', action='store_true',
                        help='Run in DEBUG mode', required=False)

    # parser.add_argument ( '-e', '--env', help = 'Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required = False )
    # parser.add_argument ( '-v', '--verbose', action='store_true',  help = 'Include output to console -- not used', required = False )
    return vars(parser.parse_args())


def bucketGroups(pCluster, pBucket):
    """
    Return the APP and User group names based on the received bucket.
    """
    logger.debug("...bucketGroups")
    logger.debug(" bucket: %s[%s]" % (pCluster, pBucket))
    lGroups = []

    if pCluster[-1] != 'p':
        lGroups.append("APP-%s" % pBucket)
        lGroups.append("USR-%s" % pBucket)
    else:
        lGroups.append("APP-%s" % pBucket)

    logger.debug("Groups: %s" % str(lGroups))

    return lGroups


def prepGroupList(pCluster, pBuckets):
    """
    Returns a list of groups for the received bucket list
    """
    logger.debug("...prepGroupList: %s [%s]" % (pCluster, str(pBuckets)))

    lGroupList = []

    for vBucket in pBuckets:
        lGroupList = lGroupList + bucketGroups(pCluster, vBucket)

    return lGroupList


def genGroupDetails(pCluster, pGroup):
    """
    generate the couchbase group details for the received cluster and group (type-bucket).
    details include name, roles, reference string.
    groups are for user (individuals) and applications.
    """

    logger.debug("in genGroupDetails - %s [%s]" % (pCluster, pGroup))

    vGrpDtls = {}
    vType = pGroup[:3]
    vBkt = pGroup[4:]
    vEnvSuff = pCluster[-1]
    vRoleList = []
    vRoleStr = ""

    # if Prod and user type, then return empty dict - We don't create user groups in Prod.
    if vEnvSuff == 'p' and vType == 'USR':
        logger.warning("WARNING: USR groups in prod are not created")
        return vGrpDtls

    logger.debug("%s Group -> Type: %s Bucket: %s" % (pGroup, vType, vBkt))

    vGrpDtls[pGroup] = {'ROLES': '', 'REFMAP': '', 'DESC': ''}

    if pCluster[-1] == 'i' or pCluster[-1] == 's':
        # INT Cluster
        vENV = 'INT'
        vRoleStr = ""
        vRoleList = ["query_select", "query_update", "query_insert",
                     "query_delete", "data_reader", "data_writer"]
    elif pCluster[-1] == 'q':
        # QA Cluster
        vENV = 'QA'
        if vType == 'APP':
            vRoleList = ["query_select", "query_update", "query_insert",
                         "query_delete", "data_reader", "data_writer"]
        else:
            vRoleList = ["data_reader", "query_select"]
    elif pCluster[-1] == 'p':
        # Prod Cluster
        vENV = 'PROD'
        vRoleList = ["query_select", "query_update", "query_insert",
                     "query_delete", "data_reader", "data_writer"]
    else:
        logger.warning("WARNING: cluster suffix [%s] is invalid.")
        logger.warning("WARNING: Returning an empty dictionary.")
        return {}

    logger.debug("Role List for %s [%s]: %s" % (vType, vENV, vRoleList))

    for vRole in vRoleList:
        vRoleStr += "%s[%s]," % (vRole, vBkt)
        vGrpDtls[pGroup]['ROLES'] = vRoleStr.rstrip(vRoleStr[-1])

    vGrpDtls[pGroup]['REFMAP'] = "CN=CB-%s-%s-%s,OU=%s,OU=Couchbase,OU=Groups,DC=south,DC=bbc,DC=net" % (
        vBkt, vType.lower(), pCluster[-1], vENV)

    vGrpDtls[pGroup]['DESC'] = "Group for %s on %s" % (vType, vBkt)

    logger.debug("Group Details: %s" % str(vGrpDtls))

    return vGrpDtls


def main():
    """
    Main function to handle group reporting and existance for AD authentication in a couchbase cluster
    """
    logger.debug("In main")

    vClusterNames = getClusterNames()

    # Split cluster names (comman separated list)
    for vCluster in re.split(r'[,\s]\s*', gvArgs['cluster'].strip()):
        # print("Cluster: %s" % vCluster)
        logger.info("Cluster: %s" % vCluster)

        if vCluster in vClusterNames:
            # Cluster name is valid
            logger.info("Cluster %s is valid" % vCluster)

            # Determine cluster details (env suffix, AD group name & ref string, roles)
            vClusterSuffix = vCluster[-1]
            logger.debug("Cluster suffix: %s" % vClusterSuffix)

            vNode = getRandomClusterNode(vCluster)
            logger.info("Cluster node: %s" % vNode)
            print("Cluster: %s [%s]" % (vCluster, vNode))

            # Determine if version of cluster supports User Groups (6.5 min)
            vClusterVersion = getClusterMinVersion((gvArgs['user'], gvArgs['password']), vCluster)
            logger.debug("Versions: Cluster: %s - Min Version: %s" % (str(vClusterVersion), str(vMinVersion)))
            
            try:
                if vClusterVersion <= vMinVersion:
                    logger.warning("WARNING: Cluster %s has version %s which does not support user groups. Minimum version: %s" % (
                        vCluster, vClusterVersion, vMinVersion))
                    logger.warning("WARNING: skipping past this cluster")
                    print("   ### Cluster does not support user groups ... skipping")
                    continue
            except:
                logger.warning("Something happened when getting the version from the cluster [%s]" % vCluster)
                logger.warning("This could be a timeout/Netork latency issue")
                print("***\tSomething happened when getting the version from the cluster [%s]" % vCluster)
                print("***\tThis could be a timeout/Netork latency issue")
                print("")
                continue
            

            vBuckets = getClusterBuckets(
                vNode, gvArgs["user"], gvArgs["password"])

            # Limit the buckets by the bucket(s) provided, if any.
            if gvArgs['bucket'] is not 'all':
                vTmpBucket = []
                logger.info("Limit the buckets to %s" % gvArgs['bucket'])
                for item in re.split(r'[,\s]\s*', gvArgs['bucket'].strip()):
                    if item in vBuckets:
                        logger.info("%s is a valid bucket in the %s" %
                                    (item, vCluster))
                        vTmpBucket.append(item)
                    else:
                        logger.info(
                            "%s is a NOT valid bucket in the %s" % (item, vCluster))
                        print("    * Invalid bucket: %s" % item)

                if len(vTmpBucket) < 1:
                    print("    Valid buckets: %s" % vBuckets)
                vBuckets = vTmpBucket

            if len(vBuckets) < 1:
                logger.warning("No valid buckets provided")
                continue

            logger.debug("Buckets: %s" % str(vBuckets))
            print("   buckets: %s" % str(vBuckets))

            for lGroup in prepGroupList(vCluster, vBuckets):
                vGrpInfo = getRbacGroupDetails(
                    (gvArgs['user'], gvArgs['password']), vNode, lGroup)

                if "bbc_err_code" in vGrpInfo.keys():
                    print("%10s %-20s [%s]" % ('-', lGroup, "missing group"))
                    vGroupDetails = genGroupDetails(vCluster, lGroup)

                    if vGroupDetails != {}:
                        for vKey in vGroupDetails[lGroup].keys():
                            print("%15s %-10s : %s" %
                                  ('~', vKey, str(vGroupDetails[lGroup][vKey])))

                        # if -e parameter passed (exec) add the group to the cluster
                        if gvArgs['exec']:
                            logger.warning(
                                "WARNING: Creating the user group %s" % lGroup)
                            print("%15s Create the user group %s" %
                                  ("***", lGroup))
                            vRetDict = createUserGroup(
                                (gvArgs['user'], gvArgs['password']), vNode, vGroupDetails)

                            for item in vRetDict.keys():
                                logger.info("Group %s: %s" %
                                            (item, vRetDict[item]))
                                print("%15s Group %s: %s" %
                                      ("*", item, vRetDict[item]))

                    print("")
                else:
                    print("%10s %-20s [%s]" % ('-', lGroup, "OK"))

        else:
            # Cluster name is invalid, skip it
            logger.warning("Cluster %s is invalid... skipping" % vCluster)
            print("... invalid cluster, skipping\n")

    # Get bucket names
    # Construct bucket group names

    return True

# ---------------------------------------------------------------------------------------------------------------------


if __name__ == '__main__':
    logger = logging.getLogger(__name__)
    logNamePrefix = 'bucketADGroups'
    gvArgs = get_args()

    if gvArgs['password'] == None or gvArgs['password'] == '':
        gvArgs['password'] = get_user_info(
            "Enter %s\'s Password   : " % gvArgs['user'])

    if gvArgs['debug'] == True:
        vLogName = init_logger(logNamePrefix, logging.DEBUG)
    else:
        vLogName = init_logger(logNamePrefix, logging.INFO)

    # print("Args: %s" % str(gvArgs))
    # logger.info("Args: %s" % str(gvArgs))
    # logger.debug("test debug msg")
    # logger.warning("Teest warning msg")
    # logger.error("Test error msg")
    # print("Log Name: %s" % str(vLogName))

    main()

exit(0)

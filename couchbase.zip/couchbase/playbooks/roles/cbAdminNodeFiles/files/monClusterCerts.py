#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2021.08.23
# Purpose : This script will monitor the certificate status for each node in the cluster.
#           Accept user inputs, clusters, env, etc.

import sys
import os
import json
import argparse
import requests
import logging

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import getClusterNames
from bbc_cb.cb_api import verifyAdminConnection
from bbc_cb.env_detail import CBENV
from bbc_cb.cb_monitor import monClusterCerts

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="monClusterCerts.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Script verify status of all or one Couchbase Cluster.
      ''')
    parser.add_argument(
        '-u', '--user', help='Admin Account to be used', required=False)
    parser.add_argument('-c', '--cluster', help='Cluster Name', default='all', required=False)
    #parser.add_argument('-b', '--bucket', help='Bucket Name', default='all', required=False)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-e', '--env', help='Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required=False)
    parser.add_argument('-d', '--debug', action='store_true', help='Run in DEBUG mode', required=False)

    return vars(parser.parse_args())


def main( gvArgs, pSNOW="TEST"):
    #print("Main function")
    logger.info("Monitor Cluster Certs Main - Service Now: %s" % pSNOW) 
    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    if (gvArgs['cluster'] == 'all' and gvArgs['env'] == 'iqp' ):
        # Traverse the CBENV and list all clusters
        for e in CBENV.keys():
            #print ("=====================================================================================================================\n")
            for vClstr in sorted(CBENV[e].keys()):
                #print (vClstr)
                vRC = monClusterCerts(vClstr, (gvArgs['user'], gvArgs['password']), pSNOW )
    elif (gvArgs['cluster'] == 'all' and  gvArgs['env'] != 'iqp' ):
        # traverse received environments
        for e in (list(gvArgs['env'])):
            if e in CBENV.keys():
                #print ("=====================================================================================================================\n")
                for vClstr in sorted(CBENV[e].keys()):
                    #print (vClstr)
                    vRC = monClusterCerts(vClstr, (gvArgs['user'], gvArgs['password']), pSNOW )
    elif (gvArgs['cluster'] != 'all'):
        # Allow for multiple clusters to be passed at once
        #print( "=====================================================================================================================\n")
        vClusterList = gvArgs['cluster'].replace(" ", ",").split(",")
        logger.info("Cluster List: %s" % str(vClusterList))
        for vClstr in vClusterList:
            #if gvArgs['cluster'] not in getClusterNames():
            if vClstr not in getClusterNames():
                #print ("ERROR: cluster %s does not exist." % (vClstr))
                logger.error("ERROR: cluster %s does not exist." % (vClstr))
            else:
                #print (vClstr)
                vRC = monClusterCerts(vClstr, (gvArgs['user'], gvArgs['password']), pSNOW )

    if vRC == True:
        logging.info("Cluster(s) Certs successfully checked")
    else:
        logging.warning("Issues found while checking Couchbase Cluster certs")
        return False
        
    return True


# ------------------------------------------------------------------------------------------------------------------------


if __name__ == "__main__":

    gvArgs = get_args()

    logNamePrefix = 'monClusterCerts'
    if gvArgs['debug']:
        vLogName = init_logger(logNamePrefix, logging.DEBUG)
        vSNOW = 'TEST'
    else:
        vLogName = init_logger(logNamePrefix, logging.INFO)
        vSNOW = 'PROD'


    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info(
                "Enter %s\'s Password   : " % gvArgs['user'])

    logger.debug("Args: " + str(gvArgs))

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password'])):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        print("ERROR: Connection using %s failed" % gvArgs['user'])
        print("ERROR: Please verify credentials")
        print("ERROR: Check log (%s) for details" % vLogName)
        exit(-1)
    else:
        logger.info("Credentials verified")
        #print("Credentials verified")

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    if gvArgs['debug']:
        for k in gvArgs.keys():
            if k == 'password':
                print ("%15s: %s" % (k, gvArgs[k].replace(gvArgs['password'], '*'*len(gvArgs['password']))  ) )
                logger.debug ("%15s: %s" % (k, gvArgs[k].replace(gvArgs['password'], '*'*len(gvArgs['password']))  ) )
            else:
                print ("%15s: %s" % (k, gvArgs[k]))
                logger.debug ("%15s: %s" % (k, gvArgs[k]))

    if main( gvArgs, vSNOW):
        exit(0)
    else:
        exit (-1)
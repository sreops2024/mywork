#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2021.06.04
# Purpose : This script will list all buckets (or a subset) and the clusters where the bucket exists.
#           Accept user inputs - buckets

import sys
import os
import argparse
import logging

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.cb_api import getAllClustBuckets, getBucketClustDict
from bbc_cb.cb_api import verifyAdminConnection

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="bucketCluster.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Script to list bucket and the clusters where it exists.
      ''')
    parser.add_argument(
        '-u', '--user', help='Admin Account to be used', required=False)
    #parser.add_argument('-c', '--cluster', help='Cluster Name', default='all', required=False)
    parser.add_argument('-b', '--bucket', help='Bucket Name', default='all', required=False)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    #parser.add_argument('-e', '--env', help='Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required=False)
    parser.add_argument('-d', '--debug', action='store_true', help='Run in DEBUG mode', required=False)

    return vars(parser.parse_args())


def main( gvArgs):
    logger.debug("Main function")
    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    # Get all clusters and buckets info
    vdClusterBuckets = getAllClustBuckets( gvArgs['user'], gvArgs['password'] )
    logger.debug("Cluster Buckets: %s" % str(vdClusterBuckets))
    #vdBucketClusters = getBucketClustDict( getAllClustBuckets( gvArgs['user'], gvArgs['password'] ))
    vdBucketClusters = getBucketClustDict( vdClusterBuckets )
    
    logger.debug("Bucket Clusters: %s" % str(vdBucketClusters))
    logger.debug("Bucket param: %s" % gvArgs['bucket'])
    print( "=====================================================================================================================\n")
    print ("Bucket Cluster List:")
    if gvArgs['bucket'] == 'all':
        # Traverse the CBENV and list all clusters
        vBucketList = list(vdBucketClusters.keys())
        logger.info("Bucket List: %s" % str(vBucketList))
    else:
        # Allow for multiple buckets to be passed at once
        vBucketList = (gvArgs['bucket'].replace(" ", ",").split(","))
        logger.info("Bucket List: %s" % str(vBucketList))

    vBucketList.sort()
    #print ("Buckets to list: %s" % str(vBucketList))

    for vBkt in vBucketList:
        vTmpBkt = (vBkt+" " + '.'*15)[:20]
        #print ("   %-18s %s" % (vTmpBkt, ', '.join(vdBucketClusters[vBkt]) ))
        #vTmpBkt = "   %-18s %s" % vTmpBkt
        print (("   %-18s" % vTmpBkt), end=' ')
        
        try:
            vClstrList = ''
            for vClstr in vdBucketClusters[vBkt]:
                #vClstrList = vClstrList + ((vClstr +',' + ' '*5)[:11])
                vClstrList += (vClstr +',' + ' '*5)[:11]
                #print( ("%-10s" % vClstr), end=',')
            print (vClstrList.rstrip()[:-1])
        except:
            print("No cluster found")

    print( "\n=====================================================================================================================\n")
    return True


# ------------------------------------------------------------------------------------------------------------------------


if __name__ == "__main__":

    gvArgs = get_args()

    logNamePrefix = 'bucketCluster'
    if gvArgs['debug']:
        vLogName = init_logger(logNamePrefix, logging.DEBUG)
    else:
        vLogName = init_logger(logNamePrefix, logging.INFO)
    
    logger.info("starting")

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info(
                "Enter %s\'s Password   : " % gvArgs['user'])

    logger.debug("Args: " + str(gvArgs))

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password'])):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        print("ERROR: Connection using %s failed" % gvArgs['user'])
        print("ERROR: Please verify credentials")
        print("ERROR: Check log (%s) for details" % vLogName)
        exit(-1)
    else:
        logger.info("Credentials verified")
        #print("Credentials verified")

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    if gvArgs['debug']:
        for k in gvArgs.keys():
            if k == 'password':
                print ("%15s: %s" % (k, gvArgs[k].replace(gvArgs['password'], '*'*len(gvArgs['password']))  ) )
            else:
                print ("%15s: %s" % (k, gvArgs[k]))

    if main( gvArgs):
        logger.info ("completed successfully")
    else:
        logger.warning ("completed unsuccessfully")

exit(0)
#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2019.09.13
# Purpose : Script to display user accounts in the cluster
#
# History
# Date        Name                  Description
# ----------  --------------------  -----------------------------------------------------------------------------------
# 2023.05.03  Victor Zuniga         Add group information to the script output.
# ---------------------------------------------------------------------------------------------------------------------

import argparse
import re

from bbc_cb.cb_api import verifyAdminConnection, getClusterUserList
from bbc_cb.env_config import *
from bbc_sec.get_creds import get_user_info


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="userList.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description=
                                     '''
                                     Script verify status of all or one Couchbase Cluster.
                                     ''')
    parser.add_argument('-u', '--user', help='Admin Account to be used', required=False)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-c', '--cluster', help='Cluster Name', default='all', required=True)
    parser.add_argument('-a', '--account', help='Account Name', default=None, required=False)
    parser.add_argument('-f', '--filter', help='String to match in account name', default=None, required=False)
    parser.add_argument('-d', '--domain', help='External or local', default=None, required=False)

    return vars(parser.parse_args())


def printUserList(pUserList, pFilter = '(.)', pAccount = None):
    """
    Print the users in the list or the subset based on the filter.
    """
    logger.info("Printing user list")
    logger.info("Filter: " + str(pFilter))
    logger.info("Account: " + str(pAccount))

    logger.info("Converting list to dictionary for easier searching of individual accounts")

    ldUsers = { pUserList[i]['id']: pUserList[i] for i in range(len(pUserList))}

    if pFilter == None:
        pFilter = r'(.)'
        
    if pAccount is not None:
        logger.info("Looking for account: %s" % pAccount )
        try:
            vUser = ldUsers[pAccount]
            logger.info ("User Info: %s " % str(vUser) )
            print("id   : {}  [{}] ".format(vUser['id'], vUser['domain']))
            print("name : {}".format(vUser['name']))
            
            if vUser['external_groups'] == []:
                print("  groups: {}".format(vUser['groups']))
            else:
                print("  groups: {}".format(vUser['external_groups']))

            for i in range(len(vUser['roles'])):
                if 'bucket_name' in vUser['roles'][i].keys():
                    #print("    {} : {} ".format(vUser['roles'][i]['bucket_name'], vUser['roles'][i]['role']))
                    if 'name' in vUser['roles'][i]['origins'][0].keys():
                        print("    {} : {} [{}]".format(vUser['roles'][i]['bucket_name'], vUser['roles'][i]['role'], vUser['roles'][i]['origins'][0]['name'] ))
                    else:
                        print("    {} : {} []".format(vUser['roles'][i]['bucket_name'], vUser['roles'][i]['role'] ))
                else:
                    print("    {}".format(vUser['roles'][i]['role']))
            print("")
        except:
            logger.debug("User Acct %s does not exist " % pAccount)
            print ("Acount " + pAccount + " does not exist")

    else:
        for vUsr in sorted(ldUsers.keys()):

            vUser = ldUsers[vUsr]

            vDisplay = re.search( pFilter, vUser['id'], re.M|re.I)

            if vDisplay:
                print("id   : {}  [{}] ".format(vUser['id'], vUser['domain']))
                print("name : {}".format(vUser['name']))
                
                if vUser['external_groups'] == []:
                    print("  groups: {}".format(vUser['groups']))
                else:
                    print("  groups: {}".format(vUser['external_groups']))

                for i in range(len(vUser['roles'])):
                    if 'bucket_name' in vUser['roles'][i].keys():
                        if 'name' in vUser['roles'][i]['origins'][0].keys():
                            print("    {} : {} [{}]".format(vUser['roles'][i]['bucket_name'], vUser['roles'][i]['role'], vUser['roles'][i]['origins'][0]['name'] ))
                        else:
                            print("    {} : {} []".format(vUser['roles'][i]['bucket_name'], vUser['roles'][i]['role'] ))
                    else:
                        print("    {}".format(vUser['roles'][i]['role']))
                print("")
            else:
                logger.debug ("User Acct: %s does not match fileter %s" % (vUser['id'], pFilter))

    logger.info("Printing Complete")
    return True


def main():
    """Main code function"""
    logNamePrefix = 'userList'

    # vLogName = init_logger(logNamePrefix, logging.DEBUG)
    vLogName = init_logger(logNamePrefix, logging.INFO)

    gvArgs = get_args()

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info("Enter %s\'s Password   : " % gvArgs['user'])

    if (gvArgs['domain'] != None):
        if (gvArgs['domain'].lower() not in ['local', 'external']):
            errMsg = "ERROR: Invalid domain value [%s]" % gvArgs['domain']
            logger.error(errMsg)
            print(errMsg)
            exit(-1)
    else:
        gvArgs['domain'] = 'All'

    logger.debug("Args: " + str(gvArgs))

    if not gvArgs['cluster'] in getClusterNames():
        errMsg = "ERROR: Cluster name [%s] is not valid. Please verify it." % gvArgs['cluster']
        logger.error(errMsg)
        print(errMsg)
        exit(-1)

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password']), gvArgs['cluster']):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        print("ERROR: Connection using %s failed" % gvArgs['user'])
        print("ERROR: Please verify credentials")
        print("ERROR: Check log (%s) for details" % vLogName)
        exit(-1)
    else:
        logger.info("Credentials verified")
        # print("Credentials verified")
        logger.info("Getting user listing from cluster %s - domain %s - filter %s" % (
        gvArgs['cluster'], gvArgs['domain'], gvArgs['filter']))

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    lNode = getRandomClusterNode(gvArgs['cluster'])
    logger.info("Using node: %s" % lNode)

    # print("Domain: " + gvArgs['domain'])
    userList = getClusterUserList(lvAuthCreds, lNode, 8091, gvArgs['domain'])

    print("")
    printUserList(userList, gvArgs['filter'], gvArgs['account'])
    print("")
    print("done")


if __name__ == '__main__':
    main()

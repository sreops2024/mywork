#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2019.09.13
# Purpose : Script to create index metric statistics file
#
# 2021.11.16 Victor Zuniga      Fixed bug caused by new cluster/node classes.
# 2023.03.01 Victor Zuniga      Added logic to handle scope and collections introduced in CB v7.0


import sys
import os
import json
import argparse
import requests
import csv
import time

from datetime import datetime

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import *
from bbc_cb.cb_api import verifyAdminConnection, getEndpoint
from bbc_cb.cb_cluster import cCluster

import pprint
# ------------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="getIndexStats.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Script to get index statistics
      ''')
    parser.add_argument(
        '-u', '--user', help='Admin Account to be used', required=False)
    #parser.add_argument ( '-c', '--cluster', help = 'Cluster Name', default='all', required = False )
    parser.add_argument('-p', '--password',
                        help='Admin Password to be used', required=False)
    #parser.add_argument ( '-e', '--env', help = 'Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required = False )
    #parser.add_argument ( '-d', '--debug', action='store_true',  help = 'Run in DEBUG mode', required = False )
    #parser.add_argument ( '-v', '--verbose', action='store_true',  help = 'Include output to console -- not used', required = False )
    return vars(parser.parse_args())

# ------------------------------------------------------------------------------------------------------------------------


def getEndpointTLS(pAuth, pURL):
    """Return JSON format from received endpoint"""
    logger.info("getEndpoint")
    logger.info("URL: " + pURL)
    logger.debug(
        ("auth: " + str(pAuth)).replace(pAuth[1], '*' * len(pAuth[1])))

    try:
        r = requests.get(pURL, auth=(
            pAuth[0], pAuth[1]), verify='/etc/pki/tls/certs/ca-bundle.crt')

        if r.status_code != 200:
            logger.error("ERROR: Could not retrieve data from " + pURL)
            logger.error("ERROR: status_code: " + str(r.status_code))
            return {"bbc_err_code": r.status_code}
        else:
            logger.debug("r.json: %s" % r.json())
            return r.json()

    except:
        logger.error("ERROR: Could not retrieve data from " + pURL)
        logger.error("ERROR: bbc_err_code: " + '0001')
        return {"bbc_err_code": "0001"}


def getIndexStats(pNode, pAuth):
    """Return the index stats from the node received"""
    logger.debug("getIndexStats: " + pNode)

    vURL = "https://" + pNode + ":19102/api/v1/stats?pretty=false"
    #vURL = "http://" + pNode + ":9102/api/v1/stats?pretty=false"
    logger.debug("vURL: " + vURL)
    
    r = getEndpointTLS(pAuth, vURL)
    #r = getEndpoint(pAuth, vURL)

    lvNodeDict = {}
    # Format stats dict/json by Node, bucket, index
    if "bbc_err_code" not in r.keys():
        logger.info("Successfully retrieved node index stats")

        lvPrevBkt = ''
        for lvBktIdx in sorted(r.keys()):
            logger.debug("Bucket:Index : " + lvBktIdx)
            if lvBktIdx == 'indexer':
                logger.info("Indexex Stats: ")
                logger.info(str(r[lvBktIdx]))
            else:
                if lvBktIdx.count(":") == 1:
                    # No scope/collection provided
                    lvBkt, lvIdx = lvBktIdx.split(":")
                    lvScope, lvColl = '_default', '_default'
                else:
                    # Scope/collection provided
                    lvBkt, lvScope, lvColl, lvIdx = lvBktIdx.split(":")

                logger.debug( "Bucket: " + lvBkt + " ~ [Prev Bkt: " + lvPrevBkt + "]" )
                logger.debug( "Index : " + lvIdx )
                logger.debug( "Scope : " + lvScope )
                logger.debug( "Coll  : " + lvColl )

                logger.debug( "PrevBkt: " + lvPrevBkt )
                logger.debug( "Bkt    : " + lvBkt )
                if lvPrevBkt != lvBkt:
                    lvNodeDict[lvBkt] = {}
                
                if lvScope not in lvNodeDict[lvBkt].keys():
                    lvNodeDict[lvBkt][lvScope] = {}

                if lvColl not in lvNodeDict[lvBkt][lvScope].keys():
                    lvNodeDict[lvBkt][lvScope][lvColl] = {}
                    
                logger.debug( "[" + pNode + "] Bucket Keys: " + str(lvNodeDict.keys()) )
                #lvNodeDict[lvBkt][lvIdx] = r[lvBktIdx]
                lvNodeDict[lvBkt][lvScope][lvColl][lvIdx] = r[lvBktIdx]

                #vMetricCount = len(lvNodeDict[lvBkt][lvIdx])
                vMetricCount = len(lvNodeDict[lvBkt][lvScope][lvColl][lvIdx])
                logger.debug("metrics count: " + str(vMetricCount))
                if vMetricCount != 28:
                    logger.debug("add missing metrics")
                    #lvNodeDict[lvBkt][lvIdx]['avg_array_length'] = ''
                    #lvNodeDict[lvBkt][lvIdx]['docid_count'] = ''
                    lvNodeDict[lvBkt][lvScope][lvColl][lvIdx]['avg_array_length'] = ''
                    lvNodeDict[lvBkt][lvScope][lvColl][lvIdx]['docid_count'] = ''
                lvPrevBkt = lvBkt

        logger.debug("Node Index Data:")
        logger.debug(str(lvNodeDict))
        return lvNodeDict

    else:
        logger.warning(
            "WARNING: Could not get node {" + pNode + "] index stats")
        #return r
        return lvNodeDict


def createIdxDataFile(pIdxDataFile):
    """
    Create the index metric data file for all clusters
    """

    pp = pprint.PrettyPrinter(indent=4)
    logger.debug("createIdxDataFile: " + pIdxDataFile)

    vClusterList = getClusterNames()
    logger.debug("Cluster List: %s" % str(vClusterList))

    vData = {}

    logger.debug("Cluster Names: " + str(vClusterList))

    # Traverse the Clusters
    for lvName in vClusterList:
        logger.info("Processing Cluster: " + lvName)
        vCluster = cCluster(lvName, gvAuthCreds)
        vData[lvName] = {}

        # Traverse the nodes in the cluster
        for lvNode in vCluster.clusterInfo['nodes'].keys():
            if 'index' in vCluster.clusterInfo['nodes'][lvNode].nodeInfo['services']:
                logger.info("Index Node: " + lvNode)
                vData[lvName][lvNode] = {}

                # Get index stats for this node
                vTmpStats = getIndexStats(lvNode, gvAuthCreds)
                vData[lvName][lvNode] = vTmpStats

    # Traverse the data dictionary and save as CSV

    #hdr1 = ['Cluster', 'Node', 'Bucket', 'Index']
    hdr1 = ['Cluster', 'Node', 'Bucket', 'Scope', 'Collection', 'Index']
    metricsHdr = ['avg_array_length', 'avg_drain_rate', 'avg_item_size', 'avg_scan_latency', 'cache_hit_percent',
                  'cache_hits', 'cache_misses', 'data_size', 'disk_size', 'docid_count', 'frag_percent',
                  'initial_build_progress', 'items_count', 'last_known_scan_time', 'memory_used','num_docs_indexed', 'num_docs_pending',
                  'num_docs_queued', 'num_items_flushed', 'num_pending_requests', 'num_requests', 'num_rows_returned',
                  'num_scan_errors', 'num_scan_timeouts', 'recs_in_mem', 'recs_on_disk', 'resident_percent',
                  'scan_bytes_read', 'total_scan_duration']

    hdr = hdr1 + metricsHdr

    row = []

    # try:
    with open(pIdxDataFile, 'w') as dataFile:
        # write Headers
        dataFile.write(','.join(hdr) + "\n")
        logger.debug("File [ " + pIdxDataFile + "] opened for CSV data")
        # Clusters
        for cluster in vData.keys():
            logger.debug("Processing cluster: " + cluster)
            #dataFile.write( cluster + ", \n")
            # Traverse nodes
            for node in vData[cluster].keys():
                logger.debug(".. processing node: " + node)
                #dataFile.write( node + ", " )
                # Traverse buckets
                for bucket in vData[cluster][node].keys():
                    logger.debug(".... processing bucket: " + bucket)
                    #dataFile.write( bucket + ", " )

                    #Traverse Scope and Collections
                    for scope in vData[cluster][node][bucket].keys():
                        logger.debug( "....... Processing scope: %s" % scope)

                        for collection in vData[cluster][node][bucket][scope].keys():
                            logger.debug( "........ Processing collection: %s" % collection )

                            # Traverse indexes
                            #for index in vData[cluster][node][bucket].keys():
                            for index in vData[cluster][node][bucket][scope][collection].keys():
                                logger.debug("...... Processing index: " + index)
                                ##dataFile.write (index + ", \n" )

                                # Traverse mertrics for each index
                                #row = [cluster, node, bucket, index]
                                row = [cluster, node, bucket, scope, collection, index]
                                for metric in sorted(metricsHdr):
                                    if metric == 'last_known_scan_time':
                                        # Translate nanoseconds to date string
                                        #if vData[cluster][node][bucket][index][metric] == 0:
                                        if vData[cluster][node][bucket][scope][collection][index][metric] == 0:
                                            row.append('0')
                                        else:
                                            #dt = datetime.fromtimestamp( vData[cluster][node][bucket][index][metric] // 1000000000 )
                                            dt = datetime.fromtimestamp( vData[cluster][node][bucket][scope][collection][index][metric] // 1000000000 )
                                            row.append(dt.strftime( '%Y.%m.%d %H:%M:%S') )
                                    else:
                                        #row.append( str(vData[cluster][node][bucket][index][metric]) )
                                        row.append( str(vData[cluster][node][bucket][scope][collection][index][metric]) )

                                # Save row
                                #print ( ', '.join(row) + "\n" )
                                dataFile.write(','.join(row) + "\n")

    # except:
    ###   logger.error( "ERROR: Could not write csv file : " + pIdxDataFile )

    # return False

    # Save data to file
    # try:
    #   with open ( pIdxDataFile, 'w' ) as dataFile:
    #      json.dump (vData, dataFile)
    # except:
    #   logger.error ("ERROR: writing json to file " + str(pIdxDataFile) )
    #   return False
    # dataFile.close()

    return True


def getIdxMetrics():
    """
    Return name of file containing index metrics data
    File is dated on a daily basis.  If the file is not available, a new one will be created.
    """

    lLogDir = os.environ['LOG_DIR']
    logger.debug("getIdxMetric : log dir: " + lLogDir)

    lDTSuf = time.strftime("%Y%m%d")
    lIdxMetricsFile = lLogDir + "/clstrIdxMetrics." + lDTSuf + '.csv'

    # If file exists, return its name
    if os.path.exists(lIdxMetricsFile):
        logger.info("File " + lIdxMetricsFile + " found.")
        return lIdxMetricsFile
    logger.info("File " + lIdxMetricsFile + " not found. Create it.")

    if createIdxDataFile(lIdxMetricsFile):
        logger.info(lIdxMetricsFile + " file created successfully")
        return lIdxMetricsFile
    else:
        logger.error("ERROR: Could not create file: " + lIdxMetricsFile)
        return False


def main():

    gvArgs = get_args()

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info(
                "Enter %s\'s Password   : " % gvArgs['user'])

    logger.debug("Args: " + str(gvArgs))

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password'])):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        print("ERROR: Connection using %s failed" % gvArgs['user'])
        print("ERROR: Please verify credentials")
        print("ERROR: Check log (%s) for details" % vLogName)
        exit(-1)
    else:
        logger.info("Credentials verified")
        #print ( "Credentials verified" )

    global gvAuthCreds
    gvAuthCreds = (gvArgs['user'], gvArgs['password'])

    # Get All stats & save to daily file.
    vMetricsFile = getIdxMetrics()
    #print ("Index Metrics Data File: " + vMetricsFile )

    return True


if __name__ == '__main__':
    logNamePrefix = 'idxStatsDataFileCreate.csv'

    vLogName = init_logger( logNamePrefix, logging.DEBUG )
    #vLogName = init_logger(logNamePrefix, logging.INFO)
    logger = logging.getLogger(__name__)

    logger.info("***************************************************")

    main()

    logger.info("***************************************************")
    #print ("Done")

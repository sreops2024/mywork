#!/usr/bin/bash



function usage {
   echo "$0 [options]"
   echo "   options:"
   echo "     -c=<s>               The cluster name(s) the the SRV in question.  [REQUIRED]  (Comma separated, no spaces)"

   exit

}

if [ $# -lt 1 ]; then
    usage
fi

# parse any cli arguments
while [ $# -gt 0 ]; do
  case "$1" in
    -c=*)
      CLSTRS="${1#*=}"
      ;;
    *)
      printf "* Error: Invalid argument.*\n"
      usage
      exit 1
  esac
  shift
done


IFS=', ' read -r -a arCLSTRS <<< "${CLSTRS}"


for vCLSTR in "${arCLSTRS[@]}"
do
    echo "Cluster: ${vCLSTR}"
    echo "nslookup -type=any _couchbases._tcp.${vCLSTR}.south.edu"
    nslookup -type=any _couchbases._tcp.${vCLSTR}.south.edu
    echo ""
    echo ""

done

echo ""
echo "Done"
echo ""

#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2019.09.13
# Purpose : Script to display basic cluster information across the QVC Couchbase environment

import sys
import os
import json
import argparse
import requests
import logging

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import *
from bbc_cb.cb_api import verifyAdminConnection, getClusterBuckets, getBucketIndexStats
from prettytable import PrettyTable

def get_args() :
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser ( prog = "idxStats.py",
                                       formatter_class=argparse.RawDescriptionHelpFormatter,
                                       description=
                                       '''
                                       Script verify status of all or one Couchbase Cluster.
                                       ''' )
    parser.add_argument ( '-u', '--user', help = 'Admin Account to be used', required = False )
    parser.add_argument ( '-c', '--cluster', help = 'Cluster Name', default='all', required = True )
    parser.add_argument ( '-p', '--password', help = 'Admin Password to be used', required = False )
    parser.add_argument ( '-b', '--bucket', help = 'Bucket Name', default = None, required = False )
    return  vars(parser.parse_args() )

def avg ( pList ):
    logger.debug ( str(pList) )
    return sum( pList ) / len ( pList )

def getIdxStatsLastReading( idxStats ):
    '''Return a dictionary with the last entry for each index stat.'''

    logger.debug ("getIdxStatsLastReading")
    idx = ''
    dIndex = {}

    for item in sorted( idxStats.keys() ):
        # Capture only the stats for indexes -- some stats are not assiciated to any index, ignore those.
        # The stats have the key format index/<index name>/<metric>:[array with values]
        logger.debug( "Metric: " + item )
        if len( item.split('/') ) == 3:
            (dummy, idxName, metric) = item.split('/')

            if idxName != idx:
                logger.debug("IdxName: " + idxName)
                dIndex[idxName] = {}

            idx = idxName
            x = len(idxStats[item]) - 1
            dIndex[idxName][metric] = idxStats[item][ x ]

            logger.debug("Metric: %s [%d] " % (metric, dIndex[idxName][metric]))

    return dIndex

def getIdxStatsAvg(idxStats):
    '''Return a dictionary with the average for each index stat.'''

    logger.debug("getIdxStatsAvg")
    idx = ''
    dIndex = {}

    for item in sorted(idxStats.keys()):
        # Capture only the stats for indexes -- some stats are not assiciated to any index, ignore those.
        # The stats have the key format index/<index name>/<metric>:[array with values]
        logger.debug("Metric: " + item)
        if len(item.split('/')) == 3:
            (dummy, idxName, metric) = item.split('/')

            if idxName != idx:
                logger.debug("IdxName: " + idxName)
                dIndex[idxName] = {}

            idx = idxName
            dIndex[idxName][metric] = avg(idxStats[item])

            logger.debug("Metric: %s [%d] " % (metric, dIndex[idxName][metric]))

    return dIndex



# ------------------------------------------------------------------------------------------------------------------------

logNamePrefix = 'idxStats'

#LogName = init_logger( logNamePrefix, logging.DEBUG )
vLogName = init_logger( logNamePrefix, logging.INFO )

gvArgs = get_args()

if gvArgs['user'] == None or gvArgs['user'] == '':
    gvArgs['user'] = os.environ.get( 'MON_USER' )
    gvArgs['password'] = os.environ.get( 'MON_PSWD' )
else:
    if gvArgs['password'] == None or gvArgs['password'] == '':
        gvArgs['password'] = get_user_info  ("Enter %s\'s Password   : " % gvArgs['user'] )

logger.debug ("Args: " + str(gvArgs) )

if not gvArgs['cluster'] in getClusterNames():
    errMsg = "ERROR: Cluster name [%s] is not valid. Please verify it." % gvArgs['cluster']
    logger.error( errMsg )
    print (errMsg)
    exit(-1)

if not verifyAdminConnection ( (gvArgs['user'], gvArgs['password']), gvArgs['cluster'] ):
    logger.error ("ERROR: Connection using %s failed" % gvArgs['user'] )
    logger.error ("ERROR: Please verify credentials" )
    print ("ERROR: Connection using %s failed" % gvArgs['user'] )
    print ("ERROR: Please verify credentials" )
    print ("ERROR: Check log (%s) for details" % vLogName)
    exit (-1)
else:
    logger.info ( "Credentials verified" )
    print ( "Credentials verified" )

lvAuthCreds = (gvArgs['user'], gvArgs['password'])

node = getRandomClusterNode ( gvArgs['cluster'] )
buckets = getClusterBuckets (node, lvAuthCreds[0], lvAuthCreds[1] )

if (gvArgs['bucket' ] != None ) and ( gvArgs['bucket'] not in buckets ):
    # A bucket name was provided, and not in the list
    logger.error ( "ERROR: provied bucket name not in the bucket list" )
    logger.error ( "ERROR: bucket name: " + gvArgs['bucket'] )
    print ("ERROR: provied bucket name not in the bucket list")
    print ("ERROR: bucket name: " + gvArgs['bucket'])
    exit (-1)
else:
    print ("Cluster: " + gvArgs['cluster'])
    print ("bucket:  " + str(gvArgs['bucket']))

    logger.info("Cluster: " + gvArgs['cluster'])
    logger.info("Node: " + node)
    logger.info("Buckets: " + str(buckets))
    logger.info("bucket:  " + str(gvArgs['bucket']))

    if gvArgs['bucket'] in buckets:
        rawStats = getBucketIndexStats( lvAuthCreds, node, gvArgs['bucket'] )
        dIdxStats = getIdxStatsAvg(rawStats['samples'])
        #dIdxStats = getIdxStatsLastReading(rawStats['samples'])
    else:
        errMsg = "ERROR: Bucket %s does not exist in cluster %s" % (gvArgs['bucket'], gvArgs['cluster'])
        logger.error( errMsg )
        print (errMsg)
        exit (-1)

    # Prepare table
    logger.debug ("Prepare table")

    if len(dIdxStats) != 0:
        lMetrics = list(dIdxStats[list(dIdxStats.keys())[0]].keys())
        tHdr = ['Index'] + lMetrics

        # Cleanup column headers
        for x in range(len(tHdr)):
            logger.debug("Header : " + tHdr[x])
            tHdr[x] = tHdr[x].replace('index_resident_percent', 'resident_percent')
            tHdr[x] = tHdr[x].replace('index_frag_percent', 'ind_frag_percent')
            tHdr[x] = tHdr[x].replace('percent','%')
            tHdr[x] = tHdr[x].replace('_', ' ').capitalize()
            logger.debug("... now: " + tHdr[x])

        logger.debug ("Metrics: " + str(lMetrics) )
        logger.debug ("Tab Hdr: " + str(tHdr) )

        t1 = PrettyTable(tHdr)

        #for x in lMetrics:
        #    t1.align[x] = 'r'
        for x in tHdr:
            if x == 'Index':
                t1.align[x] = 'l'
            else:
                t1.align[x] = 'r'

        # Parse the sorted indices
        for i in sorted(dIdxStats.keys()):
            row = []
            row.append(i)

            #Add the metrics to the index dictionary
            for m in lMetrics:
                if str( type( dIdxStats[i][m] ) ) == "<class 'float'>":
                    row.append("{0:,.2f}".format(dIdxStats[i][m]))
                elif str( type( dIdxStats[i][m] ) ) == "<class 'int'>":
                    row.append("{0:6,}".format(dIdxStats[i][m]))
                else:
                    row.append(dIdxStats[i][m])
            t1.add_row(row)

        #print(t1.get_string(
        #    fields=["Index", 'cache_hits', 'cache_misses', 'items_count', 'index_resident_percent','index_frag_percent']))
        print(t1.get_string(
            fields = ["Index", 'Cache hits', 'Cache misses', 'Items count', 'Resident %', 'Ind frag %']))
    else:
        errMsg = "Warning: the bucket %s[%s] does not have any indices" % ( gvArgs['cluster'], gvArgs['bucket'])
        logger.warning(errMsg)
        print (errMsg)

print ("Done")
exit (0)

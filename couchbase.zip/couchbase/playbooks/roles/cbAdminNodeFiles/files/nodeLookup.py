#!/usr/bin/python3

# Author : Victor Zuniga
# Date   : 2022.07.05
# Purpose: Capture the VM and the host (VM) name for each node in the couchbase clusters.
#          Save the information to a json file.


import os, sys
import time
import pprint
import json

def getJSONData():
    lDTSuf = time.strftime("%Y%m%d")
    lLogDir = os.environ['LOG_DIR']
    lvFile = "%s/cbNodeInfo.%s.json" % (lLogDir, lDTSuf)

    print ("File to read: %s" % lvFile)

    vData = {}

    try:
        with open(lvFile) as f:
            vData = json.load(f)

    except:
        print ("ERROR: Could NOT read file : %s" % lvFile)
        exit(1)
    
    return vData

def usage():

    print ("nodeLookup.py <option>")
    print ("\t option:")
    print ("\t\t node name    - the name of the node in question")
    print ("\t\t VM name      - the name of the VM in question")
    print ("\t\t cluster name - the name of the cluster in question")
    
    exit(-1)
    
def displayData( pData):

    #print(len(pData))
    for k in pData.keys():
        print("%s:"% k)
        for k1 in pData[k].keys():
            print("\t%s : %s" % (k1,pData[k][k1]))

if __name__ == "__main__":
    
    #print ('Number of arguments: %s' % len(sys.argv) )
    #print ('Argument List: %s' % str(sys.argv))

    if len(sys.argv) <= 1:
        usage()

    vTimeSrt = time.time()

    vData = getJSONData()

    vTimeEnd = time.time()

    pp = pprint.PrettyPrinter( indent = 4)
    #pp.pprint("%s:" % sys.argv[1])
    #pp.pprint (vData[sys.argv[1]])
    vParams = sys.argv
    #print ("Parameters: %s" % str(vParams))
    vParams.pop(0)   # Remove the script name
    #print ("Parameters: %s" % str(vParams))

    print ("====="*10)
    for vItem in vParams:
        vRes = {}
        try:
            #print("Item: %s" % vItem)
            #pp.pprint(vData[vItem])
            #print ("-----")
        
            vRes[vItem.lower()] = vData[vItem.lower()]
            displayData ( vRes )
            
        except:
            print ("%s - not found in the file." % vItem.lower())

        print("")
    print ("====="*10)
    #print("Start Time: %s" % str(vTimeSrt))
    #print("End   Time: %s" % str(vTimeEnd))
    #print("Dur: %s" % vTimeEnd - vTimeSrt)

exit(0)

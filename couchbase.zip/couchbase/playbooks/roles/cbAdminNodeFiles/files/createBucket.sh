#!/bin/bash
# ***********************************************************************************************************
# bucket-create.sh
#
#   Usage: ./bucket-create.sh [options]
#
#   This script will run the provided script against the necessary nodes/cluster to create the buckets in the
#   cluster. Bucket size defults to 512M if not provied.
#
#   Options:
#
#     --username=<s>                   The user executing script
#     --password=<s>                   The user's password                 (optional, will prompt)
#     --node=<s>                       The cluster alias name
#     --name=<s>                       The bucket name
#     --ram=<s>                        The RAM Quota in MB                 (optional, defaults to 512)
# ***********************************************************************************************************
# History
# 2022.04.26 Ellen Cox		Initial version.
# 2022.04.29 Victor/Ellen       Error Handling
# 
# ***********************************************************************************************************

# Variables
DTS=`date +"%Y%m%d"`
CBCLI="/opt/couchbase/bin/couchbase-cli"
SLEEPDELAY=30

# set the defaults, these can all be overriden as environment variables or passed via the cli
PORT=${PORT:='8091'}
PROTOCOL=${PROTOCOL:='http'}

function usage {
   echo "$0 [options]"
   echo "   options:"
   echo "     --node=<s>              The node alias name"
   echo "     --username=<s>          Cluster Admin or RBAC username" 
   echo "     --password=<s>          Cluster Admin or RBAC password" 
   echo "     --bucket=<s>            The bucket name to be created"
   echo "     --ram=<s>               Bucket RAM Quota in mb [Default to 512]"

   exit

}

LOG_FILE="${LOG_DIR}/bucket_create.${DTS}.log"

echo "----------------------------------------------------------------------------------------------------" >> $LOG_FILE

date >> $LOG_FILE

if [ $# -eq 0 ]; then
  usage
fi

# parse any cli arguments
while [ $# -gt 0 ]; do
  case "$1" in
    --username=*)
      USERNAME="${1#*=}"
      ;;
    --password=*)
      PASS="${1#*=}"
      ;;
    --node=*)
      NODE="${1#*=}"
      ;;
    --bucket=*)
      BUCKET="${1#*=}"
      ;;
    --ram=*)
      RAM="${1#*=}"
      ;;
    *)
      printf "* Error: Invalid argument.*\n"
      usage
      exit 1
  esac
  shift
done

# Set default values as needed
RAM=${RAM:=512}
USR=`who am i | awk '{print $1}'`
USERNAME=${USERNAME:=$USR}

if [[ $BUCKET == '' ]]; then
  echo "Must provide bucket name"
  usage
fi

if [ -z "${PASS}" ]; then
   read -s -p "${USERNAME}\'s password: " PASS
   echo " "
   echo " "
fi

echo "------------------------------" >> $LOG_FILE
echo "UserName : ${USERNAME}" >> $LOG_FILE
echo "UserPaswd: *********" >> $LOG_FILE
echo "Node     : ${NODE}" >> $LOG_FILE
echo "Ram      : ${RAM}" >> $LOG_FILE
echo "Bucket   : ${BUCKET}" >> $LOG_FILE
echo "------------------------------" >> $LOG_FILE
echo ""
echo ""

echo "----------------------------------------------------------------------------------------------------"
echo ""
echo ""
echo ""
echo "Build BUCKET..." >> $LOG_FILE
echo "Build BUCKET..."
#couchbase-cli bucket-create --cluster=${NODE}.south.edu:8091 --username ${USERNAME} --password --bucket ${BUCKET} --bucket-type couchbase --bucket-ramsize ${RAM} --bucket-replica 1 --compression-mode off --conflict-resolution timestamp
CLIOUT=`${CBCLI} bucket-create --cluster=${NODE}.south.edu:${PORT} --username ${USERNAME} --password ${PASS} --bucket ${BUCKET} --bucket-type couchbase --bucket-ramsize ${RAM} --bucket-replica 1 --compression-mode off --conflict-resolution timestamp 2>&1`
RC=$?

if [ $RC -ne 0 ]; then
   echo "RC: ${RC}" >> $LOG_FILE
   echo "CLIOUT: ${CLIOUT}"
   echo "CLIOUT: ${CLIOUT}" >> $LOG_FILE
   echo "Bucket creation failed"
   echo "Bucket creation failed" >> $LOG_FILE
else
   echo ""
   echo "Bucket Creation completed" >> $LOG_FILE
   echo "Bucket Creation completed"
   echo ""
fi
   
date >> $LOG_FILE
echo "----------------------------------------------------------------------------------------------------" >> $LOG_FILE
echo "----------------------------------------------------------------------------------------------------"

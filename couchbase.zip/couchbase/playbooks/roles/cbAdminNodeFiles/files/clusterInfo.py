#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2019.09.13
# Purpose : Script to display basic cluster information across the QVC Coucbase environment

# 2021.05.17  Victor Zuniga       Cleaned up import falls and added some variables to avoid SDK warnings.
#                                 Made as part of adding timeout calls on the cluster build/init to speed up execution.
# 2022.01.25  Victor Zuniga       Removed cluster sorting to display the clusters in the order of the env_detail dict.
#                                 This makes it easier to monitor replicated clusters.
# 2022.06.14  Victor Zuniga       Trapped error when cluster is defined cluster is invalid or not available.

import sys
import os
import json
import argparse
import requests
import logging

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
#from bbc_cb.env_config import *
from bbc_cb.env_config import getClusterNames
from bbc_cb.cb_api import verifyAdminConnection
from bbc_cb.cb_cluster import cCluster
from bbc_cb.env_detail import CBENV

logger = logging.getLogger ( __name__ )

# ------------------------------------------------------------------------------------------------------------------------

def get_args() :
   """ Set up the arguments and return the python dictionary containing the received values """
   parser = argparse.ArgumentParser ( prog = "clusterStatus.py",
                                      formatter_class=argparse.RawDescriptionHelpFormatter,
                                      description=
      '''
      Script verify status of all or one Couchbase Cluster.
      ''' )
   
   parser.add_argument ( '-c', '--cluster', help = 'Cluster Name', default='all', required = False )
   parser.add_argument ( '-e', '--env', help = 'Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required = False )
   parser.add_argument ( '-d', '--debug', action='store_true',  help = 'Run in DEBUG mode', required = False )
   
   parser.add_argument ( '-u', '--user', help = 'Admin Account to be used', required = False )
   parser.add_argument ( '-p', '--password', help = 'Admin Password to be used', required = False )
   #parser.add_argument ( '-v', '--verbose', action='store_true',  help = 'Include output to console -- not used', required = False )
   return  vars(parser.parse_args() )

# ------------------------------------------------------------------------------------------------------------------------

gvArgs = get_args()

logNamePrefix = 'clusterInfo'

if gvArgs['debug']:
    vLogName = init_logger( logNamePrefix, logging.DEBUG )
else:
    vLogName = init_logger( logNamePrefix, logging.INFO )

if gvArgs['user'] == None or gvArgs['user'] == '':
   gvArgs['user'] = os.environ.get( 'MON_USER' )
   gvArgs['password'] = os.environ.get( 'MON_PSWD' )
else:
   if gvArgs['password'] == None or gvArgs['password'] == '':
      gvArgs['password'] = get_user_info  ("Enter %s\'s Password   : " % gvArgs['user'] )

logger.debug ("Args: " + str(gvArgs) )

#if not verifyAdminConnection ( (gvArgs['user'], gvArgs['password']) ):
#   logger.error ("ERROR: Connection using %s failed" % gvArgs['user'] )
#   logger.error ("ERROR: Please verify credentials" )
#   print ("ERROR: Connection using %s failed" % gvArgs['user'] )
#   print ("ERROR: Please verify credentials" )
#   print ("ERROR: Check log (%s) for details" % vLogName)
#   exit (-1)
#else:
#   logger.info ( "Credentials verified" )
#   print ( "Credentials verified" )

lvAuthCreds = (gvArgs['user'], gvArgs['password'])

if (gvArgs['cluster'] == 'all' and gvArgs['env'] == 'iqp' ):
    # Traverse the CBENV and list all clusters
    if not verifyAdminConnection ( (gvArgs['user'], gvArgs['password']) ):
        logger.error ("ERROR: Connection using %s failed" % gvArgs['user'] )
        logger.error ("ERROR: Please verify credentials" )
        print ("ERROR: Connection using %s failed" % gvArgs['user'] )
        print ("ERROR: Please verify credentials" )
        print ("ERROR: Check log (%s) for details" % vLogName)
        exit (-1)
    else:
        logger.info ( "Credentials verified" )
        print ( "Credentials verified" )

    for e in CBENV.keys():
        print ("=====================================================================================================================\n")
        #for n in sorted(CBENV[e].keys()):
        for n in CBENV[e].keys():
            x = cCluster (n, lvAuthCreds )
            print (x)
elif (gvArgs['cluster'] == 'all' and  gvArgs['env'] != 'iqp' ):
    # traverse received environments
    for e in (list(gvArgs['env'])):
        if e in CBENV.keys():
            print ("=====================================================================================================================\n")
            #for n in sorted(CBENV[e].keys()):
            for n in CBENV[e].keys():
                x = cCluster (n, lvAuthCreds)
                print (x)
        else:
             logger.error( "ERROR: environment %s not found" % e)
             print ("ERROR: environment %s not found" % e)
elif (gvArgs['cluster'] != 'all'):
    # Allow for multiple clusters to be passed at once
    vClusterList = gvArgs['cluster'].replace(" ", "").split(",")
    logger.info("Cluster List: %s" % str(vClusterList))
    for vClstr in vClusterList:
        #if gvArgs['cluster'] not in getClusterNames():
        if vClstr not in getClusterNames():
            #print ("ERROR: cluster %s does not exist." % (gvArgs['cluster']))
            print ("ERROR: cluster %s does not exist." % (vClstr))
        else:
            print( "=====================================================================================================================\n")
            #x = cCluster( gvArgs['cluster'], lvAuthCreds )
            x = cCluster( vClstr, lvAuthCreds)
            print (x)

print ("Done")

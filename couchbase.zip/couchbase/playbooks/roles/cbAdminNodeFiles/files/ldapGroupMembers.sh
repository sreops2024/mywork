#!/bin/bash
#
# Author :  Victor Zuniga
# Date   :  2022.02.11
# Purpose:  Dsiplay LDAP group membership for bucket/environment received.

ENV='i,q,p'
TYPE='a,u'

function usage {
   echo "$0 [options]"
   echo "   options:"
   echo "      --b=<bucket name(s)     REQUIRED        Name(s) of buckets to verify    [comma separated]"
   echo "      --e=<env: i,q,p         OPTIONAL        Environment flag(s)             [comma separated]"
   echo "      --t=<type: a,u          OPTIONAL        Group type, app or user.        [comma separated]"

   exit 1

}

if [ $# -lt 1 ]; then
    usage
fi

# parse any cli arguments
while [ $# -gt 0 ]; do
  case "$1" in
    --b=*)
      BUCKETS="${1#*=}"
      ;;
    --e=*)
      ENV="${1#*=}"
      ;;
    --t=*)
      TYPE="${1#*=}" 
      ;;
    --h)
      usage
      ;;
    *)
      printf "* Error: Invalid argument.*\n"
      exit 1
  esac
  shift
done



IFS=', ' read -r -a arBUCKETS <<< "${BUCKETS}"
IFS=', ' read -r -a arENVS <<< "${ENV}"
IFS=', ' read -r -a arTYPES <<< "${TYPE}"

echo ""

for vBKT in "${arBUCKETS[@]}"
do
    for vENV in "${arENVS[@]}"
    do
        if [[ ${vENV} == 'p' ]]; then
            vENVDESC="prod"
        elif [[ ${vENV} == 'q' ]]; then
            vENVDESC="qa"
        else
            vENVDESC="int"
        fi

        for vTYPE in "${arTYPES[@]}"
        do
            if [[ ${vTYPE} == "a" ]]; then
                vT='app'
            else
                vT='usr'
            fi
            GRP="CB-${vBKT}-${vT}-${vENV}"
            echo "Group Name: $GRP"

            ldapsearch -LLL -o ldif-wrap=no -b "cn=${GRP},ou=${vENVDESC},ou=couchbase,ou=groups,DC=south,DC=bbc,DC=net" \
            -H ldaps://ldaps.south.edu -D "CN=CouchbaseBind,OU=Bind,OU=ServiceAccounts,DC=south,DC=bbc,DC=net" -w EU24Vn3B7T6@tY3K \
            member | grep -i member | awk -F= '{print $2}' | awk -F',' '{print $1}' | sort | while read -r line
            do
                echo "   - ${line}"
            done
            echo ""
            
        done
    done
done

echo ""
echo 'Done.'
exit


#!/bin/bash
#set -vx 

if [ $# -ne 2 ]; then 
    echo "USAGE:  $0  CLUSTER      HOST        "
    echo "EG   :  $0  cbfp01i      hcb001fp01i "
    exit 12
fi 

RECIP_LIST=couchbase_dba@bbc.com
HOSTNAME=`hostname`

. /home/couchbase/DBA/parfile/.cbbackup.par

CLUSTER=$1
HOST=$2
REPO=${BKP_REPO}
ARCHIVE=/backup/${CLUSTER}
PASSWORD=$connect
USERNAME=bkup_admin
PORT=8091
THREADS=1

# # of incr backups kept before it is merged back into a "full"
RESTOREPOINTS=2

CBBACKUPMGR=/opt/couchbase/bin/cbbackupmgr
BACKUP_DATE=`date +%Y`

#######################################################
STEPTEXT="running backup on $CLUSTER "
#######################################################
# 
CMD="${CBBACKUPMGR} backup --archive ${ARCHIVE} --repo ${REPO} --cluster ${HOST}:${PORT} --username ${USERNAME} --password ${PASSWORD} --threads ${THREADS} --no-progress-bar --purge "
#CMD="${CBBACKUPMGR} backup --archive ${ARCHIVE} --repo ${REPO} --cluster couchbase://${HOST} --username ${USERNAME} --password ${PASSWORD} --threads ${THREADS} --no-progress-bar "
echo -e "Running backup...\nCommand: ${CMD}"
$CMD
RC=$?
 
if [ $? -ne 0 ]; then
    mailx -s "$0 failed  on $HOSTNAME for $STEPTEXT"  $RECIP_LIST 
    exit 12
fi

#######################################################
STEPTEXT="compacting backup on $CLUSTER "
#######################################################
# 
#BACKUPLIST=$(${CBBACKUPMGR} list --archive ${ARCHIVE} --repo ${REPO} | awk '{print $NF}' | grep  ${BACKUP_DATE})
BACKUPLIST=$(${CBBACKUPMGR} info --archive ${ARCHIVE} --repo ${REPO} | awk '{print $2}' | grep  ${BACKUP_DATE})
LASTBACKUP=$(echo "${BACKUPLIST}" | sed '$!d')
CMD="${CBBACKUPMGR} compact --archive ${ARCHIVE} --repo ${REPO} --backup ${LASTBACKUP}"
echo -e "Compacting the backup...\nCommand: ${CMD}"
$CMD
RC=$?

if [ $? -ne 0 ]; then
    mailx -s "$0 failed  on $HOSTNAME for $STEPTEXT"  $RECIP_LIST 
    exit 12
fi


#######################################################
STEPTEXT="MERGING OLD BACKUPSETS   "
#######################################################
# Merging old backups
COUNT=$(echo "${BACKUPLIST}" | wc -l)

if [ "$COUNT" -gt "$RESTOREPOINTS" ]; then
    START=$(echo "${BACKUPLIST}" | sed -n 1p)
    END=$(echo "${BACKUPLIST}" | sed -n $((1+COUNT-RESTOREPOINTS))p)
    CMD="${CBBACKUPMGR} merge --archive ${ARCHIVE} --repo ${REPO} --start ${START} --end ${END}"
    echo -e "Merging old backups...\nCommand: ${CMD}"
    $CMD
    RC=$?

    if [ $? -ne 0 ]; then
        mailx -s "$0 failed  on $HOSTNAME for $STEPTEXT"  $RECIP_LIST 
        exit 12
    fi
fi

 cbbackupmgr restore --archive /qutil/couchbase/backup/cb01core01q --repo dev_repo --cluster h01cbcore001q --username Administrator --password password  --include-buckets  dba_test7 --map-buckets dba_test7=dba_test8 


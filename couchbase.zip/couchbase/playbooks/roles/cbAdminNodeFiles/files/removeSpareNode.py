#!/usr/bin/python3
# Author  : Victor Zuniga
# Date    : 2021.01.26
# Purpose : Remove the spare node from the received cluster based on the configuration files.
#

import os
import argparse
import logging
import time
from subprocess import check_output
#from pprint import PrettyPrinter

from bbc_log.dba_log import init_logger
from bbc_cb.env_config import getClusterNames, getClusterNodes, getFirstClusterNode, getClusterSpareNode
from bbc_cb.cb_api import removeSpareDataNode, startRebalance, showRebalanceProgress
from bbc_sec.get_creds import get_user_info
from bbc_fileSec.encServer import getClusterCred
from bbc_cb.cb_cluster import cCluster
from bbc_email.dba_email import send_email

# ------------------------------------------------------------------------------------------------------------------------


def timeDelay(pSecDelay=15, pMsg=None):
    """
    Sleep for a period of time to allow operations from being received and processed.
    This prevents different errors from popping up, like div by 0 due to unavailable data.
    The message is to be displayed on the log for traceability purposes.
    """
    logger.debug("in timeDelay")

    logger.info("Sleep %d secs - %s" % (pSecDelay, pMsg))
    time.sleep(pSecDelay)

    return True


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="removeSpareNode.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Removes spare node from the received cluster, if spare node is defined.
      ''')
    parser.add_argument('-c', '--cluster', help='Cluster Name', required=True)
    return vars(parser.parse_args())

# ------------------------------------------------------------------------------------------------------------------------


def main():
    """Remove spare node from the received cluster """

    # Set operation time delay - seconds
    vTimeDelay = 5
    logger.debug("Set time Delay to %d (secs)" % vTimeDelay)

    logger.info("Main...")
    gvArgs = get_args()

    vDBA = check_output(["who", "am", "i"]).decode()
    logger.info("Executed by: " + str(vDBA))
    #print("Executed by: " + str(vDBA))

    logger.info("Cluster Name: " + gvArgs['cluster'])
    print("Cluster Name: " + gvArgs['cluster'])

    if gvArgs['cluster'].lower() in getClusterNames():
        logger.info("Cluster name is valid")

        # Get cluster node, and spare node info
        vNodeName = getFirstClusterNode(gvArgs['cluster'])
        vSpareNode = getClusterSpareNode(gvArgs["cluster"])
        logger.info("Cluster: %s [%s] - Spare: %s" %
                    (gvArgs["cluster"], vNodeName, vSpareNode))
        # print("Cluster: %s [%s] - Spare: %s" %
        #      (gvArgs["cluster"], vNodeName, vSpareNode))

        if vSpareNode is None or vSpareNode == '':
            logger.warning(
                "No Spare Node has been configured for cluster %s" % gvArgs["cluster"])
            print("WARNING: No Spare Node has been configured for cluster %s" %
                  gvArgs["cluster"])
            return False

        # Get admin Creds for the cluster
        vAdminCreds = ('dbadmin', getClusterCred(
            'dbadmin', gvArgs["cluster"], "/home/couchbase/DBA/.cbAdmin"))
        # print(
        #    "Creds: " + str(vAdminCreds).replace(vAdminCreds[1], '*' * len(vAdminCreds[1])))

        vCluster = cCluster(gvArgs["cluster"], vAdminCreds)
        if vSpareNode.lower() not in vCluster.nodeInfo.keys():
            # The cluster does not have the spare node as a member
            logging.warning("The cluster (%s) does not include the spare node (%s)" % (
                gvArgs["cluster"], vSpareNode.lower()))
            print("The cluster (%s) does not include the spare node (%s)" %
                  (gvArgs["cluster"], vSpareNode.lower()))
            return True

        # Remove Spare Node
        if removeSpareDataNode(vAdminCreds, vSpareNode):
            # Rebalance Cluster
            timeDelay(vTimeDelay, "Just before getting cluster information")
            vClusterNodes = list(
                cCluster(gvArgs["cluster"], vAdminCreds).nodeInfo.keys())
            logger.debug("Cluster Nodes: " + str(vClusterNodes))
            print("Cluster Nodes: " + str(vClusterNodes))
            if startRebalance(vAdminCreds, vNodeName, vClusterNodes):
                showRebalanceProgress(vAdminCreds, vNodeName)

                vCluster = cCluster(gvArgs["cluster"], vAdminCreds)
                timeDelay(vTimeDelay, "Get cluster status")
                # Send notification email
                send_email(Subject="%s - Node removal" % gvArgs["cluster"],
                           From="%s [%s] Couchbase DBA" % (
                               gvArgs["cluster"], vNodeName),
                           To=os.getenv('DBA_EMAIL'),
                           Body="Removed node: %s\n\nCluster: %s\n Cluster Info: %s\n\n" % (vSpareNode, gvArgs["cluster"], str(vCluster.getClusterText())))

                return True

        else:
            logger.error("ERROR: Could not add spare %s to cluster %s[%s]" % (
                vSpareNode, gvArgs["cluster"], vNodeName))
            print("ERROR: Could not add spare %s to cluster %s[%s]" % (
                vSpareNode, gvArgs["cluster"], vNodeName))
            return False

    else:
        logger.error("Invalid Cluster Name provided")
        print("ERROR: Invalid Cluster Name - " + gvArgs["cluster"].lower())
        return False

    return False

# ------------------------------------------------------------------------------------------------------------------------


if __name__ == "__main__":
    logFileName = 'removeSpareNode'
    #vLogName = init_logger(logFileName, logging.DEBUG)
    vLogName = init_logger(logFileName, logging.INFO)

    print("Log file: %s" % vLogName)
    logger = logging.getLogger()
    logger.info("------------------------------------------------------------------------------------------------------------------------")

    if main():
        logger.info("Spare node removal process completed successfully")
        print("Spare node removal process completed successfully")
        exit(0)
    else:
        logger.error("Spare node removal process completed unsuccessfully")
        print("Spare node removal process completed unsuccessfully")
        exit(1)

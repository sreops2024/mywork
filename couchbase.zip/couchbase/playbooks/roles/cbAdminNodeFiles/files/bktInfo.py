#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2019.09.13
# Purpose : Script to display basic bucket information on a given cluster or clusters.
#
# History
# Name
# Date       Name                Comments
# ---------- ------------------- -----------------------------------------------------------------
# 2019.12.10 Victor Zuniga       Add table output to log file.  Will allow history of bucket info.
# 2020.06.25 Victor Zuniga       Added replica resident % metric to report.
# 2022.07.19 Victor Zuniga       Adding water marks to report.
#                                Added cache miss ratio to repor.
# 2022.11.02 Victor Zuniga       Compute the average of readings, instead of the last reading, for the metrics that need to be displayed.
#                                Added logic to provide zoom intervals: (minute | hour | day | week | month | year) as a parameter
# 2023.02.01 Victor Zuniga       Replaced local getBucketInfo function with getBucketStats from cb_api module
#                                Add bucket TTL setting to table.

import argparse
import datetime

from bbc_cb.cb_api import verifyAdminConnection, getClusterBuckets, getEndpoint, getBucketTTL
from bbc_cb.cb_api import getBucketStats
from bbc_cb.env_config import *
from bbc_sec.get_creds import get_user_info
from prettytable import PrettyTable
#from prettytable import PLAIN_COLUMNS

def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="bktInfo.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description=
                                     '''
                                     Provide bucket information on a set of clusters.
                                     ''')
    parser.add_argument('-u', '--user', help='Admin Account to be used', required=False)
    parser.add_argument('-c', '--cluster', help='Cluster Name', default='all', required=True)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-b', '--bucket', help='Bucket Name', default="*", required=False)
    parser.add_argument('-z', '--zoom', help='interval (minute | hour | day | week | month | year)', default='minute', required=False)
    return vars(parser.parse_args())


#def getBucketInfo(pAuth, pNode, pBucket, pZoom = 'minute'):
#    logger.debug("getBucketInfo: Node [" + pNode + "] Bucket [" + pBucket + "]")
#    logger.debug("getBucketInfo: Zoom = %s" % pZoom)

#    #lURL = "http://%s:8091/pools/default/buckets/%s/stats" % (pNode, pBucket)
#    lURL = "http://%s:8091/pools/default/buckets/%s/stats?zoom=%s" % (pNode, pBucket, pZoom.lower())

#    logger.debug(lURL)

#    r = getEndpoint(pAuth, lURL)

#    return r


def getAvg (pList):
    ''' Return list average '''

    logger.debug( "getAverage: list: %s" % str(pList))
    try:
        vAvg = sum(pList)/len(pList)
        logger.debug("Average: %s" % str(vAvg))
        return vAvg
    except Exception as ex:
        logger.warning ("WARNING: Error computing list average")
        logger.warning ("warning: %s" % str(ex))
        return 0.0

# ------------------------------------------------------------------------------------------------------------------------
def bucketCount():
    logNamePrefix = 'bktInfo'

    vLogName = init_logger(logNamePrefix, logging.DEBUG)
    # vLogName = init_logger( logNamePrefix, logging.INFO )

    gvArgs = get_args()

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info("Enter %s\'s Password   : " % gvArgs['user'])

    logger.debug("Args: " + str(gvArgs))

    if gvArgs['zoom'].lower() not in ['minute', 'hour', 'day', 'week','month','year']:
        logger.debug ("Invalid zoom parameter [%s] reset to minute" % pZoom)
        gvArgs['zoom'] = 'minute'
    else:
        gvArgs['zoom'] = gvArgs['zoom'].lower()

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password'])):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        print("ERROR: Connection using %s failed" % gvArgs['user'])
        print("ERROR: Please verify credentials")
        print("ERROR: Check log (%s) for details" % vLogName)
        exit(-1)
    else:
        logger.info("Credentials verified")

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    lClusters = gvArgs['cluster'].split(",")

    #t = PrettyTable(['Cluster', 'Bucket', 'Doc Count', 'OPS', 'Miss Ratio', 'aDoc Res%', 'rDoc Res%', 'Low WM', 'High WM', 'Mem-Used/Total', 'Disk Used', 'doc_frag%', 'TimeStamp'])
    t = PrettyTable(['Cluster', 'Bucket', 'TTL', 'Doc Count', 'OPS', 'Miss Ratio', 'aDoc Res%', 'rDoc Res%', 'Low WM', 'High WM', 'Mem-Used/Total', 'Disk Used', 'doc_frag%', 'vb_pending_num', 'TimeStamp'])
    t.align['Bucket'] = 'l'
    t.align['TTL'] = 'c'
    t.align['Doc Count'] = 'r'
    t.align["doc_frag%"] = "r"
    t.align["OPS"] = "r"
    t.align['aDoc Res%'] = "r"
    t.align['rDoc Res%'] = "r"
    t.align['Disk Used'] = "r"
    t.align['Low WM'] = "r"
    t.align['High WM'] = "r"
    t.align['Miss Ratio'] = "r"
    t.align['vb_pending_num'] = 'r'

    tmpClusters = gvArgs['cluster'].split(",")
    allClusters = getClusterNames()

    for c in tmpClusters:
        if c not in allClusters:
            logger.warning ("WARNING: Cluster name " + c + " not found")
            print ("*" * 45)
            print ("WARNING: Cluster name " + c + " not found")
            print ("*" * 45)
            lClusters.remove(c)    

    if len (lClusters) < 1:
        exit (0)

    for cluster in lClusters:
        # Traverse the clusters received
        node = getRandomClusterNode(cluster.strip())
        buckets = getClusterBuckets(node, lvAuthCreds[0], lvAuthCreds[1])
        lBuckets = gvArgs['bucket'].split(",")

        if lBuckets == ["*"]:
            logger.debug ("Scan all buckets")
            lBuckets = buckets

        for lvBucket in lBuckets:
            if (lvBucket.strip() not in buckets):
                # A bucket name was provided, and not in the list
                logger.error("ERROR: provied bucket name not in the bucket list")
                logger.error("ERROR: bucket name: " + lvBucket)
                print("ERROR: provied bucket name not in the bucket list")
                print("ERROR: bucket name: " + lvBucket)
            else:
                logger.debug("   Buckets: " + str(buckets))
                #lBucketInfo = getBucketInfo(lvAuthCreds, node, lvBucket.strip())
                #lBucketInfo = getBucketInfo(lvAuthCreds, node, lvBucket.strip(), gvArgs['zoom'])
                lBucketInfo = getBucketStats( lvBucket.strip(), node, lvAuthCreds, gvArgs['zoom'] )
                lBucketTTL = getBucketTTL ( lvBucket.strip(), node, lvAuthCreds )
                if lBucketTTL != 0:
                    lBktTTlStr = "{:0>8}".format(str(datetime.timedelta(seconds=lBucketTTL)))
                else:
                    lBktTTlStr = ''
                #sampleCount = (lBucketInfo['op']['samplesCount'] - 1)
                sampleCount = ( len ( lBucketInfo['op']['samples']['curr_items'])-1 )
                logger.debug("Sample Count : " + str(sampleCount))

                try:
                    vDocsFragPct = lBucketInfo['op']['samples']['couch_docs_fragmentation'][sampleCount]
                except:
                    logger.warning("Did not find couch_docs_fragmentation, setting avg to 0.00")
                finally:
                    vDocsFragPct = '0.00'
                
                #print(lBucketInfo['op']['samples']['timestamp'][sampleCount])

                vDateStr = str(datetime.datetime.fromtimestamp(lBucketInfo['op']['samples']['timestamp'][sampleCount] / 1000.0))

                #lStr = "{c} : {n:15s} : {b} : {i:10,} : {f:10,}[ {d} ]".format(
                #    c=cluster.strip(),
                #    n=node,
                #    b=lvBucket,
                #    i=lBucketInfo['op']['samples']['curr_items'][sampleCount],
                #    f=vDocsFragPct,
                #    d=vDateStr
                #)
                
                lStr = "%s : %s : %s : %s : %s [%s]" % (cluster.strip(), 
                                                        node, 
                                                        lvBucket,
                                                        lBucketInfo['op']['samples']['curr_items'][sampleCount],
                                                        vDocsFragPct,
                                                        vDateStr                                                        
                                                        )

                logger.debug( "lStr : " + lStr )

                try:
                    # Compute Cache miss ratio
                    #vCacheMissRatio = (lBucketInfo['op']['samples']['ep_bg_fetched'][sampleCount]/lBucketInfo['op']['samples']['cmd_lookup'][sampleCount])*100
                    vCacheMissRatio = ( getAvg( lBucketInfo['op']['samples']['ep_bg_fetched'])/ getAvg( lBucketInfo['op']['samples']['cmd_lookup']))*100
                    logger.debug ("Cache Miss Ratio: %s" % str(vCacheMissRatio))
                except ZeroDivisionError:
                    logger.warning("Issue computing cache miss ratio, div by 0")
                    logger.warning("ep_bg_fetched: %s" % str(lBucketInfo['op']['samples']['ep_bg_fetched'][sampleCount]))
                    logger.warning("cmd_lookup: %s" % str(lBucketInfo['op']['samples']['cmd_lookup'][sampleCount]))
                except:
                    logger.warning("Possible metric missing - Due to couchbase version")
                finally:
                    vCacheMissRatio = 0.00

                try:
                    vDocFragAvg = getAvg(lBucketInfo['op']['samples']['couch_docs_fragmentation'] )
                except:
                    logger.warning("Did not find couch_docs_fragmentation, setting avg to 0.00")
                finally:
                    vDocFragAvg = 0.00

                t.add_row( [cluster.strip(),
                            "{0:<10s}".format(lvBucket),
                            #"{:0>8}".format(str(datetime.timedelta(seconds=lBucketTTL))),
                            lBktTTlStr,
                            "{0:,.2f}".format( getAvg( lBucketInfo['op']['samples']['curr_items'])),
                            "{0:5.3f}".format( getAvg( lBucketInfo['op']['samples']['ops']) ),
                            "{0:4.2f}".format(vCacheMissRatio),
                            "{0:4.2f}".format( getAvg(lBucketInfo['op']['samples']['vb_active_resident_items_ratio']) ),
                            "{0:4.2f}".format( getAvg(lBucketInfo['op']['samples']['vb_replica_resident_items_ratio'])),
                            "{0:4.2f}".format( getAvg(lBucketInfo['op']['samples']['ep_mem_low_wat'] ) / (1024 * 1024 * 1024)),
                            "{0:4.2f}".format( getAvg(lBucketInfo['op']['samples']['ep_mem_high_wat'] ) / (1024 * 1024 * 1024)),
                            "{0:6.2f}".format( getAvg(lBucketInfo['op']['samples']['mem_used'] ) / (1024 * 1024 * 1024)) + " /"
                            "{0:6.2f}".format( getAvg(lBucketInfo['op']['samples']['ep_max_size'] ) / (1024 * 1024 * 1024)),
                            "{0:6.2f}".format( getAvg(lBucketInfo['op']['samples']['couch_total_disk_size'] ) / (1024* 1024* 1024)),
                            "{0:4.2f}".format( vDocFragAvg ),
                            "{0:,.2f}".format( getAvg(lBucketInfo['op']['samples']['vb_pending_num'])),
                            "{0:%Y-%m-%d %H:%M:%S}".format(datetime.datetime.fromtimestamp(lBucketInfo['op']['samples']['timestamp'][sampleCount] / 1000.0))])

                #t.add_row( [cluster.strip(),
                #            "{0:<10s}".format(lvBucket),
                #            "{0:10,}".format(lBucketInfo['op']['samples']['curr_items'][sampleCount]),
                #            "{0:5.3f}".format(lBucketInfo['op']['samples']['ops'][sampleCount]),
                #            "{0:4.2f}".format(vCacheMissRatio),
                #            "{0:4.2f}".format(lBucketInfo['op']['samples']['vb_active_resident_items_ratio'][sampleCount]),
                #            "{0:4.2f}".format(lBucketInfo['op']['samples']['vb_replica_resident_items_ratio'][sampleCount]),
                #            "{0:4.2f}".format(lBucketInfo['op']['samples']['ep_mem_low_wat'][sampleCount] / (1024 * 1024 * 1024)),
                #            "{0:4.2f}".format(lBucketInfo['op']['samples']['ep_mem_high_wat'][sampleCount] / (1024 * 1024 * 1024)),
                #            "{0:6.2f}".format(lBucketInfo['op']['samples']['mem_used'][sampleCount] / (1024 * 1024 * 1024)) + " /"
                #            "{0:6.2f}".format(lBucketInfo['op']['samples']['ep_max_size'][sampleCount]/ (1024 * 1024 * 1024)),
                #            "{0:6.2f}".format(lBucketInfo['op']['samples']['couch_total_disk_size'][sampleCount] / (1024* 1024* 1024)),
                #            "{0:4.2f}".format(lBucketInfo['op']['samples']['couch_docs_fragmentation'][sampleCount]),
                #            "{0:%Y-%m-%d %H:%M:%S}".format(datetime.datetime.fromtimestamp(lBucketInfo['op']['samples']['timestamp'][sampleCount] / 1000.0))])

                logger.info(lStr)
                #print(lStr)

        t.add_row( [' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '])
        #t.add_row( ['---- ', '---------',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '])
        #t.add_row( ['zoom ',gvArgs['zoom'],' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '])
        #print("------------------------------------------------------------------------------")

    print ("")
    logger.info ( "\n" + str(t) + "\n" )
    t.add_row( ['---- ', '---------',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '])
    t.add_row( ['zoom ',gvArgs['zoom'],' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '])
    print (t)
    print ("Done")


if __name__ == "__main__":
    bucketCount()

exit(0)

#!/bin/bash
# ***********************************************************************************************************
# enable_ldap.sh
#
#   Usage: ./create_dba_group.sh [options]
#
#   This script will create the DBA group authenticated to the DBA_Couchbase LDAP group.
#
#   Options:
#
#     --node=<s>              The cluster address
#     --username=<s>          Cluster Admin or RBAC username (default: Administrator)
#     --password=<s>          Cluster Admin or RBAC password (default: '')
#     --port=<port>           Port Number (default: 8091)
#     --protocol=<protocol>   Protocol (default: http)
# ***********************************************************************************************************

# Variables
DTS=`date +"%Y%m%d"`
CURL="/opt/couchbase/bin/curl"

CB_USERNAME=${CB_USERNAME:='Administrator'}
CB_PASSWORD=${CB_PASSWORD:=''}
PORT=${PORT:='8091'}
PROTOCOL=${PROTOCOL:='http'}


function usage {
   echo "$0 [options]"
   echo "   options:"
   #echo "     --node=<s>              The node (node alias) name"
   echo "     --username=<s>          Cluster Admin or RBAC username (default: Administrator)"
   echo "     --password=<s>          Cluster Admin or RBAC password (default: password)"
   echo "     --port=<port#>          Port number (default: 8091)"
   echo "     --protocol=<protocol>   Protocol (default: http)"

   exit 1

}

# parse any cli arguments
while [ $# -gt 0 ]; do
  case "$1" in
    --username=*)
      CB_USERNAME="${1#*=}"
      ;;
    --password=*)
      CB_PASSWORD="${1#*=}"
      ;;
    #--node=*)
    #  NODE="${1#*=}"
    #  ;;
    --port=*)
      PORT="${1#*=}"
      ;;
    --protocol=*)
      PROTOCOL="${1#*=}"
      ;;
    *)
      printf "* Error: Invalid argument.*\n"
      usage
      exit 1
  esac
  shift
done

if [[ ${NODE} == '' ]]; then
  #usage
  #NODE=hcb001fp01q,hcb001sp01q
  NODE=hcb001fp01q
fi

if [[ ${CB_PASSWORD} == '' ]]; then
  #echo -n "Password: "
  #read -s CB_PASSWORD
  #echo 
  read -s -p "${CB_USERNAME}'s Password: " CB_PASSWORD

fi

echo "------------------------------"
echo "UserName : ${CB_USERNAME:-Administrator}"
echo "UserPaswd: *********"
echo "Node(s)  : ${NODE}"
echo "------------------------------"

BKTS="gpa_us,ice_de,ice_jp,ice_uk,ice_us,product_api,supplychain"
ROLES_APP="data_reader,data_writer,query_select,query_insert,query_update,query_delete"
ROLES_USR="data_reader,query_select"
TYPES='USR,APP'

IFS=', ' read -r -a arNODES <<< "${NODE}"
IFS=', ' read -r -a arBKTS <<< "${BKTS}"
IFS=', ' read -r -a arROLES_APP <<< "${ROLES_APP}"
IFS=', ' read -r -a arROLES_USR <<< "${ROLES_USR}"
IFS=', ' read -r -a arTYPES <<< "${TYPES}"

echo "Role App: ${ROLES_APP} : ${arROLES_APP[@]}"
echo "Role Usr: ${ROLES_USR} : ${arROLES_USR[@]}"

for vNODE in "${arNODES[@]}"
do
   echo "***Node: ${vNODE}"
   for vBKT in "${arBKTS[@]}"
   do
      echo "***   Bucket: ${vBKT}"

      vRoleStrApp=""
      for vRole in "${arROLES_APP[@]}"
      do
         #echo "         role: ${vRole}"
         vRoleStrApp="${vRoleStrApp}${vRole}[${vBKT}],"
      done
      vRoleStrApp=${vRoleStrApp::-1}
      #echo "      RolesApp: ${vRoleStrApp}"

      vRoleStrUsr=""
      for vRole in "${arROLES_USR[@]}"
      do
         #echo "         role: ${vRole}"
         vRoleStrUsr="${vRoleStrUsr}${vRole}[${vBKT}],"
      done
      vRoleStrUsr=${vRoleStrUsr::-1}
      #echo "      RolesUsr: ${vRoleStrUsr}"

      for vTYPE in "${arTYPES[@]}"
      do
          vGROUP="${vTYPE}-${vBKT}"
          vGroupDesc="Group for ${vTYPE} on ${vBKT}"
          #vLDAPGroup="ldap_group_ref=\"CN=CB-${vBKT}-${vTYPE,,}-q,OU=INT,OU=Couchbase,OU=Groups,DC=south,DC=bbc,DC=net\" "
          vLDAPGroup="ldap_group_ref=\"CN=CB-${vBKT}-${vTYPE,,}-q,OU=QA,OU=Couchbase,OU=Groups,DC=south,DC=bbc,DC=net\" "
          echo "Group: ${vGROUP}"

          if [[ ${vTYPE} == 'APP' ]]; then
             CMD="${CURL} -X PUT -u ${CB_USERNAME}:${CB_PASSWORD} ${PROTOCOL}://${vNODE}:${PORT}/settings/rbac/groups/${vGROUP} -d roles=\"${vRoleStrApp}\" -d description=\"${vGroupDesc}\" --data-urlencode ${vLDAPGroup} "
             CMDDISP="${CURL} -X PUT -u ${CB_USERNAME}:********** ${PROTOCOL}://${vNODE}:${PORT}/settings/rbac/groups/${vGROUP} -d roles=\"${vRoleStrApp}\" -d description=\"${vGroupDesc}\" --data-urlencode ${vLDAPGroup} "
          else
             CMD="${CURL} -X PUT -u ${CB_USERNAME}:${CB_PASSWORD} ${PROTOCOL}://${vNODE}:${PORT}/settings/rbac/groups/${vGROUP} -d roles=\"${vRoleStrUsr}\" -d description=\"${vGroupDesc}\" --data-urlencode ${vLDAPGroup} "
             CMDDISP="${CURL} -X PUT -u ${CB_USERNAME}:********** ${PROTOCOL}://${vNODE}:${PORT}/settings/rbac/groups/${vGROUP} -d roles=\"${vRoleStrUsr}\" -d description=\"${vGroupDesc}\" --data-urlencode ${vLDAPGroup} "
          fi
          echo "Command: ${CMDDISP}"
          #echo "LDAP Group: ${vLDAPGroup}"
          echo "Executing ... "
          eval ${CMD}
          echo " "
          echo "RC: $?"
          echo " "
      done
      echo " "
   done
done
exit 0


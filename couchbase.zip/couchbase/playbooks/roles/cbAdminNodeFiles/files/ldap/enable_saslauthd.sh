#!/bin/bash
# ***********************************************************************************************************
# enable_saslauthd.sh
#
#   Usage: ./enable_saslauthd.sh [options]
#
#   This script will enable the saslausthd authentication on the recived node/cluster.
#
#   Options:
#
#     --node=<s>              The cluster address
#     --username=<s>          Cluster Admin or RBAC username (default: Administrator)
#     --password=<s>          Cluster Admin or RBAC password (default: password)
#     --protocol=<protocol>   Protocol (default: http)
#     --port=<port#>          Port Number (default: 8091)
# ***********************************************************************************************************

# Variables
DTS=`date +"%Y%m%d"`
CLI="/opt/couchbase/bin/couchbase-cli"
CURL="/opt/couchbase/bin/curl"

CB_USERNAME=${CB_USERNAME:='Administrator'}
CB_PASSWORD=${CB_PASSWORD:=''}
NODE=${CLUSTER:='localhost'}
PORT=${PORT:='8091'}
PROTOCOL=${PROTOCOL:='http'}


function usage {
   echo "$0 [options]"
   echo "   options:"
   echo "     --node=<s>              The node (node alias) name"
   echo "     --username=<s>          Cluster Admin or RBAC username (default: Administrator)"
   echo "     --password=<s>          Cluster Admin or RBAC password (default: password)"
   echo "     --protocol=<protocol>   Protocol (default: http)"
   echo "     --port=<port#>          Port Number (default: 8091)"

   exit 1

}

# parse any cli arguments
while [ $# -gt 0 ]; do
  case "$1" in
    --username=*)
      CB_USERNAME="${1#*=}"
      ;;
    --password=*)
      CB_PASSWORD="${1#*=}"
      ;;
    --node=*)
      NODE="${1#*=}"
      ;;
    --port=*)
      PORT="${1#*=}"
      ;;
    --protocol=*)
      PROTOCOL="${1#*=}"
      ;;

    *)
      printf "* Error: Invalid argument.*\n"
      exit 1
  esac
  shift
done

if [[ ${CB_PASSWORD} == '' ]]; then
  read -s -p "Password: " CB_PASSWORD
fi

echo "------------------------------"
echo "UserName : ${CB_USERNAME:-Administrator}"
echo "UserPaswd: *********"
echo "Node(s)  : ${NODE}"
echo "------------------------------"


CMD="${CURL} -X POST -u ${CB_USERNAME}:${CB_PASSWORD} ${PROTOCOL}://${NODE}:${PORT}/settings/saslauthdAuth -d enabled=true -d admins=Administrator"
CMDDISP="${CURL} -X POST -u ${CB_USERNAME}:********** ${PROTOCOL}://${NODE}:${PORT}/settings/saslauthdAuth -d enabled=true -d admins=Administrator"
echo "Command: ${CMDDISP}"
eval ${CMD}
echo "RC: $?"

exit 0


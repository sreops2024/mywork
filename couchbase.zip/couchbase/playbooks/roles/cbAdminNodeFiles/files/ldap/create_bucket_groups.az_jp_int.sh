#!/bin/bash
# ***********************************************************************************************************
# enable_ldap.sh
#
#   Usage: ./create_dba_group.sh [options]
#
#   This script will create the DBA group authenticated to the DBA_Couchbase LDAP group.
#
#   Options:
#
#     --node=<s>              The cluster address
#     --username=<s>          Cluster Admin or RBAC username (default: Administrator)
#     --password=<s>          Cluster Admin or RBAC password (default: '')
#     --port=<port>           Port Number (default: 8091)
#     --protocol=<protocol>   Protocol (default: http)
# ***********************************************************************************************************

# Variables
DTS=`date +"%Y%m%d"`
CURL="/opt/couchbase/bin/curl"

CB_USERNAME=${CB_USERNAME:='Administrator'}
CB_PASSWORD=${CB_PASSWORD:=''}
PORT=${PORT:='8091'}
PROTOCOL=${PROTOCOL:='http'}


function usage {
   echo "$0 [options]"
   echo "   options:"
   #echo "     --node=<s>              The node (node alias) name"
   echo "     --username=<s>          Cluster Admin or RBAC username (default: Administrator)"
   echo "     --password=<s>          Cluster Admin or RBAC password (default: password)"
   echo "     --port=<port#>          Port number (default: 8091)"
   echo "     --protocol=<protocol>   Protocol (default: http)"

   exit 1

}

# parse any cli arguments
while [ $# -gt 0 ]; do
  case "$1" in
    --username=*)
      CB_USERNAME="${1#*=}"
      ;;
    --password=*)
      CB_PASSWORD="${1#*=}"
      ;;
    #--node=*)
    #  NODE="${1#*=}"
    #  ;;
    --port=*)
      PORT="${1#*=}"
      ;;
    --protocol=*)
      PROTOCOL="${1#*=}"
      ;;
    *)
      printf "* Error: Invalid argument.*\n"
      exit 1
  esac
  shift
done

if [[ ${NODE} == '' ]]; then
  #usage
  NODE=hcb001jpe01i
fi

if [[ ${CB_PASSWORD} == '' ]]; then
  #echo -n "Password: "
  #read -s CB_PASSWORD
  #echo 
  read -s -p "${CB_USERNAME}'s Password: " CB_PASSWORD

fi

echo "------------------------------"
echo "UserName : ${CB_USERNAME:-Administrator}"
echo "UserPaswd: *********"
echo "Node(s)  : ${NODE}"
echo "------------------------------"

BKTS="ice_jp"
ROLES="data_reader,data_writer,query_select,query_insert,query_update,query_delete"
TYPES='USR,APP'

IFS=', ' read -r -a arNODES <<< "${NODE}"
IFS=', ' read -r -a arBKTS <<< "${BKTS}"
IFS=', ' read -r -a arROLES <<< "${ROLES}"
IFS=', ' read -r -a arTYPES <<< "${TYPES}"

for vNODE in "${arNODES[@]}"
do
   echo "***Node: ${vNODE}"
   for vBKT in "${arBKTS[@]}"
   do
      echo "***   Bucket: ${vBKT}"
      vRoleStr=""
      for vRole in "${arROLES[@]}"
      do
         #echo "         role: ${vRole}"
         vRoleStr="${vRoleStr}${vRole}[${vBKT}],"
      done
      vRoleStr=${vRoleStr::-1}
      #echo "      Roles: ${vRoleStr}"

      for vTYPE in "${arTYPES[@]}"
      do
          vGROUP="${vTYPE}-${vBKT}"
          vGroupDesc="Group for ${vTYPE} on ${vBKT}"
          vLDAPGroup="ldap_group_ref=\"CN=CB-${vBKT}-${vTYPE,,}-i,OU=INT,OU=Couchbase,OU=Groups,DC=south,DC=bbc,DC=net\" "
          echo "Group: ${vGROUP}"
          CMD="${CURL} -X PUT -u ${CB_USERNAME}:${CB_PASSWORD} ${PROTOCOL}://${vNODE}:${PORT}/settings/rbac/groups/${vGROUP} -d roles=\"${vRoleStr}\" -d description=\"${vGroupDesc}\" --data-urlencode ${vLDAPGroup} "
          CMDDISP="${CURL} -X PUT -u ${CB_USERNAME}:********** ${PROTOCOL}://${vNODE}:${PORT}/settings/rbac/groups/${vGROUP} -d roles=\"${vRoleStr}\" -d description=\"${vGroupDesc}\" --data-urlencode ${vLDAPGroup} "
          echo "Command: ${CMDDISP}"
          #echo "LDAP Group: ${vLDAPGroup}"
          echo "Executing ... "
          eval ${CMD}
          echo " "
          echo "RC: $?"
          echo " "
      done
      echo " "
   done
done
exit 0


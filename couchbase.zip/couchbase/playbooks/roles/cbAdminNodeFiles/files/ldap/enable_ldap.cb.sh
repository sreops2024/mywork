#!/bin/bash
# ***********************************************************************************************************
# enable_ldap.sh
#
#   Usage: ./enable_sldap.sh [options]
#
#   This script will enable the saslauthd authentication on the received node/cluster.
#
#   Options:
#
#     --node=<s>              The cluster address
#     --username=<s>          Cluster Admin or RBAC username (default: Administrator)
#     --password=<s>          Cluster Admin or RBAC password (default: '')
# ***********************************************************************************************************

# Variables
DTS=`date +"%Y%m%d"`
CURL="/opt/couchbase/bin/curl"

CB_USERNAME=${CB_USERNAME:='Administrator'}
CB_PASSWORD=${CB_PASSWORD:=''}
PORT=${PORT:='8091'}
PROTOCOL=${PROTOCOL:='http'}


function usage {
   echo "$0 [options]"
   echo "   options:"
   echo "     --node=<s>              The node (node alias) name"
   echo "     --username=<s>          Cluster Admin or RBAC username (default: Administrator)"
   echo "     --password=<s>          Cluster Admin or RBAC password (default: password)"
   echo "     --port=<port#>          Port number (default: 8091)"
   echo "     --protocol=<protocol>   Protocol (default: http)"

   exit 1

}

# parse any cli arguments
while [ $# -gt 0 ]; do
  case "$1" in
    --username=*)
      CB_USERNAME="${1#*=}"
      ;;
    --password=*)
      CB_PASSWORD="${1#*=}"
      ;;
    --node=*)
      NODE="${1#*=}"
      ;;
    --port=*)
      PORT="${1#*=}"
      ;;
    --protocol=*)
      PROTOCOL="${1#*=}"
      ;;
    *)
      printf "* Error: Invalid argument.*\n"
      exit 1
  esac
  shift
done

if [[ ${NODE} == '' ]]; then
   usage
fi

if [[ ${CB_PASSWORD} == '' ]]; then
  #echo -n "Password: "
  #read -s CB_PASSWORD
  #echo 
  read -s -p "Password: " CB_PASSWORD

fi

echo "------------------------------"
echo "UserName : ${CB_USERNAME:-Administrator}"
echo "UserPaswd: *********"
echo "Node(s)  : ${NODE}"
echo "------------------------------"


CMD="${CURL} -X POST -u ${CB_USERNAME}:${CB_PASSWORD} ${PROTOCOL}://${NODE}:${PORT}/settings/ldap \
-d hosts=ldaps-cb.south.edu \
-d port=636 \
-d encryption=TLS \
-d serverCertValidation=true \
-d bindDN=\"CN=CouchbaseBind,OU=Bind,OU=ServiceAccounts,DC=south,DC=bbc,DC=net\" \
-d bindPass=\"EU24Vn3B7T6@tY3K\" \
-d authenticationEnabled=true \
--data-urlencode userDNMapping='{\"query\":\"dc=south,dc=bbc,dc=net??sub?(sAMAccountName=%u)\"}' \
-d authorizationEnabled=true \
--data-urlencode groupsQuery=\"dc=south,dc=bbc,dc=net??sub?(member=%D)\" "

CMDDISP="${CURL} -X POST -u ${CB_USERNAME}:*********** ${PROTOCOL}://${NODE}:${PORT}/settings/ldap \
-d hosts=ldaps-cb.south.edu \
-d port=636 \
-d encryption=TLS \
-d serverCertValidation=true \
-d bindDN=\"CN=CouchbaseBind,OU=Bind,OU=ServiceAccounts,DC=south,DC=bbc,DC=net\" \
-d bindPass=\"EU24Vn3B7T6@tY3K\" \
-d authenticationEnabled=true \
--data-urlencode userDNMapping='{\"query\":\"dc=south,dc=bbc,dc=net??sub?(sAMAccountName=%u)\"}' \
-d authorizationEnabled=true \
--data-urlencode groupsQuery=\"dc=south,dc=bbc,dc=net??sub?(member=%D)\" "


echo "Command: ${CMDDISP}"
echo " "

eval ${CMD}
echo " "
echo "RC: $?"

exit 0


#!/bin/bash
# ***********************************************************************************************************
# enable_ldap.sh
#
#   Usage: ./ldap_wrapper.sh [options]
#
#   This script will wrap the scripts needed to set up ldap at the provided node/cluster.
#
#   Options:
#
#     --node=<s>              The cluster address
#     --username=<s>          Cluster Admin or RBAC username (default: Administrator)
#     --password=<s>          Cluster Admin or RBAC password (default: '')
# ***********************************************************************************************************

# Variables
DTS=`date +"%Y%m%d"`
CURL="/opt/couchbase/bin/curl"

CB_USERNAME=${CB_USERNAME:='Administrator'}
CB_PASSWORD=${CB_PASSWORD:=''}
PORT=${PORT:='8091'}
PROTOCOL=${PROTOCOL:='http'}


function usage {
   echo "$0 [options]"
   echo "   options:"
   echo "     --node=<s>              The node (node alias) name"
   echo "     --username=<s>          Cluster Admin or RBAC username (default: Administrator)"
   echo "     --password=<s>          Cluster Admin or RBAC password (default: password)"
   echo "     --port=<port#>          Port number (default: 8091)"
   echo "     --protocol=<protocol>   Protocol (default: http)"

   exit 1

}

# parse any cli arguments
while [ $# -gt 0 ]; do
  case "$1" in
    --username=*)
      CB_USERNAME="${1#*=}"
      ;;
    --password=*)
      CB_PASSWORD="${1#*=}"
      ;;
    --node=*)
      NODE="${1#*=}"
      ;;
    --port=*)
      PORT="${1#*=}"
      ;;
    --protocol=*)
      PROTOCOL="${1#*=}"
      ;;
    *)
      printf "* Error: Invalid argument.*\n"
      exit 1
  esac
  shift
done

if [[ ${NODE} == '' ]]; then
   usage
fi

if [[ ${CB_PASSWORD} == '' ]]; then
  #echo -n "Password: "
  #read -s CB_PASSWORD
  #echo 
  read -s -p "Password: " CB_PASSWORD

fi

echo "------------------------------"
echo "UserName : ${CB_USERNAME:-Administrator}"
echo "UserPaswd: *********"
echo "Node(s)  : ${NODE}"
echo "------------------------------"
echo ""
echo ""

echo "Enable LDAP - ${NODE}"
enable_ldap.sh --node=${NODE} --username=${CB_USERNAME} --password=${CB_PASSWORD}

echo "Disable saslauthd - ${NODE}"
disable_saslauthd.sh --node=${NODE} --username=${CB_USERNAME} --password=${CB_PASSWORD}

echo "Create DBA Group - ${NODE}"
create_dba_group.sh --node=${NODE} --username=${CB_USERNAME} --password=${CB_PASSWORD}

#echo "Delete DBA ind accts - ${NODE}"
#delete_dba_users.sh --node=${NODE} --username=${CB_USERNAME} --password=${CB_PASSWORD}

echo ""
echo "Done"

exit 0


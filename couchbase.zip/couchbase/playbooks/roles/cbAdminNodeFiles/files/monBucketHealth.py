#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2021.06.04
# Purpose : This script is to serve as a template for other python scripts.
#           Accept user inputs, clusters, buckets, etc.

import sys
import os
import json
import argparse
import requests
import logging

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import getClusterNames, getRandomClusterNode
from bbc_cb.cb_api import verifyAdminConnection, getClusterBuckets, getBucketInfo
from bbc_cb.env_detail import CBENV
from bbc_cb.cb_monitor import monBucket

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="monBucketHealth.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Script to monitor the .
      ''')
    parser.add_argument(
        '-u', '--user', help='Admin Account to be used', required=False)
    parser.add_argument('-c', '--cluster', help='Cluster Name', default='all', required=False)
    parser.add_argument('-b', '--bucket', help='Bucket Name', default='all', required=False)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-e', '--env', help='Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required=False)
    parser.add_argument('-d', '--debug', action='store_true', help='Run in DEBUG mode', required=False)
    parser.add_argument('-v', '--verbose', action='store_true', help='Display information to screen', default=False, required=False)

    return vars(parser.parse_args())


def main(gvArgs):
    #print("Main function")
    vSNOW = 'PROD'
    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    if (gvArgs['cluster'] == 'all' and gvArgs['env'] == 'iqp' ):
        # Traverse the CBENV and list all clusters
        for e in CBENV.keys():
            if gvArgs['verbose']:
                print ("=====================================================================================================================\n")
            for vClstr in sorted(CBENV[e].keys()):
                vNode = getRandomClusterNode(vClstr)
                vBuckets = getClusterBuckets(vNode, gvArgs['user'], gvArgs['password'])
                if gvArgs['verbose']:
                    print ("%s [%s] : %s " % (vClstr, vNode, str(vBuckets)) )
                
                for vBkt in vBuckets:
                    monBucket(vBkt, vNode, lvAuthCreds, gvArgs['verbose'], pSNOW = vSNOW)

    elif (gvArgs['cluster'] == 'all' and  gvArgs['env'] != 'iqp' ):
        # traverse received environments
        for e in (list(gvArgs['env'])):
            if e in CBENV.keys():
                if gvArgs['verbose']:
                    print ("=====================================================================================================================\n")
                for vClstr in sorted(CBENV[e].keys()):
                    vNode = getRandomClusterNode(vClstr)
                    vBuckets = getClusterBuckets(vNode, gvArgs['user'], gvArgs['password'])
                    if gvArgs['verbose']:
                        print ("%s [%s] : %s " % (vClstr, vNode, str(vBuckets)) )
                    
                    for vBkt in vBuckets:
                        logger.debug("Get bucket Info: %s" % vBkt)
                        #vBktInfo = getBucketInfo(vBkt, vNode, lvAuthCreds)
                        #print("   %s : %s" % (vBkt, str(vBktInfo)))
                        monBucket(vBkt, vNode, lvAuthCreds, gvArgs['verbose'], pSNOW = vSNOW)
                    
    elif (gvArgs['cluster'] != 'all'):
        # Allow for multiple clusters to be passed at once
        if gvArgs['verbose']:
            print( "=====================================================================================================================\n")
        vClusterList = gvArgs['cluster'].replace(" ", ",").split(",")
        logger.info("Cluster List: %s" % str(vClusterList))
        for vClstr in vClusterList:
            #if gvArgs['cluster'] not in getClusterNames():
            if vClstr not in getClusterNames():
                print ("ERROR: cluster %s does not exist." % (vClstr))
            else:
                vNode = getRandomClusterNode(vClstr)
                vBuckets = getClusterBuckets(vNode, gvArgs['user'], gvArgs['password'])
                if gvArgs['verbose']:
                    print ("%s [%s] : %s " % (vClstr, vNode, str(vBuckets)) )
                
                for vBkt in vBuckets:
                    logger.debug("Get bucket Info: %s" % vBkt)
                    #vBktInfo = getBucketInfo(vBkt, vNode, lvAuthCreds)
                    #print("   %s : %s" % (vBkt, str(vBktInfo)))
                    monBucket(vBkt, vNode, lvAuthCreds, gvArgs['verbose'], pSNOW = vSNOW)


    return True


# ------------------------------------------------------------------------------------------------------------------------


if __name__ == "__main__":

    gvArgs = get_args()

    logNamePrefix = 'monBucketHealth'
    if gvArgs['debug']:
        vLogName = init_logger(logNamePrefix, logging.DEBUG)
    else:
        vLogName = init_logger(logNamePrefix, logging.INFO)

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info(
                "Enter %s\'s Password   : " % gvArgs['user'])

    logger.debug("Args: " + str(gvArgs))

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password'])):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        print("ERROR: Connection using %s failed" % gvArgs['user'])
        print("ERROR: Please verify credentials")
        print("ERROR: Check log (%s) for details" % vLogName)
        exit(-1)
    else:
        logger.info("Credentials verified")
        #print("Credentials verified")

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    if gvArgs['debug'] or gvArgs['verbose']:
        for k in gvArgs.keys():
            if k == 'password':
                print ("%15s: %s" % (k, gvArgs[k].replace(gvArgs['password'], '*'*len(gvArgs['password']))  ) )
            else:
                print ("%15s: %s" % (k, gvArgs[k]))
    logger.info("----------"*12)
    main( gvArgs)
    logger.info("----------"*12)

exit(0)
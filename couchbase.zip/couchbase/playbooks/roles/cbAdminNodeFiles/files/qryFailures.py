#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2021.09.15
# Purpose : This script will report the number of query failures/timeouts in the cluster in the last hour.
#           This script is a predecessor to monitoring the query failures/timeouts
#           Uses the couchbase SDK to connect to the cluster and run a query against completed_requests.

import sys
import os
#import json
import pprint
import argparse
import logging

from datetime import datetime

from bbc_log.dba_log import init_logger
from bbc_sec.get_creds import get_user_info
from bbc_cb.env_config import getClusterNames
from bbc_cb.cb_api import verifyAdminConnection
from bbc_cb.env_detail import CBENV
from bbc_cb.cb_monitor import monQueryTimeouts
from bbc_email.dba_email import send_email

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------------------------------


def get_args():
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser(prog="qryFailures.py",
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                     description='''
      Script verify status of all or one Couchbase Cluster.
      ''')
    parser.add_argument(
        '-u', '--user', help='Admin Account to be used', required=False)
    parser.add_argument('-c', '--cluster', help='Cluster Name [default: all]', default='all', required=False)
    parser.add_argument('-p', '--password', help='Admin Password to be used', required=False)
    parser.add_argument('-e', '--env', help='Life Cycle Environment - i (int), q (qa), p (prod)', default='iqp', required=False)
    parser.add_argument('-d', '--debug', action='store_true', help='Run in DEBUG mode', required=False)
    parser.add_argument('-t', '--test', action='store_const', const='TEST', help='ServiceNow Instance - TEST/[PROD]', default='PROD', required=False)
    parser.add_argument('-v', '--verbose', action='store_true', help='Get failed query details', default=False, required=False)
    parser.add_argument('-s', '--silent', action='store_true', help='Silent execution - email output', default=False, required=False)
    parser.add_argument('--period', help='time period [default: -1]', default=-1, required=False)
    parser.add_argument('--unit', help='time period Unit - hour|day [default: hour]', default='hour', required=False)

    return vars(parser.parse_args())


def main( gvArgs):
    logger.debug("Main function")
    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    vlResults = []

    if (gvArgs['cluster'] == 'all' and gvArgs['env'] == 'iqp' ):
        # Traverse the CBENV and list all clusters
        for e in CBENV.keys():
            for vClstr in sorted(CBENV[e].keys()):
                vRC = monQueryTimeouts(vClstr, (gvArgs['user'],gvArgs['password']), gvArgs['test'], gvArgs['period'], gvArgs['unit'], gvArgs['verbose'])
                #print(vRC)
                vlResults.append(vRC)
                
    elif (gvArgs['cluster'] == 'all' and  gvArgs['env'] != 'iqp' ):
        # traverse received environments
        for e in (list(gvArgs['env'])):
            if e in CBENV.keys():
                for vClstr in sorted(CBENV[e].keys()):
                    vRC = monQueryTimeouts(vClstr, (gvArgs['user'],gvArgs['password']), gvArgs['test'], gvArgs['period'], gvArgs['unit'], gvArgs['verbose'])
                    #print(vRC)
                    vlResults.append(vRC)
                    
    elif (gvArgs['cluster'] != 'all'):
        # Allow for multiple clusters to be passed at once
        vClusterList = gvArgs['cluster'].replace(" ", ",").split(",")
        logger.info("Cluster List: %s" % str(vClusterList))
        for vClstr in vClusterList:
            #if gvArgs['cluster'] not in getClusterNames():
            if vClstr not in getClusterNames():
                print ("ERROR: cluster %s does not exist." % (vClstr))
            else:
                #print (vClstr)
                vRC = monQueryTimeouts(vClstr, (gvArgs['user'],gvArgs['password']), gvArgs['test'], gvArgs['period'], gvArgs['unit'], gvArgs['verbose'])
                #print(vRC)
                vlResults.append(vRC)
                
    return vlResults


# ------------------------------------------------------------------------------------------------------------------------


if __name__ == "__main__":

    gvArgs = get_args()

    logNamePrefix = 'qryFailures'
    if gvArgs['debug']:
        vLogName = init_logger(logNamePrefix, logging.DEBUG)
    else:
        vLogName = init_logger(logNamePrefix, logging.INFO)

    if gvArgs['env'] not in 'iqp':
        logger.error("ERROR: Invalid environment provided: %s" % gvArgs['env'])
        if not gvArgs['silent']:
            print("ERROR: Invalid environment provided: %s" % gvArgs['env'])
        sys.exit("Invalid parameter")

    if gvArgs['user'] == None or gvArgs['user'] == '':
        gvArgs['user'] = os.environ.get('MON_USER')
        gvArgs['password'] = os.environ.get('MON_PSWD')
    else:
        if gvArgs['password'] == None or gvArgs['password'] == '':
            gvArgs['password'] = get_user_info(
                "Enter %s\'s Password   : " % gvArgs['user'])

    logger.debug("Args: " + str(gvArgs))

    if not verifyAdminConnection((gvArgs['user'], gvArgs['password'])):
        logger.error("ERROR: Connection using %s failed" % gvArgs['user'])
        logger.error("ERROR: Please verify credentials")
        sys.exit("Connection using %s failed" % gvArgs['user'])
        #print("ERROR: Connection using %s failed" % gvArgs['user'])
        #print("ERROR: Please verify credentials")
        #print("ERROR: Check log (%s) for details" % vLogName)
        #exit(-1)
    else:
        logger.info("Credentials verified")
        #print("Credentials verified")

    lvAuthCreds = (gvArgs['user'], gvArgs['password'])

    if gvArgs['debug']:
        for k in gvArgs.keys():
            if k == 'password':
                print ("%15s: %s" % (k, gvArgs[k].replace(gvArgs['password'], '*'*len(gvArgs['password']))  ) )
            else:
                print ("%15s: %s" % (k, gvArgs[k]))

    vResList = main( gvArgs)
    logger.debug("Main Results: %s" % str(vResList))

    vFormattedResult = "Failed/timed out query report for the last %s %s(s) \n\n %s " % ( gvArgs['period'], gvArgs['unit'], pprint.pformat(vResList, width=150))

    if not gvArgs['silent']:
        print (vFormattedResult)
    else:
        try:
            vDBAEmail = os.environ.get('DBA_EMAIL')
            vHOST = os.environ.get('HOST_ALIAS')
            vFrom = "%s@bbc.com" % vHOST

            send_email ( Subject = "Couchbase Query Failures Report - %s" % (datetime.now().strftime("%Y%m%d.%H%M")), From = vFrom, To = vDBAEmail, Body = vFormattedResult )
        except:
            print("ERROR: Could not send email")

exit(0)
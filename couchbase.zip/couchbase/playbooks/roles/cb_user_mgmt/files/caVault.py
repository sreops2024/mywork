
from os import getlogin
from bbc_log.dba_log import *
from bbc_sec.passwd_gen import pwd_gen_ca

#from bbc_sec.cb_cyberark import *
from bbc_sec.cb_cyberark import getAcctDetails, getCyberarkToken, caLogoff
from bbc_sec.cb_cyberark import getAcctPassword, createCAAccount, caResetPassword
from bbc_sec.cb_cyberark import getCyberarkPass


logger = logging.getLogger ( __name__ )


class caAcct:

    logger = logging.getLogger ( __name__ )

    gvSep = '.'
    gvCAUnavailable = {'bbc_err_code': 1000, 'bbc_err_msg': 'Cyberark Information Unavailable'}


    def __init__ (self, pName, pBucket = None, pCAInfo = gvCAUnavailable, pSetPass = None, vSep = gvSep):
        self.status = 'init'
        self.vCADetails = pCAInfo
        self.passSource = None

        # Get OS loging information, for auditing purposes.
        self.__dba = getlogin()

        logger.debug ("CA Info: %s" % str(self.vCADetails).replace(self.vCADetails['restpass'], '*' * len(self.vCADetails['restpass'])))

        if 'bbc_err_code' in self.vCADetails.keys():
            logger.error('ERROR: Could not get all Cyberark details.')
            exit(-2)
        
        try:
            if self.vCADetails['token'] != None:
                self.tmpDtls = getAcctDetails( self.vCADetails['baseurl'], self.vCADetails['token'], self.vCADetails['safe'], pBucket + vSep + pName )

                if 'password' not in self.tmpDtls.keys():
                    self.tmpDtls['password'] = getCyberarkPass (pName, 'south', self.vCADetails['safe'], self.vCADetails['server'])['password']
                    self.passSource = 'Cyberark AD entry'
                else:
                    self.status = 'ACCT FOUND'
                    self.passSource = 'Cyberark entry'
            else:
                self.tmpDtls = {"bbc_err_code" : "Unable to get account details"}
                self.status = 'VAULT FAILURE'

        except Exception as e:
            logger.error("ERROR getting Cyberark information")
            logger.error("ERROR: Token: {0}".format(self.vCADetails['token']))
            logger.error("ERROR: exception: %s" % str(e))
            self.status = 'FAILURE'

        if "bbc_err_code" in self.tmpDtls.keys():
            # The account was not found or was not unique enough.
            logger.warning("WARNING: Account name not found or not unique enough.")
            self.status = 'ACCT NOT FOUND'

            self.__acctId = None
            self.userName = pName
            self.bucketName = pBucket

            if pSetPass == None and (self.passSource == None or self.tmpDtls['password'] == ''):
                logger.info ("Password not received, generate one.")
                self.__password = pwd_gen_ca(20,2,4,1)
                self.passSource = "Script generated"
            else:
                logger.info ("Password received, use it")
                if pSetPass == None:
                    self.__password = self.tmpDtls['password']
                else:
                    self.__password = pSetPass
                    self.passSource = "Password provided"

            self.__newPass = None
            self.safeName = pCAInfo['safe']
            self.folder = None
            self.address = 'CB'
            self.platformId = pCAInfo['platform']
            self.acctName = None
            self.deviceType = "Database"
            self.comments = "created by CB admin scripts [{0}]".format(self.__dba)
            self.accountName = "{0}{1}{2}{3}{4}".format(self.address, vSep, self.bucketName, vSep, self.userName)
        
        else:
            # Account name found.  Process it.
            try:
                self.__acctId = self.tmpDtls['id']
                self.__password = getAcctPassword(self.vCADetails['baseurl'], self.vCADetails['token'], self.__acctId)
                self.__newPass = pSetPass
                self.status = 'ACCT FOUND PSWD'
                self.passSource = "Cyberark provided"
                #print("PassSource: %s" % self.passSource)
            except Exception as e:
                logger.warning("WARNING: Account ID not available, yet")
                logger.error ("Error: %s" % str(e) )
                self.__acctId = None
                self.__password = 'na'
                self.passSource = 'na'
                #print("PassSource: %s" % self.passSource)

            self.accountName = self.tmpDtls['name']
            self.safeName = self.tmpDtls['safeName']
            self.folder = 'Root'
            self.address = self.tmpDtls['address']
            self.userName = self.tmpDtls['userName']
            self.comments = self.tmpDtls['platformAccountProperties']['Comments']
            self.bucketName = self.tmpDtls['platformAccountProperties']['Database']
            self.port = self.tmpDtls['platformAccountProperties']['Port']
            self.platformId = self.tmpDtls['platformId']
            self.deviceType = "Database"
                 


    def __str__( self ):
        '''
        Print Cyberark account information
        '''

        #vStr = ("---------" * 10) + "\n"
        #vStr += ("Account Name: {0} [{1}]".format( self.accountName, self.__acctId )) + "\n"
        #vStr += ("User Name   : {0}".format( self.userName)) + "\n"
        #vStr += ("Password    : {0}".format( '*' * len(self.__password))) + "\n"
        ##vStr += ("Password    : {0} => {1}".format( self.__password, self.__newPass)) + "\n"
        #vStr += (" .. source  : {0}".format( self.passSource )) + "\n"
        #vStr += ("Safe Name   : {0}".format( self.safeName)) + "\n"
        #vStr += ("Bucket Name : {0}".format( self.bucketName)) + "\n"
        #vStr += ("Platform ID : {0}".format( self.platformId)) + "\n"
        #vStr += ("Device Type : {0}".format( self.deviceType)) + "\n"
        #vStr += ("Comments    : {0}".format( self.comments)) + "\n"
        #vStr += ("*** Status  : {0}".format( self.status))  + "\n"
        #vStr += ("Token       : {0}{1}{2}".format( self.vCADetails['token'][:10], '.'*10, self.vCADetails['token'][-10:])) + "\n"
        #vStr += ("---------" * 10) + "\n"

        return self.getStr()
    

    def __del__( self ):
        if self.vCADetails['token'] == None:
            logger.warning("WARNING: Invalid/unavailable token - can't logoff of cyberArk")
        else:
            caLogoff(self.vCADetails['baseurl'], self.vCADetails['token'])


    def acctId( self ):
        return self.__acctId


    def getCreds( self ):
        return {self.userName : self.__password}


    def getStr( self ):
        '''
        Return String with  Cyberark account information
        '''

        vStr = ("---------" * 10) + "\n"
        vStr += ("Account Name: {0} [{1}]".format( self.accountName, self.__acctId )) + "\n"
        vStr += ("User Name   : {0}".format( self.userName)) + "\n"
        vStr += ("Password    : {0}".format( '*' * len(self.__password))) + "\n"
        #vStr += ("Password    : {0} => {1}".format( self.__password, self.__newPass)) + "\n"
        vStr += (" .. source  : {0}".format( self.passSource )) + "\n"
        vStr += ("Safe Name   : {0}".format( self.safeName)) + "\n"
        vStr += ("Bucket Name : {0}".format( self.bucketName)) + "\n"
        vStr += ("Platform ID : {0}".format( self.platformId)) + "\n"
        vStr += ("Device Type : {0}".format( self.deviceType)) + "\n"
        vStr += ("Comments    : {0}".format( self.comments)) + "\n"
        vStr += ("*** Status  : {0}".format( self.status))  + "\n"
        vStr += ("Token       : {0}{1}{2}".format( self.vCADetails['token'][:10], '.'*10, self.vCADetails['token'][-10:])) + "\n"
        vStr += ("---------" * 10) + "\n"

        return vStr


    def password( self ):
        return self.__password


    def setPassword(self, pPassword):
        '''
        Sets the password property to received value.
        '''

        if self.status == 'ACCT NOT FOUND':
            self.__password = pPassword
        else:
           self.__newPass = pPassword
        return True

    def store( self ):
        '''
        Creates the account in cyberark.
        Will set the account_id from response.
        '''

        logger.debug("in caCreate")

        if self.vCADetails['token'] == None:
            logger.warning("WARNING: Token is invalid/unavailable")
            self.comments = "Token invalid/unavailable"
            self.platformId = ''
            self.deviceType = ''
            return False

        # If the account does not exist in Cyberark, then create it.
        if self.status == 'ACCT NOT FOUND':
            logger.info ("{0} - Creating account".format( self.status ))
            vPayload = {
                "safeName": self.safeName,
                "deviceType": self.deviceType,
                "platformId": self.platformId,
                "name": self.accountName,
                "secretType": "password",
                "secret": self.__password,
                "secretManagement": { "automaticManagementEnabled": False,
                                      "manualManagementReason": "Application Service Account" },
                "platformAccountProperties": { 
                    "userName": self.userName, 
                    "Comments": self.comments,
                    "Port": "8091", 
                    "database": self.bucketName, 
                    "address" : "CB"}
                }

            vRet = createCAAccount( self.vCADetails['baseurl'], self.vCADetails['token'], vPayload )

            if "ErrorCode" in vRet.keys():
                logger.warning ("WARNING: Could not create the Account in Cyberark")
                logger.warning ("WARNING: {0}".format( str( vRet )))
                return False
            else:
                self.status = "ACCT CREATED"
                self.__acctId = vRet["id"]
                return True

        # If the account exits, then update the password.
        if self.status == 'ACCT FOUND PSWD':
            logger.info ("{0} - Update password".format( self.status ))
            return self.storePassword()

        # Catch any other status, just in case.
        logger.warning ("This should not happen - Status {0}".format( self.status ))
        return False

    def storePassword( self ):
        '''
        Reset the password in Cyberark to the new password (self.__newPass )
        '''

        # If status is not ACCT FOUND then exit.
        if self.status not in [ 'ACCT FOUND', 'ACCT FOUND PSWD' ]:
            #print( "huh: *{0}* ?? *{1}*".format( "ACCT FOUND PSWD", self.status))
            logger.warning( "{0} - Cannot reset password if account is not in Cyberark".format( self.status ))

        else:
            if caResetPassword( self.vCADetails['baseurl'], self.vCADetails['token'], self.__acctId, self.__newPass ):
                # Password reset successful.
                logger.info( "Password Reset Successful: {0}".format( self.__acctId ))
                self.__password = self.__newPass
                self.__newPass = None
                self.status = 'ACCT RESET'
                return True
            else:
                #Password reset Failed
                logger.warning( "Password Reset Failed: {0}".format (self.__acctId ))
                return False

        return False


    def tokenOK( self ):
        if self.vCADetails['token'] != '':
            logger.info( "Token is available")
            return True
        else:
            logger.info( "Token is NOT available")
            return False


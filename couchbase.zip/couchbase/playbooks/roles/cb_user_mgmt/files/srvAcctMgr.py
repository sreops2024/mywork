#!/bin/python3

# Author  : Victor Zuniga
# Date    : 2022.11.25
# Purpose : Script that will manage the service (local) accounts in our couchbase clusters.
#
# 2023.05.24 Victor Zuniga        Hide password from debug log call.

import os
import argparse
import logging

from bbc_log.dba_log import init_logger
from bbc_cb.cbServiceAcct import cbSrvAcct

def get_args() :
    """ Set up the arguments and return the python dictionary containing the received values """
    parser = argparse.ArgumentParser ( prog = "srvAcctMgr.py",
                                      formatter_class=argparse.RawDescriptionHelpFormatter,
                                      description=
       '''
       Script will manage service accounts in couchbase.
       ''' )

    parser.add_argument ( '-a', '--acct', help = 'Service Account Name', required = False)
    parser.add_argument ( '-b', '--bucket', help = 'Bucket Name', required = False)
    parser.add_argument ( '-n', '--name', help = 'Account Name', required = False)
    parser.add_argument ( '-p', '--password', help = 'Account Password', required = False )
    parser.add_argument ( '-d', '--debug', action = 'store_true', help = 'Run in DEBUG mode', required = False )
    parser.add_argument ( '-r', '--remove', action ='store_true', help = 'remove the account, if present', required = False )
    parser.add_argument ( '-f', '--file', help = 'Batch process using file', required = False )
    parser.add_argument ( '--verify', action = 'store_true', help = 'Verify the account exists in Cyberark', required = False )
    
    return  vars(parser.parse_args() )

def manageBulkAccounts( pFile, pVerifyOnly = False ):
    '''
    Manage the bulk creation of accounts, provided in the received file.
    '''

    import yaml

    if not os.path.isfile( pFile ):
        # File does not exist... exit.
        print( "ERROR: File [%s] does not exist." % pFile )
        return False

    else:
        with open( pFile, 'r') as file:
            vUserData = yaml.safe_load( file )

    #print( "File %s loaded" % pFile )
    #print( "Contents: %s" % str(vUserData ) )


    for vAcct in vUserData.keys():
        logger.debug( "Verify %s" % vAcct )
        print( '=' * 120 )
        print( "Processing %s" % vAcct, end='' )
        
        if verifyAcctInfo( vAcct, vUserData[vAcct] ):
            logger.debug( "Account %s verified" % vAcct )
            print( "... verified" )

            # Prepare account info
            try:
                vAccount = {}
                vAccount['acct'] = vAcct
                vAccount['bucket'] = vUserData[vAcct]['bucket']

                try:
                    vAccount['name'] = vUserData[vAcct]['name']
                except:
                    logger.debug( "Name/Desc not provided, generate one = acct + bucket" )
                    vAccount['name'] = "%s %s" % (vAcct, vUserData[vAcct]['bucket'])
                    logger.debug( "Name: %s" % vAccount['name'] )

                try:
                    vAccount['password'] = vUserData[vAcct]['password']
                except:
                    logger.debug( "Password not provided, set to none" )
                    vAccount['password'] = None

                try:
                    vAccount['remove'] = vUserData[vAcct]['remove'].upper()
                except:
                    logger.debug( "Remove not provided, set to none" )
                    vAccount['remove'] = None
            except:
                logger.warning( "WARNING: Could not set acct or bucket which are required." )
                logger.warning( "Info: %s" % str( vUserData[vAcct] ) )
                print( "WARNING: Could not set acct or bucket which are required." )
                print( "Info: %s" % str( vUserData[vAcct] ) )

            #print( "Info to be sent....")
            #print( "... %s" % str(vAccount) )

            #print( '-' * 80 )
            #if pVerifyOnly != True:
            #    vRet =  manageLocalServiceAcct( vAccount )
            #    logger.debug( "Account: %s - return code: %s" % (vAcct, str(vRet)) )
            #else:
            #    logger.debug( "Only verifying the accounts" )

            vAccount['verify'] = pVerifyOnly
            vRet =  manageLocalServiceAcct( vAccount )

            #print( '-' * 80 )
            print()

        else:
            logger.warning( "WARNING: Account verification failed for %s" % vAcct )
            logger.warning( "WARNING: Acct Info: %s" % str(vUserData[vAcct]) )
            print()
            print( "WARNING: Account verification failed for %s" % vAcct )

    return True



def verifyAcctInfo ( pAcct, pAcctInfo ):
    '''
    Verify the account, pAcct, is correct, including the environment suffix.
    Ensure the proper information is included in the account info:
    - bucket
    - password
    - name
    - remove
    and that their values make sense, ie, remove is Y|N, or even true|false (reset to Y|N)
    Check bucket name and determine if valid one.
    '''
    
    from bbc_cb.env_config import getEnvClusterNames, getRandomClusterNode
    from bbc_fileSec.encServer import getClusterCred
    from bbc_cb.cb_api import getClusterBuckets
    from bbc_misc.bbc_os import getOSVar

    logger.debug( "verifyAcctInfo: %s" % pAcct )
    for k in pAcctInfo.keys():
        if k == 'password':
            logger.debug( "    %s - %s" % (k, '*' * len(pAcctInfo[k]) ))
        else:
            logger.debug( "    %s - %s" % (k, pAcctInfo[k]) )

    # Verify account suffix [s,i,q,p]
    vAcctSuffix = pAcct[-1]

    if vAcctSuffix in ['s', 'i', 'q', 'p']:

        # Check properties provided
        for vProp in pAcctInfo.keys():
            if vProp not in ['bucket', 'name', 'password', 'remove']:
                logger.warning( "WARNING: invalid property used: %s for account: %s" % (vProp, pAcct) )
                print( "WARNING: invalid property used: %s for account: %s" % (vProp, pAcct) )
                return False


        # Verify bucket
        vBucketFound = False
        for vCluster in getEnvClusterNames( vAcctSuffix ):
            logger.debug ("Checking Cluster: %s" % vCluster )
            if pAcctInfo['bucket'] in getClusterBuckets( getRandomClusterNode( vCluster), 'dbadmin', getClusterCred( 'dbadmin', vCluster, getOSVar( 'CB_KEY_DIR'))):
                vBucketFound = True

        logger.debug( "Account looks OK: %s" % pAcct )
        logger.debug( "Bucket [%s] - Found: %s" % (pAcctInfo['bucket'], str(vBucketFound)) )

        return True

    else:
        print( "WARNING: Account [%s] does not meet service account requirements" % pAcct )

    return False


def manageLocalServiceAcct( pArgs ):
    '''
    Manage the service account.
    '''

    vAcctName = pArgs['acct']
    vAcctDesc = pArgs['name']
    vBucketName = pArgs['bucket']
    vPassword = pArgs['password']

    logger.info ("Account Name: %s" % vAcctName)
    logger.info ("Account Desc: %s" % vAcctDesc)
    logger.info ("Bucket Name : %s" % vBucketName)
    
    try:
        logger.info ("Password    : %s" % ('*' * len(vPassword) ))
    except:
        logger.info ("Password    : %s" % vPassword )

    logger.debug ("Account Name: %s" % vAcctName)
    logger.debug ("Account Desc: %s" % vAcctDesc)
    logger.debug ("Bucket Name : %s" % vBucketName)
    if vPassword is None:
        logger.debug ("Password    : %s" % ( ''  ))
    else:
        logger.debug ("Password    : %s" % ( '*' * len(vPassword) ))
    logger.debug ("Remove      : %s" % gvArgs['remove'])
    logger.debug ("Debug       : %s" % gvArgs['debug'])
    
    if pArgs['remove']:
        logger.info ("*** Removing account: %s" % vAcctName )

    if vAcctDesc == '' or vAcctDesc is None:
        logger.debug ("No account description provided, set to acct name and bucket name")
        vAcctDesc = "%s [ %s ]" % (vAcctName, vBucketName)
        logger.debug ("Account Desc: %s" % vAcctDesc)

    vSrvAcct = cbSrvAcct ( vAcctName, vAcctDesc, vBucketName, vPassword )

    #if pArgs['debug']:
    #    print( vSrvAcct )
    #print (vSrvAcct) if pArgs['debug'] else None
    print (vSrvAcct) if gvArgs['debug'] else None

    if pArgs['verify'] == True:
        # Print the Account info, return true
        print (vSrvAcct)
        logger.info ("Verify only, return")
        return True

    if pArgs['remove'] == True or pArgs['remove'] == 'Y':
        # Remove the account
        if vSrvAcct.existsNone():
            # Account does not exist in any cluster
            logger.warning("WARNING: Account %s does not exit in %s" % (vSrvAcct.name, str(list(vSrvAcct.clusters.keys()))))
            print ("WARNING: Account %s does not exit in %s" % (vSrvAcct.name, str(list(vSrvAcct.clusters.keys()))))
        else:
            if vSrvAcct.delete():
                logger.info ("Acct %s deleted in %s" % (vSrvAcct.name, str(list(vSrvAcct.clusters.keys()))))
                print ("Acct %s deleted in %s" % (vSrvAcct.name, str(list(vSrvAcct.clusters.keys()))))
            else:
                logger.warning("WARNING: Could not delete account %s in all needed clusters %s" % (vSrvAcct.name, str(list(vSrvAcct.clusters.keys()))))
                for vClstr in vSrvAcct.clusters:
                    logger.warning("WARNING: %s: %s" % (vClstr, vSrvAcct.clusters[vClstr].status() ))

    else:
        # Create the account
        if vSrvAcct.create():
            logger.info ("Acct %s created in %s" % (vSrvAcct.name, str(list(vSrvAcct.clusters.keys()))))
            print ("Acct %s created/modified in %s" % (vSrvAcct.name, str(list(vSrvAcct.clusters.keys()))))

        else:
            logger.warning("WARNING: Could not create account %s in all needed clusters %s" % (vSrvAcct.name, str(list(vSrvAcct.clusters.keys()))))
            for vClstr in vSrvAcct.clusters:
                logger.warning("WARNING: %s: %s" % (vClstr, vSrvAcct.clusters[vClstr].status() ))
        
    return True

if __name__ == "__main__":
    logger = logging.getLogger ( __name__ )

    gvArgs = get_args()

    logNamePrefix = 'srvAcctMgr'

    if gvArgs['debug']:
        vLogName = init_logger( logNamePrefix, logging.DEBUG)    
    else:
        vLogName = init_logger( logNamePrefix, logging.INFO)

    logger.info ('=' * 80)
    logger.info ("Args: %s" % str(gvArgs))

    if ( gvArgs['acct'] is None or gvArgs['bucket'] is None ) and gvArgs['file'] is None:
        logger.warning ("WARNING: not enough parameters provided")
        logger.warning ("WARNING: either account and bucket, or file parameters must be provided")
        print ("\nWARNING: not enough parameters provided")
        print ("WARNING: either account and bucket, or file parameters must be provided\n\n")
        exit(1)

    if ( gvArgs['acct'] is not None or gvArgs['bucket'] is not None ) and gvArgs['file'] is not None:
        logger.warning( "WARNING: too many parameters provided" )
        logger.warning( "WARNING: cannot provide account (and/or bucket) and file parameters together.  Please chose single method." )
        print( "WARNING: too many parameters provided" )
        print( "WARNING: cannot provide account (and/or bucket) and file parameters together.  Please chose single method." )
        exit(1)

    if gvArgs['file'] is not None:
        logger.info( "Process file: %s" % str(gvArgs['file']) )
        print( "Process file: %s" % str(gvArgs['file']) )
        if manageBulkAccounts( gvArgs['file'], gvArgs['verify'] ):
            print( "Success" )
        else:
            print( "Failure" )

        exit(0)
    else:
        logger.info( "No file provided ... process individual account" )
        print( "No file provided ... process individual account" )
        #exit(0)

    if manageLocalServiceAcct( gvArgs ):
        logger.info ("srvAcctMgr - Done OK")
        exit (0)
    else:
        logger.info ("srvAcctMgr - Done NOT OK")
        exit (1)
    logger.info ('=' * 80)

# ------------------------------------------------------------------------------------------------------------------------
# Author : Victor Zuniga
# Date   : 2022.09.13
# Purpose: Define functions for cyberark opertations.

# ------------------------------------------------------------------------------------------------------------------------

import sys
import json
import requests

from bbc_log.dba_log import *

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------------------------------------------------------------
# Functions
# ------------------------------------------------------------------------------------------------------------------------

def getRESTPass( pRestUser = 'REST_Couchbase', pSafe = 'US_D_Couchbase_Test', pServer = '10.184.24.72', pAppID = 'Couchbase_AAM', pFolder = 'Root' ):
    '''
    Returns the Rest Credentials to connect to Cyberark.
    '''
    
    from subprocess import PIPE, run

    logger.debug ("User: %s - Safe: %s - Server %s - AppID: %s - Folder: %s" % (pRestUser, pSafe, pServer, pAppID, pFolder) )

    #vCmd = '/opt/CARKaim/sdk/clipasswordsdk GetPassword -p AppDescs.AppID=%s -p Query="Safe=%s;Folder=%s;Object=%s-%s" -o Password' % ( pAppID, pSafe, pFolder, pServer, pRestUser)
    vCmd = '/opt/CARKaim/sdk/clipasswordsdk GetPassword -p AppDescs.AppID=%s -p Query="Safe=%s;Folder=%s;Object=%s" -o Password' % ( pAppID, pSafe, pFolder, pRestUser)

    logger.debug ("Command: %s" % vCmd)

    vRes = run (vCmd, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)

    vRet = {}
    vRet['password'] =  vRes.stdout.strip()
    vRet['err'] = vRes.stderr
    if vRes.stderr != '':
        vRet['bbc_err_code'] = '1001'
        vRet['bbc_err_msg'] = 'ERROR: Cyberark Agent could not get credentials'
        
        logger.error ("ERROR: Cyberark Agent could not get credentials")

    return vRet


def getCyberarkPass( pUserAcct, pDomain = 'south',  pSafe = 'US_D_Couchbase_Test', pServer = '10.184.24.72', pAppID = 'Couchbase_AAM', pFolder = 'Root', pSep = '-' ):
    '''
    Returns the password stored in Cyberark for the user account, if found.  If not found, then return error message.
    '''

    from subprocess import PIPE, run
    
    logger.debug( "User: %s - Domain: %s - Safe: %s" % (pUserAcct, pDomain, pSafe) )

    vCmd = '/opt/CARKaim/sdk/clipasswordsdk GetPassword -p AppDescs.AppID=%s -p Query="Safe=%s;Object=%s%s%s" -o Password' % ( pAppID, pSafe, pDomain, pSep, pUserAcct )

    logger.warning( "Command: %s" % vCmd )

    vRes = run( vCmd, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True )

    vRet = {}
    vRet['password'] = vRes.stdout.strip()
    vRet['err'] = vRes.stderr

    if vRes.stderr != '':
        vRet['bbc_err_code'] = '1002'
        vRet['bbc_err_msg'] = 'ERROR: Cyberark Agent could not get credentials'

        logger.error ("ERROR: Cyberark Agent could not get credentials")

    return vRet


def getCyberarkDtl ():
    '''
    Return Cyberark variables needed to communicate with the appropriate safe.
    '''

    import os

    vCADict = {}
    try:
        vCADict['restuser'] = os.environ['CYBERARK_USER']
        vCADict['safe'] = os.environ['CYBERARK_SAFE']
        vCADict['server'] = os.environ['CYBERARK_SERVER']
        vCADict['platform'] = os.environ['CYBERARK_PLAT']
        vCADict['folder'] = os.environ['CYBERARK_FOLDER']
        vCADict['appid'] = 'Couchbase_AAM'
        vCADict['baseurl'] = os.environ['CYBERARK_BASE_URL']
        vCADict['restpass'] = getRESTPass( vCADict['restuser'], vCADict['safe'], vCADict['server'], vCADict['appid'], vCADict['folder'] )['password']

        logger.info ("Cyberark Details: %s" % str(vCADict).replace(vCADict['restpass'], '*' * len(vCADict['restpass'])))

    except:
        vCADict['bbc_err_code'] = '1002'
        vCADict['bbc_err_msg'] = 'ERROR reading Cyberark environment variables'
        logger.error ("Error: [%s] - %s" % (vCADict['bbc_err_code'], vCADict['bbc_err_msg'] ))

    return vCADict


def getCerFileLoc():
    
    from os.path import exists

    if exists('/etc/ssl/certs/ca-bundle.crt'):
        vCert = '/etc/ssl/certs/ca-bundle.crt'
    else:
        vCert = '/etc/pki/tls/certs/ca-bundle.crt'

    logger.debug( "Cert file: %s" % vCert )

    return vCert


def getCyberarkToken( pBaseURL, pUser, pPassword):
    '''
    Logs into Cyberark and returns the token to be used to authenticate in later calls.
    '''

    vCert = getCerFileLoc()

    vURL = "{0}/API/Auth/Cyberark/Logon".format(pBaseURL)
    vPayload = "{\n\t\"username\": \"%s\",\n\t \"password\": \"%s\",\n\t\"concurrentSession\": \"%s\"\n}" % (pUser, pPassword, "true" )
    vHeaders = { 'Content-Type': 'application/json' }

    logger.debug("getCyberarkToken - URL    : %s" % vURL)
    logger.debug("getCyberarkToken - payload: %s" % vPayload) 
    logger.debug("getCyberarkToken - headers: %s" % vHeaders)

    vResponse = requests.request("POST", vURL, headers=vHeaders, data=vPayload, verify=vCert)

    if vResponse.status_code == 200:
        vToken = (vResponse.text).strip('\"')
        logger.debug ("Token: {0}".format(vToken))
    else:
        vToken = None
        logger.error ("ERROR: unable to log into Cyberark")
        logger.error ("ERROR: Token - [%s]" % vToken)

    return vToken


def getAcctDetails (pBaseURL, pToken, pSafe, pAcctString ):
    '''
    Search the cyberArk safe (pSafe) for accounts starting with pAcctString.  Ideally, the result set will be a single account.  If not, return an error.
    Return a dictionary with the details for the account.
        - 'AccountId', 'Safe', 'Folder', 'Name', 'UserName', 'PolicyID', 'DeviceType', 'Address', 'Comments'
    '''
    from json import loads as jsonLoad

    vCert = getCerFileLoc()

    vURL = "{0}/api/accounts?search={1}&searchType=contains&sort=UserName&filter=safeName eq {2}".format(pBaseURL, pAcctString, pSafe)

    vPayload = {}
    vHeaders = { 'Authorization': str(pToken) }

    logger.debug("getAcctDetails - URL    : %s" % vURL)
    logger.debug("getAcctDetails - payload: %s" % vPayload) 
    logger.debug("getAcctDetails - headers: %s" % vHeaders)

    try:
        vResponse = requests.request("GET", vURL, headers=vHeaders, data=vPayload, verify=vCert)

        logger.debug("Response: {0}".format(str(vResponse.text)))

        vRes = jsonLoad (vResponse.text)

        if vRes["count"] != 1:
            logger.error( "ERROR: Account search did not produced an unique ({0}) account.".format( vRes["count"] ) )
            return {"bbc_err_code": "{0} Records found".format( vRes["count"])}
        else:
            return vRes["value"][0]
    except Exception as e:
        logger.error ("URL: %s" % str(vURL))
        logger.error ("Headers: %s" % str(vHeaders))
        logger.error ("Payload: %s" % str(vPayload))
        logger.error ("ERROR: Could not get account details for {0}".format(pAcctString))
        logger.error ("ERROR: {0}".format(vResponse))
        return {"bbc_err_code": vResponse}


def getAcctPassword( pBaseURL, pToken, pAcctID ):
    '''
    Return the password stored in cyberark for the received account.
    '''
    
    from os import getlogin

    vCert = getCerFileLoc()
    vUSR = getlogin()

    vURL = "{0}/api/Accounts/{1}/Password/Retrieve".format( pBaseURL, pAcctID)

    vHeaders = {
                "Content-Type": "application/json",
                "Authorization": str(pToken)
            }

    vJSON = { "Reason": "Retrieved by Database Admin Script [{0}]".format(vUSR) }
    #vJSON = { "Reason": "Retrieved by Database Admin Script"}

    logger.debug("getAcctPassword - URL    : %s" % vURL)
    logger.debug("getAcctPassword - json   : %s" % str(vJSON)) 
    logger.debug("getAcctPassword - headers: %s" % str(vHeaders))

    try:
        vResponse = requests.request("POST", vURL, headers=vHeaders, json=vJSON, verify=vCert)
    except:
        logger.warning("WARNING: Could not get password for acct {0}".format( pAcctID))
        return None
    
    # Cyberark returns the password surrownded in double quotes, remove the first and last characters only.  Cannot remove all double quotes
    # in case there is a special character in the password; however unlikely.
    return vResponse.text[1:-1]


def createCAAccount(pBaseURL, pToken, pPayload):
    '''
    Function to create an account entry in Cyberark.
    Class variables will be reset after account creation, such as account id.
    '''

    vCert = getCerFileLoc()

    vURL = "{0}/api/Accounts".format( pBaseURL )

    vHeaders = {
                "Authorization": str(pToken)
            }

    vResponse = requests.request("POST", vURL, headers=vHeaders, json=pPayload, verify=vCert)

    logger.info( "Resp: %s" % str(vResponse.text))

    return json.loads(vResponse.text)


def caLogoff (pBaseURL, pToken):
    '''
    Log off using the current token
    '''

    vCert = getCerFileLoc()

    vURL = "{0}/api/Auth/Logoff".format( pBaseURL )
    vHeaders = { 'Content-Type': 'application/json' }

    vResponse = requests.request("POST", vURL, headers=vHeaders, verify=vCert)

    logger.info ('Logoff: {0}'.format(vResponse.text))

    return vResponse.text


def caResetPassword (pBaseURL, pToken, pAcctId, pNewPassword):
    '''
    Set the account's password to new value received.
    '''

    logger.debug ("caResetPassword - acct id: {0}".format( pAcctId ))

    vCert = getCerFileLoc()

    vURL = "{0}/api/accounts/{1}/password/update".format( pBaseURL, pAcctId )
    vHeaders = {
                "Authorization": str(pToken)
            }
    
    vData = { "ChangeEntireGroup": False, "NewCredentials": pNewPassword }

    logger.info( "URL: {0}".format( vURL ))
    logger.debug( "Headers: {0}".format( str( vHeaders )))
    logger.debug( "Data: {0}".format( str( vData )))
    logger.debug( "Cert: {0}".format( vCert ))

    vResponse = requests.request( "POST", vURL, headers=vHeaders, data=vData, verify=vCert )

    logger.error ("Response: {0}".format( str( vResponse )))

    if vResponse.status_code != 200:
        logger.warning( "WARNING: Could not reset password" )
        logger.warning( "{0}".format( vResponse.text ))
        return False

    return True




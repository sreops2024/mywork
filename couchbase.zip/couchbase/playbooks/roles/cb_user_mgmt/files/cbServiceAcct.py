# Author : Victor Zuniga
# Date   : 2022.11.10
# Purpose: Classes that will manage the couchbase service account management.

from bbc_log.dba_log import *
from bbc_sec.cb_cyberark import getCyberarkDtl,getCyberarkToken,getAcctDetails
from bbc_cb.cbAcct import cbAcct
from bbc_cb.caVault import caAcct
from bbc_sec.passwd_gen import pwd_gen_ca
from bbc_cb.cb_api import getClusterBuckets
from bbc_cb.env_config import getEnvClusterNames, getRandomClusterNode
from bbc_misc.bbc_os import getOSVar

logger = logging.getLogger( __name__ )

class cbSrvAcct:
    """ Class that will handle the service account management for couchbase. """

    def __init__(self, pName, pDesc, pBucket, pPassword = None):
        """
        Initialize the class with the following:
        - pName -- account name for the account.  Expected to have env suffix with the following options:
                        -s for Sandbox
                        -i for INT
                        -q for QA
                        -p for Prod
        - pDesc -- account description 
        - pBucket -- the bucket assiciated with the service/application account
        - pPassword -- use a defined password( to be used in case the account needs reset).  Default to None.

        Note: using the name suffix and bucket, the class will determin the cluster(s) where the account will be created.
        """

        logger = logging.getLogger(  __name__ )

        self.name = pName
        self.__password = pPassword
        self.desc = pDesc
        self.type = 'local'
        self.bucket = pBucket
        self.env = self.name[-1]
        #self.__adminAcct = pAdminCreds

        self.groups = "APP-%s" %( self.bucket)

        # Get info from Cyberark, if possible.
        self.vCALogin = getCyberarkDtl()
        self.vCALogin['token'] = getCyberarkToken( self.vCALogin['baseurl'], self.vCALogin['restuser'], self.vCALogin['restpass'] )
        self.caInfo = caAcct( self.name, self.bucket, self.vCALogin, self.__password, '.' )
        if self.caInfo.status in [ 'ACCT FOUND', 'ACCT FOUND PSWD']:
            #  Account info found in Cyberark
            self.foundInCyberark = True
            self.__password = self.caInfo.password()
        else:
            # Account NOT found in Cyberark
            self.foundInCyberark = False
            # Generate password, if not provided( is None)
            if self.__password is None:
                #self.__password = pwd_gen_ca()
                self.__password = self.caInfo.password()
            logger.debug( "string [%s]" % self.__password )

        # Get clusters in "env" with bucket 
        self.clusters = {}
        vTmpAuth =( getOSVar('MON_USER'), getOSVar('MON_PSWD' ))
         
        try:
            for vCluster in getEnvClusterNames( self.env):
                if self.bucket in getClusterBuckets( getRandomClusterNode( vCluster), vTmpAuth[0], vTmpAuth[1]):
                    #self.clusters.append(vCluster)
                    self.clusters[vCluster] = cbAcct( self.name, self.desc, self.__password, vCluster, self.type, pGroups = self.groups) 
        except: 
            # 
            pass


    def __str__(self):
        vStr =( "---------" * 15) + "\n"
        vStr +=( "CB Srv Account: {0}/{1}".format( self.name, "*" * len( self.__password) )) + "\n"
        #vStr +=( "CB Srv Account: {0}/{1}".format( self.name, self.__password )) + "\n"
        vStr +=( "Acct Type     : {0}".format( self.type)) + "\n"
        vStr +=( "Bucket        : {0}".format( self.bucket)) + "\n"
        vStr +=( "Groups        : {0}".format(str(self.groups))) + "\n"
        #vStr +=( "Cluster(s)    : {0}".format( str(self.clusters))) + "\n"
        vStr +=( "Cluster(s)    : {0}".format( list(set(self.clusters)))) + "\n"
        vStr +=( "\n")

        for lvClstr in self.clusters.keys():
            vStr += "    ---------\n"
            for k in self.clusters[lvClstr].getJSON().keys():
                vStr +=( "    %9s : %s\n" %(  k, self.clusters[lvClstr].getJSON()[k] ))

            vStr +=( "    %9s : %s\n" %(  'STATUS', self.clusters[lvClstr].status()['state']))

        vStr +=( "---------" * 15) + "\n"
        vStr +=( "\nCyberark Account: \n")
        vStr +=( self.caInfo.getStr() )
        vStr +=( "---------" * 15) + "\n"

        return vStr


    def allExist(self):
        ''' Returns True if the account exists in all necessary clusters '''
        
        vRet = False
        
        # If the cluster list is empty, return false.
        if self.clusters == {}:
            return False

        vTmpList = []
        for vClstr in self.clusters:
            vAcctExists = self.clusters[vClstr].acctExists()
            logger.info( "%s - acct exists: %s" %( self.name, vAcctExists ))
            vTmpList.append(vAcctExists)

        logger.info( "Acct Exists list: %s" % str(vTmpList))

        return( False not in vTmpList)

    def create(self):
        """
        Create the account(s) in the cluster(s) as needed.
        """

        logger.debug( "cbSrvAcct: create account(s)")

        # If cluster list is empty, do not create the account in cyberark.
        if self.clusters == {}:
            logger.warning( "WARNING: Cluster list is empty: %s" % str(self.clusters))
            return False

        # If account is not in Cyberark, store it.
        if self.caInfo.status == 'ACCT NOT FOUND':
            vRet = self.caInfo.store()

        if self.caInfo.status in ['ACCT FOUND', 'ACCT FOUND PSWD', 'ACCT CREATED']:

            if self.allExist():
                # All accounts exists.  Exit True, but add log message
                logger.warning( "WARNING: the account %s already exists in all the clusters as needed" % self.name)
                print( "WARNING: the account %s already exists in all the clusters as needed" % self.name)

                return True

            for vClstr in self.clusters:
                logger.info( "create %s acct in %s, groups: %s" %( self.clusters[vClstr].name, self.clusters[vClstr].node, self.clusters[vClstr].groups))
                logger.debug("acct info: %s" % str(self.clusters[vClstr].getJSON()))
                if self.clusters[vClstr].create():
                    #  Account created successfully
                    logger.info( "Account %s created successfully in %s" %( self.clusters[vClstr].name, self.clusters[vClstr].node))
                else:
                    logger.warning( "WARNING: Account %s NOT created successfully in %s" %( self.clusters[vClstr].name, self.clusters[vClstr].node))

        return True

    
    def delete(self):
        '''
        Delete the accounts in the respective clusters
        '''

        logger.debug("cbSrvAcct: delete account(s)")

        for vClstr in self.clusters:
            if self.clusters[vClstr].acctExists():
                logger.info( "delete %s acct in %s" %( self.clusters[vClstr].name, self.clusters[vClstr].node))
                logger.debug("acct info %s" % str(self.clusters[vClstr].getJSON()))
                if self.clusters[vClstr].delAcct():
                    # Account removed successfully
                    logger.info( "Account %s removed successfully from %s" %( self.clusters[vClstr].name, self.clusters[vClstr].cluster ))
                else:
                    logger.error( "ERROR: Account %s not removed from %s" %( self.clusters[vClstr].name, self.clusters[vClstr].cluster ))
            else:
                # Account does not exist
                logger.info( "Account %s does not exist in %s" %( self.clusters[vClstr].name, self.clusters[vClstr].cluster))

        #### Update information in Cyberark
        ## If account in in Cyberark, mark as retired

        return True


    def existsNone(self):
        '''Returns true when the account does not exist in any of the necessary clusters'''

        vRet = False
        vTmpList = []
        for vClstr in self.clusters:
            vAcctExists = self.clusters[vClstr].acctExists()
            logger.info( "%s - acct exists: %s" %( self.name, vAcctExists ))
            vTmpList.append(vAcctExists)

        logger.info( "Acct Exists list: %s" % str(vTmpList))

        return ( True not in vTmpList)


    def password( self ):
        '''Return the passowrd value'''
        return self.__password


    def setPassword( self, pPassword ):
        '''Set the password to be used in Couchbase and Cyberark.'''

        logger.debug( "Resetting password: %s" % ('*' * len( pPassword )))
        self.caInfo.setPassword( pPassword )
        self.__password = self.caInfo.password()

        if self.__password != pPassword:
            logger.warning( "WARNING: setPassword failed." )
            return False

        return True


    def status( self ):
        '''Return a dictionary of all account statuses'''

        vStatus = {}

        for vClstr in self.clusters:
            vStatus[vClstr] = self.clusters[vClstr].status()

        return vStatus


# Author  : Victor Zuniga
# Date    : 2019.06.03
# Purpose : Library/Module of credential related functions, both Oracle and Couchbase
#
# ------------------------------------------------------------------------------------------------------------------------
import sys
import os
import logging
import getpass

logger = logging.getLogger ( __name__ )

from bbc_sec.bbc_decode import *
from bbc_sec.passwd_gen import *

# ------------------------------------------------------------------------------------------------------------------------

def get_OMS_creds ( pUser ):
   """Return directory containing credential and OMS host information"""
   dInfo = {}

   cfgFile = '/tools/oracle/dba/oms/.' + pUser.lower() + '.oms'

   if os.path.isfile( cfgFile ):
      logger.debug ( 'File exists: ' + cfgFile )
   else:
      logger.error ( 'Error reading ' + cfgFile )

   l_cred_file =  open ( cfgFile, 'r') 
   for line in l_cred_file:
      vStr = decodeString( line.rstrip('\n') )
      if 'OMSPWD' in vStr:
         # str.replace ( str [ str.find ('=')+1:], '*' * (len(str) - str.find ('=')-1 ))
         logger.debug ( vStr.replace ( vStr [ vStr.find ('=')+1:], '*' * (len(vStr) - vStr.find ('=')-1 )) )
      else:
          logger.debug ( vStr )
      (sKey, sValue) = vStr.split ( '=' )
      dInfo[sKey] = sValue.rstrip()

   return dInfo

# ------------------------------------------------------------------------------------------------------------------------

def get_user_info ( pMsg ):
   """Return user provided string"""
   l_user_info = getpass.getpass ( pMsg )

   return l_user_info
  
# ------------------------------------------------------------------------------------------------------------------------

def get_verified_password ( pUser, pDefaultPwd, pLength=8, pUpper=1, pDigits=2, pSpecial=2 ):
   """
   Return a verified password for the received user
   If password received is null, then return the received default password.
   """

   vFailure = '-1'
   vPassword = ''
   vPassConfirm = ''
   bPwdMatched = False

   vLoopLimit = 3    # Use to limit the number of attempts to get a password.
   vLoopCounter = 0
   logger.debug ("Get password for user %s -- %d attempts." % (pUser, vLoopLimit) )
   print ("Leave password blank to use %s\'s OEM password..." % pUser)
   while not bPwdMatched:
      logger.debug ("Requesting Password")
      vPassword = getpass.getpass ("Enter %s\'s password: " % pUser )

      # Confirm Password
      logger.debug ("Requesting Confirmation")
      vPassConfirm = getpass.getpass ("Re-enter %s\'s password: " % pUser )

      if vPassword == vPassConfirm:
         logger.info ("Passwords matched!")
         bPwdMatched = True
      else:
         logger.info ("Passwords did not match")
         print ("Passwords did not match, try again or leave blank to use OEM\'s password\n\n")

   if vPassword == '':
      logger.info ('Using OEM password for %s' % pUser )
      #return pDefaultPwd     # Uncomment if OEM password should not be verified.
      vPassword = pDefaultPwd

   # Verify password.
   logger.info ( "Verify password..." )
   vPwdVerify = verify_password ( vPassword, pLength, pUpper, pDigits, pSpecial)  
   if vPwdVerify != 'OK':
      logger.error ("ERROR: Password verification failed for %s" % pUser )
      return vFailure

   logger.info ("Password verified successfully for %s" % pUser )
   return vPassword







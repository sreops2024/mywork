# ------------------------------------------------------------------------------------------------------------------------
import random
import string
import logging
logger = logging.getLogger ( __name__ )

# ------------------------------------------------------------------------------------------------------------------------

def hide_str ( p_str ):
   """Returns a string of asterisks the length of the received string"""
   l_str = ''
   for s in range ( len ( p_str ) ):
      l_str = l_str + '*'

   return l_str

# ------------------------------------------------------------------------------------------------------------------------

def revStr ( pStr ):
   """Reverse the received string"""
   lTmp1 = list( pStr )
   lTmp1.reverse()
   sTmp1 = ''
   sTmp2 = sTmp1.join(lTmp1)
   return sTmp2

# ------------------------------------------------------------------------------------------------------------------------

def encodeString ( pStr ):
   """Return encoded string to base64."""
   if pStr != None:
      vStr = pStr.encode( 'base64', 'strict')
      vStr = vStr.rstrip('\n')
      vStr = revStr ( vStr )
   else:
      vStr = None
   return vStr

# ------------------------------------------------------------------------------------------------------------------------

def decodeString ( pStr ):
   """Return decoded string"""
   vStr = revStr ( pStr )
   vStr = vStr.decode ( 'base64' )
   return vStr

# ------------------------------------------------------------------------------------------------------------------------



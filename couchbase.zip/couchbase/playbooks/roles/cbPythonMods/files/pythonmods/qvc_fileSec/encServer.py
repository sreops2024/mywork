# Author  : Victor Zuniga
# Date    : 2019.06.14
# Purpose : Package of host encryption functions used in interpretation of cluster keys and credential files
#
# History:
# Date        Name                    Comments
# ----------  ----------------------  ------------------------------------------------------------------------------------------------
# 2023.07.31  Victor Zuniga           Added new function to return dbadmin creds.
# ----------------------------------------------------------------------------------------------------------------------

import os

from Crypto.PublicKey import RSA
from Crypto.Cipher import AES
from Crypto.Cipher import PKCS1_OAEP

from bbc_log.dba_log import *

logger = logging.getLogger(__name__)


# ----------------------------------------------------------------------------------------------------------------------

def getPassword(pAcct):
    '''Returns the password for the received account, or None if not found.'''

    logger = logging.getLogger(__name__)
    logger.debug("getPassword: " + pAcct)

    lcDefaultKeyDIR = '/home/couchbase/DBA/.keys'

    # Determine file path and name using account name
    lvKeyDir = os.environ.get("CB_KEY_DIR", lcDefaultKeyDIR)
    logger.info("Key directory: " + lvKeyDir)

    lvClusterName = os.environ.get("CLUSTER_NAME")
    logger.info("Cluster Name: " + lvClusterName)

    # Ensure files exist
    logger.debug("Checking key file(s) existance")

    lvMissingFile = False

    ldFiles = {}
    # ldFiles["pubkey"] = lvKeyDir + "/" + lvClusterName + ".bin"
    ldFiles["prvKey"] = lvKeyDir + "/" + lvClusterName + "_priv.bin"
    ldFiles["cred"] = lvKeyDir + "/" + lvClusterName + "." + pAcct.lower() + ".cred"
    

    logger.debug("Files: " + str(ldFiles))

    logger.debug("Checking credential file existance")

    for file in ldFiles.keys():
        if os.path.isfile(ldFiles[file]):
            logger.debug("File found: " + ldFiles[file])
        else:
            logger.warning("File NOT Found: " + ldFiles[file])
            lvMissingFile = True

    if lvMissingFile:
        logger.warning("Cannot continue with missing cred or key files.")
        logger.error("ERROR: Missing file.")
        return None

    # Read Cred file and decrypt
    vData = eval(decryptData(ldFiles["prvKey"], ldFiles["cred"]).decode())

    return vData[pAcct]

# ----------------------------------------------------------------------------------------------------------------------

def getClusterCred(pAcct, pClusterName, pPath):
    '''
    Function to return decrypted admin credential for a particular cluster.  
    To be used mostly from the admin hosts for remote automated operations.
    '''

    logger = logging.getLogger(__name__)

    lvMissingFile = False

    logger.debug("Start getClusterCred")
    logger.debug("Acct: " + pAcct)
    logger.debug("Cluster: " + pClusterName)
    logger.debug("Path: " + pPath)

    ldFiles = {}

    ldFiles["prvKey"] = pPath + "/" + pClusterName.lower() + "_priv.bin"
    ldFiles["cred"] = pPath + "/" + pClusterName.lower() + "." + pAcct.lower() + ".cred"

    for file in ldFiles.keys():
        if os.path.isfile(ldFiles[file]):
            logger.debug("File found: " + ldFiles[file])
        else:
            logger.warning("File NOT Found: " + ldFiles[file])
            lvMissingFile = True

    if lvMissingFile:
        logger.warning("Cannot continue with missing cred or key files.")
        logger.error("ERROR: Missing file.")
        return None

    vData = eval(decryptData(ldFiles["prvKey"], ldFiles["cred"]).decode())

    return vData[pAcct]

# ----------------------------------------------------------------------------------------------------------------------

def decryptData(pKey, pEncFile):
    '''Decrypt the recieved encrypted file using the received key.'''

    logger = logging.getLogger(__name__)

    logger.debug("Start decryptData")
    logger.debug("Key File: " + pKey)
    logger.debug("Data File: " + pEncFile)

    vCode = 'Zeazqohryxqujbcy'
    data = ''

    with open(pEncFile, 'rb') as fObj:
        vPrivKey = RSA.import_key(open(pKey).read(), passphrase=vCode)
        encSessionkey, nonce, tag, cipherText = [
            fObj.read(x) for x in (vPrivKey.size_in_bytes(), 16, 16, -1)]
        cipherRSA = PKCS1_OAEP.new(vPrivKey)
        sessionKey = cipherRSA.decrypt(encSessionkey)
        cipherAES = AES.new(sessionKey, AES.MODE_EAX, nonce)
        data = cipherAES.decrypt_and_verify(cipherText, tag)

    # Uncomment to see decoded data -- careful, it could be a password.
    # logger.debug("Data: " + data.decode())

    return data

# ----------------------------------------------------------------------------------------------------------------------

def getDBAdminPass ( pCluster ):
    '''
    Return the password for the dbadmin account for the received cluster.
    Returns None if cluster is invalid.
    '''

    return getClusterCred('dbadmin', pCluster, os.environ.get('CB_KEY_DIR'))
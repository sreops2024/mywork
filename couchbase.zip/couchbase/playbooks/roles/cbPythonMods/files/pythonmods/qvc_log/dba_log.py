# ----------------------------------------------------------------------------------------------------------------------
# Author  : Victor Zuniga
# Date    : 2017.03.23
# Purpose : Organize emcli functions for QVC purposes.
# ----------------------------------------------------------------------------------------------------------------------
# History
#
# Author               Date         Changes
# -------------------- ----------  -------------------------------------------------------------------------------------
# Victor Zuniga        2019.06.04  Modified init_logger to accept optional log path and default to LOG_DIR env variable
#                                  if no path is provided.

import os
import time
import logging

logger = logging.getLogger ( __name__ )

# ----------------------------------------------------------------------------------------------------------------------

def init_logger ( p_log_name, p_log_level, log_dir=None ):
   """Initialize the logger capabilities"""

   # Use different location so that the log retention can be modified (increased).
   if log_dir == None:
      l_log_dir = os.environ['LOG_DIR']

   l_dt_suf = time.strftime("%Y%m%d")
   l_log_name = l_log_dir + "/" + p_log_name + '.' + l_dt_suf + '.log'

   # create logger
   logger = logging.getLogger ( )
   logger.setLevel ( p_log_level )

   # create console handler and set level to debug
   # ch = logging.StreamHandler ( ) # Uncomment for terminal output.
   ch = logging.FileHandler ( l_log_name )
   ch.setLevel ( p_log_level )

   # create formatter
   #formatter = logging.Formatter ( '%(asctime)s - %(name)-12s - %(levelname)-8s - %(message)s', datefmt='%Y%m%d %H:%M:%S' )
   #formatter = logging.Formatter ( '%(asctime)s - %(levelname)-8s - %(message)s', datefmt='%Y%m%d %H:%M:%S' )
   #formatter = logging.Formatter ( '%(asctime)s - %(name)-19s - %(levelname)-8s - %(message)s', datefmt='%Y%m%d %H:%M:%S' )
   formatter = logging.Formatter('%(asctime)s - %(name)-22s - %(levelname)-8s - %(message)s', datefmt='%Y%m%d %H:%M:%S')

   # add formatter to ch
   ch.setFormatter ( formatter )

   # add ch to logger
   logger.addHandler ( ch )

   logger.debug ( 'Log file : ' + l_log_name )

   return l_log_name

# ----------------------------------------------------------------------------------------------------------------------

def init_logger2 ( p_log_name, p_log_level, consoleOutput = False ):
   """Initialize the logger capabilities"""

   # Use different location so that the log retention can be modified (increased).
   #l_log_dir = os.environ['LOG_DIR']
   l_log_dir = '/tools/oracle/dba/oms/bbc_emcli_logs'
   l_dt_suf = time.strftime("%Y%m%d")
   l_log_name = l_log_dir + "/" + p_log_name + '.' + l_dt_suf + '.log'
   # print " LOG: " + l_log_name

   # create logger
   logger = logging.getLogger ( )
   logger.setLevel ( p_log_level )

   if consoleOutput :
      # create console handler(s) and set level to debug
      ch= logging.StreamHandler ( ) 
      #ch.setLevel ( logging.INFO )
      ch.setLevel ( logging.WARNING )

   fh = logging.FileHandler ( l_log_name )
   fh.setLevel ( p_log_level )

   # create formatter
   #formatter = logging.Formatter ( '%(asctime)s - %(name)-12s - %(levelname)-8s - %(message)s', datefmt='%Y%m%d %H:%M:%S' )
   #formatter = logging.Formatter ( '%(asctime)s - %(levelname)-8s - %(message)s', datefmt='%Y%m%d %H:%M:%S' )
   formatter = logging.Formatter ( '%(asctime)s - %(name)-19s - %(levelname)-8s - %(message)s', datefmt='%Y%m%d %H:%M:%S' )

   # add formatter to fh
   fh.setFormatter ( formatter )

   # add fh to logger
   logger.addHandler ( fh )
   if consoleOutput :
      #chFormatter  = logging.Formatter ( '%(asctime)s - %(levelname)-8s - %(message)s', datefmt='%Y%m%d %H:%M:%S' )
      chFormatter  = logging.Formatter ( '%(asctime)s - %(message)s', datefmt='%Y%m%d %H:%M:%S' )
      ch.setFormatter ( chFormatter )
      logger.addHandler ( ch )

   logger.debug ( 'Log file : ' + l_log_name )

   return l_log_name

# ----------------------------------------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------------------------------------
# Author  : Victor Zuniga
# Date    : 2017.03.23
# Purpose : Organize email functions for QVC purposes.
# ----------------------------------------------------------------------------------------------------------------------
# History
#
# Author               Date         Changes
# -------------------- ----------  -------------------------------------------------------------------------------------
# Victor Zuniga        2019.08.28  Initial version
# Dhinesh              2023.05.24  For Cloud nodes set SMTP to smtpcustomerouta.south.edu
# ----------------------------------------------------------------------------------------------------------------------

import os
import logging
import smtplib

logger = logging.getLogger ( __name__ )

from email.message import EmailMessage

# ----------------------------------------------------------------------------------------------------------------------

def send_email ( Subject = None, From = None, To = None, Body = None ):
   '''
   Email received content.
   Return:
      Success => True
      Failure => False
   '''

   # Ensure the needed information is available.  Use default is needed.
   if Subject == None:
      Subject = ""
   if From == None:
      From = os.environ['CLUSTER_NAME'].upper() + " [" + os.uname()[1] + "]"
   if To == None:
      To = os.environ['DBA_EMAIL']
   if Body == None:
      Body = "Empty Message"

   logger.debug ("Send_email:")
   logger.debug (" From   : " + From )
   logger.debug (" To     : " + To )
   logger.debug (" Subject: " + Subject )
   logger.debug (" Body   : " + Body )

   # Prepare the email
   msg = EmailMessage()
   msg.set_content( Body )

   msg['Subject'] = Subject
   msg['From'] = From
   msg['To'] = To

   # Send the email
   try:
      logger.info ("Sending email message..." )
      host_name = os.uname()[1]
      if 'az' in host_name:
         #smtp_host='smtpcustomerouta.south.edu'
         s = smtplib.SMTP( 'smtpcustomerouta.south.edu' )
      else:
         s = smtplib.SMTP( 'localhost' )
      #s = smtplib.SMTP( 'localhost' )
      s.send_message( msg )
      s.quit()
   
   except:
      logger.error ("ERROR: Error sending email message")
      return False

   logger.debug ("exiting send_email")
   return True
   
# ----------------------------------------------------------------------------------------------------------------------

def email_log ( Subject = None, From = None, To = None, File = None ):
   '''
   Send the log contents as the body of the email.  Will work on attaching file later.
   Return:
      Success => True
      Failure => False
   '''
   # Ensure the needed information is available.  Use default is needed.
   if Subject == None:
      Subject = ""
   if From == None:
      From = os.environ['CLUSTER_NAME'].upper() + " [" + os.uname()[1] + "]"
   if To == None:
      To = os.environ['DBA_EMAIL']
   if File == None:
      logger.error ("ERROR: Must provide a file path and name")
      return False

   logger.debug ("Send_email:")
   logger.debug (" From   : " + From )
   logger.debug (" To     : " + To )
   logger.debug (" Subject: " + Subject )
   logger.debug (" File   : " + File )

   # Read the file contents into a variable.
   fileContents = ''
   try:
      with open( File ) as fp:
         fileContents = fp.read()

   except IOError:
      logger.error ("ERROR: File not accessible")
      logger.error ("ERROR: File " + File )
      return False

   # Send the email
   if not send_email ( Subject, From, To, fileContents ):
      logger.warning ("Issues sending email")
      return False
   else:
      logger.info ("Email Sent")

   return True
   
# ----------------------------------------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------------------------------------
# Author  : Victor Zuniga
# Date    : 2019.12.06
# Purpose : Organize misc OS functions for QVC purposes
# ----------------------------------------------------------------------------------------------------------------------
# History
#
# Author               Date         Changes
# -------------------- ----------  -------------------------------------------------------------------------------------
# Victor Zuniga        2019.12.06  Initial version
#                                  Can't hide the password since the variable is out of scope.
# Victor Zuniga        2020.06.19  Comment out logger call that shows passwords in debug mode in execOSCommand function.
# ----------------------------------------------------------------------------------------------------------------------

import logging

logger = logging.getLogger ( __name__ )

def execOSCommand ( cmd ):
    '''Executes the command received'''

    import subprocess

    logging.debug ("execOSCommand")

    #logging.debug ("Cmd: " + cmd.replace(vAdminPswd, '*' * len(vAdminPswd) ) )
    #logging.debug ("Cmd: " + cmd )
    arCmd = cmd.split()
    
    # 2020.06.19 - Victor Zuniga
    # Comment out - some passwords are being passed and cannot easily be commented out.
    # Better Safe than sorry.
    #logging.debug ("Cmd Array: " + str(arCmd) )

    logging.info ("Exceute subprocess")
    proc = subprocess.Popen (arCmd,
                      stdout=subprocess.PIPE,
                      stderr=subprocess.PIPE,
                      universal_newlines=True)
    stdout, stderr = proc.communicate()
    rc = proc.poll()

    logging.info ("Std Output: " + stdout)
    logging.debug ("Std Error : " + stderr)
    logging.info ("Ret Code  : " + str(rc) )

    return rc


def getOSVar (pEnvVar):
    ''' Return the environment/OS variable'''

    from os import getenv

    logger.debug( "Getting env var: %s" % pEnvVar )

    return getenv(pEnvVar)

    
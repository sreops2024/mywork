import sys
import json

sys.path.insert ( 0,'/home/couchbase/DBA/tools/pythonmods' )

from bbc_log.dba_log import *

logger = logging.getLogger ( __name__ )

# ------------------------------------------------------------------------------------------------------------------------

def logConfig ( d, depth=0 ):
   """ Function to traverse dictionary and log the contents"""

   for k,v in sorted (d.items(),key=lambda x: x[0]):
      if isinstance (v, dict):
         logger.info ( ("  ")*depth + ("%s:" % k) )
         logConfig (v,depth+1)
      else:
         if type(v).__name__ == 'list':
            v = [x.encode('utf-8') for x in v]
         logger.info ( ("  ")*depth + "%s: %s" % (k, v) )

# ------------------------------------------------------------------------------------------------------------------------

def loadConfigFile ( pConfigFile ):
   """Load the configuration file into a dictionary for processing. """

   logger.debug ("loadConfigFile: %s" % pConfigFile )
   with open(pConfigFile ) as jsonFile:
      try:
         gvUserInfo = json.load(jsonFile)
         logger.info ("Loaded file: %s" % pConfigFile)
         #logConfig (gvUserInfo)
         return gvUserInfo

      except ValueError, e:
         logger.error ("File cannot be loaded: %s" % pConfigFile )
         logger.error ("invalid json %s" % e )
         return {}

# ------------------------------------------------------------------------------------------------------------------------

def jsonVerify ( pConfigFile ):
   """ Verify the file is in JSON format and can be processed. """

   logger.debug ("jsonVerify: %s" % pConfigFile )
   with open(pConfigFile ) as jsonFile:
      try:
         gvUserInfo = json.load(jsonFile)
         logger.info ("File verified as json: %s" % pConfigFile )

      except ValueError, e:
         logger.error ("File cannot be verified as json: %s" % pConfigFile )
         logger.error ("invalid json %s" % e )
         return False

      # Traverse the user info directory and log the contents
      logConfig (gvUserInfo)
      return True



# ------------------------------------------------------------------------------------------------------------------------

def verifyConfigFile ( pConfigFile ):
   """ Verify the existance of the received configuration file. """

   logger.debug ("verifyConfigFile: %s" % (pConfigFile) )
   vAbsFile = os.path.abspath( pConfigFile )
   logger.info ("Full path to config file: %s" % vAbsFile )

   if os.path.isfile(vAbsFile):
      logger.info ("Config file exists: %s" % pConfigFile )
      if not jsonVerify (pConfigFile ):
         logger.error ("Error: exiting")
         return False
   else:
      logger.error ("Config file does NOT exists: %s" % pConfigFile )
      return False

   return True

# ------------------------------------------------------------------------------------------------------------------------

def validateConfig ( pConfigDict ):
   """ Make sure that each account item has the necessary records: GEOs, Roles.  Name is optional, but encouraged."""

   logger.info ("Validating User Information")
   #vNeededItems = ['GEOS', 'NAME', 'ROLES', 'ENV'] 
   #vNeededItems = ['NAME', 'ROLES', 'ENV']
   vNeededItems = ['NAME', 'ROLES']
   logger.info ("Should have the following: %s" % vNeededItems )

   logger.info ("Config keys: %s" % pConfigDict.keys())

   for env in pConfigDict.keys():
      logger.info ("Checking env: %s" % env)
      for usr in pConfigDict[env].keys():
         logger.info ("Checking %s" % usr)
         for i in range(len(vNeededItems)):
            logger.debug ("   %s" % vNeededItems[i] )
            if vNeededItems[i] not in pConfigDict[env][usr].keys():
               logger.info ( "%s is missing the %s property" % (usr, vNeededItems[i] ) )
               return False

   return True

# ------------------------------------------------------------------------------------------------------------------------


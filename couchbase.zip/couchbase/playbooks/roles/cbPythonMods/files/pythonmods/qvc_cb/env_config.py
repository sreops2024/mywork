from bbc_log.dba_log import *
import os
import sys
import random

from bbc_cb.env_detail import *

logger = logging.getLogger(__name__)

def getFirstNode(pENV):
    """Return single (first) node for each env cluster in each data center.  Currently, it will return list of 2 host names."""

    logger.debug("getFirstNode")

    vNodes = []

    for vCluster in CBENV[pENV].keys():
        logger.debug("Cluster: %s" % vCluster)
        tNode = CBENV[pENV][vCluster][0]
        logger.debug("   Node: %s" % tNode)
        vNodes.append(tNode)

    logger.info("Nodes: %s" % vNodes)

    return vNodes

# ------------------------------------------------------------------------------------------------------------------------


def getPort():
    """Returns the port (non-tls)"""
    logger.debug("getPort")

    return PORT

# ------------------------------------------------------------------------------------------------------------------------


def getTLSPort():
    """Returns the TLS port """
    logger.debug("getTLSPort")

    return TLS_PORT

# ------------------------------------------------------------------------------------------------------------------------

def getClusterNames():
    """Returns an array of cluster names from the defined environment"""
    logger.debug("getClusterNames")

    lClusters = []

    for k in CBENV.keys():
        logger.debug("Getting clusters for %s" % k)
        lClusters = lClusters + list(CBENV[k].keys())

    logger.debug("Cluster Names: %s" % lClusters)

    return lClusters

# ------------------------------------------------------------------------------------------------------------------------

def getEnvClusterNames( pEnv = 's'):
    """ Return an array of cluster names for the received environment"""

    if pEnv not in ['s','i','q','p']:
        logger.warning ("WARNING: received environment ({0}) is not valid".format(pEnv))
        return []

    try:
        lClusters = list(CBENV[pEnv].keys())
        logger.debug ("Cluster Names: {0}".format(str(lClusters)))
    except:
        logger.warning( "WARNING: Could not determin cluster names")
        logger.warning( "WARNING: Env: %s" % pEnv)
        logger.warning( "WARNING: Env available: %s" % str(CBENV.keys()))
        return []

    return lClusters

# ------------------------------------------------------------------------------------------------------------------------

def getFirstClusterNode(pClusterName):
    """Return first node in the received Cluster"""
    logger.debug("getFirstClusterNode")

    lNode = ""
    lClustNodes = {}

    if pClusterName not in getClusterNames():
        logger.error("ERROR: invalid Cluster Name - %s" % pClusterName)
        return None
    
    for k in CBENV.keys():
        logger.debug("Process env: %s" % k)
        for l in CBENV[k]:
            logger.debug("Cluster: %s:%s" % (l, CBENV[k][l]))
            lClustNodes[l] = CBENV[k][l]
    lNode = lClustNodes[pClusterName][0]

    logger.debug("Returning node: %s" % lNode)
    return lNode

# ------------------------------------------------------------------------------------------------------------------------

def getRandomClusterNode(pClusterName):
    """Return random node in received cluster"""
    logger.debug("getRandomClusterNode")

    lNode = ""
    lClustNodes = {}

    for k in CBENV.keys():
        logger.debug("Process env: %s" % k)
        for l in CBENV[k]:
            logger.debug("Cluster: %s:%s" % (l, CBENV[k][l]))
            lClustNodes[l] = CBENV[k][l]

    lNode = lClustNodes[pClusterName][random.randint(
        0, len(lClustNodes[pClusterName])-1)]
    logger.debug("Returning node: %s" % lNode)
    return lNode

# ------------------------------------------------------------------------------------------------------------------------

def getRandomNode():
    """
    Return a random node from a random cluster.
    This is intended to verify database connectivity
    """

    lNode = ""
    lClust = ""
    lClustNodes = {}

    for k in CBENV.keys():
        logger.debug("Process env: %s" % k)
        for l in CBENV[k]:
            logger.debug("Cluster: %s:%s" % (l, CBENV[k][l]))
            lClustNodes[l] = CBENV[k][l]

    lNode = getRandomClusterNode(list(lClustNodes.keys())[
                                 random.randint(0, len(lClustNodes.keys())-1)])
    logger.debug("Returning node: %s" % lNode)

    return lNode

# ------------------------------------------------------------------------------------------------------------------------


def getClusterNodes(pClusterName):
    """Returns the list of nodes for the cluster received"""
    logger.debug("getClusterNodes")

    lEnvSuffix = pClusterName[-1].lower()

    try:
        return CBENV[lEnvSuffix][pClusterName.lower()]
    except:
        logger.error("ERROR: Cluster %s not found" % pClusterName)
        return []

# ------------------------------------------------------------------------------------------------------------------------

def getClusterSpareNode( pCluster = None ):
    """
    Return the first node in the cluster list for this particular cluster.
    If the cluster is not defined, then return none
    """
    logger.debug("in getClusterSpareNode - cluster: %s" % pCluster)

    lEnvSuffix = pCluster[-1].lower()

    #if pCluster in SPARES.keys():
    #    return SPARES[pCluster][0]

    try:
        # Since each cluster should have only 1 spare, return only the first item in the list.
        return SPARES[lEnvSuffix][pCluster.lower()][0]
    except:
        logger.warning("WARNING: Cluster %s not found in spare dict" % pCluster)
        return ''

    return ''

# ------------------------------------------------------------------------------------------------------------------------

def getNodeCluster( pNode = None ):
    """
    Returns the cluster where the node is defined.
    Return None if the node does not exist, or not define
    """

    logger.debug("in getNodeCluster: Node : %s" % pNode)

    for vEnv in CBENV.keys():
        for vCluster in CBENV[vEnv].keys():
            if pNode in CBENV[vEnv][vCluster]:
                return vCluster
    logger.warning("Node %s does not belong to a cluster")
    
    return None




# ------------------------------------------------------------------------------------------------------------------------


from bbc_log.dba_log import *
from bbc_sec.caVault import caAcct
from bbc_cb.env_config import getEnvClusterNames, getRandomClusterNode
from bbc_cb.cb_api import getClusterBuckets, getRbacGroupDetails, getRbacGroupDetails
from bbc_cb.cb_api import createCBUserLocalGroup, getLocalUserInfo, checkCreds
from bbc_cb.user_admin import checkGroupName

logger = logging.getLogger ( __name__ )


class cbLocalServiceAcct (caAcct):
#class cbLocalServiceAcct:

    logger = logging.getLogger ( __name__ )

    def __init__(self, name, bucket, pAuth):

        self.env = name[-1]
        self.__auth = pAuth
        logger.debug ("Admin Account: {0}/{1}".format( self.__auth[0], '*' * len( self.__auth[1] )))

        if self.env not in ['s','i','q','p']:
            logger.error ("ERROR: invalid account name.  Must have env (siqp) suffix")
        else:
            # Get clusters for this environment
            self.clusterBuckets = {}
            self.acctsChecked = {}
            self.credsChecked = {}
            tmpClusters = getEnvClusterNames(self.env)

            # Get buckets available in the clusters.
            
            for lvCluster in tmpClusters:
                logger.debug ("Get buckets for cluster: {0}".format(lvCluster))
                vRet = getClusterBuckets(getRandomClusterNode(lvCluster), self.__auth[0], self.__auth[1])
                if bucket in vRet:
                    self.clusterBuckets[lvCluster] = bucket
                    #print ("1a: {0}".format(str(vRet)))
            
            if len(self.clusterBuckets) > 0:

                super().__init__(name, bucket)

                self.userGroup = 'APP-' + self.bucketName
                self.userGroupVerified = {}
                for vClstr in self.clusterBuckets:
                    self.userGroupVerified[vClstr] = checkGroupName(self.userGroup, vClstr, self.__auth)
            
            else:
                self.status = "Unknown Clusters/Bucket"
                logger.warning("WARNING: Cluster list is empty")
                self.userName = name
                self.bucketName = bucket
                self.userGroup = ''
                self.userGroupVerified = {}


    def createAcct(self):
        '''
        Create the local account on the cluster(s) where the bucket exists.
        Track the creation in a dictionary, since there could be multiple clusters.
        '''
        vRet = {}

        for vCluster in self.clusterBuckets:
            logger.info ("Create account {0} in cluster {1} using group {2}".format(self.userName, vCluster, self.userGroup))
            vRet = createCBUserLocalGroup((self.userName,self.password()), self.userGroup, getRandomClusterNode(vCluster), self.__auth)

        return vRet

    
    def resetAcct(self):
        '''
        Resets the password using the current instance password.  Uses the same logic/commands as create account function.
        '''

        vRet = {}

        for vCluster in self.clusterBuckets:
            logger.info ("Create account {0} in cluster {1} using group {2}".format(self.userName, vCluster, self.userGroup))
            vRet = createCBUserLocalGroup((self.userName,self.password()), self.userGroup, getRandomClusterNode(vCluster), self.__auth)

        return vRet


    def checkAllAcct(self):
        '''
        Checks all accounts in the necessary clusters and saves the status in acctsChecked dictionary
        '''

        for vClstr in self.clusterBuckets.keys():
            vTmpUsrInfo = getLocalUserInfo(self.userName, getRandomClusterNode(vClstr), self.__auth)
            
            try:
                if vTmpUsrInfo.json()["id"] == self.userName:
                    logger.debug ("checkAllAccts: {0} [{1}]: Acct Found".format(self.userName, vClstr))
                    self.acctsChecked[vClstr] = "Found"
                else:
                    logger.debug ("checkAllAccts: {0} [{1}]: Acct NOT Found".format(self.userName, vClstr))
                    self.acctsChecked[vClstr] = "Not Found"
            except:
                logger.warning ("checkAllAccts: {0} [{1}]: Acct NOT Found".format(self.userName, vClstr))
                self.acctsChecked[vClstr] = "Not Found"

        return True


    def checkAcct(self, pCluster):
        '''
        Return true if the account is present,  False otherwise.
        '''

        logger.debug("testAcct: %s" % pCluster)

        vUserInfo = getLocalUserInfo(self.userName, getRandomClusterNode(pCluster), self.__auth)
        
        logger.debug('testAcct: vUserInfo: %s' % str(vUserInfo))
        
        try:
            if vUserInfo.json()["id"] == self.userName:
                return True
        except:
            return False

        return False


    def checkAllCreds(self):
        '''
        Checks the credentials of the account against all necessary clusters.  Sets the status on credsChecked dict.
        '''

        for vClstr in self.clusterBuckets.keys():
            self.credsChecked[vClstr] = checkCreds(getRandomClusterNode(vClstr), self.bucketName, (self.userName, self.password()))

        return True

        
    def checkCreds(self, pCluster):
        '''
        Checks the credentials of the account against a particular cluster.
        '''

        logger.debug("in verifyCreds: %s" % pCluster)

        return checkCreds(getRandomClusterNode(pCluster), self.bucketName, (self.userName, self.password()))

    def __str__(self):

        vStr = ("---------" * 15) + "\n"
        vStr += ("CB Account    : {0}".format( self.userName )) + "\n"
        vStr += ("CB Bucket     : {0}".format( self.bucketName )) + "\n"
        vStr += ("Admin Account : {0}/{1}".format( self.__auth[0], '*' * len( self.__auth[1] ))) + "\n"
        vStr += ("Cluster Bucket: {0}".format(str(self.clusterBuckets))) + "\n"
        vStr += ("User Group    : {0}".format(self.userGroup)) + "\n"
        vStr += ("Grps Checked  : {0}".format(str(self.userGroupVerified))) + "\n"
        vStr += ("---------" * 15) + "\n"

        if len(self.clusterBuckets) > 0:
            vStr += super(cbLocalServiceAcct, self).__str__()
        return vStr

    def __del__(self):
        pass

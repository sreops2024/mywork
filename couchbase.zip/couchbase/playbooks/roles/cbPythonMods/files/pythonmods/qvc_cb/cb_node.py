# ------------------------------------------------------------------------------------------------------------------------
# Author : Victor Zuniga
# Date   : 2017.12.15
# Purpose: Define a class to handle the node information for Couchbase clusters.
#
# 2018.11.26 Victor Zuniga  Initial Class definition
# 2021.07.30 Victor Zuniga  Change logging calls from info to debug to reduce log noise.
#                           Added variables: clusterMembership, uptime,memUsedGb
# 2021.08.09 Victor Zuniga  Cleaned up formatting for clusterMembersip.  
#                           Needed to add a small hack to get formatting to work.
# 2021.10.27 Victor Zuniga  Redesign to gather node details from init as opposed to receiving them from cluster class.
# 2022.02.28 Victor Zuniga  Fixed issue when node is not part of the cluster and not available. 
# 2022.04.28 Victor Zuniga  Fixed formatting when swap hits 100%.  Needed an extra character/space.
#                           Fixed errors when node does not have a cert exp date
# 2022.12.29 Victor Zuniga  Found issue with nodeEnv when node name is not the alias.  Fixed by extracting environment 
#                           from the host name.
# 2023.01.17 Victor Zuniga  Added collection of hostname and IP address into the class.
#                           Looking how to better provide that information.  Currently only added to the getNodeText func.
# 2023.01.20 Victor Zuniga  Added VM name to node string.
# 2023.07.31 Victor Zuniga  Cleanup the cert wrnings a little.
# ------------------------------------------------------------------------------------------------------------------------

import sys
import json
import socket
from math import ceil


#sys.path.insert ( 0, '/home/mobaxterm/vzuniga/pythonmods/' )

from bbc_log.dba_log import *
from bbc_cb.cbThresholds import *
from bbc_cb.strFormat import strColorFmt, dateStrColorFmt
from bbc_cb.cb_api import getNodeInfo, getNodeCertInfo, getCertExpDate

logger = logging.getLogger(__name__)


def millis2time( pMillis):
    """Convert uptime(millis) to hours:mins:secs"""
    logger.debug("millis2time: %s" % str(pMillis))

    vMil = int(pMillis)*1000
    vSec, vMil = divmod(vMil,1000) 
    vMin, vSec = divmod(vSec, 60) 
    vHrs, vMin = divmod(vMin, 60) 
    vDys, vHrs = divmod(vHrs, 24)
    vSec = vSec + vMil/1000 

    #vTime = "%s d %s:%s:%s" % (str(vDys), str(vHrs).zfill(3), str(vMin).zfill(3), str(vSec))
    #vTime = "%3sd %2sh %2sm" % (str(vDys), str(vHrs), str(vMin))
    
    try:
        vTime = "%s:%s:%s" % ( ("   " + str(vDys))[-3:], str(vHrs).zfill(2)[-2:], str(vMin).zfill(2)[-2:] )
        #vTime = "%s" % ( str(vDys)[-3:]  )
    except:
        #logger.warning( "hmmm: %s" % vTime )
        logger.error("days: %s" % str(vDys))

    logger.debug("Time: %s" % vTime)
    return vTime

class cNode:

    vEmptyNode = {"status": "Unknown",
                  "clusterMembership": "Unknown",
                  "upTimeStr": "n/a",
                  "uptime" : "00000",
                  "version": "n/a",
                  "cpuCount": 0,
                  "cpu_util_rate": 0,
                  "mem_total": 0,
                  "mem_util_rate": 0,
                  "swap_rate": "n/a",
                  "services": [],
                  "certExpDate": "n/a",
                  "nodeEnv":"x",
                  "hostName": "n/a"
                  }

    def __init__(self, name, nodeCreds, nodeData = vEmptyNode):
        logger.debug("Initializing node: %s " % name)
        #print("Initializing node: %s " % name)
        logger.debug("... node data: %s" % str(nodeData))
        vEmptyNode = False

        #self.nodeInfo = getNodeInfo(nodeCreds, name)
        self.nodeInfo = nodeData

        #print( "Name: %s - Hostname %s" % (name, self.nodeInfo['hostname']))
        try:
            if name in self.nodeInfo['hostname']:
                self.nodeInfo['name'] = name
                self.nodeInfo['certExpDate'] = ''
            else:
                #self.nodeInfo['name'] = self.nodeInfo['hostname'].split('.')[0]
                self.nodeInfo['name'] = name
        except:
            # Could not get information from the node. Set to empty dict
            self.nodeInfo = self.vEmptyNode
            vEmptyNode = True
            self.nodeInfo['name'] = name
            
            #return None
        
        # Get VM/Host Name
        try:
            vHost, vAlias, vIP = socket.gethostbyname_ex(self.nodeInfo['name'])
            self.nodeInfo['hostname'] = vHost.split('.')[0]
            self.nodeInfo['ip'] = vIP
        except:
            logger.warning("WARNING: Could not get VM infor for %s" % self.nodeInfo['name'])
            self.nodeInfo['hostname'] = 'unknown'
            self.nodeInfo['ip'] = "['xxx.xxx.xxx.xxx']"

        if self.nodeInfo['name'] != '':
            if self.nodeInfo['name'][-1] in 'siqp':
                self.nodeInfo['nodeEnv']= self.nodeInfo['name'][-1]
            else:
                # Node name could be a regular host name.  Extract 4th character (starts at 0).
                self.nodeInfo['nodeEnv'] = self.nodeInfo['name'][4]
        
        if vEmptyNode == True:
            self.nodeInfo['status'] = "Unknown"
            self.nodeInfo['clusterMembership'] = 'UNKNOWN'
            self.nodeInfo['services'] = []

        try:
            self.nodeInfo['upTimeStr'] = millis2time(int(self.nodeInfo['uptime']))
        except:
            logger.warning("node.init: uptime: %s" % self.nodeInfo['uptime'])
            self.nodeInfo['upTimeStr'] = "n/a"

        if ('services' not in self.nodeInfo.keys()):
            self.nodeInfo['services'] = []

        if ('cpuCount' not in self.nodeInfo.keys()):
            self.nodeInfo['cpuCount'] = ' '

        if self.nodeInfo['status'] == "Unknown":
            self.nodeInfo['cpu_util_rate'] = -0.0
            self.nodeInfo['mem_util_rate'] = -0.0
            self.nodeInfo['swap_rate'] = -00.0
            self.nodeInfo['mem_total'] = -0.0
        else:
            self.nodeInfo['cpu_util_rate'] = self.nodeInfo['systemStats']['cpu_utilization_rate']
            
            try:
                self.nodeInfo['memUsedGb'] = round((self.nodeInfo['systemStats']['mem_total'] - self.nodeInfo['systemStats']['mem_free'])/(1024*1000*1000), 2)
                self.nodeInfo['mem_util_rate'] = round((((self.nodeInfo['systemStats']['mem_total'] - self.nodeInfo['systemStats']['mem_free']) / self.nodeInfo['systemStats']['mem_total']) * 100), 2)
            except:
                logger.warning("WARNING: Error computing mem_util_rate")
                logger.warning("mem_total: %s" % str(self.nodeInfo['systemStats']['mem_total']))
                logger.warning("mem_free : %s" % str(self.nodeInfo['systemStats']['mem_free']))
                self.nodeInfo['mem_util_rate'] = -0.0

            self.nodeInfo['mem_total'] = ceil(self.nodeInfo['systemStats']['mem_total'] / 1024 / 1024 / 1024)
            try:
                logger.debug("WARNING: computing swap_rate")
                logger.debug("swap_used : %s" % str(self.nodeInfo['systemStats']['swap_used']))
                logger.debug("swap_total: %s" % str(self.nodeInfo['systemStats']['swap_total']))
                self.nodeInfo['swap_rate'] = round(((self.nodeInfo['systemStats']['swap_used'] / self.nodeInfo['systemStats']['swap_total'])* 100), 2)
            except:
                logger.warning("WARNING: Error computing swap_rate")
                logger.warning("swap_used : %s" % str(self.nodeInfo['systemStats']['swap_used']))
                logger.warning("swap_total: %s" % str(self.nodeInfo['systemStats']['swap_total']))
                self.nodeInfo['swap_rate'] = -0.0
                
            self.nodeInfo['certInfo'] = None
            self.nodeInfo['certInfo'] = getNodeCertInfo(nodeCreds, name)
            
            self.cert_warn = None
            if "bbc_err_code" in self.nodeInfo['certInfo'].keys():
                self.nodeInfo['cert_warn'] = self.nodeInfo['certInfo']
            else:
                 if self.nodeInfo['certInfo']["warnings"] != []:
                     try:
                         self.nodeInfo['cert_warn'] = []
                         for w in self.nodeInfo['certInfo']["warnings"]:
                             #self.nodeInfo['cert_warn'] = w
                             self.nodeInfo['cert_warn'].append(w['message'])
                         self.nodeInfo['cert_warn'] = list(set(self.nodeInfo['cert_warn']))
                     except Exception as e:
                         logger.debug ( "exception found: %s" % repr(e))
                         #self.nodeInfo['cert_warn'] = self.nodeInfo['certInfo']["warnings"]
                         self.nodeInfo['cert_warn'] = []
                         for j in range(len( self.nodeInfo["certInfo"]["warnings"])):
                             self.nodeInfo['cert_warn'].append( self.nodeInfo['certInfo']["warnings"][j]["message"])
                         self.nodeInfo['certExpDate'] = "n/a"

            logger.debug("%s: cpu_util_rate: %f" % (self.nodeInfo['name'], self.nodeInfo['cpu_util_rate']))
            logger.debug("%s: mem_util_rate: %f" % (self.nodeInfo['name'], self.nodeInfo['mem_util_rate']))
            logger.debug("%s: swap_rate: %f" % (self.nodeInfo['name'], self.nodeInfo['swap_rate']))

            # Get node's certificate expiration date
            try:
                self.nodeInfo['certExpDate'] = getCertExpDate(self.nodeInfo['name'])
                #print("TEST1: %s : %s " % (self.nodeInfo['name'], self.nodeInfo['certExpDate']))
            except:
                self.nodeInfo['certExpDate'] = "NA"
                #print("TEST1.1: %s : %s " % (self.nodeInfo['name'], self.nodeInfo['certExpDate']))

            #print("TEST2: %s : %s " % (self.nodeInfo['name'], self.nodeInfo['certExpDate']))
            return None


    def __str__(self):
        """Print node information"""
        
        #print("TEST3: %s : %s " % (self.nodeInfo['name'], self.nodeInfo['certExpDate']))

        if 'cert_warn' in self.nodeInfo.keys() and self.nodeInfo['cert_warn'] != None:
            outTxt = "  %15s %-16s: %-9s [%-14s] Upt: %-10s v: %-7s cpu(%s): %5s  mem( %s ): %5s%%  swap: %8s%% crtExp: %-10s srv: %-25s \n          Cert Warn: %s\n" % (
                self.nodeInfo['name'],
                self.nodeInfo['hostname'],
                strColorFmt(self.nodeInfo['status'], "", "unhealthy"),
                strColorFmt(self.nodeInfo['clusterMembership'], "inactiveAdded", "inactiveFailed"),
                self.nodeInfo['upTimeStr'],
                self.nodeInfo['version'].split('-')[0],
                self.nodeInfo['cpuCount'],
                strColorFmt(round(self.nodeInfo['cpu_util_rate'], 2), hostCPU.warnThresh, hostCPU.critThresh),
                strColorFmt(self.nodeInfo['mem_total'], 900, 999),
                strColorFmt(self.nodeInfo['mem_util_rate'], hostRAM.warnThresh, hostRAM.critThresh),
                strColorFmt(self.nodeInfo['swap_rate'], hostSWAP.warnThresh,hostSWAP.critThresh, "%6.2f"),
                dateStrColorFmt(self.nodeInfo['certExpDate'], gTHRESH[self.nodeInfo['nodeEnv']]['certExpDays']['warnThres'], gTHRESH[self.nodeInfo['nodeEnv']]['certExpDays']['critThres']),
                strColorFmt(str(self.nodeInfo['services']), '', '[]'),
                str(self.nodeInfo['cert_warn']))
        else:
            outTxt = "  %15s %-16s: %-9s [%-14s] Upt: %-10s v: %-7s cpu(%s): %5s  mem( %s ): %5s%%  swap: %8s%% crtExp: %-10s srv: %-25s \n" % (
                self.nodeInfo['name'],
                self.nodeInfo['hostname'],
                strColorFmt(self.nodeInfo['status'], "", "unhealthy"),
                strColorFmt(self.nodeInfo['clusterMembership'], "inactiveAdded ", "inactiveFailed"),
                self.nodeInfo['upTimeStr'],
                self.nodeInfo['version'].split('-')[0],
                self.nodeInfo['cpuCount'],
                strColorFmt(round(self.nodeInfo['cpu_util_rate'], 2), hostCPU.warnThresh, hostCPU.critThresh),
                strColorFmt(self.nodeInfo['mem_total'], 900, 999), strColorFmt(self.nodeInfo['mem_util_rate'], hostCPU.warnThresh, hostCPU.critThresh),
                strColorFmt(self.nodeInfo['swap_rate'], hostSWAP.warnThresh,hostSWAP.critThresh, "%6.2f"),
                dateStrColorFmt(self.nodeInfo['certExpDate'], gTHRESH[self.nodeInfo['nodeEnv']]['certExpDays']['warnThres'], gTHRESH[self.nodeInfo['nodeEnv']]['certExpDays']['critThres']),
                strColorFmt(str(self.nodeInfo['services']), '', '[]'))

        logger.debug("cNode.outTxt:")
        logger.debug("%s" % outTxt)
        return outTxt

    def getNodeText(self):
        """Return plain text of node information"""
        #if self.cert_warn != None:
        if 'cert_warn' in self.nodeInfo.keys() and self.nodeInfo['cert_warn'] != None:
            outTxt = "  %15s %-16s: %-9s [%-14s] Upt: %-10s v: %-7s cpu(%s): %5s  mem( %s ): %5s%%  swap: %8s%% crtExp: %-10s srv: %-25s \n          Cert Warn: %s\n" % (
                self.nodeInfo['name'],
                self.nodeInfo['hostname'],
                strColorFmt(self.nodeInfo['status'], "", "unhealthy"),
                strColorFmt(self.nodeInfo['clusterMembership'], "inactiveAdded", "inactiveFailed"),
                self.nodeInfo['upTimeStr'],
                self.nodeInfo['version'].split('-')[0],
                self.nodeInfo['cpuCount'],
                strColorFmt(round(self.nodeInfo['cpu_util_rate'], 2), hostCPU.warnThresh, hostCPU.critThresh),
                strColorFmt(self.nodeInfo['mem_total'], 900, 999),
                strColorFmt(self.nodeInfo['mem_util_rate'], hostRAM.warnThresh, hostRAM.critThresh),
                strColorFmt(self.nodeInfo['swap_rate'], hostSWAP.warnThresh,hostSWAP.critThresh, "%6.2f"),
                dateStrColorFmt(self.nodeInfo['certExpDate'], gTHRESH[self.nodeInfo['nodeEnv']]['certExpDays']['warnThres'], gTHRESH[self.nodeInfo['nodeEnv']]['certExpDays']['critThres']),
                strColorFmt(str(self.nodeInfo['services']), '', '[]'),
                str(self.nodeInfo['cert_warn']))
        else:
            outTxt = "  %15s %-16s: %-9s [%-14s] Upt: %-10s v: %-7s cpu(%s): %5s  mem( %s ): %5s%%  swap: %8s%% crtExp: %-10s srv: %-25s \n" % (
                self.nodeInfo['name'],
                self.nodeInfo['hostname'],
                strColorFmt(self.nodeInfo['status'], "", "unhealthy"),
                strColorFmt(self.nodeInfo['clusterMembership'], "inactiveAdded ", "inactiveFailed"),
                self.nodeInfo['upTimeStr'],
                self.nodeInfo['version'].split('-')[0],
                self.nodeInfo['cpuCount'],
                strColorFmt(round(self.nodeInfo['cpu_util_rate'], 2), hostCPU.warnThresh, hostCPU.critThresh),
                strColorFmt(self.nodeInfo['mem_total'], 900, 999), strColorFmt(self.nodeInfo['mem_util_rate'], hostCPU.warnThresh, hostCPU.critThresh),
                strColorFmt(self.nodeInfo['swap_rate'], hostSWAP.warnThresh,hostSWAP.critThresh, "%6.2f"),
                dateStrColorFmt(self.nodeInfo['certExpDate'], gTHRESH[self.nodeInfo['nodeEnv']]['certExpDays']['warnThres'], gTHRESH[self.nodeInfo['nodeEnv']]['certExpDays']['critThres']),
                strColorFmt(str(self.nodeInfo['services']), '', '[]'))

        logger.debug("cNode.outTxt:")
        logger.debug("%s" % outTxt)
        
        return outTxt

    def json(self):
        """Return node information in json format"""

        return json.dumps(self.nodeInfo)

    def getNodeDict(self):
        """Return dictionary node information """
        return self.nodeInfo

    def nodeStatus(self):
        '''Return the node status'''
        return self.nodeInfo['status']

    def memUsagePct(self):
        '''Return the node memory usage percent'''
        return self.nodeInfo['mem_util_rate']

    def certExpDate(self):
        '''Return certificate expiration date'''
        return self.nodeInfo['certExpDate']

    def nodeServices(self):
        '''Return node services'''
        return self.nodeInfo['services']
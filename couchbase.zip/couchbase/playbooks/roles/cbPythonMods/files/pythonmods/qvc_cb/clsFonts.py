class fontColors:
   CBOLD = '\33[1m'
   CITALIC = '\33[3m'
   OKBLUE = '\33[94m'
   OKGREEN = '\33[92m'
   WARNING = '\33[93m'
   FAIL = '\33[91m'
   ENDC = '\33[0m'
   BOLD = '\33[1m'
   UNDERLINE = '\33[4m'


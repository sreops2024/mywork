# Author : Victor Zuniga
# Date   : 2021.05.17
# Purpose: Collection of couchbase api functions for the use in the QVC environment.

# 2021.05.17   Victor Zuniga      Add timout to the requests.get call in the getEndpoint function.
#                                 The timeout has been set to 1 second for get calls.  This will help
#                                 speed up the execution of getting cluster information on call to the
#                                 cloud clusters, where permissions may not be ready, causing the execution
#                                 to take much time without any feedback.
# 2021.05.27   Victor Zuniga      Added the following functions:
#                                    - createUserGroup -- Used to create a user group.  We will be creating user
#                                                         groups for each bucket.
#                                    - getClusterMinVersion -- returns the minimum node version for the cluster.
# 2021.07.30   Victor Zuniga      Change getEndpoint* logging from info to debug to reduce log size and noise.
# 2021.08.09   Victor Zuniga      Added functions for XDCR gathering remote replication information.
# 2022.01.10   Victor Zuniga      Add function to get certificate information and return expiration date.
# 2022.03.25   Victor Zuniga      Fix issue with getNodeCertInfoSSL on some servers.
# 2022.06.28   Victor Zuniga      Increase timeout to 6 secs -- Azure latency
# 2022.07.21   Victor Zuniga      Modify getCertExpDate to account for Time Zone returned from Cert.
# 2022.07.25   Victor Zuniga      Fixed bug displaying a password.
# 2023.01.27   Victor Zuniga      Replace getBucketInfo function with getBucketStats for a more accurate name.
#                                 Must replace getBucketInfo from cb_monitor.py module.
# 2023.02.02   Victor Zuniga      Rename addNode function to addClusterNode to remove duplication from cluster class.
# 2023.06.20   Victor Zuniga      Hide password and maintain case provided by the user/script.


import os
import sys
import requests
import json

from pprint import PrettyPrinter

# sys.path.insert ( 0,'/home/couchbase/DBA/tools/pythonmods' )

from bbc_log.dba_log import *
from bbc_cb.env_config import getClusterNames
from bbc_cb.env_config import getPort
from bbc_cb.env_config import getRandomClusterNode
from bbc_cb.env_config import getRandomNode
from bbc_cb.env_config import getClusterNodes

logger = logging.getLogger(__name__)
gvGetTimeout = 6

# ------------------------------------------------------------------------------------------------------------------------


def formatRoles(pRoleDict):
    """ Return the bucket roles string based on the dictionary received"""

    logger.debug("formatRoles: " + str(pRoleDict))

    vRoleStr = ''

    for bucket in pRoleDict.keys():
        logger.debug("Bucket: " + bucket)
        for x in range(len(pRoleDict[bucket])):
            if len(vRoleStr) != 0:
                vRoleStr = vRoleStr + ","
            vRoleStr = (vRoleStr + pRoleDict[bucket][x] + "[" + bucket + "]")

    logger.debug("Roles: " + (vRoleStr))
    return vRoleStr

# ------------------------------------------------------------------------------------------------------------------------


def getClusterBuckets(pNode, pUser, pPass):
    """Return list of buckets for the cluster using the received node"""
    logger.debug("getClusterBuckets")

    llBuckets = []
    lvPort = getPort()

    lvURL = "http://" + pNode + ".south.edu:" + \
        str(lvPort) + "/pools/default/buckets/"
    logger.debug("Bucket URL: " + lvURL)

    try:
        r = requests.get(lvURL, auth=(pUser, pPass))

        if r.status_code != 200:
            logger.error("ERROR: Received code " +
                         str(r.status_code) + " from request call")
            llBuckets = None
        else:
            for x in range(len(r.json())):
                logger.debug("Append " + r.json()[x]['name'])
                llBuckets.append(r.json()[x]['name'])
    except:
        logger.error("ERROR: Unexpected error " + str(sys.exc_info()[0]))
        # logger.error("ERROR: Unexpected error ", sys.exc_info()[0] )
        llBuckets = None

    return llBuckets

# ------------------------------------------------------------------------------------------------------------------------


def getAllClustBuckets(pUser, pPass):
    """Return dictionary of cluster and its buckets"""
    logger.debug("getAllClustBuckets")

    ldClustBuckets = {}
    lvClusters = getClusterNames()
    lvNode = ""
    llBuckets = []

    for clstr in lvClusters:
        logger.debug("getAllClustBuckets: Get buckets for cluster: " + clstr)
        lvNode = getRandomClusterNode(clstr)
        logger.debug("getAllClustBuckets: Using node: " + lvNode)
        llBuckets = getClusterBuckets(lvNode, pUser, pPass)

        if llBuckets is None:
            logger.error("getAllClustBuckets: No buckets found for " + clstr)
        else:
            logger.debug("getAllClustBuckets: Cluster/buckets: " + clstr + "[" + str(llBuckets) + "]")
            ldClustBuckets[clstr] = llBuckets

    return ldClustBuckets


# ------------------------------------------------------------------------------------------------------------------------

def getBucketClustDict(pClusterBucketDict):
    """
    Takes a dictionary of Cluster and its buckets, and flips it to a dictionary of buckets and its clusters.
    This is useful to assist in the search of clusters containing a bucket.
    """
    logger.debug("getBucketClustDict")

    lBucketCluster = {}

    # Create empty dictionary of buckets
    for x in pClusterBucketDict.keys():
        for y in pClusterBucketDict[x]:
            # logger.debug("Create dict key %s" % y)
            lBucketCluster[y] = []

    # Populate the dictionary with the clusters accordingly
    for x in pClusterBucketDict.keys():
        for y in pClusterBucketDict[x]:
            # logger.debug("Append %s to %s" % (x, y) )
            lBucketCluster[y].append(x)

    logger.debug("Resulting dictionary: %s" % lBucketCluster)

    return lBucketCluster

# ------------------------------------------------------------------------------------------------------------------------


def verifyAdminConnection(pAdminCreds, pCluster=None):
    """
    Verify the credentials provided are valid to connect to a cluster
    """

    logger.debug("verifyAdminConnection - Cluster: " + str(pCluster))

    if pCluster == None or pCluster == 'all':
        lNode = getRandomNode()
    else:
        lNode = getRandomClusterNode(pCluster.split(',')[0]) # Use only the first cluster if more than one is provided.
        logger.debug("Random Node -- cluster: " +
                     pCluster + " [" + lNode + "]")

    lvPort = getPort()

    lvURL = "http://" + lNode + ".south.edu:" + \
        str(lvPort) + "/pools/default/buckets/"
    logger.debug("URL: " + lvURL)

    try:
        r = requests.get(lvURL, auth=(pAdminCreds[0], pAdminCreds[1]))

        if r.status_code != 200:
            logger.error("ERROR: Received code " +
                         str(r.status_code) + " from request call")
            return False
        else:
            return True

    except:
        logger.error("ERROR: Unexpected error " + str(sys.exc_info()[0]))
        # logger.error( "ERROR: Unexpected error ", sys.exc_info()[0])
        return False


# ------------------------------------------------------------------------------------------------------------------------

def getUserInfo(pUser, pNode, pAdminCreds, pType='external'):
    """
    Get user information.
    """

    #logger.debug("getUserInfo: " + pUser + " " + pNode + " ["+ pType + "]")
    logger.debug("getUserInfo: %s - %s [%s]" % (pUser,pNode, pType) )

    vPort = getPort()
    vUserInfo = {}
    #vURL = "http://" + pNode + ".south.edu:" + str(vPort) + "/settings/rbac/users/external/" + pUser
    vURL = "http://%s.south.edu:%s/settings/rbac/users/%s/%s" % (pNode, str(vPort), pType, pUser)
    logger.debug("URL: " + vURL)
    r = requests.get(vURL, auth=(pAdminCreds[0], pAdminCreds[1]))

    if r.status_code != 200:
        logger.warning(
            "WARNING: Could not get user information for " + pUser + " from node " + pNode)
        logger.warning("WARNING: status code: " + str(r.status_code))
    return r

# ------------------------------------------------------------------------------------------------------------------------

def getLocalUserInfo(pUser, pNode, pAdminCreds):
    """
    Get user information for local account.
    """

    logger.debug("geLocaltUserInfo: " + pUser + " " + pNode)

    vPort = getPort()
    vUserInfo = {}
    vURL = "http://" + pNode + ".south.edu:" + \
        str(vPort) + "/settings/rbac/users/local/" + pUser
    logger.debug("URL: %s" % vURL)
    logger.debug("Creds: %s" % str(pAdminCreds))

    r = requests.get(vURL, auth=(pAdminCreds[0], pAdminCreds[1]))

    if r.status_code != 200:
        logger.warning(
            "WARNING: Could not get local user information for " + pUser + " from node " + pNode)
        logger.warning("WARNING: status code: " + str(r.status_code))
    return r


# ------------------------------------------------------------------------------------------------------------------------

def checkCreds(pNode, pBucket, pCreds):
    '''
    Returns True/False whether the connecton was successful.
    Uses the bucket streaming URI to determine if credentials work against the cluster/bucket.
    '''

    logger.debug("In checkCreds: %s [%s]" % (pNode, pBucket))
    logger.debug("in checkCreds: %s/%s" % (pCreds[0], '*' * len(pCreds[1])))

    vPort = getPort()
    vURL = "http://{0}.south.edu:{1}/pools/default/buckets/{2}".format(pNode, vPort, pBucket)

    r = requests.get (vURL, auth=(pCreds[0], pCreds[1]))

    if r.status_code != 200:
        logger.warning ("WARNING: Could not get URI to verify credentials for {0} on {1} [{2}]".format(pCreds[0], pNode, pBucket))
        return False
    
    return True


# ------------------------------------------------------------------------------------------------------------------------


def createCBUser(pAcctInfo, pNode, pAdminCreds, pType='EXTERNAL'):
    """
    Create the account in the Couchbase cluster.
    """

    logger.debug("createUser")
    logger.debug("pAcctInfo: " + str(pAcctInfo))

    # There should be only one account in the dictionary.
    vUser = pAcctInfo.keys()[0].lower()
    vUserName = pAcctInfo[vUser]['NAME']
    vRoles = formatRoles(pAcctInfo[vUser]['ROLES'])
    vPort = getPort()

    vData = {'roles': vRoles, 'name': vUserName}

    if pType.upper() == 'EXTERNAL':
        vURL = "http://" + pNode + ".south.edu:" + \
            str(vPort) + "/settings/rbac/users/external/" + vUser
    else:
        vURL = "http://" + pNode + ".south.edu:" + \
            str(vPort) + "/settings/rbac/users/" + pType.lower() + "/" + vUser

    logger.debug("User : " + vUser)
    logger.debug("Name : " + vUserName)
    logger.debug("Roles: " + vRoles)
    logger.debug("URL  : " + vURL)
    logger.debug("Data : " + str(vData))

    r = requests.put(vURL, auth=(pAdminCreds[0], pAdminCreds[1]), data=vData)

    if r.status_code != 200:
        logger.error("ERROR: Could not create/update account " +
                     vUser + " on node " + pNode)
        logger.error("ERROR: status code: " + str(r.status_code))
        return False
    else:
        logger.info("Account " + vUser + "[" + pNode + "] created")

    return True


# ------------------------------------------------------------------------------------------------------------------------

def createCBUser2(pAcctInfo, pNode, pAdminCreds, pType='EXTERNAL'):
    ''' 
    New version to above function.  Will handle group assignement as well as look for password information for local
    accounts.
    '''

    logger.debug ("createCBUser2")
    logger.debug ("pAcctInfo: " + str(pAcctInfo))
    #print ("pAcctInfo: " + str(pAcctInfo))
    #print ("Type: %s" % pType)
    #print ("Node: %s" % pNode)

    vUser = list(pAcctInfo.keys())[0]
    vUserName = pAcctInfo[vUser]['NAME']
    vPort = getPort()

    # Prepare vData structure
    vData = {}

    for k,v in pAcctInfo[vUser].items():
        # Hide the password
        if k.lower() == 'password':
            logger.debug ("processing %s:%s" % (k,"*" * len(v)))
        else:
            logger.debug ("processing %s:%s" % (k,v))
        if k.lower() == 'roles':
            vData[k.lower()] = formatRoles(v)
        else:
            vData[ k.lower() ] = v

    if pType.upper() == 'EXTERNAL':
        vURL = "http://" + pNode + ".south.edu:" + str(vPort) + "/settings/rbac/users/external/" + vUser.lower()
    else:
        #vURL = "http://" + pNode + ".south.edu:" + str(vPort) + "/settings/rbac/users/local/" + vUser.lower()
        # Couchbase is case sensitive, keep the case provided.
        vURL = "http://" + pNode + ".south.edu:" + str(vPort) + "/settings/rbac/users/local/" + vUser

    logger.debug("User : " + vUser)
    logger.debug("Name : " + vUserName)
    logger.debug("URL  : " + vURL)
    logger.debug("Data : " + str(vData))

    #print ("User : " + vUser)
    #print ("Name : " + vUserName)
    #print ("URL  : " + vURL)
    #print ("Data : " + str(vData))

    r = requests.put(vURL, auth=(pAdminCreds[0], pAdminCreds[1]), data=vData)

    if r.status_code == 200:
        logger.info("Account " + vUser + "[" + pNode + "] created")
        return True

    else:
        logger.error("ERROR: Could not create/update account " +
                     vUser + " on node " + pNode)
        logger.error("ERROR: status code: " + str(r.status_code))
        logger.error("ERROR: status text: " + str(r.text))
        logger.error("User : " + vUser)
        logger.error("Name : " + vUserName)
        logger.error("URL  : " + vURL)
        logger.error("Data : " + str(vData))

        return False

    return False

# ------------------------------------------------------------------------------------------------------------------------


def getEndpoint(pAuth, pURL):
    """Return JSON format from received endpoint"""
    logger.debug("getEndpoint")
    logger.debug("URL: " + pURL)
    logger.debug(
        ("auth: " + str(pAuth)).replace(pAuth[1], '*' * len(pAuth[1])))
    logger.debug("getEndpoint: timeout: %d" % gvGetTimeout)

    try:
        r = requests.get(pURL, auth=(pAuth[0], pAuth[1]), timeout=gvGetTimeout)

        if r.status_code != 200:
            logger.error("ERROR: Could not retrieve data from " + pURL)
            logger.error("ERROR: status_code: " + str(r.status_code))
            logger.debug("ERROR: auth: %s" % str(pAuth).replace(pAuth[1], '*****'))
            return {"bbc_err_code": r.status_code}
        else:
            # logger.debug ( "r.json: %s" % r.json() )
            return r.json()

    except Exception as e:
        logger.error("ERROR: Could not retrieve data from " + pURL)
        logger.error("ERROR: bbc_err_code: " + '0001')
        logger.error("ERROR: Exception %s" % str(e))
        return {"bbc_err_code": "0001"}


# ------------------------------------------------------------------------------------------------------------------------


def getSSLEndpoint(pAuth, pURL, pCert=None):
    """Return JSON format from received endpoint"""
    logger.debug("getSSLEndpoint")
    logger.debug("URL: " + pURL)
    logger.debug(
        ("auth: " + str(pAuth)).replace(pAuth[1], '*'*len(pAuth[1])))
    logger.debug("Cert: " + str(pCert))

    vCert = pCert

    if pCert is None:
        # Use default Couchbase location and file name for certificate
        vCert = "/opt/couchbase/var/lib/couchbase/inbox/ca.pem"
        logger.debug("Using default cert: " + vCert)
    else:
        # Verify that certificate file exists
        if not os.path.exists(vCert):
            logger.error("Certificate [%s] not found." % vCert)
            logger.error("ERROR: bbc_err_code: " + '0002')
            return {"bbc_err_code": "0002"}

    try:
        r = requests.get(pURL, auth=(
            pAuth[0], pAuth[1]), verify=vCert, timeout=gvGetTimeout)

        if r.status_code != 200:
            logger.error("ERROR: Could not retrieve data from " + pURL)
            logger.error("ERROR: status_code: " + str(r.status_code))
            return {"bbc_err_code": r.status_code}
        else:
            # logger.debug ( "r.json: %s" % r.json() )
            return r.json()

    except:
        logger.error("ERROR: Could not retrieve data from " + pURL)
        logger.error("ERROR: bbc_err_code: " + '0001')
        return {"bbc_err_code": "0001"}


# ------------------------------------------------------------------------------------------------------------------------

def getNodeInfo(pAuth, pNode, pPort=8091):
    """Get node information from the couchbase cluster."""
    logger.info("getNodeInfo: " + pNode)

    #lURL = "http://" + pNode + ":" + str(pPort) + "/pools/default/"
    lURL = "http://" + pNode + ":" + str(pPort) + "/nodes/self"

    logger.debug("getNodeInfo - URL : " + lURL)

    r = getEndpoint(pAuth, lURL)

    if 'status_code' in r.keys():
        """The call to getEndpoint failed"""
        logger.warning("WARNING: could not get data from " + lURL)
        logger.warning("WARNING: Status Code: " + str(r['status_code']))

        return {}

    else:
        #for n in range(len(r['nodes'])):
        #    if 'thisNode' in r['nodes'][n].keys():
        #        logger.debug("This Node: " + r['nodes'][n])
        #        return r['nodes'][n]
        return r


# ------------------------------------------------------------------------------------------------------------------------

def getClusterStorage(pAuth, pNode, pPort=8091):
    """Return storage portion of the cluster json doc."""
    logger.info("getClusterStorage: %s" % pNode)

    lURL = "http://%s:%d/pools/default/" % (pNode, pPort)

    logger.debug("getClusterStorage - URL : %s" % lURL)

    r = getEndpoint(pAuth, lURL)

    # if 'status_code' in r.keys():
    if r['bbc_err_code'] != 200:
        """The call to getEndpoint failed"""
        logger.warning("WARNING: could not get data from %s" % lURL)
        logger.warning("WARNING: Status Code: %d" % r['bbc_err_code'])

        return {}

    else:
        return r['storageTotals']

# ------------------------------------------------------------------------------------------------------------------------


def getPoolsDefault(pAuth, pCluster, pPort=8091):
    """Return endpoint /pools/default from Couchbase cluster"""

    logger.debug("getPoolsDefault: %s" % pCluster)

    lvNodes = getClusterNodes(pCluster)
    logger.debug("%s : %s" % (pCluster, lvNodes))

    lvFound = 0
    lvCount = 0
    r = {}

    while lvFound == 0 and lvCount < len(lvNodes):
        logger.debug("Nodes: %s" % lvNodes)
        logger.debug("Index: %d" % lvCount)
        lvNode = lvNodes[lvCount]

        lURL = "http://%s:%d/pools/default/" % (lvNode, pPort)
        logger.debug("getPoolsDefault - URL: %s" % lURL)

        r = getEndpoint(pAuth, lURL)

        if 'bbc_err_code' in r.keys():
            lvFound = 0
        else:
            lvFound = 1

        lvCount += 1

    if lvFound == 1:
        logger.debug("%s:%s" % (pCluster, r))
        return r
    else:
        logger.debug("%s:%s" % (pCluster, {}))
        return {}


# ------------------------------------------------------------------------------------------------------------------------

def getUIOverHTTP(pAuth, pNode, pPort=8091):
    """
    Return whether access to UI has been disabled over HTTP
    Returns True or False
    """

    logger.info("getUIOverHTTP: %s" % pNode)
    lURL = "http://%s:%d/settings/security" % (pNode, pPort)

    logger.debug(" getUIOverHTTP - URL: %s" % lURL)

    r = getEndpoint(pAuth, lURL)

    if 'bbc_err_code' in r.keys():
        logger.error("ERROR: Could not get UI Over HTTP setting")
        logger.error("ERROR: %s" % r["bbc_err_code"])
        return False
    else:
        return r['disableUIOverHttp']

    return False

# ------------------------------------------------------------------------------------------------------------------------


def getSSLMinProtocol(pAuth, pNode, pPort=8091):
    """Returns the minimum protocol setting value."""

    lURL = "http://%s:%d/diag/eval" % (pNode, pPort)

    logger.debug(" getUIOverHTTP - URL: %s" % lURL)

    r = getEndpoint(pAuth, lURL)

    if 'bbc_err_code' in r.keys():
        logger.error("ERROR: Could not get minimum SSL protocol setting")
        logger.error("ERROR: %s" % r["bbc_err_code"])
        return 'unknown'
    else:
        return r['ssl_minimum_protocol']


# ------------------------------------------------------------------------------------------------------------------------

def getLDAPEnabled(pAuth, pNode, pPort=8091):
    """Return whether ldap in enabled or not"""

    lURL = "http://%s:%d/settings/saslauthdAuth" % (pNode, pPort)

    logger.debug("getLDAPEnabled - URL: %s" % lURL)

    r = getEndpoint(pAuth, lURL)

    if 'bbc_err_code' in r.keys():
        logger.error("ERROR: Could not get LDAP_enabled setting")
        logger.error("ERROR: %s" % r["bbc_err_code"])
        return 'unknown'
    else:
        if 'enabled' in r.keys():
            return r['enabled']
        else:
            return ''

# ------------------------------------------------------------------------------------------------------------------------


def getClusterLDAP(pAuth, pNode, pPort=8091):
    """Return whether ldap in enabled or not"""

    lURL = "http://%s:%d/settings/ldap" % (pNode, pPort)

    logger.debug("getClusterLDAP - URL: %s" % lURL)

    r = getEndpoint(pAuth, lURL)

    if 'bbc_err_code' in r.keys():
        logger.error("ERROR: Could not get LDAP_enabled setting")
        logger.error("ERROR: %s" % r["bbc_err_code"])
        return {'authenticationEnabled': 'N/A', 'authorizationEnabled': 'N/A'}
    else:
        return r

# ------------------------------------------------------------------------------------------------------------------------


def getClusterSASL(pAuth, pNode, pPort=8091):
    """Return saslauthd setting from the cluster"""

    lURL = "http://%s:%d/settings/saslauthdAuth" % (pNode, pPort)

    logger.debug("getClusterSASL - URL: %s" % lURL)

    r = getEndpoint(pAuth, lURL)

    if 'bbc_err_code' in r.keys():
        logger.error("ERROR: Could not get LDAP_enabled setting")
        logger.error("ERROR: %s" % r["bbc_err_code"])
        return 'unknown'
    else:
        return r

# ------------------------------------------------------------------------------------------------------------------------


def getNodeCipherList(pAuth, pNode, pPort=8091):
    """Return the Cipher List setting for the node."""

    lURL = "http://%s:%d/pools/default/settings/memcached/node/self" % (
        pNode, pPort)

    logger.debug("getNodeCipherList - URL: %s" % lURL)

    r = getEndpoint(pAuth, lURL)

    if 'bbc_err_code' in r.keys():
        logger.error("ERROR: Could not get cipher list value")
        logger.error("ERROR: %s" % r["bbc_err_code"])
        return 'unknown'
    else:
        if 'ssl_cipher_list' in r.keys():
            return r['ssl_cipher_list'].encode()
        else:
            return ''


# ------------------------------------------------------------------------------------------------------------------------

def getNodeSecSettings(pAuth, pNode, pPort=8091):
    """Get the node's security settings, and return in JSON dictionary"""

    logger.debug("getNodeSecSettings - Node: %s:%d" % (pNode, pPort))

    lDict = {"disableUIOverHTTP": 'unknown',
             "sslCipherList": 'unknown',
             "sslMinProtocol": 'unknown',
             "ldapEnabled": 'unknown'}

    # Commented out since not needed currently.
    # lDict['sslCipherList'] = getNodeCipherList ( pAuth, pNode, pPort )
    # lDict['disableUIOverHTTP'] = getUIOverHTTP ( pAuth, pNode, pPort )
    # lDict['sslMinProtocol'] = getSSLMinProtocol ( pAuth, pNode, pPort )
    # lDict['ldapEnabled'] = getLDAPEnabled ( pAuth, pNode, pPort )

    return lDict

# ------------------------------------------------------------------------------------------------------------------------


def getBucketIndexStats(pAuth, pNode, pBucket, pPort=8091, pZoom='minute'):
    """Get the index stats for the bucket received.  Return the JSON dictionary received"""

    logger.debug(
        "getBucketIndexStats - Node: %s[%d]  - Bucket: %s " % (pNode, pPort, pBucket))

    lURL = "http://%s:%d//pools/default/buckets/@index-%s/stats?zoom=%s" % (
        pNode, pPort, pBucket, pZoom)

    logger.debug(" getBucketIndexStats - URL: %s" % lURL)

    r = getEndpoint(pAuth, lURL)

    if 'bbc_err_code' in r.keys():
        logger.error("ERROR: Could not get Index Stats for Bucket " + pbucket)
        logger.error("ERROR: %s" % r["bbc_err_code"])
        return False
    else:
        return r['op']

    return False

# ------------------------------------------------------------------------------------------------------------------------


def getClusterUserList(pAuth, pNode, pPort=8091, pDomain='All'):
    """ Get a list of RBAC accounts from the cluster.  Retrn the JSON dictionary received"""

    logger.debug(
        "getClusterUserList: - Node: %s[%d] - Domain: %s" % (pNode, pPort, pDomain))

    if pDomain == 'All':
        lURL = "http://%s:%d/settings/rbac/users" % (pNode, pPort)
    else:
        lURL = "http://%s:%d/settings/rbac/users/%s" % (
            pNode, pPort, pDomain.lower())

    r = getEndpoint(pAuth, lURL)

    return r

# ------------------------------------------------------------------------------------------------------------------------


def postEndpoint(pAuth, pURL, pData={}):
    """Post a curl command to the received node.  Returns the value received from the node"""

    logger.info("postEndPoint: URL: %s - Data: %s" % (pURL, str(pData)))

    try:
        r = requests.post(pURL, data=pData, auth=(pAuth[0], pAuth[1]))

        if r.status_code != 200:
            logger.error("ERROR: Post not successful to %s" % (pURL))
            logger.error("ERROR: status_code " + str(r.status_code))
            logger.error("ERROR: " + str(r))
            return {"bbc_err_code": r.status_code}
        else:
            return r.json()

    except:
        logger.error("ERROR: Could not retrieve data from " + pURL)
        logger.error("ERROR: bbc_err_code: " + '0001')
        return {"bbc_err_code": "0001"}

# ------------------------------------------------------------------------------------------------------------------------


def startRebalance(pAdminCreds, pNodeAlias, pClusterNodes):

    logger.info("startRebalance : starting")

    tmpList = []
    for node in pClusterNodes:
        tmpList.append('ns_1@' + node + '.south.edu')

    vKnownNodes = ','.join(tmpList)
    logger.info("startRebalance : known nodes : " + vKnownNodes)

    vData = {'knownNodes': vKnownNodes}
    logger.info("startRebalance : data : " + str(vData))

    vURL = 'http://' + pNodeAlias + ':8091/controller/rebalance'
    logger.info("startRebalance : URL : " + vURL)

    r = requests.post(vURL, data=vData, auth=(pAdminCreds))

    if r.status_code != 200:
        logger.error("startRebalance : rebalance call failed. Status Code : " + str(r.status_code))
        logger.error("startRebalance : text : " + r.text)

        logger.debug("ERROR: Rebalance start failed")
        logger.debug("ERROR: Ret Code: " + str(r.status_code))
        logger.debug("ERROR: " + r.text)
        logger.debug("ERROR: URL: %s" % vURL)
        logger.debug("ERROR: Data: %s" % str(vData))
        
        return False

    logger.info(
        "startRebalance : Rebalance Started. Status Code : " + str(r.status_code))

    return True

# ------------------------------------------------------------------------------------------------------------------------


def showRebalanceProgress(pAdminCreds, pNodeAlias, delay=30):

    vSleepDelay = 15
    logger.info("showRebalanceProgress : Sleep delay : " + str(vSleepDelay))

    pp = PrettyPrinter(indent=4)

    time.sleep(vSleepDelay)

    vURL = 'http://' + pNodeAlias + \
        '.south.edu:8091/pools/default/rebalanceProgress'
    logger.info("showRebalanceProgress : URL : " + vURL)

    r = requests.get(vURL, auth=(pAdminCreds))

    if r.status_code != 200:
        logger.info(
            "showRebalanceProgress : request failed : status_code : " + str(r.status_code))
        logger.info("showRebalanceProgress : text : " + r.text)
        print("Rebalance Completed or call failed")
        return True

    logger.info("showRebalanceProgress : " + str(r.text))
    pp.pprint(json.loads(r.text))
    print("...")
    logger.info("showRebalanceProgress : looping until done...")
    while r.text != '{"status":"none"}':
        time.sleep(vSleepDelay)
        r = requests.get(vURL, auth=(pAdminCreds))
        logger.info("showRebalanceProgress : " + str(r.text))
        pp.pprint(json.loads(r.text))
        print("...")

    logger.info("Rebalance Complete")
    print("Rebalance Completed")

    return True

# ------------------------------------------------------------------------------------------------------------------------


def addSpareDataNode(pAuth, pClusterNode, pNewNode):
    """Adds data node to the existing cluster provided."""
    logger.info("addSpareDataNode...")
    logger.info(" ... existing node: %s" % pClusterNode)
    logger.info(" ... spare node   : %s" % pNewNode)

    vData = {
        'hostname': ("http://%s.south.edu:8091" % pNewNode),
        'user': pAuth[0],
        'password': pAuth[1],
        'services': 'kv'
    }

    vURL = "http://%s.south.edu:8091/controller/addNode" % pClusterNode
    logger.debug("Data: %s" %
                 (str(vData).replace(pAuth[1], '*' * len(pAuth[1]))))
    logger.debug("URL: %s" % vURL)

    vRC = postEndpoint(pAuth, vURL, vData)
    logger.debug("Ret Code: " + str(vRC))

    if "bbc_err_code" in vRC.keys():
        # Error returned
        logger.error("ERROR: Error adding node: %s to cluster" % pNewNode)
        logger.error("ERROR: %s" % (str(vRC)))
        return False
    else:
        logger.info("Node %s added to the cluster succesfully" % pNewNode)
        return True

    return False

# ------------------------------------------------------------------------------------------------------------------------

def addClusterNode (pAuth, pNode, pNewNode, pServices):
    '''
    Add node to cluster using received services
    '''

    logger.info("addClusterNode...")
    logger.info(" ... existing node: %s" % pNode)
    logger.info(" ... new node   : %s" % pNewNode)
    logger.info(" ... services   : %s" % str(pServices))

    #vData = {
    #    'hostname': ("http://%s.south.edu:8091" % pNewNode),
    #    'user': pAuth[0],
    #    'password': pAuth[1],
    #    'services': pServices
    #}
    vData = {
        'hostname': ("%s.south.edu" % pNewNode),
        'user': pAuth[0],
        'password': pAuth[1],
        'services': pServices
    }

    vURL = "http://%s.south.edu:8091/controller/addNode" % pNode
    logger.debug("Data: %s" %
                 (str(vData).replace(pAuth[1], '*' * len(pAuth[1]))))
    logger.debug("URL: %s" % vURL)

    vRC = postEndpoint(pAuth, vURL, vData)
    logger.debug("Ret Code: " + str(vRC))

    if "bbc_err_code" in vRC.keys():
        # Error returned
        logger.error("ERROR: Error adding node: %s to cluster" % pNewNode)
        logger.error("ERROR: %s" % (str(vRC)))
        logger.error("ERR: Data: %s" % str(vData).replace(pAuth[1], '*' * len(pAuth[1])))
        return False
    else:
        logger.info("Node %s added to the cluster succesfully" % pNewNode)
        return True

    return False



# ------------------------------------------------------------------------------------------------------------------------


def removeSpareDataNode(pAdminCreds, pNodeAlias):

    logger.info("removeSpareDataNode : alias : " + pNodeAlias)

    vNodeServices = getNodeServices(pNodeAlias.lower(), pAdminCreds)
    logger.info("Node Services: " + str(vNodeServices))

    otpNode = 'ns_1@' + pNodeAlias.lower() + '.south.edu'
    vData = {'otpNode':  otpNode}

    logger.info("nodeFailover : data : " + str(vData))

    # If node is not running the kv service (data), then perform a hard failover
    # if 'kv' in vNodeServices:
    #    vURL = "http://%s.south.edu:8091/controller/startGracefulFailover" % (pNodeAlias.lower())
    #    logger.info ("Perform a graceful failover")
    # else:
    #    vURL = "http://%s.south.edu:8091/controller/failOver" % (pNodeAlias.lower())
    #    logger.info ("Perform a hard failover")

    vURL = "http://%s.south.edu:8091/controller/failOver" % (
        pNodeAlias.lower())
    logger.info("Perform a hard failover")

    logger.info("nodeFailover : URL : " + vURL)

    r = requests.post(vURL, data=vData, auth=(pAdminCreds))

    if r.status_code != 200:
        logger.error(
            "nodeFailover : request call failed. Status : " + str(r.status_code))
        logger.error("nodeFailover : error text : " + r.text)
        logger.error("ERROR: Failed to run request.post")
        logger.error("ERROR: " + r.text)
        return False

    logger.info("nodeFailover : status_code : " + str(r.status_code))
    logger.info("nodeFailover : text : " + r.text)

    return True


# ------------------------------------------------------------------------------------------------------------------------

def getNodeServices(pNodeName, pAuth):
    ''' Return the services for the recieved node name.
        Empty if node is not found or invalid
    '''
    logger.info("Get node services for : " + pNodeName)

    vURL = "http://%s:8091/pools/nodes" % (pNodeName)
    try:
        r = requests.get(vURL, auth=(pAuth))
    except:
        logger.error("ERROR getting services for " + pNodeName)
        logger.debug("URL: " + vURL)
        logger.error("ERROR: ", sys.exc_info()[0])
        return list('')
    for n in range(len(r.json()['nodes'])):
        if pNodeName in r.json()['nodes'][n]['hostname'].lower():
            return r.json()['nodes'][n]['services']
    return list('')

# ------------------------------------------------------------------------------------------------------------------------


def initNode(pAuth, pNodeName, pPort=8091, pDataPath='/data/couchbase', pIndexPath='/index/couchbase', pAnalyticsPath=['/data/analytics'], pEventPath='/index/couchbase'):
    """Initialize the couchbase node paths"""

    logger.info("initNode")
    logger.debug("initNode: %s" % pNodeName)
    logger.debug("initNode: %s" % pDataPath)
    logger.debug("initNode: %s" % pIndexPath)
    logger.debug("initNode: %s" % str(pAnalyticsPath))
    logger.debug("initNode: %s" % pEventPath)

    if pPort == 8091:
        vlProtocol = "http"
    else:
        vlProtocol = "https"
    logger.debug("Protocol: %s" % vlProtocol)

    vlURL = "%s://%s:%d/nodes/self/controller/settings" % (
        vlProtocol, pNodeName, pPort)

    vlData = [("path", pDataPath), ("index_path", pIndexPath)]

    try:
        r = requests.post(vlURL, data=vlData, auth=pAuth)
    except:
        logger.error("ERROR initializing node: " + pNodeName)
        logger.debug("URL: " + vlURL)
        logger.error("ERROR: ", str(sys.exc_info()[0]))
        # logger.error("ERROR: ", str(sys.exc_info()))
        return False

    if r.status_code != 200:
        logger.error("ERROR initializing node: " + pNodeName)
        logger.debug("URL: " + vlURL)
        logger.error("ERROR: ", str(sys.exc_info()[0]))
        # logger.error("ERROR: ", str(sys.exc_info()))

    logger.info("Node %s successfully initialized" % pNodeName)

    return True


# ------------------------------------------------------------------------------------------------------------------------


def getNodeCertInfo(pAuth, pNode):
    """Get the Couchbase node's certificate information"""

    logger.debug("getNodeCertInfo: ")
    logger.debug("... node: %s" % pNode)

    # Get the node certificate location
    vCertDir = os.getenv("CB_CERTS_INBOX")
    logger.debug("Env Variable CB_CERTS_INBOX: %s" % str(vCertDir))

    if vCertDir is None:
        logger.info("CB_CERTS_INBOX env var is not set")
        logger.info("Using default location")
        vCertDir = "/opt/couchbase/var/lib/couchbase/inbox"
        logger.info("Setting log dir to %s" % vCertDir)

    vCert = "%s/%s" % (vCertDir, "ca.pem")

    logger.debug("Certificate: %s" % vCert)

    if os.path.exists(vCert):
        # Certificate file found, try using TLS to get certificate information
        logger.debug("Using SSL calls")

        vURL = "https://%s:18091/pools/default/certificate?extended=true" % pNode
        vCertInfo = getSSLEndpoint(pAuth, vURL, vCert)

        # If error getting cert with SSL, try without.
        if "bbc_err_code" in vCertInfo.keys():
            logger.warning("Error retrieving cert using SSL, try without")
            vURL = "http://%s:8091/pools/default/certificate?extended=true" % pNode
            vCertInfo = getEndpoint(pAuth, vURL)

    else:
        # Certificate was not found, use regular http.
        logger.debug("Using non-SSL calls")

        vURL = "http://%s:8091/pools/default/certificate?extended=true" % pNode
        vCertInfo = getEndpoint(pAuth, vURL)

    logger.debug("Cert Info Received: %s " % str(vCertInfo))

    if "bbc_err_code" in vCertInfo.keys():
        logger.error("ERROR getting certificate info")
    else:
        logger.debug("Cert Info retrieved successfully")

    return vCertInfo


# ------------------------------------------------------------------------------------------------------------------------


def getRbacGroupDetails(pAuth, pNode, pGroupName):
    """
    Retrieve the details for the group name received.
    """

    logger.debug("in getRbacGroupDetails")
    logger.debug("... node: %s" % pNode)
    logger.debug("... Group: %s" % pGroupName)

    # Get the node certificate location
    vCertDir = os.getenv("CB_CERTS_INBOX")
    logger.debug("Env Variable CB_CERTS_INBOX: %s" % str(vCertDir))

    if vCertDir is None:
        logger.info("CB_CERTS_INBOX env var is not set")
        logger.info("Using default location")
        vCertDir = "/opt/couchbase/var/lib/couchbase/inbox"
        logger.info("Setting log dir to %s" % vCertDir)

    vCert = "%s/%s" % (vCertDir, "ca.pem")

    if os.path.exists(vCert):
        vURL = "https://%s:18091/settings/rbac/groups/%s" % (pNode, pGroupName)
        logger.info("URL: %s" % vURL)
        vGroupInfo = getSSLEndpoint(pAuth, vURL, vCert)

        if "bbc_err_code" in vGroupInfo.keys():
            logger.warning(
                "Error retrieving group info using SSL, try without")
            vURL = "http://%s:8091/settings/rbac/groups/%s" % (
                pNode, pGroupName)
            vGroupInfo = getEndpoint(pAuth, vURL)

    else:
        # Certificate was not found, use regular http.
        logger.info("Using non-SSL calls")

        vURL = "http://%s:8091/settings/rbac/groups/%s" % (pNode, pGroupName)
        vGroupInfo = getEndpoint(pAuth, vURL)

    logger.debug("Cert Info Received: %s " % str(vGroupInfo))

    if "bbc_err_code" in vGroupInfo.keys():
        logger.error("ERROR getting Group info - %s" % pGroupName)
        logger.error("Error: %s" % str(vGroupInfo))
    else:
        logger.debug("Cert Info retrieved successfully")

    return vGroupInfo


# ------------------------------------------------------------------------------------------------------------------------

def createUserGroup(pAuth, pNode, pGroupDtls):
    """
    Create the user group with the details received.
    """

    logger.debug("in createUserGroup")
    logger.debug("Node: %s" % pNode)
    logger.debug("group Details: %s" % str(pGroupDtls))

    vRetInfo = {}

    # Group details may contain multiple group details.

    for vGrp in pGroupDtls.keys():
        vData = {}
        logger.info("Processing group: %s" % vGrp)
        vURL = "http://%s:8091/settings/rbac/groups/%s" % (pNode, vGrp)
        vData['roles'] = pGroupDtls[vGrp]["ROLES"]
        vData['description'] = pGroupDtls[vGrp]["DESC"]
        vData['ldap_group_ref'] = pGroupDtls[vGrp]["REFMAP"]

        logger.debug("Data  : %s" % str(vData))
        logger.debug("URL   : %s" % str(vURL))

        try:
            # Put request to create the group
            r = requests.put(vURL, data=vData, auth=pAuth)

            if r.status_code == 200:
                logger.info("Group %s created successfully on %s" %
                            (vGrp, pNode))
                vRetInfo[vGrp] = 'OK'
            else:
                logger.warning(
                    "WARNING: Error encountered creating group %s on %s" % (vGrp, pNode))
                logger.warning("Group Info: %s" % str(pGroupDtls))
                vRetInfo[vGrp] = "FAIL"
        except:
            logger.warning(
                "WARNING: Error encountered creating group %s on %s" % (vGrp, pNode))
            logger.warning("Group Info: %s" % str(pGroupDtls))
            vRetInfo[vGrp] = "FAIL"

    return vRetInfo


# ------------------------------------------------------------------------------------------------------------------------


def getClusterMinVersion(pAuth, pCluster):
    """
    Get the min/lowest version of the cluster.  Couchbase will run on the lowest version of the nodes, so we can assume
    this will be the cluster version.
    """

    logger.debug("in getClusterMinVersion - cluster: %s" % pCluster)

    vClusterVersion = []

    vNode = getRandomClusterNode(pCluster)

    vURL = "http://%s:8091/pools/default" % vNode

    r = getEndpoint(pAuth, vURL)

    if 'bbc_err_code' in r.keys():
        # Error getting cluster info.
        logger.error("Could not get cluster version")
        return []

    # Extract the versions into a unique list
    for nodeNum in range(len(r['nodes'])):
        if r['nodes'][nodeNum]['version'] not in vClusterVersion:
            vClusterVersion.append(r['nodes'][nodeNum]['version'])

    return min(vClusterVersion)

# ------------------------------------------------------------------------------------------------------------------------

def getXDCRRemoteClusters( pAuth, pCluster):
    """
    Gets information on the XDCR remote clusters defined in the cluster
    """
    logger.debug ("In getXDCRRemoteClusters - [%s]" % pCluster)
    logger.debug ("Auth: %s/%s" % (pAuth[0], "******"))

    vNode = getRandomClusterNode( pCluster)
    logger.debug("Cluster: %s [%s]" % (pCluster, vNode))

    vURL = "https://%s:18091/pools/default/remoteClusters" % vNode

    vCert = "%s/ca.pem" % os.getenv("CB_CERTS_INBOX")
    logger.debug ("cert: %s" % vCert)

    vRemoteClusters = getSSLEndpoint( pAuth, vURL, vCert)
    
    logger.debug ("RemoteClusters: %s" % str(vRemoteClusters))

    return vRemoteClusters

# ------------------------------------------------------------------------------------------------------------------------

def getXDCRReplications( pAuth, pCluster):
    """
    Gets task information from the cluster where type = xdcr
    """
    logger.debug ("In getXDCRReplications- [%s]" % pCluster)
    logger.debug ("Auth: %s/%s" % (pAuth[0], "******"))

    vNode = getRandomClusterNode( pCluster)
    logger.debug("Cluster: %s [%s]" % (pCluster, vNode))
    
    vURL = "https://%s:18091/pools/default/tasks" % vNode

    vCert = "%s/ca.pem" % os.getenv("CB_CERTS_INBOX")
    logger.debug ("cert: %s" % vCert)

    vReplications = getSSLEndpoint( pAuth, vURL, vCert)
    logger.debug ("Raw Replications: %s" % str(vReplications))

    # Keep only the items with type xdcr
    for rep in vReplications:
        if rep["type"] != "xdcr":
            # Remove the item
            vReplications.remove(rep)

    logger.debug("Net Replications: %s" % str(vReplications))

    for r in vReplications:
        logger.debug ("type: %s" % r["type"])
    
    return vReplications

# ------------------------------------------------------------------------------------------------------------------------

def getBucketTTL(pBucket, pNode, pAuth):
    logger.debug("getBucketTTL: Node [" + pNode + "] Bucket [" + pBucket + "]")

    
    r = getBucketInfo(pBucket, pNode, pAuth)

    if 'bbc_err_code' in r.keys():
        # Error received, could not get bucket info.
        logger.warning ("WARNING, could not get TTL for bucket %s from %s" % (pBucket, pNode))
        return 0
    else:
        return r['maxTTL']

# ------------------------------------------------------------------------------------------------------------------------

def getBucketInfo(pBucket, pNode, pAuth):
    logger.debug("getBucketInfo: Node [" + pNode + "] Bucket [" + pBucket + "]")

    lURL = "http://%s:8091/pools/default/buckets/%s" % (pNode, pBucket)

    logger.debug(lURL)

    r = getEndpoint(pAuth, lURL)

    return r

# ------------------------------------------------------------------------------------------------------------------------

def getBucketStats(pBucket, pNode, pAuth, pZoom='minute'):
    #logger.debug("getBuckeStats: Node [" + pNode + "] Bucket [" + pBucket + "]")
    logger.debug("getBuckeStats: Node [%s] Bucket [%s]" % (pNode, pBucket))

    if pZoom not in ['minute','hour','day','week','month','year']:
        logger.warning('WARNING, zoom value {%s} is invalid, resetting to minute' % pZoom)
        vZoom = 'minute'
    else:
        vZoom = pZoom

    lURL = "http://%s:8091/pools/default/buckets/%s/stats?zoom=%s" % (pNode, pBucket, vZoom)

    logger.debug(lURL)

    r = getEndpoint(pAuth, lURL)

    return r

# ------------------------------------------------------------------------------------------------------------------------


def ejectNode ( pAdminCreds, pActiveNode, pInactiveNode):
    '''Eject inactive node from the cluster'''

    logger.debug( "ejectNode: %s [using node: %s]" % (pInactiveNode, pActiveNode))

    vData = {'otpNode': ("ns_1@%s.south.edu" % pInactiveNode) }
    vURL = "http://%s.south.edu:8091/controller/ejectNode" % pActiveNode

    logger.debug ("URL: %s" % vURL)
    logger.debug ("Data: %s" % vData)

    r = requests.post (vURL, data=vData, auth=(pAdminCreds))

    if r.status_code != 200:
        logger.error ("nodeEject : request call failed. Status : " + str(r.status_code) )
        logger.error ("nodeEject : error text : " + r.text )
        print ("ERROR: Failed to run request.post")
        print ("ERROR: " + r.text )
        return False

    logger.info ("nodeEject : status_code : " + str( r.status_code) )
    logger.info ("nodeEject : text : " + r.text )

    return True

# ------------------------------------------------------------------------------------------------------------------------

def nodeFailover( pAdminCreds, pNodeAlias, pOption='graceful' ):

    logger.info ("nodeFailover : alias : " + pNodeAlias )

    #vNodeServices = getNodeServices( pNodeAlias, pAdminCreds )
    #logger.info ("Node Services: " + str(vNodeServices ))

    otpNode = 'ns_1@' + pNodeAlias + '.south.edu'
    vData = { 'otpNode' :  otpNode }

    logger.info ("nodeFailover : data : " + str (vData) )

    if pOption == 'graceful':
        vURL = "http://%s.south.edu:8091/controller/startGracefulFailover" % (pNodeAlias)
        logger.info ("Perform a graceful failover - %s" % vURL)
    else:
        vURL = "http://%s.south.edu:8091/controller/failOver" % (pNodeAlias)
        logger.info ("Perform a hard failover - %s" % vURL)

    logger.info ("nodeFailover : URL : " + vURL )

    r = requests.post (vURL, data=vData, auth=(pAdminCreds) )

    if r.status_code != 200:
        logger.error ("nodeFailover : request call failed. Status : " + str(r.status_code) )
        logger.error ("nodeFailover : error text : " + r.text )
        print ("ERROR: Failed to run request.post")
        print ("ERROR: " + r.text )
        return False

    logger.info ("nodeFailover : status_code : " + str( r.status_code) )
    logger.info ("nodeFailover : text : " + r.text )

    return True

# ------------------------------------------------------------------------------------------------------------------------

def showRebalanceProgress( pAdminCreds, pNodeAlias, pDelay = 30 ):

    logger.info ("showRebalanceProgress : Sleep delay : " + str( pDelay ) )

    from time import sleep
    from pprint import PrettyPrinter

    pp = PrettyPrinter(indent=4)

    # Initial request delay of 3 seconds
    sleep( 3 )

    vURL = 'http://' + pNodeAlias + '.south.edu:8091/pools/default/rebalanceProgress'
    logger.info ("showRebalanceProgress : URL : " + vURL )

    r = requests.get( vURL, auth=(pAdminCreds) )

    if r.status_code != 200:
        logger.info ("showRebalanceProgress : request failed : status_code : " + str(r.status_code) )
        logger.info ("showRebalanceProgress : text : " + r.text )
        print ("Rebalance Completed or call failed" )
        return True

    logger.info ("showRebalanceProgress : " + str ( r.text ) )
    pp.pprint ( json.loads(r.text ) )
    print ("...")
    logger.info ("showRebalanceProgress : looping until done..." )
    while r.text != '{"status":"none"}':
        time.sleep( pDelay )
        r = requests.get( vURL, auth=(pAdminCreds) )
        logger.info ("showRebalanceProgress : " + str ( r.text ) )
        pp.pprint ( json.loads(r.text ) )
        print ("...")

    logger.info ("Rebalance Complete")
    print ("Rebalance Completed")

    return True

# ------------------------------------------------------------------------------------------------------------------------

def getRebalanceStatus(pAdminCreds, pNodeAlias):
    '''
    Get the cluster rebalance status
    '''

    import json

    logger.info ("getRebalanceStatus : %s" % pNodeAlias )

    vURL = 'http://' + pNodeAlias + '.south.edu:8091/pools/default/rebalanceProgress'
    logger.info ("showRebalanceProgress : URL : " + vURL )

    r = requests.get( vURL, auth=(pAdminCreds) )

    if r.status_code != 200:
        logger.info ("showRebalanceProgress : request failed : status_code : " + str(r.status_code) )
        logger.info ("showRebalanceProgress : text : " + r.text )
        return True
    
    return json.loads(r.text )


# ------------------------------------------------------------------------------------------------------------------------

def getNodeCertInfoSSL(pNode):
    """
    Get node certificate information using urllib calls.
    """

    logger.debug("in getNodeCertInfo")

    from urllib.request import Request, urlopen, ssl, socket
    from urllib.error import URLError, HTTPError

    import json
    import sys
    import os
    import ssl
    
    vPort = '18091'
    vCert = "%s/ca.pem" % os.getenv("CB_CERTS_INBOX")
    logger.debug ("cert: %s" % vCert)

    ssl.match_hostname = lambda cert, hostname: True
    vContext = ssl.create_default_context(cafile=vCert)

    vData = {}

    try:
        with socket.create_connection((pNode, vPort)) as vSock:
            with vContext.wrap_socket(vSock, server_hostname=pNode) as vSock2:
                lvData = json.dumps(vSock2.getpeercert())
                vData=json.loads(lvData)
        logger.debug("Cert Info: %s" % str(vData))

    except Exception as ex:
        logger.warning("Could not get cert Info")
        logger.warning("%s" % ex)
        return {"bbc_err_code": "Unable to get cert SSL Info"}
    return vData

# ------------------------------------------------------------------------------------------------------------------------
def getCertExpDate (pNode, pFormat="%Y.%m.%d"):
    '''
    Return the expiration data from the peer certificate at the couchbase node.  It ignores the time information.
    '''

    from datetime import datetime

    logger.debug("in getCertExpDate - %s" % pNode)

    vCertInfo = getNodeCertInfoSSL( pNode )

    if "bbc_err_code" in vCertInfo.keys():
        logger.warning("No date available from cert")
        return 'N/A'

    vNodeCertExp = vCertInfo['notAfter']
    logger.debug("%s expiration date: %s" % (pNode, str(vNodeCertExp)))
    #vNodeCertExpStr = vNodeCertExp.rsplit(' ',1)[0]
    #logger.debug("%s exp date str   : %s" % (pNode, str(vNodeCertExpStr)))
    #vNodeCertExpObj = datetime.strptime(vNodeCertExpStr, '%b  %d %H:%M:%S %Y')
    vNodeCertExpObj = datetime.strptime(vNodeCertExp, '%b  %d %H:%M:%S %Y %Z')
    logger.debug("%s exp date obj   : %s" % (pNode, str(vNodeCertExpObj)))

    try:
        return vNodeCertExpObj.strftime(pFormat)
    except:
        return vNodeCertExpObj.strftime("%Y.%m.%d")
    

# ------------------------------------------------------------------------------------------------------------------------


def createCBUserLocalGroup(pAcctCreds, pGroup, pNode, pAdminCreds):
    """
    Create the account in the Couchbase cluster.
    """

    logger.debug("createCBUserLocalGroup: %s Group: %s Node: %s" % (pAcctCreds[0], pGroup, pNode))

    vPort = getPort()
    vAcctName = "{0} {1}".format(pAcctCreds[0], pGroup[4:])

    vData = {'groups': pGroup, 'password': pAcctCreds[1], 'name': vAcctName}

    vURL = "http://{0}.south.edu:{1}/settings/rbac/users/local/{2}".format(pNode, vPort, pAcctCreds[0])

    logger.debug("User : " + pAcctCreds[0])
    logger.debug("Paswd: " + ('*' * len(pAcctCreds[1])))
    logger.debug("Name : " + vAcctName)
    logger.debug("Group: " + pGroup)
    logger.debug("URL  : " + vURL)
    logger.debug("Data : " + str(vData))

    r = requests.put(vURL, auth=(pAdminCreds[0], pAdminCreds[1]), data=vData)

    if r.status_code != 200:
        logger.error("ERROR: Could not create/update account " +
                     pAcct + " on node " + pNode)
        logger.error("ERROR: status code: " + str(r.status_code))
        logger.error("ERROR: " + str(r.text))
        logger.error("ERROR: URL: " + str(vURL))
        return False
    else:
        logger.info("Account " + pAcctCreds[0] + "[" + pNode + "] created")

    return True


# ------------------------------------------------------------------------------------------------------------------------

def removeNode(pAuth, pKnownNodes, pEjectedNodes):
    '''
    Remove the ejected node(s) using rebalance call.
    pKnowNodes and pEjectedNodes should be lists
    '''

    logger.debug ("removeNode: %s - %s" % (str(pKnownNodes), str(pEjectedNodes)) )

    vRemainingNodes = list( set(pKnownNodes ) - set( pEjectedNodes ))
    logger.debug( "Remaining Nodes: %s" % str( vRemainingNodes ))

    vEjectedStr = 'ns_1@' + ',ns_1@'.join(pEjectedNodes)
    vKnownStr = 'ns_1@' + ',ns_1@'.join(pKnownNodes)
    logger.debug("Ejected Str: %s" % vEjectedStr)
    logger.debug("Known   Str: %s" % vKnownStr)

    vData = { 'ejectedNodes': vEjectedStr, 'knownNodes': vKnownStr}
    logger.debug("Data: %s" % vData)

    
    vURL = "http://%s:8091/controller/rebalance" % (vRemainingNodes[0])
    logger.debug("URL: %s"  % vURL)

    try:
        vRet = requests.post(vURL, data=vData, auth=(pAuth))
    except:
        logger.error("ERROR: vURL: %s" % vURL)
        logger.error("ERROR: data: %s" % vData)
        return False

    if vRet.status_code != 200:
        logger.error("ERROR: Could not remove node(s) [%s] " % str(pEjectedNodes))
        logger.error("ERROR: status code: " + str(vRet.status_code))
        logger.error("ERROR: " + str(vRet.text))
        logger.error("ERROR: URL: " + str(vURL))

        logger.warning("EARNING: data=%s" % str(vData))
        return False
    else:
        logger.info("Nodes Ejected: %s" % str(pEjectedNodes) )
        return True

# ------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------

def removeCBUser (pAcctName, pNode, pAdminCreds, pType='EXTERNAL'):
    ''' 
    Remove the account from the couchbase cluster.
    '''

    logger.debug ("removeCBUser")
    logger.debug ("pAcctInfo: " + str(pAcctName))
    
    #vUser = list(pAcctInfo.keys())[0]
    vUser = pAcctName
    #vUserName = pAcctInfo[vUser]['NAME']
    #vUserName = pAcctName
    vPort = getPort()

    # Prepare vData structure
    vData = {}

    #for k,v in pAcctInfo[vUser].items():
    #    logger.debug ("processing %s:%s" % (k,v))
    #    if k.lower() == 'roles':
    #        vData[k.lower()] = formatRoles(v)
    #    else:
    #        vData[ k.lower() ] = v

    #print("Data: %s" % str(vData))
    
    if pType.upper() == 'EXTERNAL':
        vURL = "http://" + pNode + ".south.edu:" + str(vPort) + "/settings/rbac/users/external/" + vUser.lower()
    else:
        vURL = "http://" + pNode + ".south.edu:" + str(vPort) + "/settings/rbac/users/local/" + vUser.lower()

    logger.debug("User : " + vUser)
    #logger.debug("Name : " + vUserName)
    logger.debug("URL  : " + vURL)
    #logger.debug("Data : " + str(vData))

    #print ("User : " + vUser)
    #print ("Name : " + vUserName)
    #print ("URL  : " + vURL)
    #print ("Data : " + str(vData))

    r = requests.delete(vURL, auth=(pAdminCreds[0], pAdminCreds[1]), data=vData)

    if r.status_code == 200:
        logger.info("Account " + vUser + "[" + pNode + "] deleted")
        return True

    else:
        logger.error("ERROR: Could not delete account " +
                     vUser + " on node " + pNode)
        logger.error("ERROR: status code: " + str(r.status_code))
        logger.error("ERROR: status text: " + str(r.text))
        logger.error("User : " + vUser)
        logger.error("URL  : " + vURL)
                
        return False

    return False

# ------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------

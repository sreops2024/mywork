# ------------------------------------------------------------------------------------------------------------------------
# Author : Victor Zuniga
# Date   : 2017.12.15
# Purpose: Define a class to handle the bucket information for Couchbase Buckets.
#
# 2018.11.26 Victor Zuniga  Initial Class definition
#
# ------------------------------------------------------------------------------------------------------------------------

import sys

from bbc_log.dba_log import *
from bbc_cb.cb_api import getBucketInfo, getBucketStats
from bbc_cb.env_config import getRandomClusterNode

class cBucket ( object ):

    def __init__ ( self, bucketName, clusterName, auth, zoom='minute' ):
        logger.info ("Initializing bucket : %s [%s]" % ( bucketName, clusterName ) )
        self.bucketName = bucketName.lower()
        self.clusterName = clusterName.lower()
        self.nodeName = getRandomClusterNode( self.clusterName )
        self.__bucketAuth = auth
        self.zoomLevel = zoom
        self.bucketInfo = getBucketInfo( self.bucketName, self.nodeName, self.__bucketAuth )
        try:
            self.rawStats = getBucketStats( self.bucketName, self.nodeName, self.__bucketAuth, self.zoomLevel )['op']
        except:
            logger.warning("WARNING: Unable to get stats for %s[%s:%s]" % (self.bucketName, self.clusterName, self.nodeName))
            logger.warning(str(self.rawStats))
        

    def __str__ ( self ):
        
        logger.debug ("printing bucket information")

        vOutStr = "%s : %s" % (self.clusterName, self.bucketName)
        
        return vOutStr

    def getInfo( self ):
        return False

    def getStats( self ):

        return False

    
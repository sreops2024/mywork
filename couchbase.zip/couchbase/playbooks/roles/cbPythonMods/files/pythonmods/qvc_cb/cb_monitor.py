# Author : Victor Zuniga
# Date   : 2021.07.19
# Purpose: Collection of python3 functions for getting incidents into the QVC environment.
#          ServiceNow is currently the tool of choice.
#
# Date         Name               Comments
# ------------ ------------------ -------------------------------------------------------------------
# 2021.07.19   Victor Zuniga      Initial version
# 2021.07.23   Victor Zuniga      Make default TNL 4 so that an incident is created.
# 2021.09.07   Victor Zuniga      Add functionality to handle prod instance of Service Now (SNOW).
# 2021.09.15   Victor Zuniga      Cleaned up ServiceNow message for ease of parsing.
#                                 Cleaned up incorrect TNL on message call.
# 2021.09.23   Victor Zuniga      Added function to monitor failed queries in a cluster.
# 2022.07.26   Victor Zuniga      fixed issue where list of nodes and expected nodes did not match
#                                 causing an unhandled exception - "ValueError: list.remove(x): x not in list"
# 2023.01.30   Victor Zuniga      Replacing function call from getBucketInfo to getBucketStats.  Same signature,
#                                 just more accurate function name.

import os
import sys
import requests
import logging

from bbc_log.dba_log import *
#from bbc_cb.cbThresholds import *
from bbc_cb.cbThresholds import gTHRESH
from bbc_cb.cb_cluster import cCluster
from bbc_cb.env_config import getClusterNodes
from bbc_cb.cb_api import getNodeCertInfo, getSSLEndpoint
from bbc_cb.env_config import getClusterNodes

logger = logging.getLogger(__name__)

gvSNOWGroup = "Database Admin Couchbase"
gvTNLLevel = 4
gvSource = "CB-DBA-Monitor"

#gdTNL = {'i': 4, 'q': 4, 'p': 4}

# ------------------------------------------------------------------------------------------------------------------------


def createSNOWEvent(pMetric, pDesc, pGroup=gvSNOWGroup, pTNL=gvTNLLevel, pSNOW='TEST'):
    """
    Create ServiceNow event
    """

    logger.debug("createSNOWEvent")
    logger.debug("createSNOWEvent: Metric:     %s" % pMetric)
    logger.debug("createSNOWEvent: Desciption: %s" % pDesc)
    logger.debug("createSNOWEvent: Group:      %s" % pGroup)
    logger.debug("createSNOWEvent: TNL Level:  %s" % pTNL)
    logger.info ("createSNOWEvent: SNow Inst:  %s" % pSNOW)

    if pSNOW == 'TEST':
        vURL = 'https://bbctest.service-now.com:443/api/global/em/jsonv2?source=em_event.list'
    else:
        vURL = 'https://bbcprod.service-now.com:443/api/global/em/jsonv2?source=em_event.list'

    vHdrs = {'Accept': 'application/json', 'Content-Type': 'application/json'}
    vParams = (('source', 'em_event.list'))
    logger.debug("createSNOWEvent: Headers: %s" % str(vHdrs))
    #logger.debug("Params:  %s" % str(vParams))

    vData = '{"records" : [ { "source":"%s","metric_name":"%s","description":"-issue:%s","additional_info":"{\'short_description\':\'%s\',\'owner\':\'%s\',\'tnl\':\'%s\'}" } ] }' % (
        gvSource, pMetric, pDesc, pDesc, pGroup, pTNL)

    logger.info("createSNOWEvent: Data: %s" % str(vData))
    logger.info("createSNOWEvent: SNOW URL: %s" % vURL)

    #vRC = requests.post('https://bbctest.service-now.com:443/api/global/em/jsonv2?source=em_event.list', headers=vHdrs, data=vData)
    vRC = requests.post( vURL, headers=vHdrs, data=vData)
    

    if vRC.status_code != 200:
        logger.warning('createSNOWEvent: Ret Code: %s' % str(vRC.status_code))
        logger.warning("createSNOWEvent: RC Text : %s" % vRC.text)
        return vRC
    else:
        logger.info("createSNOWEvent: Event created")
        logger.info("createSNOWEvent: RC Text : %s" % vRC.text)
    return vRC


# ------------------------------------------------------------------------------------------------------------------------

def monClusterHealth(pCluster, pSNOW='TEST'):
    """
    Process the cluster and monitor cluster/node health.
    Expects pCluster to be an instance of cCluster class.
    """

    #logger.info("In monClusterHealth: %s" % pCluster.clusterName)
    logger.info("In monClusterHealth: %s" % pCluster.clusterInfo['name'])

    try:

        logger.debug("... monClusterHealth. try1 ")
        vClusterEnv = pCluster.clusterInfo['name'][-1]
        logger.debug("Cluster: %s - Env: %s" %
                     (pCluster.clusterInfo['name'], vClusterEnv))
        #vTNL = gdTNL[vClusterEnv]
        vEnvTNL = gTHRESH[vClusterEnv]['defaultTNL']
        logger.debug("Env TNL Level: %s" % vEnvTNL)

        # Cluster balanced
        if pCluster.clusterInfo['clusterBalanced'] == True:
            logger.info("%s - Cluster is balanced" % pCluster.clusterInfo['name'])
            #print("%s - cluster is balanced" % pCluster.clusterName)
        else:
            #print("%s - cluster is NOT balanced" % pCluster.clusterName)
            logger.error("%s - cluster is NOT balanced" % pCluster.clusterInfo['name'])
            vRet = createSNOWEvent(
                "[Cluster Health]", "%s - cluster is NOT balanced" % pCluster.clusterInfo['name'], pTNL=vEnvTNL, pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")
                print("ERROR: Service Now event not created.")
                # Consider sending email to DBA team about failed event.

        # Cluster memory(RAM) Usage
        logger.info("Checking %s memory usage" % pCluster.clusterInfo['name'])
        logger.debug("Checking %s memory usage" % pCluster)
        vClusterRAMPct = round(
            (pCluster.clusterInfo['storage']['ram']['quotaUsed']/pCluster.clusterInfo['storage']['ram']['quotaTotal'])*100, 2)
        
        #if vClusterRAMPct >= clustRAM.critThresh:
        if vClusterRAMPct >= gTHRESH[vClusterEnv]['clustRAM']['critThres']:
            logger.warning("%s RAM Usage Alert: %s " %
                           (pCluster.clusterInfo['name'], str(vClusterRAMPct)))
            vRet = createSNOWEvent("[Cluster Health]", "%s - RAM Usage Alert: %s " % (
                pCluster.clusterInfo['name'], str(vClusterRAMPct)), pTNL=gTHRESH[vClusterEnv]['clustRAM']['critTNL'], pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")
                print("ERROR: Service Now event not created.")
                # Consider sending email to DBA team about failed event.
        elif vClusterRAMPct >= gTHRESH[vClusterEnv]['clustRAM']['warnThres']:
            logger.warning("%s RAM Usage Warning: %s " %
                           (pCluster.clusterInfo['name'], str(vClusterRAMPct)))
            vRet = createSNOWEvent("[Cluster Health]", "%s - RAM Usage Warning: %s " % (
                pCluster.clusterInfo['name'], str(vClusterRAMPct)), pTNL=gTHRESH[vClusterEnv]['clustRAM']['warnTNL'], pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")
                print("ERROR: Service Now event not created.")
                # Consider sending email to DBA team about failed event.

        else:
            logger.info("%s - RAM Usage PCT: %s" %
                        (pCluster.clusterInfo['name'], str(vClusterRAMPct)))

        # Check Nodes
        for vNode in pCluster.clusterInfo['nodes'].keys():
            logger.debug("Checking node: %s" % vNode)
            if pCluster.clusterInfo['nodes'][vNode].nodeInfo['status'].strip() != 'healthy' or pCluster.clusterInfo['nodes'][vNode].nodeInfo['clusterMembership'].strip() != 'active':
                logger.warning("%s -- node is %s/%s" % (
                    vNode, pCluster.clusterInfo['nodes'][vNode].nodeInfo['status'], pCluster.clusterInfo['nodes'][vNode].nodeInfo['clusterMembership']))
                vRet = createSNOWEvent("[Node Health]", "%s - node is %s/%s" % ( vNode, 
                                                                                 pCluster.clusterInfo['nodes'][vNode].nodeInfo['status'], 
                                                                                 pCluster.clusterInfo['nodes'][vNode].nodeInfo['clusterMembership']), 
                                       pTNL=vEnvTNL,
                                       pSNOW = pSNOW)
                if vRet.status_code != 200:
                    logger.error("ERROR: Service Now event not created.")
                    print("ERROR: Service Now event not created.")
                    # Consider sending email to DBA team about failed event.
            else:
                #print("%s -- node is %s/%s" % (vNode,
                #                               pCluster.nodeInfo[vNode].nodeStatus, pCluster.nodeInfo[vNode].clusterMembership))
                logger.info("%s -- node is %s/%s" % (vNode,
                                                     pCluster.clusterInfo['nodes'][vNode].nodeInfo['status'], 
                                                     pCluster.clusterInfo['nodes'][vNode].nodeInfo['clusterMembership']))

            # Node Memory & CPU
            logger.info ("Checking %s memory/CPU" % vNode)
            logger.warning("THIS FAR 1")
            if pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_util_rate'] >= gTHRESH[vClusterEnv]['hostRAM']['critThres']:
                logger.warning("%s - node RAM Usage %s above critical threshold of %s" %
                               (vNode, str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_util_rate']), hostRAM.critThresh))
                logger.warning("%s - ALERT: RAM Usage: %s%% [%sG/%sG Total]" % (vNode, 
                                                                                str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_util_rate']), 
                                                                                str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['memUsedGb']), 
                                                                                str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_total'])))
                vRet = createSNOWEvent("[Node RAM]",
                                       "%s - ALERT: RAM Usage: %s%% [%sG/%sG Total]" % (vNode, 
                                                                                        str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_util_rate']), 
                                                                                        str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['memUsedGb']), 
                                                                                        str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_total'])),
                                       pTNL=gTHRESH[vClusterEnv]['hostRAM']['critTNL'],
                                       pSNOW = pSNOW)
                if vRet.status_code != 200:
                    logger.error("ERROR: Service Now event not created.")
                    print("ERROR: Service Now event not created.")
                    # Consider sending email to DBA team about failed event.

            elif pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_util_rate'] >= gTHRESH[vClusterEnv]['hostRAM']['warnThres']:
                logger.warning("THIS FAR 2")
                logger.warning("%s - node RAM Usage %s above warning threshold of %s" %
                               (vNode, str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_util_rate']), hostRAM.critThresh))
                logger.warning("%s - WARNING: RAM Usage: %s%% [%sG/%sG Total]" % (vNode, 
                                                                                str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_util_rate']), 
                                                                                str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['memUsedGb']), 
                                                                                str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_total'])))
                
                vRet = createSNOWEvent("[Node RAM]",
                                       "%s - WARNING: RAM Usage: %s%% [%sG/%sG Total]" % (vNode, 
                                                                                        str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_util_rate']), 
                                                                                        str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['memUsedGb']), 
                                                                                        str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_total'])),
                                       pTNL=gTHRESH[vClusterEnv]['hostRAM']['warnTNL'],
                                       pSNOW = pSNOW)
                if vRet.status_code != 200:
                    logger.error("ERROR: Service Now event not created.")
                    print("ERROR: Service Now event not created.")
                    # Consider sending email to DBA team about failed event.
            else:
                logger.warning("THIS FAR 3")
                logger.debug("%s - RAM Usage: %s%% [%sG/%sG Total]" % (vNode, 
                                                                       str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_util_rate']), 
                                                                       str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['memUsedGb']), 
                                                                       str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['mem_total'])))
                logger.debug("%s - CPU Usage: %s%% [%s CPUs]" % (vNode, 
                                                                 str(round(pCluster.clusterInfo['nodes'][vNode].nodeInfo['cpu_util_rate'], 2)), 
                                                                 str(pCluster.clusterInfo['nodes'][vNode].nodeInfo['cpuCount'])))

    except:
        logger.warning(
            "WARNING: issue encountererd getting cluster information")
        logger.warning("Unexpected error: %s" % str(sys.exc_info()[0]))
        print("Unexpected error:%s" % str(sys.exc_info()[0]))
        return False

    return True

# ------------------------------------------------------------------------------------------------------------------------

def monXDCR ( pRemote, pRepls, pCluster, pSNOW='TEST'):
    '''
    Receive the remote cluster and replication information for a cluster.  Traverse those dictionaries/arrays and determin
    if there is a need to alert/alarm.
    '''

    logger.debug("In monXDCR: %s" % pCluster)
    logger.debug("pRemote: %s" % str(pRemote))
    logger.debug("pRepls : %s" % str(pRepls))

    vClusterEnv = pCluster[-1]
    logger.debug("Cluster: %s - Env: %s" % (pCluster, vClusterEnv))
    vEnvTNL = gTHRESH[vClusterEnv]['defaultTNL']
    logger.debug("Env TNL Level: %s" % vEnvTNL)


    ldRemote = {}
    
    if len(pRemote) <= 0:
        logger.info ("%s does not have remote XDCR connections" % pCluster)
        return False
    else:
        for lvRemote in pRemote:
            # Traverse Remote connections and create a dict of uuid to cluster name
            #logger.info ("%s - Remote: %s" % (pCluster, lvRemote["name"]))
            ldRemote[lvRemote['uuid']] = lvRemote['name']

    logger.debug ("Remote Dict: %s" % str(ldRemote))

    #try:
    if len(pRepls) > 0:
        for lRepl in pRepls:
            if 'id' in lRepl.keys() and 'target' in lRepl.keys():
                lvReplID = lRepl['id'].split('/')[0]
                lvTrgtBkt = lRepl['target'].split('/')[-1]
                logger.info ("%s: %s -> %s.%s Status: %s Changes Left: %s Errors: %s" % (pCluster,
                                                                                         lRepl['source'], 
                                                                                         ldRemote[lvReplID],
                                                                                         lvTrgtBkt,
                                                                                         lRepl['status'],
                                                                                         str(lRepl["changesLeft"]),
                                                                                         str(lRepl['errors']) ))
                # Check changesLeft queue.
                if lRepl["changesLeft"] >= gTHRESH[vClusterEnv]['xdcrChangesLeft']['critThres']:
                    lvMsg = "%s - %s -> %s.%s : Changes Left [%s] exceed critical threshold [%s]" % (pCluster, 
                                                                                                   lRepl['source'],
                                                                                                   ldRemote[lvReplID], lvTrgtBkt,
                                                                                                   str(lRepl["changesLeft"]), 
                                                                                                   gTHRESH[vClusterEnv]['xdcrChangesLeft']['critThres'] )
                    logger.warning (lvMsg)
                    vRet = createSNOWEvent("[XDCR ChangesLeft]", lvMsg, pTNL=gTHRESH[vClusterEnv]['xdcrChangesLeft']['critTNL'], pSNOW = pSNOW)
                    if vRet.status_code != 200:
                        logger.error("ERROR: Service Now event not created.")
                        print("ERROR: Service Now event not created.")
                        # Consider sending email to DBA team about failed event.
                elif lRepl["changesLeft"] >= gTHRESH[vClusterEnv]['xdcrChangesLeft']['warnThres']:
                    lvMsg = "%s - %s -> %s.%s : Changes Left [%s] exceed warning threshold [%s]" % (pCluster, 
                                                                                                  lRepl['source'],
                                                                                                  ldRemote[lvReplID], lvTrgtBkt,
                                                                                                  str(lRepl["changesLeft"]), 
                                                                                                  gTHRESH[vClusterEnv]['xdcrChangesLeft']['warnThres'] )
                    logger.warning (lvMsg)
                    #vRet = createSNOWEvent("XDCR ChangesLeft", lvMsg, pTNL=vTNL)
                    #vRet = createSNOWEvent("XDCR ChangesLeft", lvMsg, pTNL=5)
                    vRet = createSNOWEvent("[XDCR ChangesLeft]", lvMsg, pTNL=gTHRESH[vClusterEnv]['xdcrChangesLeft']['warnTNL'], pSNOW = pSNOW)
                    if vRet.status_code != 200:
                        logger.error("ERROR: Service Now event not created.")
                        print("ERROR: Service Now event not created.")
                        # Consider sending email to DBA team about failed event.       
                else:
                    logger.debug ("Changes left [%s]" % str(lRepl["changesLeft"]))
            
                # Check status
                if lRepl['status'] != 'running':
                    lvMsg = "%s - %s -> %s.%s : Replication status is %s [not running]" % (pCluster,
                                                                                        lRepl['source'],
                                                                                        ldRemote[lvReplID], lvTrgtBkt,
                                                                                        lRepl['status'])
                    vRet = createSNOWEvent("[XDCR Replication]", lvMsg, pTNL=vEnvTNL, pSNOW = pSNOW)
                    if vRet.status_code != 200:
                        logger.error("ERROR: Service Now event not created.")
                        print("ERROR: Service Now event not created.")
                        # Consider sending email to DBA team about failed event.                                                                                         
                else:
                    logger.debug("%s - %s -> %s.%s: Status %s " % (pCluster,lRepl['source'],
                                                                 ldRemote[lvReplID], lvTrgtBkt,
                                                                 lRepl['status'] ))
                # Check Errors
                if lRepl['errors'] != []:
                    lvMsg = "%s - %s - %s.%s : Repl has errors: %s" % (pCluster, lRepl['source'], ldRemote[lvReplID], lvTrgtBkt, str(lRepl['errors'] ))
                    logger.warning(lvMsg)
                    vRet = createSNOWEvent("[XDCR Replication]", lvMsg, pTNL=vEnvTNL, pSNOW = pSNOW)
                    if vRet.status_code != 200:
                        logger.error("ERROR: Service Now event not created.")
                        #print("ERROR: Service Now event not created.")
                        # Consider sending email to DBA team about failed event.   
                else:
                    lvMsg = "%s - %s - %s.%s : errors: %s" % (pCluster, lRepl['source'], ldRemote[lvReplID], lvTrgtBkt, str(lRepl['errors'] ))
                    logger.debug(lvMsg)

            else:
                logger.info ("Cluster %s does not have remote replications defined" % pCluster)
    else:
        logger.info ("Cluster %s does not have remote replications defined" % pCluster)
    #except:
    #    logger.warning("WARNING processing replications")
    #    #logger.warning("Repls: %s" % str(pRepls))
    #    logger.warning("WARNING: %s" % sys.exc_info()[0])

    return True


# ------------------------------------------------------------------------------------------------------------------------


def monClusterCerts (pCluster, pAuthCreds, pSNOW='TEST'):
    """
    Verify the certificate warnings from the cluster.
    Make a call to each node as needed until a valid call is received.
    """

    logger.debug ("monClusterCerts: %s" % pCluster)

    vClusterNodes = getClusterNodes(pCluster)
    logger.debug("monClusterCerts: %s [%s]" % (pCluster, vClusterNodes))
    vCertInfoFound = False

    vClusterEnv = pCluster[-1]
    logger.debug("Cluster: %s - Env: %s" % (pCluster, vClusterEnv))
    vEnvTNL = gTHRESH[vClusterEnv]['defaultTNL']
    logger.debug("Env TNL Level: %s" % vEnvTNL)

    for vNode in vClusterNodes:
        logger.debug("monClusterCerts - node: %s" % vNode)
        vNodeCertInfo = getNodeCertInfo(pAuthCreds, vNode)

        if ('bbc_err_code' not in vNodeCertInfo.keys()) and ('warnings' in vNodeCertInfo.keys()):
            # Got certificate information from node, break out of loop
            logger.info("monClusterCerts - node: %s - retrieved cert info" % vNode)
            vCertInfoFound = True
            break
        
    if vCertInfoFound:
        if vNodeCertInfo['warnings'] != []:
            # Clean up cert warnings into consize message
            try:
                vWarnList = []
                for w in vNodeCertInfo['warnings']:
                    vWarnList.append( "%s - %s" % (w['message'], w['expires'].split('T')[0] ))
                    lvMsg = "%s - %s" % (pCluster, list(set(vWarnList))[0])
                logger.info("monClusterCerts: warning list: %s" % str(vWarnList))
            except:
                lvMsg = "%s - cluster has cert warnings" % pCluster
            
            #lvMsg = "%s cluster has cert warnings: %s" % (pCluster, str(vNodeCertInfo['warnings']))
            logger.info ("monClusterCerts: %s" % (lvMsg) )
            vRet = createSNOWEvent("[Cluster Certs]", lvMsg, pTNL=vEnvTNL, pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")

    else:
        logger.warning ("monClusterCerts: %s - Could not get cluster cert info" % pCluster)
        return False
        
    return True


# ------------------------------------------------------------------------------------------------------------------------

def monQueryTimeouts (pCluster, pAuth, pSNOW='TEST', pTimeGap=-1, pTimeGapDesc='hour', pQryDtls = False):
    '''
    Function to monitor the number of query timeouts in a particular cluster.
    '''
    
    from couchbase.cluster import Cluster, ClusterOptions
    from couchbase.auth import PasswordAuthenticator
    from couchbase.cluster import QueryOptions

    logger.debug("in monQueryTimeouts")
    logger.debug("Cluster: %s" % pCluster)
    
    if int(pTimeGap) > 0:
        logger.debug("Converting time gap %d to negative: %d" % (int(pTimeGap), 0-int(pTimeGap) ))
        pTimeGap = 0-int(pTimeGap)

    logger.debug("Time Gap: %s" % str(pTimeGap))
    logger.debug("Gap Desc: %s" % pTimeGapDesc)

    ### Testing....
    #pSNOW = 'TEST'
    logger.info("Using %s ServiceNow instance" % pSNOW)

    # Since we cannot connect using SSL (and SRV record) get data nodes
    vNodes = ','.join(getClusterNodes(pCluster)[:3])
    vConnString = "couchbase://%s" % vNodes
    logger.info ("Connect String: '%s'" % vConnString)
    
    # Connect to the cluster
    try:
        vCluster = Cluster(vConnString, ClusterOptions(PasswordAuthenticator(pAuth[0],pAuth[1])))
        logger.debug("Cluster: %s" % str(vCluster))

        try:
            vN1QL = 'SELECT now_str() execDate, count(1) errCount FROM system:completed_requests WHERE requestTime > ( date_add_str(now_str(), $1, $2) ) AND errorCount > 0 group by 1'
            logger.debug("Query: %s" % vN1QL)

            vRowIter = vCluster.query(vN1QL, QueryOptions(positional_parameters=[pTimeGap, pTimeGapDesc ]))
            logger.debug("Results: %s" % str(list(vRowIter)))
            
            # There should only be 1 count, if any.
            if len(list(vRowIter)) > 1:
                logger.warning("WARNING: %s records returned, expected only 1" % str(len(list(vRowIter))) )
                logger.warning("query: [%s] %s" % (pCluster, vN1QL) )
                for vRow in vRowIter:
                    logger.warning("Row: %s" % str(vRow))
                vRetDict = {pCluster: list(vRowIter)}
            elif len(list(vRowIter)) == 1:
                logger.info( "Cluster: %s - %s" % (pCluster, str(list([vRowIter])[0])))
                #print ( "Cluster: %s - %s" % (pCluster, str(list(vRowIter)[0])))
                if list(vRowIter)[0]['errCount'] > 0:
                    vMsg = "%s has %s query timeouts in the last %s %s(s)" % (pCluster, list(vRowIter)[0]['errCount'], str(abs(pTimeGap)), pTimeGapDesc)
                    logger.warning(vMsg)
                vRetDict = {pCluster: list(vRowIter)[0]}

                #vRetDict[pCluster]["searchOptions"] = {"timeGap": pTimeGap, "unit" : pTimeGapDesc}

                if pQryDtls:
                    # Get details of failed queries
                    logger.debug("Get failed query details")
                    #vN1QL = 'SELECT cr.* FROM system:completed_requests as cr WHERE requestTime > ( date_add_str(now_str(), $1, $2) ) AND errorCount > 0 '
                    vN1QL =  'select error.code as errCode, error.`key` as errKey, error.message as errMsg, cr.node, cr.state, cr.statement, cr.users, cr.remoteAddr, cr.requestTime, cr.scanConsistency '
                    vN1QL += '  from system:completed_requests as cr '
                    vN1QL += 'unnest cr.errors as error '
                    vN1QL += ' WHERE cr.requestTime > ( date_add_str(now_str(), $1, $2) ) '
                    vN1QL += '   AND cr.errorCount > 0 '
                    logger.debug("Query: %s" % vN1QL)

                    vRowIter = vCluster.query(vN1QL, QueryOptions(positional_parameters=[pTimeGap, pTimeGapDesc ]))
                    logger.info("Results: %s" % str(list(vRowIter)))
                    vRetDict[pCluster]['failedQueries'] = list(vRowIter)

            else:
                # Nothing to do, really.
                logger.info( "Cluster: %s - %s" % (pCluster, str(list([]))))
                #print ( "Cluster: %s - %s" % (pCluster, str(list([]))))
                vRetDict = {pCluster: list(vRowIter)}

        except CouchbaseException as ex:
            import traceback
            traceback.print_exc()
        except:
            logger.warning("Error: Something happened")
            #print ("Error: ", sys.exc_info()[0])
            vRetDict =  {pCluster:{"bbc_err_code":"0003", "bbc_err_desc": sys.exc_info()[0]} }

    except:
        logger.warning("Could not establish connection to cluster %s" % pCluster)
        logger.debug("Auth: %s" % str(pAuth))
        #return {"bbc_err_code":"0002", "bbc_err_desc": "Error connecting to cluster"}
        vRetDict =  {pCluster : {"bbc_err_code":"0002", "bbc_err_desc": "Error connecting to cluster"}}

    return vRetDict

# ------------------------------------------------------------------------------------------------------------------------

def monBucket( pBucket, pNode, pAuth, pVerbose = 'False', pSNOW = 'TEST'):
    '''
    Check the bucket to ensure no issus are found
    '''

    from bbc_cb.cb_api import getBucketStats
    from bbc_cb.env_config import getNodeCluster

    logger.debug ("monBucket: %s [%s]" % (pBucket, pNode))
    logger.debug ("monBucket: %s/%s" % (pAuth[0], pAuth[1].replace(pAuth[1], '*' * len(pAuth[1]))))
    
    vBktInfo = getBucketStats(pBucket, pNode, pAuth)
    vCluster = getNodeCluster(pNode)

    
    # Determine environment level based on the node name, if not i,q,p, then use p (most restrictive)
    vENV = pNode[-1]
    if vENV not in 'iqp':
        vENV = 'p'
        logger.debug("Forcing PROD env for node %s" % pNode)

    logger.info ("Environment: %s" % vENV)

    logger.debug ("Bucket: %s - Info: %s" % (pBucket, str(vBktInfo)))

    vSampleCount = vBktInfo['op']['samplesCount']-1
    #vSampleCount = 0

    logger.debug ("Sample Count: %s" % str(vSampleCount))
    
    # ----------------------------------------------------------------------------------------------------
    # Bucket Max Memory (RAM)
    # ----------------------------------------------------------------------------------------------------
    try:
        vBktRamMax = vBktInfo['op']['samples']['ep_max_size'][vSampleCount]
    except:
        logger.debug("Reduced samples for ep_max_size")
        vBktRamMax = vBktInfo['op']['samples']['ep_max_size'][vSampleCount -1]

    vMsg = "{}[{}] - Ram Max: {:,}".format(vCluster, pBucket, vBktRamMax)
    logger.debug (vMsg)
    if pVerbose == True:
        logger.info(vMsg)
        print (vMsg)
    
    # ----------------------------------------------------------------------------------------------------
    # Bucket Document Count
    # ----------------------------------------------------------------------------------------------------
    try:
        vBktDocCount = vBktInfo['op']['samples']['curr_items'][vSampleCount]
    except:
        logger.debug("Reduced samples for curr_items")
        vBktDocCount = vBktInfo['op']['samples']['curr_items'][vSampleCount-1]

    vMsg = "{}[{}] - Doc Count: {:,}".format(vCluster, pBucket, vBktDocCount)
    logger.debug (vMsg)
    if pVerbose == True:
        logger.info(vMsg)
        print (vMsg)

    # ----------------------------------------------------------------------------------------------------
    # Bucket Memory Used %
    # ----------------------------------------------------------------------------------------------------
    try:
        vBktRamUsed = vBktInfo['op']['samples']['mem_used'][vSampleCount] 
    except:
        logger.debug("Reduced samples for mem_used")
        vBktRamUsed = vBktInfo['op']['samples']['mem_used'][vSampleCount -1] 
    
    vBktRamPct = (vBktRamUsed/vBktRamMax) * 100
    
    vMsg = "{} [{}] - Ram Used: {:,} [{:.2f}%]".format(vCluster, pBucket, vBktRamUsed, vBktRamPct)

    logger.debug (vMsg)
    if pVerbose == True:
        logger.info(vMsg)
        print (vMsg)
        
    if vBktRamPct > gTHRESH[vENV]['bktRAMPct']['critThres']:
        vMsg = "... %s [%s] RAM Usage PCT [%s] exceeds critical threshold %s" % (vCluster, pBucket, str(vBktRamPct), gTHRESH[vENV]['bktRAMPct']['critThres']) 
        logger.warning(vMsg)
        if pVerbose == True:
            print(vMsg)
        else:
            # Create Service Now event if not in verbose mode
            vRet = createSNOWEvent("[Bucket Health]", vMsg, pTNL=gTHRESH[vENV]['bktRAMPct']['critTNL'], pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")

    elif vBktRamPct > gTHRESH[vENV]['bktRAMPct']['warnThres']:
        vMsg = "%s [%s] RAM Usage PCT [%s] exceeds warning threshold %s" % (vCluster, pBucket, str(vBktRamPct), gTHRESH[vENV]['bktRAMPct']['warnThres']) 
        logger.warning(vMsg)
        if pVerbose == True:
            print("... %s" % vMsg)
        else:
            # Create Service Now event if not in verbose mode
            vRet = createSNOWEvent("[Bucket Health]", vMsg, pTNL=gTHRESH[vENV]['bktRAMPct']['warnTNL'], pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")


    # ----------------------------------------------------------------------------------------------------
    # Bucket Meta data used %
    # ----------------------------------------------------------------------------------------------------
    try:
        vBktMetaUsed = vBktInfo['op']['samples']['ep_meta_data_memory'][vSampleCount]
    except:
        logger.debug("Reduced samples for ep_meta_data_memory")
        vBktMetaUsed = vBktInfo['op']['samples']['ep_meta_data_memory'][vSampleCount-1]
    
    vBktMetaPct = (vBktMetaUsed/vBktRamMax) * 100
    vMsg = "{} [{}] - Meta Used: {:,} [{:.2f}%]".format(vCluster, pBucket, vBktMetaUsed, vBktMetaPct)
    logger.debug (vMsg)
    if pVerbose == True:
        logger.info (vMsg)
        print (vMsg)

    if vBktMetaPct > gTHRESH[vENV]['bktMetaPct']['critThres']:
        vMsg = "%s [%s] Meta Usage PCT [%5.2f%%] exceeds crit threshold %s%%" % (vCluster, pBucket, vBktRamPct, gTHRESH[vENV]['bktMetaPct']['critThres']) 
        logger.warning(vMsg)
        if pVerbose == True:
            print("... %s" % vMsg)
        else:
            vRet = createSNOWEvent("[Bucket Health]", vMsg, pTNL=gTHRESH[vENV]['bktMetaPct']['critTNL'], pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")
    elif vBktMetaPct > gTHRESH[vENV]['bktMetaPct']['warnThres']:
        vMsg = "%s [%s] Meta Usage PCT [%5.2f%%] exceeds warn threshold %s%%" % (vCluster, pBucket, vBktRamPct, gTHRESH[vENV]['bktMetaPct']['warnThres']) 
        logger.warning(vMsg)
        if pVerbose == True:
            print("... %s" % vMsg)
        else:
            vRet = createSNOWEvent("[Bucket Health]", vMsg, pTNL=gTHRESH[vENV]['bktMetaPct']['warnTNL'], pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")

    # ----------------------------------------------------------------------------------------------------
    # Bucket vBucket Resident percentages (active and replica)
    # ----------------------------------------------------------------------------------------------------
    try:
        vBktDocAPct = vBktInfo['op']['samples']['vb_active_resident_items_ratio'][vSampleCount]
    except:
        logger.debug("Reduced samples for vb_active_resident_items_ratio")
        vBktDocAPct = vBktInfo['op']['samples']['vb_active_resident_items_ratio'][vSampleCount-1]

    vMsg = "{} [{}] - VB Active Res: {:.2f}%".format(vCluster, pBucket, vBktDocAPct)
    logger.debug (vMsg)
    if pVerbose == True:
        logger.info(vMsg)
        print (vMsg)

    if vBktDocAPct < gTHRESH[vENV]['bktResPct']['critThres']:
        vMsg = "%s [%s] Active Resident PCT [%5.2f%%] is below critical threshold %s%%" % (vCluster, pBucket, vBktDocAPct, gTHRESH[vENV]['bktResPct']['warnThres'])
        logger.warning(vMsg)
        if pVerbose:
            logger.info(vMsg)
            print("... %s" % vMsg)
        else:
            vRet = createSNOWEvent("[Bucket Health]", vMsg, pTNL=gTHRESH[vENV]['bktResPct']['critTNL'], pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")
    elif vBktDocAPct < gTHRESH[vENV]['bktResPct']['warnThres']:
        vMsg = "%s [%s] Active Resident PCT [%5.2f%%] is below warning threshold %s%%" % (vCluster, pBucket, vBktDocAPct, gTHRESH[vENV]['bktResPct']['warnThres'])
        logger.warning(vMsg)
        if pVerbose:
            logger.warning(vMsg)
            print("... %s" % vMsg)
        else:
            vRet = createSNOWEvent("[Bucket Health]", vMsg, pTNL=gTHRESH[vENV]['bktResPct']['warnTNL'], pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")

    try:
        vBktDocRPct = vBktInfo['op']['samples']['vb_replica_resident_items_ratio'][vSampleCount]
    except:
        logger.debug("Reduced samples for vb_replica_resident_items_ratio")
        vBktDocRPct = vBktInfo['op']['samples']['vb_replica_resident_items_ratio'][vSampleCount-1]
    
    vMsg = "{} [{}] - VB Replica Res: {:.2f}%".format(vCluster, pBucket, vBktDocRPct)
    logger.debug (vMsg)
    if pVerbose == True:
        logger.info(vMsg)
        print (vMsg)

    if vBktDocRPct < gTHRESH[vENV]['bktResPct']['critThres']:
        vMsg = "%s [%s] Replica Resident PCT [%5.2f%%] is below critical threshold %s%%" % (vCluster, pBucket, vBktDocRPct, gTHRESH[vENV]['bktResPct']['critThres'])
        logger.warning(vMsg)
        if pVerbose:
            print("... %s" % vMsg)
        else:
            vRet = createSNOWEvent("[Bucket Health]", vMsg, pTNL=gTHRESH[vENV]['bktResPct']['critTNL'], pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")
    elif vBktDocRPct < gTHRESH[vENV]['bktResPct']['warnThres']:
        vMsg = "%s [%s] Replica Resident PCT [%5.2f%%] is below warning threshold %s%%" % (vCluster, pBucket, vBktDocRPct, gTHRESH[vENV]['bktResPct']['warnThres'])
        logger.warning(vMsg)
        if pVerbose:
            print("... %s" % vMsg)
        else:
            vRet = createSNOWEvent("[Bucket Health]", vMsg, pTNL=gTHRESH[vENV]['bktResPct']['warnTNL'], pSNOW = pSNOW)
            if vRet.status_code != 200:
                logger.error("ERROR: Service Now event not created.")


    # ----------------------------------------------------------------------------------------------------
    # Bucket Fragmentation percentage
    # ----------------------------------------------------------------------------------------------------
    try:
        vBktFragPct = vBktInfo['op']['samples']['couch_docs_fragmentation'][vSampleCount] 
    except:
        logger.debug("Reduced samples for couch_docs_fragmentation")
        vBktFragPct = vBktInfo['op']['samples']['couch_docs_fragmentation'][vSampleCount-1]

    vMsg = "%s [%s] - Doc Frag Pct: %d" % (vCluster, pBucket, vBktFragPct)
    logger.debug (vMsg)
    if pVerbose == True:
        logger.info(vMsg)
        print (vMsg)

    if pVerbose == True:
        print("")

   
    return True


# ------------------------------------------------------------------------------------------------------------------------
# Individual monitoring functions
# ------------------------------------------------------------------------------------------------------------------------

def monClusterBalance(pCluster, pAuth):
    '''
    Monitor the cluster balance state.  Does it need to be rebalanced?
    '''

    from bbc_cb.cb_api import getPoolsDefault

    logger.debug("In monClusterBalance - cluster: %s" % str(pCluster))

    try:
        vClusterPools = getPoolsDefault(pAuth, pCluster)
        logger.debug ("%s : balanced: %s" % (pCluster, str(vClusterPools["balanced"])))
        return (pCluster, vClusterPools["balanced"])
        
    except Exception as e:
        logger.warning("Exception type: %s" % str(type(e)))
        logger.warning(e.args)
        logger.warning(e)
        return "WARNING: %s - Error getting cluster balance" % pCluster

    return true


def monClusterMemoryUsage(pCluster, pSNOW='TEST'):
    '''
    Monintor the cluster memory usage 
    '''

    return True


def monClusterNodeHealth(pCluster, pAuth):
    '''
    Check the health of each node in the cluster. Return nodes that are not active or healthy.
    '''
    # Return the inactive and/or unhealthy nodes.
    from bbc_cb.cb_api import getPoolsDefault
    from bbc_cb.env_config import getRandomClusterNode, getClusterNodes

    logger = logging.getLogger ( __name__ )

    vClusterInfo = getPoolsDefault(pAuth, pCluster)
    logger.debug("vClusterInfo: %s" % str(vClusterInfo))
    
    vRetNodeList = []
    vNodeList = getClusterNodes(pCluster)
    logger.debug("Expected Nodes: %s" % str(vNodeList))

    for vNode in vClusterInfo['nodes']:
        logger.debug("%s : %s : %s" % (vNode['hostname'], vNode['status'], vNode['clusterMembership']))
        
        # Remove node from list of expected nodes.
        try:
            vNodeList.remove(vNode['hostname'].split('.')[0])
        except:
            logger.debug("vNodeList: %s" % str(vNodeList))
            logger.debug("vNode: %s" % str(vNode['hostname']))

        if vNode['status'] != 'healthy' or vNode['clusterMembership'] != 'active':
            vRetNodeList.append(vNode['hostname'].split('.')[0])

    # unchecked node
    logger.debug("unchecked nodes: %s " % str(vNodeList))
    if len(vNodeList) != 0:
        # If nodes in expected node list.  Then add them to return list
        vRetNodeList = list(set(vRetNodeList + vNodeList))

    #return list(set( pCluster.getInactiveNodes() + pCluster.getUnhealthyNodes() ))
    logger.info("Ret: %s: %s" % (pCluster,vRetNodeList))
    return vRetNodeList


def monClusterNodeMemory(pCluster, pSNOW='TEST'):
    return True


def monClusterNodeCPU(pCluster, pSNOW='TEST'):
    return True



# Author : Victor Zuniga
# Date   : 2021.01.26
# Purpose: Break out the details of each cluster.


CBENV = {
  'q'  : {
    'cbeq02q' : ['hcb001eq02q', 'hcb002eq02q', 'hcb003eq02q' ], 
    'cbsp02q' : ['hcb001sp02q', 'hcb002sp02q', 'hcb003sp02q' ]
    }, 
  'p': {
    'cbfp02p' : ['hcb001fp02p', 'hcb002fp02p', 'hcb003fp02p' ], 
    'cbeq02p' : ['hcb001eq02p', 'hcb002eq02p', 'hcb003eq02p' ], 
    'cbsp02p' : ['hcb001sp02p', 'hcb002sp02p', 'hcb003sp02p' ]
    } 
  }

SPARES = {
           'cbfp01q': ['u01vqaalapp0071', 'u01vqaalapp0072'],
           'cbsp01q': ['u02vqaalapp0021', 'u02vqaalapp0010'],
           'cbsp01p': ['u01vpaalapp0199'],
           'cbsp01p': ['u02vpaalapp0016'],
           'cbfp04p': ['u01vpaalapp0200'],
           'cbsp04p': ['u02vpaalapp0017']
         }


PORT = 8091
TLS_PORT = 18091
FQDN = 'south.edu'
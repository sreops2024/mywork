# Author : Victor Zuniga
# Date   : 2022.11.04
# Purpose: Classes that will manage the couchbase account management.

from bbc_log.dba_log import *
from bbc_cb.env_config import getEnvClusterNames, getRandomClusterNode
from bbc_cb.cb_api import createCBUser2, getUserInfo, removeCBUser
from bbc_cb.env_config import getEnvClusterNames, getRandomClusterNode
from bbc_fileSec.encServer import getClusterCred
from bbc_misc.bbc_os import getOSVar

class cbAcct:
    ''' Parent class that will handle the user account management'''

    def __init__(self, pName, pDescription, pPassword, pCluster, pType, pGroups = None, pRoles = None):
        '''
        Initialize the account instance.
           pName - Account name
           pCluster - cluster(s) where the account will reside
           pType - Account type, local/external
           pGroups - group to be granted to the account
           pRoles - roles to be grantes to the account

        Since this is a parent class, very little checking on these parameters will be done, that will be left to the child classes.
        '''

        self.name = pName
        self.desciption = pDescription
        self.__password = pPassword
        self.cluster = pCluster
        self.__adminAcct = ('dbadmin', getClusterCred('dbadmin', self.cluster, getOSVar('CB_KEY_DIR')))
        self.node = getRandomClusterNode(self.cluster)
        self.type = pType
        self.groups = pGroups
        self.roles = pRoles
        self.__status = {'state'  : 'init',
                         'errCode': 000,
                         'errMsg' : ''
                        }
        self.__acctFound = False
        self.acctExists()

    def __str__(self):
        vStr = ("---------" * 15) + "\n"
        vStr += ("CB Account    : {0}/{1}".format( self.name, "*" * len( self.__password) )) + "\n"
        vStr += ("Acct Type     : {0}".format( self.type)) + "\n"
        vStr += ("CB cluster    : {0}[{1}]".format( self.cluster, self.node)) + "\n"
        vStr += ("Admin Account : {0}/{1}".format( self.__adminAcct[0], '*' * len( self.__adminAcct[1] ))) + "\n"
        vStr += ("Groups        : {0}".format(str(self.groups))) + "\n"
        vStr += ("Roles         : {0}".format(str(self.roles))) + "\n"
        vStr += ("---------" * 15) + "\n"
        
        return vStr

    def acctExists(self):
        ''' Determines if account exists '''

        if self.name in ['', None]:
            logger.warning("WARNING: Account class not initialized")
            self.__status = {'state'  : 'unknown',
                             'errCode': '0001',
                             'errMsg' : 'Account class not initialized'
                            }
            return False

        if self.type in ['', None]:
            logger.warning("WARNING: account type (local/external) is not defined")
            self.__status = {'state'  : 'unknown type',
                             'errCode': '0002',
                             'errMsg' : 'Account type (local/external) is not defined'
                            }
            return False
        
        vRet = getUserInfo(self.name, self.node, self.__adminAcct , self.type)
        
        if vRet.status_code == 200:
            self.__status = {'state'  : 'acct exists',
                             'errCode': '0000',
                             'errMsg' : '%s (%s) found in %s' % (self.name, self.type, self.node)
                            }
            self.__acctFound = True
            return True
        else:
            self.__status = {'state'  : 'acct does not exist',
                             'errCode': '0000',
                             'errMsg' : '%s (%s) not found in %s' % (self.name, self.type, self.node)
                            }
            self.__acctFound = False

        return False


    def create(self):
        ''' create account '''

        logger.debug ("cbAcct.create %s [%s] " % (self.name, self.type))

        if self.__acctFound:
            logger.warning("WARNING: Account %s (%s) on %s found." % (self.name, self.type, self.node))
            
            # Removed to ensure the same password is set for all the accounts in the same bucket on same environments.
            # return False

        vAcctInfo = {self.name:{}}
        vAcctInfo[self.name]["NAME"] = self.desciption
        if self.groups != None:
            vAcctInfo[self.name]["GROUPS"] = self.groups

        if self.roles != None:
            vAcctInfo[self.name]["ROLES"] = self.roles

        if self.type.lower() == 'local':
            vAcctInfo[self.name]["PASSWORD"] = self.__password
        
        if createCBUser2(vAcctInfo, self.node, self.__adminAcct, self.type):
            if self.__acctFound:
                # Since the account was already created, it was then modified
                logger.info ("Reset account %s using node: %s" % (self.name, self.node))
                self.__status = {'state'  : 'account reset',
                                 'errCode': '0000',
                                 'errMsg' : '%s (%s) reset on %s' % (self.name, self.type, self.node)
                                }
            else:
                logger.info ("Created account %s using node: %s" % (self.name, self.node))
                self.__acctFound = True
                self.__status = {'state'  : 'account created',
                                 'errCode': '0000',
                                 'errMsg' : '%s (%s) created on %s' % (self.name, self.type, self.node)
                                }
            return True
        else:
            logger.warning ("WARNING: Error creating account %s using node: %s" % (self.name, self.node))
            self.__acctFound = False
            self.__status = {'state'  : 'Account creation failed',
                             'errCode': '0005',
                             'errMsg' : 'Failed to create %s (%s) on %s' % (self.name, self.type, self.node)
                            }
            return False


    def delAcct(self):
        '''
        Removes the account from the couchbase cluster
        '''
        if removeCBUser(self.name, self.node, self.__adminAcct, self.type):
            logger.info ("Account [%s] dropped using node: %s" % (self.name, self.node))
            self.__status = {"state"  : 'Account dropped', 
                             "errCode": '0000',
                             "errMsg" : "%s (%s) dropped" % (self.name, self.node)}
            return True
        else:
            logger.info ("Account [%s] drop failed using node: %s" % (self.name, self.node))
            self.__status = {"state"  : 'Account dropped', 
                             "errCode": '0006',
                             "errMsg" : "Failed to drop %s (%s)." % (self.name, self.node)}
            return False
        return False


    def getAcctInfo(self):
        ''' Returns the information about the acct '''

        vStr = ("---------" * 15) + "\n"
        vStr += ("CB Account    : {0}/{1}".format( self.name, "*" * len( self.__password) )) + "\n"
        vStr += ("Acct Type     : {0}".format( self.type)) + "\n"
        vStr += ("CB node       : {0}".format( self.node)) + "\n"
        vStr += ("Admin Account : {0}/{1}".format( self.__adminAcct[0], '*' * len( self.__adminAcct[1] ))) + "\n"
        vStr += ("Groups        : {0}".format(str(self.groups))) + "\n"
        vStr += ("Roles         : {0}".format(str(self.roles))) + "\n"
        vStr += ("---------" * 15) + "\n"
        
        return vStr

    def getJSON(self)        :
        '''Returns accoutn information in JSON (dictionary) format'''

        vRet = {}
        vRet['name'] = "{0}/{1}".format( self.name, "*" * len( self.__password) )
        vRet['type'] = self.type
        vRet['cluster'] = self.cluster
        vRet['node'] = self.node
        vRet['adminAcct'] = "{0}/{1}".format( self.__adminAcct[0], '*' * len( self.__adminAcct[1] ))
        vRet['groups'] = self.groups
        vRet['roles'] = self.roles

        return vRet


    def reset(self):
        ''' resets account password '''

        return False


    def status(self):
        ''' Return account status info '''
        return self.__status


    def updatePwd(self):
        ''' updates account password '''

        return False


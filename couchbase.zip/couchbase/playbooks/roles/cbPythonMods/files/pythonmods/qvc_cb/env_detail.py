# Author : Victor Zuniga
# Date   : 2021.01.26
# Purpose: Break out the details of each cluster.

# 2021.05.17 Victor Zuniga       Enable cloud clusters.
# 2021.09.09 Ellen Cox           Added cbfp05 cluster.
# 2022.04.22 Victor Zuniga       Added cbeq04p cluster
# 2022.04.25 Victor Zuniga       Added cbeq03p cluster (Italy)
# 2022.07.11 Patrick Santucci    Retired cbfp01p
# 2022.07.12 Victor Zuniga       Retired cbfp04p (Prashant Cundawar)

CBENV = {
    's': {
        'cbsp00s': ['hcb001sp00s', 'hcb002sp00s', 'hcb003sp00s', 'hcb004sp00s', 'hcb005sp00s']
         },
    'i': {
        'cbeq01i': ['hcb001eq01i', 'hcb002eq01i', 'hcb003eq01i', 'hcb004eq01i', 'hcb005eq01i'],
        'cbsp01i': ['hcb001sp01i', 'hcb002sp01i', 'hcb003sp01i', 'hcb004sp01i', 'hcb005sp01i'],
        'cbjpe01i': ['hcb001jpe01i', 'hcb002jpe01i', 'hcb003jpe01i', 'hcb004jpe01i', 'hcb005jpe01i'],
        'cbu2e101i': ['hcb001u2e101i', 'hcb002u2e101i', 'hcb003u2e101i', 'hcb004u2e101i', 'hcb005u2e101i'],
        'cbeun301i': ['hcb001eun301i', 'hcb002eun301i', 'hcb003eun301i', 'hcb004eun301i', 'hcb005eun301i']
    },
    'q': {
        'cbeq01q': ['hcb001eq01q', 'hcb002eq01q', 'hcb003eq01q', 'hcb004eq01q', 'hcb005eq01q'],
        'cbsp01q': ['hcb001sp01q', 'hcb002sp01q', 'hcb003sp01q', 'hcb004sp01q', 'hcb005sp01q'],
        #'cbsp02q': ['hcb001sp02q', 'hcb002sp02q', 'hcb003sp0sq'],
        #'cbfp03q': ['hcb001fp03q', 'hcb002fp03q', 'hcb003fp03q'],
        'cbsp03q': ['hcb001sp03q', 'hcb002sp03q', 'hcb003sp03q'],
        'cbu2e101q': ['hcb001u2e101q', 'hcb002u2e101q', 'hcb003u2e101q', 'hcb004u2e101q', 'hcb005u2e101q'],
        'cbu2w101q': ['hcb001u2w101q', 'hcb002u2w101q', 'hcb003u2w101q', 'hcb004u2w101q', 'hcb005u2w101q'],
        'cbjpe01q': ['hcb001jpe01q', 'hcb002jpe01q', 'hcb003jpe01q', 'hcb004jpe01q', 'hcb005jpe01q'],
        'cbjpw01q': ['hcb001jpw01q', 'hcb002jpw01q', 'hcb003jpw01q', 'hcb004jpw01q', 'hcb005jpw01q'],
        'cbeun301q': ['hcb001eun301q', 'hcb002eun301q', 'hcb003eun301q', 'hcb004eun301q', 'hcb005eun301q'],
        'cbeuw301q': ['hcb001euw301q', 'hcb002euw301q', 'hcb003euw301q', 'hcb004euw301q', 'hcb005euw301q'],
        'cbeq90q': ['hcb001eq90q', 'hcb002eq90q', 'hcb003eq90q']
    },
    'p': {
        'cbeq01p': ['hcb001eq01p', 'hcb002eq01p', 'hcb003eq01p', 'hcb004eq01p', 'hcb005eq01p', 'hcb006eq01p'],
        'cbsp01p': ['hcb001sp01p', 'hcb002sp01p', 'hcb003sp01p', 'hcb004sp01p', 'hcb005sp01p', 'hcb006sp01p'],
        #'cbsp02p': ['hcb001sp02p', 'hcb002sp02p', 'hcb003sp0sp'],
        'cbeq03p': ['hcb001eq03p', 'hcb002eq03p', 'hcb003eq03p', 'hcb004eq03p', 'hcb005eq03p'],
        'cbeq04p': ['hcb001eq04p', 'hcb002eq04p', 'hcb003eq04p', 'hcb004eq04p', 'hcb005eq04p'],
        'cbsp04p': ['hcb001sp04p', 'hcb002sp04p', 'hcb003sp04p', 'hcb004sp04p', 'hcb005sp04p'],
        'cbeq05p': ['hcb001eq05p', 'hcb002eq05p', 'hcb003eq05p', 'hcb004eq05p', 'hcb005eq05p'],
        'cbsp05p': ['hcb001sp05p', 'hcb002sp05p', 'hcb003sp05p', 'hcb004sp05p', 'hcb005sp05p'],
        'cbeq90p': ['hcb001eq90p', 'hcb002eq90p', 'hcb003eq90p', 'hcb004eq90p', 'hcb005eq90p'],
        'cbu2e101p': ['hcb001u2e101p', 'hcb002u2e101p', 'hcb003u2e101p', 'hcb004u2e101p', 'hcb005u2e101p'],
        'cbu2w101p': ['hcb001u2w101p', 'hcb002u2w101p', 'hcb003u2w101p', 'hcb004u2w101p', 'hcb005u2w101p'],
        #'cbu2e102p': ['hcb001u2e102p', 'hcb002u2e102p', 'hcb003u2e102p', 'hcb004u2e102p', 'hcb005u2e102p'],
        #'cbu2w102p': ['hcb001u2w102p', 'hcb002u2w102p', 'hcb003u2w102p', 'hcb004u2w102p', 'hcb005u2w102p'],  
        'cbjpe201p': ['hcb001jpe201p', 'hcb002jpe201p', 'hcb003jpe201p', 'hcb004jpe201p', 'hcb005jpe201p'],
        'cbjpw201p': ['hcb001jpw201p', 'hcb002jpw201p', 'hcb003jpw201p', 'hcb004jpw201p', 'hcb005jpw201p'],
        'cbeun301p': ['hcb001eun301p', 'hcb002eun301p', 'hcb003eun301p', 'hcb004eun301p', 'hcb005eun301p'],
        'cbeuw301p': ['hcb001euw301p', 'hcb002euw301p', 'hcb003euw301p', 'hcb004euw301p', 'hcb005euw301p']
    }
}

SPARES = {
    's': {
            'cbsp00s': ['hcb006sp00s']
         },
    'i': {
            'cbeq01i': ['hcb006eq01i'],
            'cbsp01i': ['hcb006sp01i'],
            'cbu2e101i': ['hcb006u2e101i'],
            'cbjpe01i': ['hcb006jpe01i'],
            'cbeun301i': ['hcb006eun301i']
         },
    'q': {
           'cbeq01q': ['hcb006eq01q'],
           'cbsp01q': ['hcb006sp01q'],
           'cbsp03q': ['hcb004sp03q'],
           'cbjpe01q': ['hcb006jpe01q'],
           'cbjpw01q': ['hcb006jpw01q'],
           'cbu2e101q': ['hcb006u2e101q'],
           'cbu2w101q': ['hcb006u2w101q'],
           'cbeun301q': ['hcb006eun301q'],
           'cbeuw301q': ['hcb006euw301q'],
           'cbeq90q': ['hcb004eq90q']
         },
    'p': {
           'cbsp01p': ['hcb007sp01p'],
           'cbeq01p': ['hcb007eq01p'],
           'cbsp04p': ['hcb006sp04p'],
           'cbeq04p': ['hcb006eq04p'],
           'cbeq05p': ['hcb006eq05p'],
           'cbsp05p': ['hcb006sp05p'],
           'cbeq90p': ['hcb006eq90p'],
           'cbu2e101p': ['hcb006u2e101p'],
           'cbu2w101p': ['tbdp'],
           'cbu2e102p': ['tbdp'],
           'cbu2w102p': ['tbdp'],
           'cbjpe201p': ['tbdp'],
           'cbjpw201p': ['tbdp'],
           'cbeun301p': ['hcb006eun301p'],
           'cbeuw301p': ['hcb006euw301p']
         }
}

PORT = 8091
TLS_PORT = 18091
FQDN = 'south.edu'

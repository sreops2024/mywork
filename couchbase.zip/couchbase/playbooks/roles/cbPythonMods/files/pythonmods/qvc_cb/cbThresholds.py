# History:
# 2021.08.26   Victor Zuniga           Replace the classes with a dictionary so that we can have different levels for each environment, if needed.
# 2021.09.15   Victor Zuniga           Make thresholds consistent, for dev.


gTHRESH = {
        's': {'defaultTNL': 5,
              'hostCPU': { 'critThres': 95,
                           'warnThres': 90,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'clustRAM': { 'critThres': 99,
                            'warnThres': 97,
                            'critTNL'  : 4,
                            'warnTNL'  : 5},
              'hostRAM': { 'critThres': 90,
                           'warnThres': 88,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'xdcrChangesLeft': { 'critThres': 300,
                           'warnThres': 200,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'bktRAMPct': {'critThres':75,
                            'warnThres':85,
                            'critTNL'  : 4,
                            'warnTNL'  : 5},
              'bktResPct': {'critThres':55,
                            'warnThres':75,
                            'critTNL'  : 5,
                            'warnTNL'  : 5},
              'bktMetaPct': {'critThres':45,
                             'warnThres':35,
                             'critTNL'  : 4,
                             'warnTNL'  : 5},
              'certExpDays': {'critThres':8,
                              'warnThres':16,
                              'critTNL'  : 4,
                              'warnTNL'  : 5}
             },   
        'i': {'defaultTNL': 5,
              'hostCPU': { 'critThres': 95,
                           'warnThres': 90,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'clustRAM': { 'critThres': 99,
                            'warnThres': 97,
                            'critTNL'  : 4,
                            'warnTNL'  : 5},
              'hostRAM': { 'critThres': 90,
                           'warnThres': 88,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'xdcrChangesLeft': { 'critThres': 300,
                           'warnThres': 200,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'bktRAMPct': {'critThres':75,
                            'warnThres':85,
                            'critTNL'  : 4,
                            'warnTNL'  : 5},
              'bktResPct': {'critThres':55,
                            'warnThres':75,
                            'critTNL'  : 5,
                            'warnTNL'  : 5},
              'bktMetaPct': {'critThres':45,
                             'warnThres':35,
                             'critTNL'  : 4,
                             'warnTNL'  : 5},
              'certExpDays': {'critThres':8,
                              'warnThres':16,
                              'critTNL'  : 4,
                              'warnTNL'  : 5}
             },
        'q': {'defaultTNL': 4,
              'hostCPU': { 'critThres': 95,
                           'warnThres': 90,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'clustRAM': { 'critThres': 99,
                           'warnThres': 97,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'hostRAM': { 'critThres': 90,
                           'warnThres': 88,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'xdcrChangesLeft': { 'critThres': 300,
                           'warnThres': 200,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'bktRAMPct': {'critThres':75,
                            'warnThres':85,
                            'critTNL'  : 4,
                            'warnTNL'  : 5},
              'bktResPct': {'critThres':55,
                            'warnThres':75,
                            'critTNL'  : 5,
                            'warnTNL'  : 5},
              'bktMetaPct': {'critThres':60,
                             'warnThres':50,
                             'critTNL'  : 4,
                             'warnTNL'  : 5},
              'certExpDays': {'critThres':10,
                              'warnThres':25,
                              'critTNL'  : 4,
                              'warnTNL'  : 5}
             },
        'p': {'defaultTNL': 3,
              'hostCPU': { 'critThres': 95,
                           'warnThres': 90,
                           'critTNL'  : 2,
                           'warnTNL'  : 3},
              'clustRAM': { 'critThres': 99,
                           'warnThres': 97,
                           'critTNL'  : 2,
                           'warnTNL'  : 3},
              'hostRAM': { 'critThres': 95,
                           'warnThres': 90,
                           'critTNL'  : 3,
                           'warnTNL'  : 4},
              'xdcrChangesLeft': { 'critThres': 2000,
                           'warnThres': 1000,
                           'critTNL'  : 2,
                           'warnTNL'  : 3},
              'bktRAMPct': {'critThres':75,
                            'warnThres':85,
                            'critTNL'  : 4,
                            'warnTNL'  : 5},
              'bktResPct': {'critThres':65,
                            'warnThres':85,
                            'critTNL'  : 5,
                            'warnTNL'  : 5},
              'bktMetaPct': {'critThres':60,
                             'warnThres':50,
                             'critTNL'  : 4,
                             'warnTNL'  : 5},
              'certExpDays': {'critThres':10,
                              'warnThres':25,
                              'critTNL'  : 3,
                              'warnTNL'  : 4}
             }
        }


class hostCPU:
    warnThresh = 90
    warnTNL = 5
    critThresh = 95
    warnTNL = 4

class clustRAM:
    warnThresh = 97
    critThresh = 99
    warnTNL = 5
    critTNL = 4

class hostSWAP:
    warnThresh = 10
    critThresh = 40

class hostRAM:
    warnThresh = 75
    warnTNL = 5
    critThresh = 90
    crtiTNL = 4

class xdcrChangesLeft:
    warnThresh = 50
    warnTNL = 5
    critThresh = 100
    critTNL = 4


gTNL = {'i': {'hostCPU': { 'critThres': 90,
                           'warnThres': 75,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'clustRAM': { 'critThres': 99,
                           'warnThres': 97,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'hostRAM': { 'critThres': 90,
                           'warnThres': 75,
                           'critTNL'  : 4,
                           'warnTNL'  : 5},
              'xdcrChangesLeft': { 'critThres': 90,
                           'warnThres': 75,
                           'critTNL'  : 4,
                           'warnTNL'  : 5}
             },
        'q': {},
        'p': {}}
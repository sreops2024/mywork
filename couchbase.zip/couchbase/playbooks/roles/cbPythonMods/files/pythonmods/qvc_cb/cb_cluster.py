# ------------------------------------------------------------------------------------------------------------------------
# Author : Victor Zuniga
# Date   : 2017.12.15
# Purpose: Define a class to handle the cluster information for Couchbase clusters.
#
# History:
# Date        Name                    Comments
# ----------  ----------------------  ------------------------------------------------------------------------------------------------
# 2018.11.26  Victor Zuniga           Initial Class definition
# 2021.08.06  Victor Zuniga           Fix some formmating
# 2021.10.27  Victor Zuniga           Delegate node information gathering to the node using new class.
# 2022.01.10  Victor Zuniga           Add method to return nodes (active, all)
# 2022.06.14  Victor Zuniga           Cleaned up parameters options.
#                                     Trapped error when cluster defined is not available.
# 2023.01.20  Victor Zuniga           Added spare node to cluster display for more accurate information display.
# 2023.04.24  Victor Zuniga           Added recovery method to class.
# 2023.07.11  Victor Zuniga           Get auth credentials from sec files ('dbadmin')
# ------------------------------------------------------------------------------------------------------------------------

import sys
import json
import random
import time
import requests


#sys.path.insert ( 0, '/home/mobaxterm/vzuniga/pythonmods/' )

from bbc_log.dba_log import *
from bbc_cb.env_config import getClusterNodes
from bbc_cb.env_config import getRandomClusterNode, getClusterSpareNode
from bbc_cb.cb_api import getNodeSecSettings, getRebalanceStatus, addClusterNode
from bbc_cb.cb_api import getPoolsDefault, getClusterLDAP, getClusterSASL
from bbc_cb.cb_api import startRebalance, nodeFailover
from bbc_cb.clsFonts import fontColors
from bbc_cb.cbThresholds import hostCPU, clustRAM

from bbc_cb.cb_node import cNode

from bbc_cb.strFormat import strColorFmt

logger = logging.getLogger ( __name__ )

#class cCluster ( cNode ):
class cCluster ( ):

    def __init__ (self, name, pAuth = None):
        logger.info ("Initializing cluster : %s" % ( name ) )
        self.clusterInfo = {}
        self.__delay = 15
        self.clusterInfo['name'] = name.lower()
        
        self.clusterInfo['status'] = ''
        if pAuth == None:
            import os
            from bbc_fileSec.encServer import getClusterCred
            logger.info ("Get credentials from key files")
            self.__clusterAuth = ('dbadmin', getClusterCred('dbadmin', self.clusterInfo['name'], os.environ.get('CB_KEY_DIR')))
        else:
            self.__clusterAuth = pAuth
        self.spareAvailable = False

        self.__clusterInfo = getPoolsDefault ( self.__clusterAuth,  self.clusterInfo['name'] )

        self.clusterInfo['nodes'] = {}

        lvNodeList = []
        if ( 'nodes' in self.__clusterInfo.keys() ):
            for n in range( len( self.__clusterInfo['nodes'])):
                lvNodeList.append( self.__clusterInfo['nodes'][n]['hostname'].split('.')[0] )
            logger.debug ("Nodes from cluster info: %s" % str(lvNodeList))
            
            try:
                #if self.clusterInfo['spare'] is not '' or self.clusterInfo['spare'] is not None:
                self.clusterInfo['spare'] = getClusterSpareNode (self.clusterInfo['name'])
            except:
                #self.clusterInfo['spare'] = getClusterSpareNode (self.clusterInfo['name'])
                self.clusterInfo['spare'] = ''

            # Append the spare node, if available
            if self.clusterInfo['spare'] != '':
                lvNodeList.append( self.clusterInfo['spare'])
                self.spareAvailable = True
            else:
                self.spareAvailable = False
            
            #lvNodeList = lvNodeList + getClusterNodes (self.clusterInfo['name']) 
            lvNodeList = list(set( lvNodeList + getClusterNodes (self.clusterInfo['name']) ))
            
            # sort node list to arrange in order
            lvNodeList.sort()
            
            #logger.debug ("... including nodes from cofig: %s" % lvNodeList)
            
            # Traverse the node list and initialize them.
            for lvNode in lvNodeList:
                logger.debug ("Initialize node: %s" % lvNode )
                vFound = 0

                #try:
                for x in range(len(self.__clusterInfo['nodes'])):
                    if lvNode in self.__clusterInfo['nodes'][x]['hostname']:
                        logger.debug ("Node %s was found" % lvNode )
                        self.clusterInfo['nodes'][ lvNode ] = cNode ( name = lvNode, nodeData = self.__clusterInfo['nodes'][x], nodeCreds=self.__clusterAuth )
                        vFound = 1

                if vFound == 0:
                    logger.debug ( "Node %s was not found, initialize to empty" % lvNode )
                    self.clusterInfo['nodes'][ lvNode ] = cNode ( name = lvNode, nodeCreds = self.__clusterAuth )

            self.clusterInfo["rebalanceStatus"] = self.__clusterInfo["rebalanceStatus"]
                        
            lvNodeList = set( lvNodeList + getClusterNodes (self.clusterInfo['name']) )
            logger.debug ("... including nodes from cofig: %s" % lvNodeList)
            
            self.clusterInfo['storage'] = self.__clusterInfo['storageTotals']
            if 'balanced' in self.__clusterInfo.keys():
                self.clusterInfo['clusterBalanced'] = self.__clusterInfo['balanced']
            else:
                self.clusterInfo['clusterBalanced'] = 'N/A'
        else:
            logger.warning ("WARNING: %s is not configured")
            self.clusterInfo['clusterBalanced'] = 'N/A'
            self.clusterInfo['storage'] = {'ram' : {'quotaUsed':1, 'quotaTotal':1} }

        #lvRandClustNode = getRandomClusterNode(self.clusterInfo['name'] )
        # Get randon node from the active nodes, which could differ from defined nodes
        lvNodeList = []
        
        try:
            for n in range( len( self.__clusterInfo['nodes'])):
                lvNodeList.append( self.__clusterInfo['nodes'][n]['hostname'].split('.')[0] )

            lvRandClustNode = lvNodeList[random.randint(0, len(lvNodeList)-1 )]    
            self.clusterInfo['LDAP'] = getClusterLDAP( self.__clusterAuth, lvRandClustNode )  
            self.clusterInfo['SASL'] = getClusterSASL( self.__clusterAuth, lvRandClustNode )

            # Capture the list of nodes in the cluster.
            self.__nodeList = list(self.clusterInfo['nodes'].keys())
            self.__activeNodeList = []
            self.__healthyNodeList = []

            for node in self.clusterInfo['nodes'].keys():
                if self.clusterInfo['nodes'][node].nodeInfo['clusterMembership'] == 'active':
                    self.__activeNodeList.append(node)
                if self.clusterInfo['nodes'][node].nodeInfo['status'] == 'healthy':
                    self.__healthyNodeList.append(node)

        except:
            logging.error("ERROR: Node list issue encountered for cluster: %s" % self.clusterInfo["name"])
            self.clusterInfo['LDAP'] = {'authorizationEnabled' : 'n/a', 'authenticationEnabled' : 'n/a'}
            self.clusterInfo['SASL'] = {'enabled' : 'n/a'}
        
        #try:
        #    #if self.clusterInfo['spare'] is not '' or self.clusterInfo['spare'] is not None:
        #    self.clusterInfo['spare'] = getClusterSpareNode (self.clusterInfo['name'])
        #except:
        #    #self.clusterInfo['spare'] = getClusterSpareNode (self.clusterInfo['name'])
        #    self.clusterInfo['spare'] = ''
        
        
    def __str__ (self):
        if self.clusterInfo['name'] == '':
            logger.debug (" cCluster: Un-initialized" )
            return "Un-initialized"
        else:
            outTxt = "%s\n" % (self.clusterInfo['name'])
            outTxt += "  Balanced: %6s (%-8s) LDAP: authentication: %-8s authorization: %-8s SASLAuth: %s\n" % (
                            strColorFmt( self.clusterInfo['clusterBalanced'], True, False ), 
                            strColorFmt( self.clusterInfo["rebalanceStatus"], None, "running" ), 
                            strColorFmt( self.clusterInfo['LDAP']['authenticationEnabled'], True, False ),
                            strColorFmt( self.clusterInfo['LDAP']['authorizationEnabled'], True, False ),
                            strColorFmt( self.clusterInfo['SASL']['enabled'], False, True)
                            )
            outTxt += "  RAM: used (gb): %6.2f/%0.2f (%s) \n" % (
                                ( float(self.clusterInfo['storage']['ram']['quotaUsed'])/(1024*1024*1024) ),
                                ( float(self.clusterInfo['storage']['ram']['quotaTotal'])/(1024*1024*1024) ),
                                strColorFmt  ( round( ( self.clusterInfo['storage']['ram']['quotaUsed']/self.clusterInfo['storage']['ram']['quotaTotal']) *100,2 ), clustRAM.warnThresh, clustRAM.critThresh )
                            )

            for n in sorted(self.clusterInfo['nodes'].keys()):
                outTxt += str( self.clusterInfo['nodes'][n] )

        logger.debug ("cCluster.outTxt:")
        logger.debug ("%s" % outTxt )

        logger.debug ("add spare to string")
        #if self.clusterInfo['spare'] != '':
        #outTxt += "   Spare: %s\n" % self.clusterInfo['spare']

        return outTxt


    def addNode(self, pNode, pServices = 'kv'):
        '''
        Add node to the cluster.  To be used to add a node back into the cluster, or add the spare node into the cluster.
        '''
        vTmpNodes = self.getNodes()
        vTmpNodes.append( self.clusterInfo['spare'] )

        logger.debug ("addNode - Cluster: %s - Node: %s %s" % (self.clusterInfo["name"], pNode, str(pServices)))
        logger.debug ("addNode - tmpNodes: %s" % str(vTmpNodes))

        #if pNode in self.getNodes():
        if pNode in vTmpNodes:
            logger.info ("Add node %s to cluster %s" % (pNode, self.clusterInfo['name']))
            if addClusterNode( self.__clusterAuth ,self.getActiveNodes()[0], pNode, pServices ):
                logger.info ("Node %s added to cluster %s" % (pNode, self.clusterInfo['name']))
                vRet = self.refresh()
                logger.debug ("addNode - vRet1: %s" % str(vRet))
                return vRet
            else:
                logger.warning( "WARNING: Could not add %s to the cluster" % pNode)
                return False
        else:
            logger.error( "ERROR: Node %s is not known to cluster %s" % (pNode, self.clusterInfo['name']))
            return False
        logger.debug ("addNode - Done")
        return True


    def addSpareNode(self, pServices = 'kv'):
        '''
        Add the spare node with the received services
        '''

        #Refresh cluster to ensure accurate node information
        if self.spareAvailable:
            self.refresh()
            if addClusterNode( self.__clusterAuth ,self.getActiveNodes()[0], self.clusterInfo['spare'], pServices ):
               return self.refresh()
            else:
                logger.warning("WARNING: Could not add spare node (%s) using %s" % (self.clusterInfo['spare'], self.getActiveNodes()[0] ))
                return False
        else:
            logger.warning("WARNING: No spare node available for %s" % self.clusterInfo['name'])
            return False
   

    def addSpareAndRebalance(self):
        '''
        Adds the spare node and rebalance the cluster to complete node addition.
        '''

        if self.addSpareNode():
            time.sleep(self.__delay)
            self.refresh()
            #return startRebalance( self.__clusterAuth, self.getActiveNodes()[0], self.getNodes() )
            return self.rebalance()

        return False


    def clusterOk(self):
        """
        Check cluster, return true if cluster is balanced and all nodes are healthy, false otherwise.
        """

        if self.clusterInfo['clusterBalanced'] != True:
            return False
        else:
            for node in self.clusterInfo['nodes'].keys():
                if self.clusterInfo['nodes'][node].nodeInfo['status'] != 'healthy':
                    return False
        return True


    def ejectInactiveNode(self, pNode):
        '''
        Removes node if inactive, otherwise
        '''

        from bbc_cb.cb_api import ejectNode

        logger.debug ("ejectInactiveNode: %s" % pNode)

        if pNode in self.getActiveNodes():
            logger.warning ("WARNING: %s is active and cannot be removed.")
            self.refresh()
            return False
        
        logger.debug ("Ejecting node %s" % pNode)

        if ejectNode (self.__clusterAuth, self.getActiveNodes()[0], pNode ):
            self.refresh()
            return True

        return False


    def failoverNode(self, pNode, pOption = 'graceful'):
        '''
        Failover the received node.
        '''

        from bbc_cb.cb_api import nodeFailover

        logger.debug("failover node: %s" % pNode)

        #If node is not running data (kv) service; then perform a hard failover
        if 'kv' in self.clusterInfo['nodes'][pNode].nodeInfo['services']:
            vOption = 'graceful'
        else:
            vOption = 'hard'
        
        if pOption == 'hard':
            logger.info ("Override the graceful type to hard.")
            vOption = 'hard'

        logger.info("%s - node failover. option: %s" % (pNode, vOption))

        return nodeFailover(self.__clusterAuth, pNode, vOption)


    def getActiveNodes(self):
        '''
        Return active node names in the cluster
        '''
        return self.__activeNodeList


    def getClusterText(self):
        """Return plain text information of the cluster"""

        if self.clusterInfo['name'] == '':
            logger.debug (" cCluster: Un-initialized" )
            return "Un-initialized"
        else:
            outTxt = "%s\n" % (self.clusterInfo['name'])
            outTxt += "   Balanced: %6s (%-8s)  LDAP: authentication: %-8s authorization: %-8s SASLAuth: %s\n" % (
                self.clusterInfo['clusterBalanced'], 
                self.clusterInfo['rebalanceStatus'], 
                self.clusterInfo['LDAP']['authenticationEnabled'],
                self.clusterInfo['LDAP']['authorizationEnabled'],
                self.clusterInfo['SASL']['enabled']
                )
            outTxt += "   RAM: used (gb): %6.2f/%0.2f (%s) \n" % (
                                ( float(self.clusterInfo['storage']['ram']['quotaUsed'])/(1024*1024*1024) ),
                                ( float(self.clusterInfo['storage']['ram']['quotaTotal'])/(1024*1024*1024) ),
                                ( round( ( self.clusterInfo['storage']['ram']['quotaUsed']/self.clusterInfo['storage']['ram']['quotaTotal']) *100,2 ))
                            )

            for n in sorted(self.clusterInfo['nodes'].keys()):
                outTxt += str( self.clusterInfo['nodes'][n].getNodeText() )

        logger.debug ("cCluster.outTxt:")
        logger.debug ("%s" % outTxt )

        return outTxt
    

    def getFQNodes(self):
        ''' return FQDN nodes '''
        return [x + '.south.edu' for x in self.__nodeList]


    def getHealthyNodes(self):
        '''
        Return healthy nodes in the cluster
        '''
        return self.__healthyNodeList


    def getInactiveNodes(self):
        '''
        Return list of nodes not active
        '''
        return list( set(self.__nodeList) - set(self.__activeNodeList) )

    
    def getNodeDict(self):
        """Return dictionary node information """
        return self.clusterInfo['nodes']

    
    def getNodeMemUsage(self, type='dict'):
        '''
        Return the list of active/healthy nodes and their memory usage.
        type can be: dict, list, str
        '''

        if type == 'list':
            vRetList = []
            for node in self.getHealthyNodes():
                vRetList.append( (node, self.clusterInfo["nodes"][node].memUsagePct()))
        elif type == 'dict':
            vRetList = {}
            for node in self.getHealthyNodes():
                vRetList[node] = ( self.clusterInfo["nodes"][node].memUsagePct())
        else:
            vRetList = []
            for node in self.getHealthyNodes():
                vRetList.append( (node, self.clusterInfo["nodes"][node].memUsagePct()))
            vRetList = str(vRetList)

        return vRetList


    def getNodes(self):
        '''
        Return the list of cluster node names
        '''
        return self.__nodeList


    def getUnhealthyNodes(self):
        '''
        Return list of nodes not healthy
        '''
        return list( set(self.__nodeList) - set(self.__healthyNodeList) )

    
    def json(self):
        """Return node information in json format"""

        return json.dumps(self.clusterInfo)
    

    def nodeExpDates(self):
        '''
        Return the dict of nodes and cert exp dates
        '''
        vRetDict = {}
        for node in self.getHealthyNodes():
            vRetDict[node] = self.clusterInfo['nodes'][node].certExpDate()

        return vRetDict


    def rebalance(self):
        '''Rebalance cluster'''
        logger.debug ("rebalancing cluster - %s" % self.clusterInfo['name'])
        #return startRebalance( self.__clusterAuth, self.getActiveNodes()[0], self.getNodes() )
        return startRebalance( self.__clusterAuth, self.getActiveNodes()[0], self.getHealthyNodes() )


    def rebalanceAndShow(self, pDelaySecs = 5):
        '''Rebalance the cluster, and show progress until done.'''

        if self.rebalance():
             return self.showRebalanceProgress(self.__clusterAuth, self.getActiveNodes()[0], pDelaySecs )


    def rebalanceStatus(self, update=False):
        '''
        Display the status of the cluster rebalance (not continuosly)
        '''

        logger.debug("getting rebalance status - getting from cluster: %s" % str(update))
        if update:
            print("Updating rebalance status")
            self.clusterInfo["rebalanceStatus"] =  getRebalanceStatus(self.__clusterAuth, self.getActiveNodes()[0])['status']
            
        return self.clusterInfo["rebalanceStatus"] 

    def recoverNode (self, pNode, pRecType = 'full'):
        '''
        Set recovery mode (full, delta) and rebalance and show rebalance process/progress
        '''
        if self.setNodeRecovery (pNode, pRecType):
            return self.rebalanceAndShow()
        
        return False


    def refresh(self):
        '''
        Refresh the cluster information
        '''
        logger.debug("... refreshing cluster instance...")
        self.__init__(self.clusterInfo['name'], self.__clusterAuth)
        return True


    def remNode( self, pNode):
        '''
        Removes the node from the cluster using rebalance call from api module
        '''
        from bbc_cb.cb_api import removeNode

        logger.info ("Remove node %s from cluster %s" % (pNode, self.clusterInfo['name']))

        if removeNode( self.__clusterAuth, self.getFQNodes(), [pNode + ".south.edu"]):
            logger.info ("Node %s removed from %s" % (pNode, self.clusterInfo['name']))
            return True
        else:
            logger.warning ("WARNING: Could NOT Remove node %s from cluster %s" % (pNode, self.clusterInfo['name']))
            return False
        return False

    
    def remNodeAndShow (self, pNode):
        '''
        Removes the node from the cluster and shows the rebalance process
        '''

        if self.remNode( pNode):
            return self.showRebalanceProgress( self.__clusterAuth, self.getActiveNodes()[0], 5 )

        return False


    def setNodeRecovery(self, pNode, pRecType = 'full'):
        '''
        Recover node and start rebalance
        '''

        logger.debug ("... set recovery for %s [%s]" % (pNode, pRecType))

        # Ensure the node is not healthy
        if pNode not in self.__activeNodeList:
            otpNode = 'ns_1@%s.south.edu' % pNode
            vData = { 'otpNode' : otpNode , 'recoveryType' : pRecType }

            vURL = "http://%s.south.edu:8091/controller/setRecoveryType" % (pNode)
            r = requests.post ( vURL, data=vData, auth=(self.__clusterAuth) )
            if r.status_code != 200:
                logger.error ("setNodeRecovery : request call failed. Status : " + str( r.status_code ) )
                logger.error ("setNodeRecovery : error text : " + r.text )
                
                return False

            logger.info ("setNodeRecovery : status_code : " + str( r.status_code ) )
            logger.info ("setNodeRecovery : text : " + r.text )

        else: 
            logger.debug ("Node %s is in active node list [%s]" %(pNode, self.__healthyNodeList))
            return False
        
        return True


    def setTimeDelay(self, pDelaySecs):
        '''Set time delay for cluster in seconds'''
        self.__delay = pDelaySecs


    def showAuth(self):
        '''
        Dsplay auth credentials set for the cluster.
        '''
        return (self.__clusterAuth[0], '*' * len(self.__clusterAuth[1]))


    def showRebalance(self, pDelaySecs = 5):
        '''Show rebalance progress until done'''
        return self.showRebalanceProgress(self.__clusterAuth, self.getActiveNodes()[0], pDelaySecs )


    def showRebalanceProgress( self, pAdminCreds, pNodeAlias, delay = 30 ):
        '''Show the rebalance progress in the cluster'''

        from pprint import PrettyPrinter

        vSleepDelay = 15
        logger.info ("showRebalanceProgress : Sleep delay : " + str( vSleepDelay ) )

        pp = PrettyPrinter(indent=4)

        time.sleep( vSleepDelay )

        vURL = 'http://' + pNodeAlias + '.south.edu:8091/pools/default/rebalanceProgress'
        logger.info ("showRebalanceProgress : URL : " + vURL )

        r = requests.get( vURL, auth=(pAdminCreds) )

        if r.status_code != 200:
            logger.info ("showRebalanceProgress : request failed : status_code : " + str(r.status_code) )
            logger.info ("showRebalanceProgress : text : " + r.text )
            print ("Rebalance Completed or call failed" )
            return True

        logger.info ("showRebalanceProgress : " + str ( r.text ) )
        pp.pprint ( json.loads(r.text ) )
        print ("...")
        logger.info ("showRebalanceProgress : looping until done..." )
        while r.text != '{"status":"none"}':
            time.sleep( vSleepDelay )
            r = requests.get( vURL, auth=(pAdminCreds) )
            logger.info ("showRebalanceProgress : " + str ( r.text ) )
            pp.pprint ( json.loads(r.text ) )
            print ("...")

        logger.info ("Rebalance Complete")
        print ("Rebalance Completed")

        return True


    def showTimeDelay(self):
        '''Display time delay setting'''

        return self.__delay


    def swapNodeWithSpare(self, pNode):
        '''
        Swap the cluster node with the spare node.
        Checks for cluster membership and swap nodes if the spare is part of the cluster, and node is not.
        '''
        
        logger.info("swapNodeWithSpare: %s: %s<->%s" % (self.clusterInfo['name'], pNode, self.clusterInfo['spare']))

        self.refresh()
        if not self.spareAvailable:
            # No spare available
            logger.warning ("WARNING: Spare node for %s undefined" % self.clusterInfo[ 'name'] )
            return False

        vNode = pNode
        vSpare = self.clusterInfo['spare']

        # Services are returned as a list, convert them to comma separated string.
        vServices = ",".join( (self.clusterInfo['nodes'][vNode].nodeServices()) )

        logger.info( "Swap %s with %s - [%s]" % ( pNode, vSpare, vServices) )

        if ( vNode not in self.getActiveNodes() ) and ( vSpare in self.getActiveNodes() ):
            logger.info ("Active nodes: %s" % str(self.getActiveNodes()))
            logger.info ("Reverse swap order: Swap %s with %s - [%s]" % (vSpare, pNode, vServices))
            vNode, vSpare = vSpare, vNode
            
            # Services are returned as a list, convert them to comma separated string.
            vServices = ",".join( (self.clusterInfo['nodes'][vNode].nodeServices()) )            
            
            logger.info( "Swap %s with %s - [%s]" % ( pNode, vSpare, vServices) )
            
        logger.info("swapNodeWithSpare: %s: %s<->%s" % (self.clusterInfo['name'], pNode, self.clusterInfo['spare']))

        # Ensure the node to be added is not an active cluster member
        if vSpare in self.getActiveNodes():
            logger.warning( "WARNING: %s is already part of the cluster - %s" % (vSpare, str(self.getActiveNodes() )) )
            return False

        logger.info ("swapWithSpareNode - Add spare node")
        if self.addNode( vSpare, vServices):
            logger.info ("swapWithSpareNode - Spare Added")
            time.sleep(self.__delay)
            
            # Use 'hard' failover to use swap rebalance of the buckets; however, this may lead to data loss if there are pending operations
            # in the bucket.  Currently, not able to easily verify the pending operations, so leaving it out for now.
            # if self.failoverNode( vNode, 'hard' ):
            #if self.failoverNode( vNode, 'hard' ):
            #    self.refresh()
            #    time.sleep(self.__delay)
            #    if removeNode( self.__clusterAuth, self.getFQNodes(), [vNode + ".south.edu"]):
            #        self.refresh()
            #        if self.clusterOk():
            #            return True
            #        else:
            #            time.sleep(self.__delay)
            #            if self.rebalanceAndShow():
            #                return self.refresh()
            #            else:
            #                return False
            #    else:
            #        return False
            logger.info ("swapWithSpareNode - Remove %s" % vNode)
            if self.remNodeAndShow( vNode ):
                logger.info ("swapWithSpareNode - Node Removed, refresh")
                return self.refresh()
            else: 
                logger.info ("swapWithSpareNode - Node NOT removed" )
                return False
        
        logger.info ("swapWithSpareNode - Done??")

        return False

   
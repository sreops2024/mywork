# Authon  : Victor Zuniga
# Date    : 2019.03.04
# Purpose : Provide a function to color the value provided and convert to a string based on provided thresholds.

# History
# Author              Date        Comments
# ------------------- ---------- -------------------------------------------------------------------------------
# Victor Zuniga       2019.09.17 Convert to python3
# Victor Zuniga       2022.04.28 Fix date formatting -- increase to 10 chars.
#                                Added optional parameter to string format to allow for larger numbers

#import os
#import sys
#import requests

#sys.path.insert ( 0,'/home/couchbase/DBA/tools/pythonmods' )

from bbc_log.dba_log import *
from bbc_cb.clsFonts import fontColors

logger = logging.getLogger ( __name__ )

def strColorFmt ( pMetric, pWarning, pCritical, pFmt="%5.2f" ):
   """Determine the display color for the received pMetric based on the type and thresholds received."""
   logger.debug ("strColorFmt")
   
   logger.debug ("Metric: %s - Type: %s - Warn: %s - Crit: %s" % ( pMetric, type(pMetric), pWarning, pCritical ) )

   lvOut = ''

   if ( str( type(pMetric) ) == "<class 'float'>" or str( type(pMetric) ) == "<class 'int'>" ):
      #lvOut = "%5.2f" % ( pMetric )
      lvOut = pFmt % ( pMetric )
      if pMetric <= pWarning:
         lvOut = "%s" % (fontColors.OKGREEN + lvOut + fontColors.ENDC)
      if pMetric <= pCritical:
         lvOut = "%s" % (fontColors.WARNING + lvOut + fontColors.ENDC)
      if pMetric > pCritical:
         lvOut = "%s" % (fontColors.FAIL + lvOut + fontColors.ENDC)
   elif str( type(pMetric) )  == "<class 'bool'>" :
      lvOut = str(pMetric)
      if pMetric == pCritical:
         lvOut = "%s" % (fontColors.FAIL + lvOut + fontColors.ENDC)
      else:
         lvOut = "%s" % (fontColors.OKGREEN + lvOut + fontColors.ENDC)
   elif ( str( type(pMetric) ) == "<class 'str'>" or str( type(pMetric) ) == "<class 'unicode'>" ):
      lvOut = pMetric
      if pMetric == pCritical:
         lvOut = "%s" % (fontColors.FAIL + lvOut + fontColors.ENDC)
      elif pMetric == pWarning:
         lvOut = "%s" % (fontColors.WARNING + lvOut + fontColors.ENDC)
      else:
         lvOut = "%s" % lvOut 
   else:
      return pMetric
      
   return lvOut


def dateStrColorFmt( pDateStr, pDaysWarn, pDaysCrit, pStrFormat = '%Y.%m.%d'):
    '''
    Determine the color of the string date based on the days difference to todays date.
    If there are any issues, the function will return the string unchanged.
    '''
    logger.debug ("dateStrColorFmt - date: %s  warn: %s  crit %s [format: %s]" % (pDateStr, pDaysWarn, pDaysCrit, pStrFormat))
    
    from datetime import datetime
    from bbc_cb.clsFonts import fontColors

    vRetStr = pDateStr

    try:
        # Convert date string to datetime object
        vDateObj = datetime.strptime(pDateStr, pStrFormat)
        
        # Get number of days until expiration
        vExpDiff = vDateObj - datetime.today()

        # Determine warning level, if any.
        if (vExpDiff.days <= pDaysCrit):
            logger.info("Critical Exp reached")
            vRetStr = "%s%s%s" % (fontColors.FAIL, pDateStr, fontColors.ENDC)
        elif (vExpDiff.days <= pDaysWarn):
            logger.info("Warning Exp reached")
            vRetStr = "%s%s%s" % (fontColors.WARNING, pDateStr, fontColors.ENDC)
        else:
            vRetStr = pDateStr

    except Exception as e:
        logger.warning ("Could not determine color for date string")
        logger.warning ("Warning: %s" % str(e))

        # Had to add spaces to get the strings to align correctly and display colors. ???
        vRetStr = "%s%s%s" % (fontColors.FAIL, pDateStr + "       ", fontColors.ENDC)
        #print("Could not determine color for date string")
        #print("Warning: %s" % str(e))

    finally:
        return vRetStr

    

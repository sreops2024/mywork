import sys
#sys.path.insert ( 0,'/home/couchbase/DBA/tools/pythonmods' )
from bbc_log.dba_log import *
from bbc_cb.cb_api import getAllClustBuckets
from bbc_cb.cb_api import getBucketClustDict
from bbc_cb.cb_api import getRandomClusterNode
from bbc_cb.cb_api import getUserInfo
from bbc_cb.cb_api import createCBUser
from bbc_cb.cb_api import getRbacGroupDetails

logger = logging.getLogger ( __name__ )

# ------------------------------------------------------------------------------------------------------------------------

def prepBucketRoles ( pBucketDict ) :
   """ Return the bucket roles string based on the dictionary received"""
   
   logger.debug ("preBucketRoles: %s" % pBucketDict )

   vRoleStr = ''

   for bucket in pBucketDict.keys():
      logger.debug ("Bucket: %s" % bucket)
      for x in range(len(pBucketDict[bucket])):
         if x != 0:
           vRoleStr = vRoleStr + ","
         vRoleStr = ("%s%s[%s]") % (vRoleStr, pBucketDict[bucket][x], bucket)

   logger.debug ("Roles: %s" % (vRoleStr) )
   return vRoleStr

# ------------------------------------------------------------------------------------------------------------------------

def formatNameRoles (pDictUserInfo):
   """
   Takes the JSON returned from a couchbase instane about an user account, and formats the name, roles dictionary.
   """

   logger.debug ("formatNameRoles")

   vRetDict =  {}
   vRetDict['NAME'] = pDictUserInfo['name']
   vRetDict['ROLES'] = {}
   
   for x in pDictUserInfo['roles']:
      logger.debug ("Initializing: %s" % x['bucket_name'])
      vRetDict['ROLES'][x['bucket_name']] = []

   for x in pDictUserInfo['roles']:
      vRetDict['ROLES'][x['bucket_name']].append( x['role'] )
      logger.debug ("Bucket roles: %s [ %s ]" % (x['bucket_name'], x['role'] ) )

   logger.debug( "Formatted JSON: %s" % vRetDict )
   return vRetDict

# ------------------------------------------------------------------------------------------------------------------------

def areDictionariesEqual ( pDictA, pDictB ):
   """
   Compare the dictionaries received to see if they are identical
   Its intended use is to compare the role dictionaries to see if buckets and roles are the same.
   """

   logger.debug ("areDictionariesEqual")

   for x in pDictA.keys():
      pDictA[x].sort()


   for x in pDictB.keys():
      pDictB[x].sort()

   return pDictA == pDictB

# ------------------------------------------------------------------------------------------------------------------------

def combineDicts ( pDictA, pDictB ):
   """
   Combine the received dictionaries
   """

   logger.debug ("combineDicts")

   # Add items in B to A for matching keys
   for x in pDictA.keys():
      if x in pDictB.keys():
         pDictA[x] = pDictA[x] + pDictB[x]

   # Add items in B to A that have no matching keys
   for x in pDictB.keys():
      if x not in pDictA.keys():
         pDictA[x] = pDictB[x]

   # Ensure that there are no duplicated items in the dict lists
   for x in pDictA.keys():
      pDictA[x] = list( set( pDictA[x] ) )

   return pDictA

# ------------------------------------------------------------------------------------------------------------------------

def createExtAcct ( pAcct, pAcctInfo, pCluster, pAdminCreds ):
   """Creates the external user account using the received information."""

   logger.debug ("createExtAcct" )
   logger.debug ( "Account    : %s" % pAcct )
   logger.debug ( "Acct Info  : %s" % pAcctInfo )
   logger.debug ( "Cluster(s) : %s" % pCluster )
   vCreds =  ("Admin Creds: %s/%s" % pAdminCreds ).replace ( pAdminCreds[1], '*' * len (pAdminCreds[1] ) ) 

   vRetCode = {}
   lNode = ""

   # Loop through clusters
   for clstr in pCluster:
      logger.info (" *** Cluster: %s" % clstr )
      lNode = getRandomClusterNode ( clstr )
      logger.info ("Will use node [%s] to connect to cluster [%s]" % (lNode, clstr) )

      # Verify if user exists
      logger.info ("Get user and roles for %s" % pAcct)
      vUsrInfo = getUserInfo ( pAcct, lNode, pAdminCreds )
      logger.debug ("Debug: %s" % vUsrInfo )
      logger.debug ("Debug: %s" % vUsrInfo.json() )
      logger.debug ("Debug: %s" % pAcctInfo )

      if vUsrInfo.status_code == 200:
         # The user was found.  Format the roles so that they can be compared to requested account and roles.
         # Compare to see if they are the same, if so, we are done on this cluster, else, append the roles
         # to prevent issues.

         vDBUserInfo = formatNameRoles ( vUsrInfo.json() )
         
         logger.info ("Acct: %s was found." % pAcct )
         logger.debug ("DB Acct Roles: %s" % vDBUserInfo['ROLES'])
         logger.debug ("Req roles    : %s" % pAcctInfo['ROLES'] )

         if areDictionariesEqual (vDBUserInfo['ROLES'], pAcctInfo['ROLES']):
            logger.info ("Roles are the same.  Skip adding account %s" % pAcct)
            vRetCode[clstr] = "OK.  Account exists with same roles."
            
         else:
            logger.info ("Roles differ... append and process" )
            logger.debug ("Roles: %s" % pAcctInfo['ROLES']) 
            pAcctInfo['ROLES'] = combineDicts (pAcctInfo['ROLES'], vDBUserInfo['ROLES'] )
            logger.debug ("Roles: %s" % pAcctInfo['ROLES']) 

            logger.debug ("Create/update account %s" % pAcct)

            if createCBUser ( {pAcct:pAcctInfo}, lNode, pAdminCreds ):
               logger.info( "Account (%s) updated successfully in %s" % (pAcct, clstr) )
               vRetCode[clstr] = "Account (%s) updated successfully in %s" % (pAcct, clstr) 
            else:
               logger.error( "Account (%s) updated failed in %s" % (pAcct, clstr) )
               vRetCode[clstr] = "Account (%s) updated failed in %s" % (pAcct, clstr) 

      else:
         # The user was not found.  Create it.
         logger.debug ("Create account %s" % pAcct)

         if createCBUser ( {pAcct:pAcctInfo}, lNode, pAdminCreds ):
            logger.info( "Account (%s) created successfully in %s" % (pAcct, clstr) )
            vRetCode[clstr] = "Account (%s) created successfully in %s" % (pAcct, clstr)
         else:
            logger.error( "Account (%s) created failed in %s" % (pAcct, clstr) )
            vRetCode[clstr] = "Account (%s) created failed in %s" % (pAcct, clstr)

   return vRetCode


# ------------------------------------------------------------------------------------------------------------------------



# ------------------------------------------------------------------------------------------------------------------------

def createExternalUsers ( pUserInfo, pAdminCreds ):
   """
   Create the external users received in the pUserInfo dictionary.
   Use the Admin credentials received
   """

   logger.debug ("createExternalUsers" )

   # Track User Creation and success.
   vUsr = {}

   # Get cluster/bucket  information
   vClustBuckets = getAllClustBuckets( pAdminCreds[0], pAdminCreds[1] )
   if len( vClustBuckets ) < 1:
      logger.error("ERROR getting cluster and bucket information.  Check credentials." )
      vUsr['ERROR'] = "ERROR getting cluster and bucket information.  Check credentials."
   else:
      logger.info ("ClusterBuckets: %s" % vClustBuckets )
      vBucketCluster = getBucketClustDict (vClustBuckets)
      logger.info ("BucketClusters: %s" % vBucketCluster )


      # Process the environments, and accounts
      for lvEnv in pUserInfo.keys():
         logger.info ("Processing ENV accounts: %s " % lvEnv)
         logger.debug ("Accounts found: %s" % str(pUserInfo[lvEnv].keys()) )

         # Process Accounts
         for lvAcct in pUserInfo[lvEnv].keys():

            logger.info ('------------------------------------------------')
            logger.info ("Account: %s" % lvAcct )
            logger.info ('------------------------------------------------')

            lvAcctIdx = lvEnv + " " + lvAcct

            # Make sure the account env (if set) matches the environment.
            # Hoping to prevent accounts being created in the wrong env.
            if lvAcct[-2] == '_' and lvAcct[-1] in set("iqp"):

               # Match env and account.
               if lvAcct[-1].lower() != lvEnv.lower():
                  logger.warning("WARNING:  %s's environment does not match set environment: %s" % (lvAcct, lvEnv) )
                  vUsr[lvAcctIdx] = "WARNING:  %s's environment does not match set environment: %s" % (lvAcct, lvEnv)

                  # Move on to next account
                  continue

            else:
               logger.debug( "Acct %s could be an individual account" % lvAcct )

            # Determine which clusters contain the bucket where access is needed.
            for lvBkt in pUserInfo[lvEnv][lvAcct]['ROLES'].keys():
               logger.debug ("Processing %s - bucket: %s" % (lvAcct, lvBkt) )

               vClstrList = []

               # Determine which clusters the account needs to be created
               vClstrList = list( set( vClstrList + vBucketCluster[lvBkt] ))
               vClstrList = [x for x in vClstrList if x[-1] == lvEnv ]
               logger.debug ("Clusters: %s" % str(vClstrList) )

               if len(vClstrList) < 1:
                  logger.warning ("Cannot create account: %s" % lvAcct)
                  logger.warning ("-- Could not find a cluster [env: %s] with bucket: %s" % ( lvAcct[-1],lvBkt ) )
                  vUsr[lvAcctIdx] = "WARNING: Could not find a cluster [env: %s] with bucket: %s" % ( lvAcct[-1],lvBkt )
               else:
                  logger.info ("Create %s in %s" % (lvAcct, vClstrList))
                  logger.info ("Create %s :  %s" % (lvAcct, pUserInfo[lvEnv][lvAcct]))
                  vUsr[lvAcctIdx] = createExtAcct (lvAcct,  pUserInfo[lvEnv][lvAcct], vClstrList, pAdminCreds )

   return vUsr


# ------------------------------------------------------------------------------------------------------------------------

def checkLocalAcct (pAcctName, pCluster, pAdminCreds):
    '''
    Checks existance of local account in the cluster.
    Returns account information (groups, etc) dictionary if exists, empty dict if it does not.
    '''

    logger.debug("checkLocalAcct: %s - Cluster: %s" % (pAcctName, pCluster))

    return {}


# ------------------------------------------------------------------------------------------------------------------------

def checkGroupName (pGroupName, pCluster, pAdminCreds):
    '''
    Checks the existance of the group name in the couchbase cluster.
    Return True/False depending on the group existance.
    '''

    logger.debug ("checkGroupName: %s - Cluster: %s" % (pGroupName, pCluster))

    vGrpInfo = getRbacGroupDetails(pAdminCreds, getRandomClusterNode(pCluster), pGroupName)
    
    try:
        if vGrpInfo["id"] == pGroupName:
            return True
        else:
            logger.warning("WARNING: Returned group name [%s] does not match expected group name [%s]" % (vGrpInfo["id"], pGroupName))
            logger.warning("WARNING: Group Info Received: %s" % str(vGrpInfo))
            return False
    except Exception as e:
        logger.error("ERROR: Could not retrieve Group Information")
        logger.error("ERROR: %s" % str(e))
        return False

    return False


# ------------------------------------------------------------------------------------------------------------------------

# ------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------



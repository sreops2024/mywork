# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
   . ~/.bashrc
fi

# User specific environment and startup programs

PATH=$PATH:$HOME/.local/bin:$HOME/bin

export PATH
export TMOUT=0

# DBA Settings

CBH=/opt/couchbase
export PATH=$CBH/bin:$PATH

alias l='ls -ltr'
alias cbh='cd $CBH'

# Set LOG_DIR env variable
export LOG_DIR="/home/couchbase/logs"


# Set PYTHONPATH env variable
export PYTHONPATH="/home/couchbase/DBA/pythonmods"


# Set Cluster Name env variable
export CLUSTER_NAME=''


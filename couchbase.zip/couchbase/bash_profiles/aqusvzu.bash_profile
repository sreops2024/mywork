# .bash_profile
# Author  : Victor Zuniga
# Date    : 2018.07.13
# Purpose : Provide a uniform bash profile file on all servers.

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
        . ~/.bashrc
fi

# User specific environment and startup programs

PATH=$PATH:$HOME/.local/bin:$HOME/bin

export PATH
export TMOUT=0

alias l='ls -ltr'
alias l1='ls -1'
alias suroot='dzdo su -'
alias sucb='dzdo su - couchbase'


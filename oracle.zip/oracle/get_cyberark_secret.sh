#!/bin/bash
#set +x

SECRET=$1
CONFIG_DIR=$(cd "$(dirname "$0")"; pwd)
CONFIG_FILE="${CONFIG_DIR}/config.json"

CYBERARK_USERNAME=$(cat ${CONFIG_FILE} | jq -r '.username')
CYBERARK_PASSWORD=$(cat ${CONFIG_FILE}| jq -r '.password')

CYBERARK_URL=https://centralmanager.south.edu
HEADER="Content-Type: application/json"
CYBERARK_SAFE="US_P_ITPLATFORMS_CD"


function get_api_token()
{

        TOKEN=$(curl -s POST "${CYBERARK_URL}/PasswordVault/API/auth/CyberArk/Logon" \
        --header "${HEADER}" \
        --data '{
            "username": "'${CYBERARK_USERNAME}'",
            "password": "'${CYBERARK_PASSWORD}'"
        }' | tr -d '"')

}


function get_account_id_by_name()
{

        ACCOUNT_ID=$(curl -s GET "${CYBERARK_URL}/PasswordVault/WebServices/PIMServices.svc/Accounts?Safe=${CYBERARK_SAFE}&Keywords=${ACCOUNT_NAME}" \
        --header "${HEADER}" \
        --header "Authorization: ${TOKEN}" | jq -r '.accounts[].AccountID'
        )

}


function get_cyberark_secret()
{

        CYBERARK_SECRET=$(curl -s POST "${CYBERARK_URL}/PasswordVault/api/Accounts/${ACCOUNT_ID}/Password/Retrieve" \
        --header "${HEADER}" \
        --header "Authorization: ${TOKEN}" \
        --data '{
            reason:"Fetch secret for K8S provisioning"
        }' | tr -d '"') 

        echo ${CYBERARK_SECRET}

}

function print_cyberark_instructions () {
echo "Usage: source ./get_cyberark_secret.sh <cyberark secret name>
Make sure you have configured a config.json file with the following structure:

{
    \"username\": \"<svc acount cyberark username>\",
    \"password\": \"<svc acount cyberark password>\",
}"

}

manage_cyberark () {
    case $SECRET in
        "-h")
            print_cyberark_instructions
            ;;
        "--help")
            print_cyberark_instructions
            ;;
        "")
            print_cyberark_instructions
            ;;
        *)
            get_api_token
            for ACCOUNT_NAME in ${SECRET}
            do
               get_account_id_by_name
               get_cyberark_secret
            done
    esac
}

manage_cyberark
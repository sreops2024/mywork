#!/bin/bash
export ORACLE_HOME=/u01/app/oracle/product/19.0.0.0/dbhome_1
##Stop the seb81qa service in QA
echo "  Output of srvctl stop service -db seb81qast -service seb81qa  .. "
echo ".."
echo ".."
$ORACLE_HOME/bin/srvctl stop service -db seb81qast -service seb81qa 
#Enable Service in SEB81POTST:
echo "  Output of srvctl enable service -db SEB81POTST -service seb81qa -instance seb81poc1  "
echo ".."
echo ".."
$ORACLE_HOME/bin/srvctl enable service -db SEB81POTST -service seb81qa -instance seb81poc1
## Start the service in POC
echo "  Output of srvctl start service -db SEB81POTST -service seb81qa -instance seb81poc1   "
echo ".."
echo ".."
$ORACLE_HOME/bin/srvctl start service -db SEB81POTST -service seb81qa -instance seb81poc1
echo "  Make QA database read only    "
echo ".."
echo ".."
$ORACLE_HOME/bin/srvctl stop database  -db seb81qast 
$ORACLE_HOME/bin/srvctl start database  -db seb81qast -startoption "READ ONLY"
##Stop the seb81qa service in QA
echo "  Output of srvctl stop service -db seb81qast -service seb81qa  .. "
echo ".."
echo ".."
$ORACLE_HOME/bin/srvctl stop service -db seb81qast -service seb81qa 
echo "  Status of Service on QA and POC   "
echo ".."
echo ".."
$ORACLE_HOME/bin/srvctl status service -db seb81qast -service seb81qa 
$ORACLE_HOME/bin/srvctl status service -db SEB81POTST -service seb81qa 
exit

#!/bin/sh
export ORAENV_ASK=NO
export ORACLE_SID=$1
export PATH=/usr/lib64/qt-3.3/bin:/usr/local/sbin:/sbin:/bin:/usr/sbin:/usr/bin:/opt/puppetlabs/bin:/root/bin:/usr/local/bin
export OPTION=$2
export TMPF=/tmp/${ORACLE_SID}_dg.log
export OPTION_SQL=/tmp/${ORACLE_SID}_${OPTION}.sql
export SBY=OEMDBPLE
export PRIM=OEMDBPSP
. /usr/local/bin/oraenv
export PATH=$PATH:$ORACLE_HOME/bin
case $OPTION in
        stop_dg)
                echo "Stoping  the Dataguard ...."
                echo "edit database \"$SBY\" set state='APPLY-OFF';" > $OPTION_SQL
                echo "edit database \"$PRIM\" set state='TRANSPORT-OFF';" >> $OPTION_SQL
                echo "show database \"$SBY\" ;" >> $OPTION_SQL
                echo "show database \"$PRIM\" ;" >> $OPTION_SQL
                echo " Executing following command "
                cat $OPTION_SQL
                $ORACLE_HOME/bin/dgmgrl / @$OPTION_SQL
                ;;
        start_dg)
                echo "Starting the Dataguard ...."
                echo "edit database \"$SBY\" set state='APPLY-ON';" > $OPTION_SQL
                echo "edit database \"$PRIM\" set state='TRANSPORT-ON';" >> $OPTION_SQL
                echo "show database \"$SBY\" ;" >> $OPTION_SQL
                echo "show database \"$PRIM\" ;" >> $OPTION_SQL
                echo " Executing following command "
                cat $OPTION_SQL
                $ORACLE_HOME/bin/dgmgrl / @$OPTION_SQL
                ;;
        status_listener)
                echo "Check Listener Status ..."
                $ORACLE_HOME/bin/lsnrctl status LISTENER
                ;;
        start_listener)
                $ORACLE_HOME/bin/lsnrctl start LISTENER 
                ls_rc=$?
                if [ $ls_rc -eq 0 ] 
                then 
                echo "Successfully started  Listener " 
                elif   [ $ls_rc -eq 1 ] 
                then 
                count=$($ORACLE_HOME/bin/lsnrctl start listener |grep 'TNS-01106'  |wc -l)
                        if [ $count -eq 1 ] 
                        then 
                        echo "Listener already started"
                        else 
                        echo "Listener failed to start "
                        fi 
                else
                echo "No Condition "
                fi
                ;;
        stop_listener)
                echo " Stop Listener"
                $ORACLE_HOME/bin/lsnrctl stop LISTENER
                ;;
        start_DB)
                $ORACLE_HOME/bin/sqlplus -s /nolog <<==EOF > /tmp/db_startup.log
                connect / as sysdba
                startup;
                exit;
==EOF
                cat /tmp/db_startup.log
                ;;
        stop_DB)
                echo " Stop the Database"
                $ORACLE_HOME/bin/sqlplus -s /nolog <<==EOF > /tmp/db_shutdown.log
                connect / as sysdba
                shutdown immediate;
                exit
==EOF
                cat /tmp/db_shutdown.log
                ;;
        create_blackout)
                echo "Creating blackout for the target "
                emctl status agent
                ;;
        
        *)
                echo "Invalid Option "
                echo "Usage: $0 ORACLE_SID OPTION"
                echo "  stop_dg  : Stop the dataguard "
                echo "  start_dg  : Start the dataguard ."

                ;;
esac


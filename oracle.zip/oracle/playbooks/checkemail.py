#!/usr/bin/python3    
import smtplib
import os   
import getpass
username = getpass.getuser() 
host_name = os.uname()[1] 
sender = username+'@'+host_name
sender_mail = sender    
receivers_mail = ['q1435246@southi.net']    
message = """
Subject: Sending SMTP e-mail   from %s
This is a test e-mail message.  
"""%(host_name)    
if 'az' in host_name:
   smtp_host='smtpcustomerouta.south.edu'
else: 
   smtp_host='localhost'
try:    
   smtpObj = smtplib.SMTP(smtp_host,25)    
   smtpObj.sendmail(sender_mail, receivers_mail, message)    
   print("Successfully sent email")    
except Exception:    
   print("Error: Host %s unable to send email" %(host_name))   

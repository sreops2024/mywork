#!/bin/bash
export ORACLE_HOME=/u01/app/oracle/product/19.0.0.0/dbhome_1
echo "  Output of  srvctl stop service -db SEB81POTST -service seb81qa .. "
echo ".."
echo ".."
$ORACLE_HOME/bin/srvctl stop service -db SEB81POTST -service seb81qa 
#Enable  Service in QA 
echo "  Output of  srvctl srvctl enable service -db seb81qast -service seb81qa  .. "
echo ".."
echo ".."
$ORACLE_HOME/bin/srvctl enable service -db seb81qast -service seb81qa 
## Start the service in QA
echo " Output of  srvctl start service -db seb81qast -service seb81qa  .. "
echo ".."
echo ".."
$ORACLE_HOME/bin/srvctl start service -db seb81qast -service seb81qa 
##Print the service of SEB81POTST
echo "Showing status of QA and POC  .. "
echo ".."
echo ".."
$ORACLE_HOME/bin/srvctl status service -db SEB81POTST -service seb81qa 
$ORACLE_HOME/bin/srvctl status service -db seb81qast -service seb81qa 
## Open QA database in read only mode 
echo "  Make QA database Open mode     "
echo ".."
echo ".."
$ORACLE_HOME/bin/srvctl stop database  -db seb81qast 
$ORACLE_HOME/bin/srvctl start database  -db seb81qast -startoption OPEN
exit

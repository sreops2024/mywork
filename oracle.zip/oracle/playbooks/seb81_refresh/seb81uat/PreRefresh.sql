set role all;
@GenerateUsersScript.sql
@GenerateSynonymsScript.sql
@GenerateDirectoriesScript.sql
@GenerateEnableSchedJobs.sql
@GenerateDisableSchedJobs.sql

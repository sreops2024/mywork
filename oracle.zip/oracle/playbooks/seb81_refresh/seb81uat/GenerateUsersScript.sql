set linesize 200
set pagesize 9999
set heading off
set echo off
set feedback off
set time off
set timi off
spool RunCreateUsers.sql

-- Create user...
select 'create user '||name||' identified by values '''||U.password||''''||
' default tablespace '||D.default_tablespace||
' temporary tablespace '||D.temporary_tablespace||' profile default_xx;'
from sys.USER$ U, SYS.DBA_USERS D
where NAME = USERNAME
ORDER BY NAME;

select 'alter user '||name||' identified by values '''||U.password||''''||
' default tablespace '||D.default_tablespace||
' temporary tablespace '||D.temporary_tablespace||' profile default_xx;'
from sys.USER$ U, SYS.DBA_USERS D
where NAME = USERNAME
ORDER BY NAME;

select 'alter user '||name||' profile '||D.profile||';'
from sys.USER$ U, SYS.DBA_USERS D
where NAME = USERNAME
ORDER BY NAME;

-- Grant Roles...
select 'grant '||granted_role||' to '||GRANTEE||';'
from sys.dba_role_privs
where GRANTEE IN (SELECT GRANTEE from dba_role_privs)
ORDER BY GRANTEE;

-- Grant System Privs...
select 'grant '||privilege||' to '||S.GRANTEE||''||
decode(S.ADMIN_OPTION, 'YES', ' WITH ADMIN OPTION')||';'
from sys.dba_sys_privs s, DBA_ROLE_PRIVS R
where S.GRANTEE = R.GRANTEE;

-- Grant Table Privs...
select 'grant '||privilege||' on '||owner||'.'||table_name||' to '||T.GRANTEE||';'
from sys.dba_tab_privs T, DBA_ROLE_PRIVS R
where T.GRANTEE = R.GRANTEE;

-- Grant Column Privs...
select 'grant '||privilege||' on '||owner||'.'||table_name||
'('||column_name||') to '||GRANTEE||';'
from sys.dba_col_privs;

-- Tablespace Quotas...
select 'alter user '||username||' quota '||
decode(max_bytes, -1, 'UNLIMITED', max_bytes)||
' on '||tablespace_name||';'
from sys.dba_ts_quotas;

-- Set Default Role...
select 'alter user '||grantee||' default role '||listagg(granted_role,',') within group (order by granted_role) ||';' from (select grantee, granted_role, row_number() over (partition by grantee, granted_role order by grantee) as rn from dba_role_privs where default_role='YES' order by grantee, granted_role) where rn = 1 group by grantee;

spool off;

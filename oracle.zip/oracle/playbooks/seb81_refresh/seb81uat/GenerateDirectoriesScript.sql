set pagesize 99
set linesize 150
set echo off
set feedback off
set heading off
set timi off
set time off
set role all;

spool RunCreateDirectories.sql

select 'create or replace directory '||directory_name||' as '''||directory_path||''';'
from dba_directories;

select 'grant '||privilege||' on directory '||table_name||' to '||grantee||case when grantable = 'YES' then ' with grant option' else null end||';'
 from sys.dba_tab_privs,
      dba_directories
 where table_name = directory_name;

spool off


set role all;
set head off
set time off
set timi off

col log_user format a12
set pagesize 999

spool DisableDbaSchedJobs.sql

prompt spool DisableDbaSchedJobs.lst

SELECT 'BEGIN '||CHR(10)||
'SYS.DBMS_SCHEDULER.DISABLE '||CHR(10)||
'(NAME => '''||OWNER||'.'||JOB_NAME||''');'||CHR(10)||
'END;'||CHR(10)||
'/'||CHR(10)||
' '
FROM DBA_SCHEDULER_JOBS;

prompt spool off;

spool off

set head on
set time on
set timi on

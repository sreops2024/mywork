#!/bin/sh
export ORACLE_SID=seb81uat1
export ORACLE_HOME=/u01/app/oracle/product/12.2.0/dbhome_1
export PWD=/u03/hqacfs/scripts/seb8_refresh/seb81uat
export DATE=$(date +"%m-%d-%Y") 
export DATE1=$(date +"%m%d%Y") 
export TMSTMP=$(date +%Y-%m-%d_%H-%M-%S)
export ORACLE_DIR_NAME=UAT_${DATE1}
export ORACLE_PATH=/u03/hqacfs/scripts/seb8_refresh/seb81uat/${ORACLE_DIR_NAME}
export LOGFILE=$PWD/uat_refresh_${TMSTMP}.log
echo "########Create UAT direcotry for DataPump Files############ " >> ${LOGFILE}
mkdir -p $ORACLE_PATH
sqlplus -s /nolog <<EOF>> ${LOGFILE}
WHENEVER OSERROR EXIT 9;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
connect / as sysdba
create or replace directory $ORACLE_DIR_NAME as '$ORACLE_PATH';
EOF
sql_return_code=$?
if [ $sql_return_code != 0 ]
then
echo "Directory creation failed "
echo "Error code $sql_return_code"
exit 0;
fi

echo " ########Check Direcotry is Empty and Load files from $PWD ############# " >> ${LOGFILE}
if [ "$(ls -A $ORACLE_PATH)" ]; then
     rm -r $ORACLE_PATH/* $ORACLE_PATH
	 mv $PWD/exp_refresh_tables1.par $ORACLE_PATH/
	 echo "DIRECTORY=$ORACLE_DIR_NAME " >> $ORACLE_PATH/exp_refresh_tables1.par
	 echo "DUMPFILE=REFRESH_TABLES_${DATE}.dmp " >> $ORACLE_PATH/exp_refresh_tables1.par
	 echo "LOGFILE=REFRESH_TABLES_${DATE}.log " >> $ORACLE_PATH/exp_refresh_tables1.par
else
    mv $PWD/exp_refresh_tables1.par  $ORACLE_PATH/
	echo "DIRECTORY=$ORACLE_DIR_NAME " >> $ORACLE_PATH/exp_refresh_tables1.par
	echo "DUMPFILE=REFRESH_TABLES_${DATE}.dmp " >> $ORACLE_PATH/exp_refresh_tables1.par
	echo "LOGFILE=REFRESH_TABLES_${DATE}.log " >> $ORACLE_PATH/exp_refresh_tables1.par
fi

echo "#########Export DB Links and tables requested by Dev Team######### " >> ${LOGFILE}
echo "Starting export of DB links "
expdp include=DB_LINK full=y dumpfile=$ORACLE_DIR_NAME:exp_dblink_seb81uat_${DATE}.dmp logfile=$ORACLE_DIR_NAME:exp_dblink_seb81uat_${DATE}.log userid =\"/ as sysdba\"
echo "Starting Export of Tables "
expdp parfile=$ORACLE_PATH/exp_refresh_tables1.par userid =\"/ as sysdba\"

###### Validate Export ###########
impdp dumpfile=$ORACLE_DIR_NAME:exp_dblink_seb81uat_${DATE}.dmp sqlfile=Validate_exp_dblink_seb81uat_${DATE}.sql userid =\"/ as sysdba\"

impdp dumpfile=$ORACLE_DIR_NAME:REFRESH_TABLES_${DATE}.dmp sqlfile=$$ORACLE_DIR_NAME:Validate_tables_seb81uat_${DATE}.sql userid =\"/ as sysdba\"


echo "#######Run Precheck Scripts #################" >> ${LOGFILE}
sqlplus -s /nolog <<EOF>> ${LOGFILE}
WHENEVER OSERROR EXIT 9;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
connect / as sysdba
@$PWD/PreRefresh.sql
EOF
sql_return_code=$?
if [ $sql_return_code != 0 ]
then
echo "PreRefresh Script  failed "
echo "Error code $sql_return_code"
exit 0;
fi

echo "######Create Pfile Backup ################ " >> ${LOGFILE}
 
sqlplus -s /nolog <<EOF>> ${LOGFILE}
WHENEVER OSERROR EXIT 9;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
connect / as sysdba
create pfile='$PWD/pfile_${ORACLE_SID}_{TMSTMP}.ora' from spfile;
EOF
sql_return_code=$?
if [ $sql_return_code != 0 ]
then
echo "Pfile pfile_${ORACLE_SID}_{TMSTMP}.ora  creation failed "
echo "Error code $sql_return_code"
exit 0;
fi


echo "###### Backup Spfile ########## " >> ${LOGFILE}
 
sqlplus -s /nolog <<EOF>> ${LOGFILE}
WHENEVER OSERROR EXIT 9;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
connect / as sysdba
create pfile='$PWD/pfile_${ORACLE_SID}_{TMSTMP}.ora' from spfile;
EOF
sql_return_code=$?
if [ $sql_return_code != 0 ]
then
echo "Script failed "
echo "Error code $sql_return_code"
exit 0;
fi

echo "###### Disable Cluster Database ##########" >> ${LOGFILE}
sqlplus -s /nolog <<EOF>> ${LOGFILE}
WHENEVER OSERROR EXIT 9;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
connect / as sysdba
alter system set cluster_database=FALSE scope=spfile sid='*';
EOF
sql_return_code=$?
if [ $sql_return_code != 0 ]
then
echo "Script failed "
echo "Error code $sql_return_code"
exit 0;
fi

echo " Checking database status "  >> ${LOGFILE}
srvctl status database -d seb81uatsp -v >> ${LOGFILE}

echo "Precheck complete "

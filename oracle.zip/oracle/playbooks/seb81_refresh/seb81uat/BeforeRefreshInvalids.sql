set lines 200 pages 200 
col owner format a30
col object_name format a40
col object_type format a20
col status format a10
spool $PWD/BeforeRefreshInvalids_${TMSTMP}.log
select owner,object_name,object_type,status from dba_objects where status='INVALID';
spool off


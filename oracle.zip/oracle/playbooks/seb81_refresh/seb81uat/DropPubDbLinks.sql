-- drop all public database links

spool DropPubDbLinks.lst

set serveroutput on

BEGIN
  FOR i in (SELECT object_name 
              FROM dba_objects
             WHERE owner IN ('PUBLIC')
               AND object_type='DATABASE LINK')
  LOOP
    EXECUTE IMMEDIATE 'DROP PUBLIC DATABASE LINK '||i.object_name;
  END loop;
END;
/

spool off;

set pagesize 9999
set linesize 130
col owner format a12
col s.owner format a12
col table_owner format a12
col s.table_owner format a12
col db_link format a15
col s.db_link format a15
set heading off
set feedback off
set echo off
set time off
set timi off

spool list_of_existing_synonyms.txt

prompt -- existing synonyms in &&NonProdDB
Select '--'||s.owner, s.synonym_name, s.table_name, s.table_owner, s.db_link
from   sys.DBA_SYNONYMS s
where  s.db_link is not null;

spool off

spool create_private_synonyms.sql

prompt -- create private synonyms for dblinks (from &&NonProdDB)
select 'create or replace synonym '||owner||'.'||synonym_name||' for '||table_owner||'.'||table_name||'@'||db_link||';'
from dba_synonyms 
where db_link is not null
and owner <> 'PUBLIC';

spool off

spool create_public_synonyms.sql

prompt -- create public synonyms for dblinks (from &&NonProdDB)
select 'create or replace public synonym '||synonym_name||' for '||table_owner||'.'||table_name||'@'||db_link||';'
from dba_synonyms 
where db_link is not null
and owner = 'PUBLIC';

spool off

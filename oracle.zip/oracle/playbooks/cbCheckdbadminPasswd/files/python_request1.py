#!/usr/bin/python3
import socket
import requests
from bbc_fileSec.encServer import getPassword
vHost=socket.getfqdn()
vPass=getPassword('dbadmin')
vAdminuser='dbadmin'
pAdminCreds=(vAdminuser,vPass)
vURL = 'http://' + vHost + ':8091/pools/default/rebalanceProgress'
r = requests.get( vURL, auth=(pAdminCreds) )
print(r.status_code)
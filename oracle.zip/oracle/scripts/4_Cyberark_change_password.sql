CREATE OR REPLACE procedure SYS.changepwd(passwd in varchar2)
as
begin
execute immediate 'alter user sys identified by '||passwd;
end;
/
CREATE OR REPLACE PROCEDURE SYS.SP_PURGE_AUDIT_TRAILS (
  daysback IN NUMBER DEFAULT 7)
AS
--*********************************************************************
--	Andrew Brittain
--	Date: 02/20/2017
--	Notes: Run as SYS, this is RAC Version 12c
-- 		We are not using FGA so will comment out
--  Brittaina 11/15/2018 Updated to reflect 365 retention for non OS auditing
--*********************************************************************
  curdate date;
  last_archtime date;
  last_std_archtime date;

BEGIN

  curdate := SYSTIMESTAMP;
  last_archtime := curdate -daysback;
  last_std_archtime := systimestamp -400;

  -- set last archive timestamp for AUD$
  SYS.DBMS_AUDIT_MGMT.set_last_archive_timestamp (audit_trail_type => SYS.DBMS_AUDIT_MGMT.AUDIT_TRAIL_AUD_STD,
   last_archive_time => last_std_archtime);

  -- set the last archive timestamp for a single instance audit trail UNIFIED, or for node 1 in a RAC cluster
  SYS.DBMS_AUDIT_MGMT.SET_LAST_ARCHIVE_TIMESTAMP(audit_trail_type  => SYS.DBMS_AUDIT_MGMT.AUDIT_TRAIL_UNIFIED,
   last_archive_time => last_std_archtime,rac_instance_number => 1);

  -- set the last archive timestamp for a single instance audit trail UNIFIED, or for node 1 in a RAC cluster
  SYS.DBMS_AUDIT_MGMT.SET_LAST_ARCHIVE_TIMESTAMP(audit_trail_type  => SYS.DBMS_AUDIT_MGMT.AUDIT_TRAIL_UNIFIED,
   last_archive_time => last_std_archtime,rac_instance_number => 2);

  -- set the last archive timestamp for a single instance OS audit trail, or for node 1 in a RAC cluster
  SYS.DBMS_AUDIT_MGMT.SET_LAST_ARCHIVE_TIMESTAMP(audit_trail_type  => SYS.DBMS_AUDIT_MGMT.AUDIT_TRAIL_OS,
   last_archive_time => last_archtime,rac_instance_number => 1);

  -- set the last archive timestamp for the second node's OS audit trail
  SYS.DBMS_AUDIT_MGMT.SET_LAST_ARCHIVE_TIMESTAMP(audit_trail_type  => SYS.DBMS_AUDIT_MGMT.AUDIT_TRAIL_OS,
   last_archive_time => last_archtime,rac_instance_number => 2);

  -- set the last archive timestamp for a single instance XML audit trail, or for node 1 in a RAC cluster
  SYS.DBMS_AUDIT_MGMT.SET_LAST_ARCHIVE_TIMESTAMP(audit_trail_type  => SYS.DBMS_AUDIT_MGMT.AUDIT_TRAIL_XML,
   last_archive_time => last_archtime,rac_instance_number => 1);

  -- set the last archive timestamp for the second node's XML audit trail
  SYS.DBMS_AUDIT_MGMT.SET_LAST_ARCHIVE_TIMESTAMP(audit_trail_type  => SYS.DBMS_AUDIT_MGMT.AUDIT_TRAIL_XML,
   last_archive_time => last_archtime,rac_instance_number => 2);

  -- write activity to alert log -------------------------------------------------------------------
  SYS.dbms_system.ksdwrt(2,'AUDIT: Purging Audit Trail until ' || last_archtime ||' / '|| last_std_archtime || ' beginning');

  -- Purge AUD$ until last time stamp
  SYS.DBMS_AUDIT_MGMT.CLEAN_AUDIT_TRAIL (audit_trail_type => SYS.DBMS_AUDIT_MGMT.AUDIT_TRAIL_AUD_STD,
   use_last_arch_timestamp => TRUE);

    -- Purge Audit_Trail_Unified
  SYS.DBMS_AUDIT_MGMT.CLEAN_AUDIT_TRAIL (audit_trail_type => SYS.DBMS_AUDIT_MGMT.AUDIT_TRAIL_UNIFIED,
    USE_LAST_ARCH_TIMESTAMP => TRUE);

  -- Purge OS audit trail until last time stamp
  SYS.DBMS_AUDIT_MGMT.CLEAN_AUDIT_TRAIL (audit_trail_type => SYS.DBMS_AUDIT_MGMT.AUDIT_TRAIL_OS,
   use_last_arch_timestamp => TRUE);

  -- Purge XML audit trail until last time stamp
  SYS.DBMS_AUDIT_MGMT.CLEAN_AUDIT_TRAIL (audit_trail_type => SYS.DBMS_AUDIT_MGMT.AUDIT_TRAIL_XML,
   use_last_arch_timestamp => TRUE);

  -- write activity to alert log -------------------------------------------------------------------
  SYS.dbms_system.ksdwrt(2,'AUDIT: Purging Audit Trail until ' || last_archtime ||' / '|| last_std_archtime || ' completed');
END;
/
